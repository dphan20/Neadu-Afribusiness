<?php

use Illuminate\Support\Facades\Route;

// Controller (not a closure) so `php artisan route:cache` works.
Route::get('/user', [\App\Http\Controllers\Api\CurrentUserController::class, '__invoke'])->middleware('auth:sanctum');

// Phase 4: signed, idempotent payment callbacks. Fails closed (503) until NEAS_PAYMENT_WEBHOOK_SECRET is set.
Route::post('/webhooks/payments/{provider}', \App\Http\Controllers\Api\PaymentWebhookController::class)
    ->where('provider', '[a-z0-9_-]{2,32}')->middleware('throttle:300,1')->name('api.webhooks.payments');

// FE-32 (R2): USSD and SMS callbacks from the aggregator. Guarded by the `ussd` feature flag and a shared secret.
Route::middleware(['feature:ussd', 'throttle:120,1'])->group(function (): void {
    Route::post('/ussd', \App\Http\Controllers\Api\UssdController::class)->name('api.ussd');
    Route::post('/sms', \App\Http\Controllers\Api\SmsController::class)->name('api.sms');
});
