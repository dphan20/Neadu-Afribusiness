<?php

use App\Http\Controllers\Landowner\LandController as OwnerLand;
use App\Http\Controllers\Shared\LandController as Land;
use App\Http\Controllers\Warehouse\WarehouseController;
use Illuminate\Support\Facades\Route;

/* S-25 / S-26: land search and detail with enquiries, for every signed-in role. */
Route::prefix('land')->name('land.')->middleware(['auth', 'active'])->group(function (): void {
    Route::get('/', [Land::class, 'index'])->name('index');
    Route::get('/enquiries', [Land::class, 'mine'])->name('enquiries');
    Route::get('/{listing}', [Land::class, 'show'])->name('show');
    Route::post('/{listing}/enquire', [Land::class, 'enquire'])->middleware('throttle:10,1')->name('enquire');
});

/* Role 6 - Land owner (L): S-27 manage land, S-26 enquiries, lease drafts (R3) */
Route::prefix('landowner')->name('landowner.')->middleware(['auth', 'active', 'role:L'])->group(function (): void {
    Route::get('/', [OwnerLand::class, 'listings'])->name('listings');
    Route::get('/land/new', [OwnerLand::class, 'form'])->name('land.create');
    Route::post('/land', [OwnerLand::class, 'save'])->name('land.store');
    Route::get('/land/{listing}/edit', [OwnerLand::class, 'form'])->name('land.edit');
    Route::put('/land/{listing}', [OwnerLand::class, 'save'])->name('land.update');
    Route::post('/land/{listing}/close', [OwnerLand::class, 'close'])->name('land.close');
    Route::get('/enquiries', [OwnerLand::class, 'enquiries'])->name('enquiries');
    Route::post('/enquiries/{enquiry}/reply', [OwnerLand::class, 'reply'])->middleware('throttle:30,1')->name('enquiries.reply');
    Route::get('/enquiries/{enquiry}/lease', [OwnerLand::class, 'lease'])->middleware('feature:contracts')->name('enquiries.lease');
});

/* Role 7 - Warehouse owner (W): S-24 facilities, bookings, receipts */
Route::prefix('warehouse')->name('warehouse.')->middleware(['auth', 'active', 'role:W'])->group(function (): void {
    Route::get('/', [WarehouseController::class, 'facilities'])->name('facilities');
    Route::get('/facilities/new', [WarehouseController::class, 'form'])->name('facilities.create');
    Route::post('/facilities', [WarehouseController::class, 'save'])->name('facilities.store');
    Route::get('/facilities/{listing}/edit', [WarehouseController::class, 'form'])->name('facilities.edit');
    Route::put('/facilities/{listing}', [WarehouseController::class, 'save'])->name('facilities.update');
    Route::post('/facilities/{listing}/{to}', [WarehouseController::class, 'setStatus'])->whereIn('to', ['pause', 'resume', 'close'])->name('facilities.status');
    Route::get('/bookings', [WarehouseController::class, 'bookings'])->name('bookings');
    Route::post('/bookings/{booking}/accept', [WarehouseController::class, 'accept'])->name('bookings.accept');
    Route::post('/bookings/{booking}/decline', [WarehouseController::class, 'decline'])->name('bookings.decline');
    Route::post('/bookings/{booking}/receipt', [WarehouseController::class, 'receipt'])->middleware('feature:storage_receipt')->name('bookings.receipt');
    Route::post('/bookings/{booking}/invoice-paid', [WarehouseController::class, 'invoicePaid'])->name('bookings.invoice');
});

