<?php

use App\Http\Controllers\Admin\AdminAccessController;
use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\AuditController;
use App\Http\Controllers\Admin\DisputeController;
use App\Http\Controllers\Admin\FinanceController;
use App\Http\Controllers\Admin\MessageController;
use App\Http\Controllers\Admin\ReferenceController;
use App\Http\Controllers\Admin\ReviewController;
use App\Http\Controllers\Admin\VehicleVerificationController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ChatMessageController;
use Illuminate\Support\Facades\Route;

/*
 | NeAS console. Its own sign-in (admin guard), no public registration, no role switcher.
 | Every route below the sign-in sits behind `admin` (guard + active + Admin role + idle timeout);
 | `area:` then enforces the admin's scope (ADM-08 least privilege).
 */
Route::prefix('admin')->name('admin.')->group(function (): void {
    Route::get('/login', [AdminAuthController::class, 'form'])->name('login');
    Route::post('/login', [AdminAuthController::class, 'login'])->middleware('throttle:5,1')->name('login.store');

    Route::middleware('admin')->group(function (): void {
        Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');

        // COM-01: staff inbox. Write to any user, answer support messages.
        Route::get('/messages', [MessageController::class, 'index'])->name('messages');
        Route::get('/messages/new', [MessageController::class, 'compose'])->name('messages.new');
        Route::post('/messages/new', [MessageController::class, 'start'])->middleware('throttle:30,1')->name('messages.start');
        Route::get('/messages/files/{message}', [MessageController::class, 'file'])->name('messages.file');
        Route::get('/messages/{conversation}', [MessageController::class, 'show'])->name('messages.show');
        Route::post('/messages/{conversation}', [MessageController::class, 'send'])->middleware('throttle:60,1')->name('messages.send');
        Route::get('/messages/message/{message}/forward', [ChatMessageController::class, 'forwardForm'])->name('messages.forward');
        Route::post('/messages/message/{message}/forward', [ChatMessageController::class, 'forward'])->middleware('throttle:20,1')->name('messages.forward.store');
        Route::delete('/messages/message/{message}', [ChatMessageController::class, 'destroy'])->middleware('throttle:60,1')->name('messages.message.destroy');
        Route::delete('/messages/{conversation}', [ChatMessageController::class, 'clear'])->name('messages.clear');

        Route::get('/', [AdminController::class, 'index'])->middleware('area:reports')->name('dashboard');                      // ADM-06
        Route::get('/reports', [AdminController::class, 'section'])->defaults('section', 'reports')->middleware('area:reports')->name('section');

        // ADM-02 users: view, suspend with reason. Roles are super-admin only.
        Route::get('/users', [AdminController::class, 'users'])->middleware('area:users')->name('users');
        Route::patch('/users/{user}/status', [AdminController::class, 'updateStatus'])->middleware('area:users')->name('users.status');
        Route::post('/users/{user}/roles', [AdminController::class, 'assignRole'])->middleware('area:reference')->name('users.roles.assign');
        Route::delete('/users/{user}/roles/{assignment}', [AdminController::class, 'removeRole'])->middleware('area:reference')->name('users.roles.remove');

        // ADM-01, LOG-01, LND-03: verification
        Route::middleware('area:verification')->group(function (): void {
            Route::get('/review/documents', [ReviewController::class, 'documents'])->name('review.documents');
            Route::get('/review/documents/{document}/file', [ReviewController::class, 'file'])->name('review.file');
            Route::post('/review/documents/{document}', [ReviewController::class, 'decideDocument'])->name('review.documents.decide');
            Route::get('/vehicles', [VehicleVerificationController::class, 'index'])->name('vehicles');
            Route::post('/vehicles/{vehicle}/decision', [VehicleVerificationController::class, 'decide'])->name('vehicles.decide');
        });

        // ADM-02 listing moderation
        Route::middleware('area:listings')->group(function (): void {
            Route::get('/review/listings', [ReviewController::class, 'listings'])->name('review.listings');
            Route::post('/review/listings/{listing}', [ReviewController::class, 'decideListing'])->name('review.listings.decide');
            Route::post('/review/listings/{listing}/remove', [ReviewController::class, 'removeListing'])->name('review.listings.remove');
        });

        // ADM-03 disputes
        Route::middleware('area:disputes')->group(function (): void {
            Route::get('/disputes', [DisputeController::class, 'index'])->name('disputes');
            Route::get('/disputes/{dispute}', [DisputeController::class, 'show'])->name('disputes.show');
            Route::post('/disputes/{dispute}/decision', [DisputeController::class, 'decide'])->name('disputes.decide');
            Route::get('/disputes/{dispute}/evidence/{index}', [DisputeController::class, 'file'])->whereNumber('index')->name('disputes.file');
        });

        // ADM-04 finance
        Route::middleware('area:finance')->group(function (): void {
            Route::get('/finance', [FinanceController::class, 'index'])->name('finance');
            Route::post('/finance/payouts/{payout}', [FinanceController::class, 'decidePayout'])->name('finance.payouts');
            Route::post('/finance/refunds/{approval}', [FinanceController::class, 'decideRefund'])->name('finance.refunds');
            Route::get('/reconcile', [FinanceController::class, 'reconcileForm'])->name('reconcile');
            Route::post('/reconcile', [FinanceController::class, 'reconcile'])->middleware('throttle:20,1')->name('reconcile.run');
        });

        // ADM-05 reference data, ADM-08 admin scopes, ADM-07 audit: super admin only
        Route::middleware('area:reference')->group(function (): void {
            Route::get('/reference/{entity?}', [ReferenceController::class, 'index'])->name('reference');
            Route::post('/reference/{entity}', [ReferenceController::class, 'store'])->name('reference.store');
            Route::put('/reference/{entity}/{id}', [ReferenceController::class, 'update'])->whereNumber('id')->name('reference.update');
            Route::delete('/reference/{entity}/{id}', [ReferenceController::class, 'destroy'])->whereNumber('id')->name('reference.destroy');
            Route::post('/flags/{flag}/toggle', [ReferenceController::class, 'toggleFlag'])->name('flags.toggle');
            Route::get('/admins', [AdminAccessController::class, 'index'])->name('admins');
            Route::put('/admins/{user}', [AdminAccessController::class, 'update'])->name('admins.update');
            Route::get('/audit', [AuditController::class, 'index'])->name('audit');
        });
    });
});
