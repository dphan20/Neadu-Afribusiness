<?php

use App\Http\Controllers\Shared\MachineryController;
use App\Http\Controllers\Trader\TraderController;
use Illuminate\Support\Facades\Route;

/* Machinery market: every signed-in role can browse and ask for a quote, financing or rental (MCH-01..04). An admin can switch it off with the `machinery` flag. */
Route::prefix('machinery')->name('machinery.')->middleware(['auth', 'active', 'feature:machinery'])->group(function (): void {
    Route::get('/', [MachineryController::class, 'index'])->name('index');
    Route::get('/requests', [MachineryController::class, 'mine'])->name('requests');
    Route::post('/requests/{quote}/withdraw', [MachineryController::class, 'withdraw'])->middleware('throttle:20,1')->name('requests.withdraw');
    Route::get('/quotes/{quote}/document', [MachineryController::class, 'document'])->name('quotes.document');
    Route::get('/{listing}', [MachineryController::class, 'show'])->name('show');
    Route::get('/{listing}/sheet', [MachineryController::class, 'sheet'])->name('sheet');
    Route::post('/{listing}/request', [MachineryController::class, 'request'])->middleware('throttle:10,1')->name('request');
});

/* Role 8 - Trader / technology provider (R): manage machinery, answer requests, business profile */
Route::prefix('trader')->name('trader.')->middleware(['auth', 'active', 'role:R'])->group(function (): void {
    Route::get('/', [TraderController::class, 'home'])->name('home');

    Route::get('/machines', [TraderController::class, 'machines'])->name('machines');
    Route::get('/machines/export', [TraderController::class, 'export'])->name('machines.export');
    Route::get('/machines/new', [TraderController::class, 'form'])->name('machines.create');
    Route::post('/machines', [TraderController::class, 'save'])->middleware('throttle:30,1')->name('machines.store');
    Route::get('/machines/{listing}/edit', [TraderController::class, 'form'])->name('machines.edit');
    Route::put('/machines/{listing}', [TraderController::class, 'save'])->middleware('throttle:30,1')->name('machines.update');
    Route::post('/machines/{listing}/duplicate', [TraderController::class, 'duplicate'])->middleware('throttle:20,1')->name('machines.duplicate');
    Route::post('/machines/{listing}/{to}', [TraderController::class, 'setStatus'])->whereIn('to', ['pause', 'resume', 'close', 'soldout', 'reopen'])->name('machines.status');
    Route::delete('/machines/{listing}', [TraderController::class, 'destroy'])->name('machines.destroy');

    Route::get('/quotes', [TraderController::class, 'quotes'])->name('quotes');
    Route::get('/quotes/export', [TraderController::class, 'quotesExport'])->name('quotes.export');
    Route::post('/quotes/{quote}/reply', [TraderController::class, 'reply'])->middleware('throttle:60,1')->name('quotes.reply');
    Route::post('/quotes/{quote}/decline', [TraderController::class, 'decline'])->middleware('throttle:60,1')->name('quotes.decline');

    Route::get('/profile', [TraderController::class, 'profile'])->name('profile');
    Route::put('/profile', [TraderController::class, 'updateProfile'])->name('profile.update');
});
