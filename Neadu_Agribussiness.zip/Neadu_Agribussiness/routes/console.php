<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Illuminate\Support\Facades\Schedule::command('neas:auto-release')->everyFifteenMinutes();
Illuminate\Support\Facades\Schedule::command('neas:check-price-alerts')->hourly();
Illuminate\Support\Facades\Schedule::command('storage:settle')->dailyAt('01:00');
Illuminate\Support\Facades\Schedule::command('storage:expiry-alerts')->dailyAt('07:00');
Illuminate\Support\Facades\Schedule::command('orders:expire-unanswered')->everyFifteenMinutes();
Illuminate\Support\Facades\Schedule::command('neas:reconcile-payments')->everyFiveMinutes()->withoutOverlapping(); // Phase 4: callbacks that never came
Illuminate\Support\Facades\Schedule::job(new \App\Jobs\CheckWeatherAlerts)->hourly(); // WTH-02 / TECH-07
