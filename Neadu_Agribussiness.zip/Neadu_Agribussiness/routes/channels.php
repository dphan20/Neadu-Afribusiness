<?php

use App\Broadcasting\DeliveryChannel;
use Illuminate\Support\Facades\Broadcast;

Broadcast::channel('delivery.{uuid}', DeliveryChannel::class);
