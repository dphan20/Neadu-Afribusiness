<?php

use App\Http\Controllers\Transporter\JobController;
use App\Http\Controllers\Transporter\TripController;
use App\Http\Controllers\Transporter\VehicleController;
use App\Http\Controllers\Transporter\WorkspaceController;
use Illuminate\Support\Facades\Route;

// Role 5 - Transporter workspace (LOG-01 .. LOG-09, S-19, S-20, S-21, S-45)
Route::prefix('transporter')->name('transporter.')->middleware(['auth', 'active', 'role:T'])->group(function (): void {
    Route::get('/', [WorkspaceController::class, 'home'])->name('home');
    Route::get('/identity', [WorkspaceController::class, 'identity'])->name('identity');
    Route::post('/identity', [WorkspaceController::class, 'verifyIdentity'])->middleware('throttle:10,1')->name('identity.verify');
    Route::get('/profile', [WorkspaceController::class, 'profile'])->name('profile');
    Route::put('/profile', [WorkspaceController::class, 'updateProfile'])->name('profile.update');
    Route::get('/earnings', [WorkspaceController::class, 'earnings'])->name('earnings');                       // S-45

    Route::get('/vehicles', [VehicleController::class, 'index'])->name('vehicles');                           // S-21
    Route::post('/vehicles', [VehicleController::class, 'store'])->name('vehicles.store');
    Route::put('/vehicles/{vehicle}', [VehicleController::class, 'update'])->name('vehicles.update');
    Route::delete('/vehicles/{vehicle}', [VehicleController::class, 'destroy'])->name('vehicles.destroy');

    Route::get('/jobs', [JobController::class, 'index'])->name('jobs');                                       // S-19
    Route::post('/jobs/{delivery}/accept', [JobController::class, 'accept'])->name('jobs.accept');
    Route::post('/jobs/{delivery}/release', [JobController::class, 'release'])->name('jobs.release');

    Route::get('/trips', [TripController::class, 'index'])->name('trips');
    Route::get('/trips/{delivery}', [TripController::class, 'show'])->name('trips.show');                     // S-20
    Route::post('/trips/{delivery}/advance', [TripController::class, 'advance'])->name('trips.advance');
    Route::post('/trips/{delivery}/code', [TripController::class, 'confirmCode'])->middleware('throttle:20,1')->name('trips.code');
    Route::post('/trips/{delivery}/proof', [TripController::class, 'confirmProof'])->middleware('throttle:10,1')->name('trips.proof');
    Route::post('/trips/{delivery}/sync', [TripController::class, 'sync'])->middleware('throttle:120,1')->name('trips.sync');
});

