<?php

declare(strict_types=1);

/**
 * Details shown on the Privacy Policy, Terms of Use and Cookie pages.
 * Set the LEGAL_* values in .env; bump "version" whenever the wording changes in a way users must re-accept.
 */
return [
    'entity' => env('LEGAL_ENTITY', 'Neadu Agribusiness System (NeAS)'),
    'email' => env('LEGAL_EMAIL', ''),
    'phone' => env('LEGAL_PHONE', ''),
    'address' => env('LEGAL_ADDRESS', 'Tanzania'),
    'version' => '2026-11-01',
    'effective_en' => '1 November 2026',
    'effective_sw' => '1 Novemba 2026',
];
