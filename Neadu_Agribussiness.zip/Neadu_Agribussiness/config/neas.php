<?php

declare(strict_types=1);

/** Business rules for the Producer role. Money values here are whole TZS; code converts to minor units. */
return [
    'order' => [
        'accept_hours' => 24,          // MKT-04: producer must respond within 24h
        'auto_release_hours' => 48,    // 11.2 OPEN-Q2
    ],
    'dispute' => [
        'evidence_days' => 3,          // BR-05
        'decide_working_days' => 5,
    ],
    'transport' => [                   // LOG-02 suggested price. OPEN: confirm rates with the business owner.
        'base_tzs' => 5_000,
        'per_km_tzs' => 900,
        'per_tonne_km_tzs' => 150,
        'road_factor' => 1.3,          // straight-line distance x road factor
    ],
    'storage' => ['price_unit' => 'per kg per day', 'expiry_alert_days' => 3],
    'expert' => ['fee_tzs' => 2_000],               // OPEN-Q2: paid from the platform float until consultation checkout exists
    'admin' => ['idle_minutes' => 30],                         // console session ends after this much inactivity
    'refund' => ['two_person_above_tzs' => 500_000], // NFR-S4: manual refunds above this need a second admin
    'weather' => [
        'provider' => env('NEAS_WEATHER_PROVIDER', 'open-meteo'), // open-meteo | mock
        'severe' => ['rain_mm' => 50, 'wind_kmh' => 60, 'heat_c' => 36],
    ],
    // TECH-08: browser-side Reverb settings, read at request time so one built bundle works on every environment.
    'realtime' => [
        'enabled' => env('BROADCAST_CONNECTION') === 'reverb',
        'key' => env('REVERB_APP_KEY'),
        'host' => env('REVERB_PUBLIC_HOST', env('REVERB_HOST', '127.0.0.1')),
        'port' => (int) env('REVERB_PUBLIC_PORT', env('REVERB_PORT', 8080)),
        'scheme' => env('REVERB_SCHEME', 'http'),
    ],
    // Phase 4: signed payment callbacks and the poll for ones that never arrive.
    'payments' => [
        'webhook_secret' => env('NEAS_PAYMENT_WEBHOOK_SECRET'),
        'pending_minutes' => 10,   // start asking the provider after this long without a callback
        'expire_minutes' => 30,    // then close the attempt (a late success can still fund it)
    ],
    'ussd' => ['secret' => env('NEAS_USSD_SECRET')],   // shared secret from the USSD/SMS aggregator; unset = open (local only)

    // Region centres for weather (no lat/lng column on regions).
    'region_coordinates' => [
        'Dar es Salaam' => [-6.7924, 39.2083], 'Iringa' => [-7.7700, 35.6900], 'Arusha' => [-3.3869, 36.6830],
        'Mbeya' => [-8.9000, 33.4500], 'Morogoro' => [-6.8210, 37.6610], 'Dodoma' => [-6.1630, 35.7516], 'Mwanza' => [-2.5164, 32.9175],
    ],

    // WTH-03: indicative planting / harvest months (1-12) per crop slug. Agronomy team to confirm per zone.
    'crop_calendar' => [
        'maize' => ['planting' => [11, 12, 1], 'harvest' => [6, 7, 8]],
        'rice' => ['planting' => [12, 1, 2], 'harvest' => [5, 6, 7]],
        'beans' => ['planting' => [3, 4, 10, 11], 'harvest' => [6, 7, 1, 2]],
        'tomatoes' => ['planting' => [3, 4, 9, 10], 'harvest' => [6, 7, 12, 1]],
    ],

    // Buyer workspace (S-08..S-18)
    /*
     * While no live mobile-money / bank gateway is connected, payments confirm instantly and a "simulate producer" panel
     * is shown on buyer orders. Defaults to on outside production. Set NEAS_SIMULATE_GATEWAYS=false when going live.
     */
    'simulate_gateways' => (bool) env('NEAS_SIMULATE_GATEWAYS', false),
    'delivery' => ['base_minor' => 500_000, 'per_km_minor' => 60_000],
    // LOG-03: crow-flies distance x road factor gives the road distance shown on jobs without a booked figure.
    'transporter' => ['road_factor' => (float) env('NEAS_ROAD_FACTOR', 1.3)],
    'auto_confirm_hours' => 48,   // MKT-06 / OPEN-Q2 (same window as order.auto_release_hours)
    'accept_window_hours' => 24,  // 11.2
];
