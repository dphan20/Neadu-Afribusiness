<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    // Google Gemini: photo diagnosis (DIA-01) and the "Ask AI" assistant. Key comes from .env only.
    // Google retires models on a schedule (gemini-2.5-* was announced for 16 Oct 2026), so the client tries the
    // primary model first and then each fallback in order when a model answers 404 / 429 / 5xx.
    'gemini' => [
        'key' => env('GEMINI_API_KEY'),
        'model' => env('GEMINI_MODEL', 'gemini-3.6-flash'),
        'fallback_models' => array_values(array_filter(array_map('trim', explode(',', (string) env('GEMINI_FALLBACK_MODELS', 'gemini-3.5-flash,gemini-3.5-flash-lite'))))),
        'thinking_level' => env('GEMINI_THINKING_LEVEL', 'minimal'), // minimal | low | high | default (gemini-3.x only); minimal = fastest
        'provider' => env('GEMINI_PROVIDER', 'auto'), // auto | studio (AIza keys) | vertex (AQ. keys)
        'base_url' => env('GEMINI_BASE_URL', 'https://generativelanguage.googleapis.com/v1beta'),
        'vertex_base_url' => env('GEMINI_VERTEX_BASE_URL', 'https://aiplatform.googleapis.com/v1'),
        'timeout' => (int) env('GEMINI_TIMEOUT', 30),
        'max_output_tokens' => (int) env('GEMINI_MAX_OUTPUT_TOKENS', 8192),
        'ask_max_tokens' => (int) env('GEMINI_ASK_MAX_TOKENS', 700), // Ask AI answers are short on purpose: fewer tokens = faster
        'retry_ms' => (int) env('GEMINI_RETRY_MS', 300),
    ],

    // SMS (OTP, order alerts, USSD replies). driver: log (local) | africastalking (production).
    'sms' => [
        'driver' => env('SMS_DRIVER', 'log'),
        'africastalking' => [
            'url' => env('AT_URL', 'https://api.africastalking.com/version1/messaging'), // sandbox: https://api.sandbox.africastalking.com/version1/messaging
            'username' => env('AT_USERNAME'),
            'api_key' => env('AT_API_KEY'),
            'sender_id' => env('AT_SENDER_ID'),
            'timeout' => (int) env('AT_TIMEOUT', 10),
        ],
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

];
