#!/usr/bin/env bash
# One command: clean, reproducible build.   Usage: bash scripts/setup.sh [--seed] [--fix-lock]
set -euo pipefail
cd "$(dirname "$0")/.."
SEED=0; FIXLOCK=0
for a in "$@"; do [ "$a" = "--seed" ] && SEED=1; [ "$a" = "--fix-lock" ] && FIXLOCK=1; done

php -r 'exit(version_compare(PHP_VERSION,"8.3.0",">=")?0:1);' || { echo "PHP 8.3+ required"; exit 1; }

if [ "$FIXLOCK" = 1 ]; then
  # Re-resolve the lock so it installs on PHP 8.3 (the committed lock needs 8.4+ for Symfony 8).
  composer config platform.php 8.3.0
  composer update --no-interaction --no-scripts --with-all-dependencies
fi

composer install --no-interaction --prefer-dist --optimize-autoloader
[ -f .env ] || cp .env.example .env
grep -q '^APP_KEY=.\+' .env || php artisan key:generate --force
[ -f database/database.sqlite ] || touch database/database.sqlite
php artisan migrate --force
[ "$SEED" = 1 ] && php artisan db:seed --force
php artisan storage:link 2>/dev/null || true

CI=true pnpm install --frozen-lockfile
pnpm run build

php artisan test
echo "OK. Start with: php artisan serve"
