<# Adds the picture slideshow (hero) and the animated gallery to resources\views\welcome.blade.php. Safe to run twice. #>
$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
$f = 'resources\views\welcome.blade.php'
if (-not (Test-Path $f)) { throw "Run this inside the project folder. Missing $f" }
$t = Get-Content $f -Raw -Encoding UTF8
if ($t -match 'landing-gallery') { Write-Host 'Already added. Nothing to do.' -ForegroundColor Yellow; return }
Copy-Item $f "$f.bak" -Force

# 1) hero picture: replace the drawn placeholder with the slideshow
$new = $t -replace '<div class="produce-art"[^>]*></div>', "@include('partials.landing-slideshow')"
if ($new -eq $t) { Write-Host "Could not find the hero placeholder. Add @include('partials.landing-slideshow') where you want the slideshow." -ForegroundColor Yellow }
$t = $new

# 2) gallery: before the trust strip, or before the escrow banner as a fallback
if ($t -match '<section class="trust-strip"') { $t = $t -replace '(<section class="trust-strip")', "@include('partials.landing-gallery')`r`n`r`n    `$1" }
elseif ($t -match '<section class="escrow-banner"') { $t = $t -replace '(<section class="escrow-banner")', "@include('partials.landing-gallery')`r`n`r`n    `$1" }
else { Write-Host "Could not place the gallery. Add @include('partials.landing-gallery') inside welcome.blade.php." -ForegroundColor Yellow }

Set-Content $f $t -Encoding UTF8
php artisan view:clear | Out-Null
Write-Host 'Done. Refresh the landing page with Ctrl+F5. (Backup: welcome.blade.php.bak)' -ForegroundColor Green
