<#
 Puts a real photograph on the NeAS landing page.
 Usage:  .\scripts\set-hero-photo.ps1 -Source "https://...jpg"      (download a photo from a link)
         .\scripts\set-hero-photo.ps1 -Source "C:\Users\me\Pictures\farm.jfif"   (use a file on this computer)
 Accepted: JPEG in any form (.jpg, .jpeg, .jfif, .jpe, Exif/JFIF), plus PNG, GIF and BMP (converted to JPEG).
 The photo is saved as public\images\hero.jpg. No rebuild is needed: refresh the page with Ctrl+F5.
#>
param([Parameter(Mandatory = $true)][string]$Source)

$ErrorActionPreference = 'Stop'
$Source = $Source.Trim().Trim('"').Trim("'")
$dest = Join-Path $PSScriptRoot '..\public\images\hero.jpg'
$tmp = Join-Path ([System.IO.Path]::GetTempPath()) ('neas-hero-' + [guid]::NewGuid().ToString('N') + '.tmp')
$out = $null

try {
    if ($Source -match '^https?://') { Invoke-WebRequest -Uri $Source -OutFile $tmp -UseBasicParsing -UserAgent 'Mozilla/5.0' }
    elseif (Test-Path -LiteralPath $Source) { Copy-Item -LiteralPath $Source -Destination $tmp -Force }
    else { throw "Cannot find '$Source'. Give a full https link or the full path of a file." }

    $bytes = [System.IO.File]::ReadAllBytes($tmp)
    if ($bytes.Length -lt 20000) { throw 'That file is too small to be a photo. Did the link open a web page instead of the image?' }

    # Decide by the file's first bytes, never by its extension. JFIF and Exif files are JPEGs: FF D8 FF.
    $isJpeg = ($bytes[0] -eq 0xFF -and $bytes[1] -eq 0xD8 -and $bytes[2] -eq 0xFF)
    $isPng  = ($bytes[0] -eq 0x89 -and $bytes[1] -eq 0x50 -and $bytes[2] -eq 0x4E -and $bytes[3] -eq 0x47)
    $isGif  = ($bytes[0] -eq 0x47 -and $bytes[1] -eq 0x49 -and $bytes[2] -eq 0x46)
    $isBmp  = ($bytes[0] -eq 0x42 -and $bytes[1] -eq 0x4D)

    if ($isJpeg) {
        $out = $tmp
        $kind = if ($bytes[3] -eq 0xE0) { 'JFIF/JPEG' } elseif ($bytes[3] -eq 0xE1) { 'Exif/JPEG' } else { 'JPEG' }
    }
    elseif ($isPng -or $isGif -or $isBmp) {
        Add-Type -AssemblyName System.Drawing
        $img = [System.Drawing.Image]::FromFile($tmp)
        try {
            $out = $tmp + '.jpg'
            $img.Save($out, [System.Drawing.Imaging.ImageFormat]::Jpeg)
        } finally { $img.Dispose() }
        $kind = 'converted to JPEG'
    }
    else { throw 'Unsupported image. Use a JPEG/JFIF, PNG, GIF or BMP photo. (WebP and HEIC are not supported: re-save as JPG first.)' }

    Copy-Item -LiteralPath $out -Destination $dest -Force
    $mb = [math]::Round((Get-Item -LiteralPath $dest).Length / 1MB, 2)
    Write-Host "Done ($kind): saved $mb MB to public\images\hero.jpg. Refresh the landing page with Ctrl+F5." -ForegroundColor Green
    if ($mb -gt 1.5) { Write-Host 'Tip: over 1.5 MB loads slowly on mobile data. Pick a smaller size (about 1920 px wide) if you can.' -ForegroundColor Yellow }
}
finally {
    Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    if ($out -and $out -ne $tmp) { Remove-Item -LiteralPath $out -Force -ErrorAction SilentlyContinue }
}
