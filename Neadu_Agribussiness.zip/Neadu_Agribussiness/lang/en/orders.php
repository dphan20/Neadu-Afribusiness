<?php

return ['status' => [
    'pending' => 'Pending', 'held' => 'Held in escrow', 'in_transit' => 'In transit',
    'delivered' => 'Delivered', 'disputed' => 'Disputed', 'released' => 'Released', 'refunded' => 'Refunded',
]];
