<?php

return [
    'title' => 'Weather', 'lead' => '7-day forecast, warnings and planting or harvest windows.',
    'district' => 'Region', 'reload' => 'Reload', 'now' => 'Now',
    'wind' => 'Wind', 'rain' => 'Rain', 'min' => 'Min', 'max' => 'Max',
    'source_line' => 'Source: :source · Updated: :time',
    'stale' => 'The weather service is not responding. Showing the last saved forecast.',
    'empty_title' => 'No forecast available yet', 'empty_body' => 'The weather service could not be reached and nothing is saved for this region. Try again in a few minutes.',
    'offline' => 'You are offline. Reconnect to refresh the forecast.',
    'loading' => 'Loading forecast…',
    'windows_title' => 'Planting & harvest windows',
    'indicative' => 'Windows are indicative. Confirm with your local extension officer.',
    'hint_title' => 'This week (indicative)',
    'hint' => [
        'dry' => 'Little rain expected (:mm mm). Good for harvesting, drying and transport; irrigate young crops.',
        'moderate' => 'Moderate rain expected (:mm mm). Suitable for planting if the soil is ready.',
        'wet' => 'Heavy rain expected (:mm mm). Delay planting, protect harvested produce and watch for waterlogging.',
    ],
    'condition' => [
        'clear' => 'Clear sky', 'mainly_clear' => 'Mostly clear', 'partly_cloudy' => 'Partly cloudy', 'overcast' => 'Overcast',
        'fog' => 'Fog', 'drizzle' => 'Drizzle', 'rain' => 'Rain', 'heavy_rain' => 'Heavy rain', 'freezing_rain' => 'Freezing rain',
        'snow' => 'Snow', 'rain_showers' => 'Rain showers', 'thunderstorm' => 'Thunderstorm', 'unknown' => 'Unknown',
    ],
    'alert' => [
        'thunderstorm' => 'Weather warning :region: thunderstorms expected. Stay indoors, secure crops and avoid open fields.',
        'heavy_rain' => 'Weather warning :region: heavy rain expected. Protect harvested produce and avoid flooded roads.',
        'wind' => 'Weather warning :region: strong wind expected (:kmh km/h). Secure sheds and tie down loose items.',
    ],
];
