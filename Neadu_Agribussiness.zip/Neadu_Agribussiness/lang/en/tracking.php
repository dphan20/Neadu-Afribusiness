<?php

return [
    'steps' => [
        'requested' => 'Requested', 'assigned' => 'Assigned', 'at_pickup' => 'At pickup', 'loaded' => 'Loaded',
        'in_transit' => 'In transit', 'arrived' => 'Arrived', 'delivered' => 'Delivered',
    ],
    'pickup' => 'Pickup', 'drop' => 'Drop-off', 'vehicle' => 'Vehicle',
    'live' => 'Live', 'offline' => 'Live updates paused. Reconnecting…', 'reconnected' => 'Live updates are back.',
    'no_points' => 'No GPS points yet. They appear once the trip starts.',
    'last_update' => 'Last update :time',
    'unavailable' => 'Live updates are not enabled on this server. Reload the page to see the latest position.',
    'map_label' => 'Live map of the delivery',
    'steps_label' => 'Delivery progress',
    'code_title' => 'Handover code',
    'code_help' => 'Give this code to the driver only when the goods have arrived (BR-09).',
    'pending' => ':count update(s) saved on the phone, waiting to sync',
];
