<?php

return [
    'messages' => 'Messages', 'new_message' => 'New message', 'new_lead' => 'Find anyone on NeAS and write to them.',
    'search' => 'Name, username or full phone number', 'search_go' => 'Search', 'any_role' => 'Anyone', 'type_to_search' => 'Type at least 2 letters of a name, or pick a role, to find people.',
    'no_people' => 'No one found.', 'write' => 'Write', 'send' => 'Send', 'write_placeholder' => 'Write your message…',
    'forward' => 'Forward', 'forward_title' => 'Forward message', 'forward_lead' => 'Choose who should receive it. You can pick up to 10 people or chats.',
    'forward_recent' => 'Your chats', 'forward_people' => 'Find other people', 'forward_send' => 'Forward to selected',
    'pick_one' => 'Choose at least one person or chat.', 'forward_failed' => 'The message could not be forwarded (its attachment is no longer available).',
    'forwarded' => 'Forwarded', 'forwarded_to' => 'Message forwarded (:count).',
    'delete' => 'Delete', 'delete_for_me' => 'Delete for me', 'delete_for_everyone' => 'Delete for everyone',
    'deleted' => 'This message was deleted', 'deleted_ok' => 'Message deleted.',
    'delete_chat' => 'Delete chat', 'delete_chat_confirm' => 'Yes, clear this chat for me', 'delete_chat_note' => 'Clears the history for you only. The other person keeps their copy.', 'chat_deleted' => 'Chat deleted.',
    'conversation' => 'Conversation', 'no_chats' => 'No conversations yet.', 'voice' => '🎤 Voice note', 'photo' => '📷 Photo',
    'back' => '← Messages', 'to' => 'To',
];
