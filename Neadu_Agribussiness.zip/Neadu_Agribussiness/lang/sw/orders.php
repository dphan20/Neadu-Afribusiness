<?php

return ['status' => [
    'pending' => 'Inasubiri', 'held' => 'Imeshikiliwa salama', 'in_transit' => 'Njiani',
    'delivered' => 'Imefika', 'disputed' => 'Mgogoro', 'released' => 'Imelipwa', 'refunded' => 'Imerudishwa',
]];
