<?php

return [
    'messages' => 'Ujumbe', 'new_message' => 'Ujumbe mpya', 'new_lead' => 'Mtafute mtu yeyote wa NeAS na umwandikie.',
    'search' => 'Jina, jina la mtumiaji au namba kamili ya simu', 'search_go' => 'Tafuta', 'any_role' => 'Yeyote', 'type_to_search' => 'Andika angalau herufi 2 za jina, au chagua jukumu, kuwapata watu.',
    'no_people' => 'Hakuna aliyepatikana.', 'write' => 'Andika', 'send' => 'Tuma', 'write_placeholder' => 'Andika ujumbe wako…',
    'forward' => 'Sambaza', 'forward_title' => 'Sambaza ujumbe', 'forward_lead' => 'Chagua atakayeupokea. Unaweza kuchagua hadi watu au mazungumzo 10.',
    'forward_recent' => 'Mazungumzo yako', 'forward_people' => 'Tafuta watu wengine', 'forward_send' => 'Sambaza kwa waliochaguliwa',
    'pick_one' => 'Chagua angalau mtu mmoja au mazungumzo moja.', 'forward_failed' => 'Ujumbe haukuweza kusambazwa (kiambatisho hakipo tena).',
    'forwarded' => 'Umesambazwa', 'forwarded_to' => 'Ujumbe umesambazwa (:count).',
    'delete' => 'Futa', 'delete_for_me' => 'Futa kwangu', 'delete_for_everyone' => 'Futa kwa wote',
    'deleted' => 'Ujumbe huu umefutwa', 'deleted_ok' => 'Ujumbe umefutwa.',
    'delete_chat' => 'Futa mazungumzo', 'delete_chat_confirm' => 'Ndiyo, safisha mazungumzo haya kwangu', 'delete_chat_note' => 'Inafuta historia kwako tu. Mwenzako anabaki na nakala yake.', 'chat_deleted' => 'Mazungumzo yamefutwa.',
    'conversation' => 'Mazungumzo', 'no_chats' => 'Bado hakuna mazungumzo.', 'voice' => '🎤 Ujumbe wa sauti', 'photo' => '📷 Picha',
    'back' => '← Ujumbe', 'to' => 'Kwa',
];
