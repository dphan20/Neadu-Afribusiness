<?php

return [
    'steps' => [
        'requested' => 'Imeombwa', 'assigned' => 'Amepangiwa', 'at_pickup' => 'Yupo kuchukua', 'loaded' => 'Mzigo umepakiwa',
        'in_transit' => 'Njiani', 'arrived' => 'Amefika', 'delivered' => 'Imewasilishwa',
    ],
    'pickup' => 'Kuchukua', 'drop' => 'Kuwasilisha', 'vehicle' => 'Gari',
    'live' => 'Moja kwa moja', 'offline' => 'Masasisho ya moja kwa moja yamesimama. Inaunganisha tena…', 'reconnected' => 'Masasisho ya moja kwa moja yamerudi.',
    'no_points' => 'Bado hakuna alama za GPS. Zitaonekana safari ikianza.',
    'last_update' => 'Sasisho la mwisho :time',
    'unavailable' => 'Masasisho ya moja kwa moja hayajawashwa kwenye seva hii. Pakia upya ukurasa kuona nafasi ya sasa.',
    'map_label' => 'Ramani ya moja kwa moja ya usafirishaji',
    'steps_label' => 'Hatua za usafirishaji',
    'code_title' => 'Msimbo wa makabidhiano',
    'code_help' => 'Mpe dereva msimbo huu tu mizigo ikishafika (BR-09).',
    'pending' => 'Masasisho :count yamehifadhiwa kwenye simu, yanasubiri kutumwa',
];
