<?php

return [
    'title' => 'Hali ya hewa', 'lead' => 'Utabiri wa siku 7, tahadhari na wakati wa kupanda au kuvuna.',
    'district' => 'Mkoa', 'reload' => 'Pakia upya', 'now' => 'Sasa',
    'wind' => 'Upepo', 'rain' => 'Mvua', 'min' => 'Chini', 'max' => 'Juu',
    'source_line' => 'Chanzo: :source · Ilisasishwa: :time',
    'stale' => 'Huduma ya hali ya hewa haipatikani. Inaonyeshwa taarifa ya mwisho iliyohifadhiwa.',
    'empty_title' => 'Hakuna utabiri kwa sasa', 'empty_body' => 'Huduma ya hali ya hewa haikufikiwa na hakuna taarifa iliyohifadhiwa kwa mkoa huu. Jaribu tena baada ya dakika chache.',
    'offline' => 'Huna mtandao. Unganisha ili kusasisha utabiri.',
    'loading' => 'Inapakia utabiri…',
    'windows_title' => 'Wakati wa kupanda na kuvuna',
    'indicative' => 'Nyakati ni elekezi. Thibitisha na afisa ugani wa eneo lako.',
    'hint_title' => 'Wiki hii (elekezi)',
    'hint' => [
        'dry' => 'Mvua kidogo inatarajiwa (mm :mm). Inafaa kuvuna, kukausha na kusafirisha; mwagilia mazao machanga.',
        'moderate' => 'Mvua ya wastani inatarajiwa (mm :mm). Inafaa kupanda ikiwa shamba liko tayari.',
        'wet' => 'Mvua kubwa inatarajiwa (mm :mm). Chelewesha kupanda, linda mazao yaliyovunwa na angalia maji kutuama.',
    ],
    'condition' => [
        'clear' => 'Anga safi', 'mainly_clear' => 'Anga safi zaidi', 'partly_cloudy' => 'Mawingu kiasi', 'overcast' => 'Mawingu mengi',
        'fog' => 'Ukungu', 'drizzle' => 'Manyunyu', 'rain' => 'Mvua', 'heavy_rain' => 'Mvua kubwa', 'freezing_rain' => 'Mvua ya barafu',
        'snow' => 'Theluji', 'rain_showers' => 'Mvua za vipindi', 'thunderstorm' => 'Radi na ngurumo', 'unknown' => 'Haijulikani',
    ],
    'alert' => [
        'thunderstorm' => 'Tahadhari ya hali ya hewa :region: radi na ngurumo zinatarajiwa. Kaa ndani, linda mazao na epuka mashamba wazi.',
        'heavy_rain' => 'Tahadhari ya hali ya hewa :region: mvua kubwa inatarajiwa. Linda mazao yaliyovunwa na epuka barabara zilizofurika.',
        'wind' => 'Tahadhari ya hali ya hewa :region: upepo mkali unatarajiwa (km/h :kmh). Imarisha mabanda na funga vitu vilivyolegea.',
    ],
];
