# Expert workspace (Role 3)

Screens live under `/expert` (route names `expert.*`), views in `resources/views/expert`, logic in
`ExpertController` and `ExpertChatController`.

| Screen | URL | Requirement |
|---|---|---|
| Overview | `/expert` | - |
| S-37 Case queue + case review, reply, correct | `/expert/cases`, `/expert/cases/{id}` | DIA-03 |
| Rate/correct the AI (R3, flag `ai_feedback`) | case page | DIA-05 |
| Publish advice | `/expert/advice` | §2.2 / ACC-05 |
| Paid consultations (offer, accept, escrow, complete) | `/expert/consultations` | - |
| S-42 Chat + voice call request (R2) | `/expert/chat` | COM-01/02 |
| S-45 Consultation earnings + payouts | `/expert/earnings` | - |
| S-44 Profile, badge, ratings, credentials | `/expert/profile` | ACC-05 |

## Decisions to confirm
- Publishing advice needs a verified identity (`verification_level` nida/full); drafts are always allowed.
- Badge tiers: Verified (identity verified) -> Trusted (10 answered, 3+ reviews, 4.0+) -> Top (50 answered, 10+ reviews, 4.5+).
- Consultation fee is held in escrow, then released to the expert minus the platform fee (config key `platform_fee`, default 2.5%).
- Voice calls: a call request is logged in the chat and a `tel:` link is shown. In-app audio needs a voice provider.
- Taking a case is atomic: the first expert to claim it owns it; it leaves everyone else's queue.
- Demo mode (`NEAS_SIMULATE_GATEWAYS`) adds buttons that play the producer (request, pay, rate) and pays out instantly.
