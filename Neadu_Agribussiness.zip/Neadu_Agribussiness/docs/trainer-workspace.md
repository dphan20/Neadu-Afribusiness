# Trainer / entrepreneur workspace (Role 4)

Screens live under `/trainer` (route names `trainer.*`), views in `resources/views/trainer`, logic in
`TrainerController` and `TrainerChatController`. Public certificate check: `/certificates/{number}`.

| Screen | URL | Requirement |
|---|---|---|
| Overview | `/trainer` | - |
| S-29 Create / edit tour (route, dates, price, seats, itinerary, goals) | `/trainer/tours/new`, `/trainer/tours/{id}/edit` | TUR-01 |
| S-28 Tour management, attendees, attendance | `/trainer/tours/{id}` | TUR-02/03 |
| S-28 Bookings & payment status (all tours) | `/trainer/bookings` | TUR-02 |
| Unpaid-seat release timer | `php artisan neas:release-unpaid-seats` (every minute) | TUR-02 |
| Group message + group chat | tour page, `/trainer/chat` | TUR-03 |
| Complete tour, certificates, public verify | tour page, `/trainer/tours/{id}/certificates` | TUR-03 |
| Attendee ratings on organiser profile | `/trainer/profile` | TUR-04 |
| S-45 Earnings and payouts | `/trainer/earnings` | S-45 |

## Flow
Draft -> submit for review (needs verified identity, BR-01; reviewed per BR-07) -> live (`active`) -> attendees reserve seats
(held for `hold_minutes`, default 30) -> pay into escrow -> organiser marks attendance -> **Complete tour**:
certificates issued to attendees marked present, paid seats released to the organiser minus the platform fee.
Cancelling refunds every paid seat from escrow. Price is locked and seats cannot drop below the booked count once seats are sold.
Seat counting is done under a row lock so a tour cannot be oversold.

## Demo mode (`NEAS_SIMULATE_GATEWAYS`)
Adds panels that play the admin (approve listing) and the attendee app (reserve, pay, rate), allows completing a tour
before its start time, and pays out instantly. Turn off for production and connect the attendee booking flow and gateway.

## Decisions to confirm
- Platform fee comes out of the organiser's earnings (same `platform_fee` rule, default 2.5%).
- No-shows still pay (no automatic refund); the organiser can refund an individual seat before completing.
- Payouts (here and in the expert workspace) now require a verified identity (BR-01).
