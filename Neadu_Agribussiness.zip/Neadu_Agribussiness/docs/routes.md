# Screen map (initial; completed per group)

Build order follows SRS 7.4: producer sells (S-07,10,09,13,14,17,18,45), buyer buys (S-08,09,11,12,18,14,16), dispute (S-14,15,50), transporter (S-21,19,20), then the rest.
Marketing: /, /how-escrow-works, /for/{producers|buyers|transporters|owners}, /pricing, /about, /help, /legal/{privacy|terms|data}.
Roles P B E T L W R A per SRS 7.3. Admin S-49..S-53 via Filament at /admin.
