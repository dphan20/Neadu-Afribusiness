# Buyer workspace (Role 2)

Screens live under `/buyer` (route names `buyer.*`), views in `resources/views/buyer`, logic in
`BuyerController`, `BuyerChatController`, `BuyerContractController`.

| Screen | URL | Requirement |
|---|---|---|
| Overview | `/buyer` | - |
| S-08 Search & filter | `/buyer/market` | MKT-03 |
| S-09 Listing detail | `/buyer/market/{listing}` | MKT-03 |
| S-11 Orders (part/full, counter-offer) | `/buyer/orders`, `/buyer/orders/{id}` | MKT-04 |
| S-12 Escrow payment | `/buyer/orders/{id}/pay` | MKT-05 |
| S-14 Confirm receipt / 48h auto-confirm | order page, `php artisan neas:auto-release` | MKT-06 |
| S-15 Dispute | `/buyer/orders/{id}/dispute` | MKT-08 |
| S-16 Rate producer | order page (after release) | MKT-09 |
| S-17/18 Delivery request & tracking | `/buyer/orders/{id}/delivery`, `/track` | LOG-02/04 |
| S-38/39 Contract offer + OTP e-sign (R3) | `/buyer/contracts` | CTR-01/02 |
| Favourites, wanted-to-buy | `/buyer/favourites`, `/buyer/wanted` | MKT-11 |
| Chat | `/buyer/chat` | COM-01 |
| Price alerts | `/buyer/alerts`, `php artisan neas:check-price-alerts` | PRC-03 |

## Demo mode
`config/neas.php` -> `simulate_gateways` (env `NEAS_SIMULATE_GATEWAYS`, default on outside production).
While on: payments confirm instantly (ledger posted), OTP codes are shown on screen, and each order page has a
"Demo mode" panel that plays the producer/transporter (accept, counter, reject, dispatch, deliver, GPS point).
Set `NEAS_SIMULATE_GATEWAYS=false` when the real mobile-money webhook and the producer/transporter workspaces exist.

## Decisions
- OPEN-Q2: the 2.5% escrow fee is charged to the buyer on top of the goods price.
- Contracts are visible when the `contracts` (R3) feature flag is enabled, and always in local/testing.
- Delivery price = base 5,000 TZS + 600 TZS/km (config/neas.php).
