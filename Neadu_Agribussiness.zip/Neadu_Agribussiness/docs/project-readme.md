# NeAS Data Notes

- Monetary values are stored as integer minor units (TZS).
- NIDA numbers, payment references, and documents use encrypted casts.
- `ledger_entries` and `audit_logs` are intended to be append-only; enforce this with database triggers in production.
- The original requirements mention both eight and nine roles; confirm the intended role count before extending role assignments.

See `decisions.md` and `routes.md` for the detailed design notes.
