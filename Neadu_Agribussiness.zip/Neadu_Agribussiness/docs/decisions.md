# Decisions (SRS v2.0 section 12.5)

| ID | Decision / default | Marker |
| --- | --- | --- |
| Q1 | Targets not set; no code depends on them | - |
| Q2 | Fee rules read from reference data; UI shows "set by business owner" until set. Auto-release 48h (11.2), free cancel before acceptance (BR-04) | `// OPEN-Q2:` |
| Q3 | Providers behind interfaces (PaymentGateway, IdentityVerifier, SmsGateway) with local mock adapters in app/Services | `// OPEN-Q3:` |
| Q4 | NIDA via IdentityVerifier; mock adapter until access path is known | `// OPEN-Q4:` |
| Q5 | Escrow holder abstracted as EscrowLedger; append-only ledger kept in-app | `// OPEN-Q5:` |
| Q6 | Flow diagram and wireframes owned by design lead; not produced here | - |
| Q7 | Diagnosis behind DiagnosisEngine interface, mock adapter | `// OPEN-Q7:` |
| Q8 | Closed: Inertia + React 19 + TypeScript | - |
| Q9 | Pin laravel/framework ^13.0; verify 13.39.0 availability at project start | `// OPEN-Q9:` |
| Q10 | Palette in 7.9.1 used as tokens in resources/css/app.css | `// OPEN-Q10:` |
| Q11 | Not present in the SRS text provided; confirm with the author | - |
