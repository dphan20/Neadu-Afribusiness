# Live tracking (LOG-04/05/06, TECH-08) and weather (WTH-01..05, INT-06)

Run everything from PowerShell in `C:\xampp\htdocs\Neadu_Agribussiness`.

## One-time setup
```powershell
composer require laravel/reverb
pnpm add laravel-echo pusher-js leaflet
php artisan migrate
pnpm run build
```

Add to `.env` (generate your own secret values):
```
BROADCAST_CONNECTION=reverb
REVERB_APP_ID=neas
REVERB_APP_KEY=neas-local-key
REVERB_APP_SECRET=neas-local-secret
REVERB_HOST=127.0.0.1
REVERB_PORT=8080
REVERB_SCHEME=http
```
On a real server set `REVERB_HOST` to your domain, `REVERB_SCHEME=https` and `REVERB_PORT=443` behind your proxy.
The browser reads these at request time (`config/neas.php` -> `realtime`), so no `VITE_REVERB_*` rebuild is needed.

## Run (separate PowerShell windows)
```powershell
php artisan serve
php artisan reverb:start
pnpm run dev          # or pnpm run build once
php artisan schedule:work   # runs the hourly CheckWeatherAlerts job
php artisan queue:work      # needed only if you queue anything else; broadcasts are sent immediately
```

## Tests
```powershell
php artisan test --filter=LiveTrackingTest
php artisan test --filter=WeatherForecastTest
php artisan test
```

## Acceptance checks
1. Buyer opens `/buyer/orders/{order}/track`; driver page `/transporter/trips/{delivery}` posts a point; the gold marker moves in under 2 s.
2. Driver goes offline: the page keeps buffering in localStorage and shows "N updates saved"; back online it flushes and the count returns to 0.
3. `/me/weather` shows 7 days, "Source: Open-Meteo" and the last-updated time.
4. Block `api.open-meteo.com` (or fake a 500): the page shows the last saved forecast with a stale notice.
