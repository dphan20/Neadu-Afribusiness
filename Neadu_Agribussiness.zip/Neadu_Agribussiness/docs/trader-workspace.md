# Trader / technology provider workspace (Role R)

For people who sell machinery and agricultural technology (tractors, pumps, sprayers, dryers, cold chain, sensors, software).
Screens live under `/trader` (route names `trader.*`), the buyer side under `/machinery` (`machinery.*`).

| Screen | URL | What the owner can do |
|---|---|---|
| Overview | `/trader` | Live/draft counts, requests waiting, quoted this month, setup checklist, latest requests |
| My machinery | `/trader/machines` | Search and filter; **add, edit, copy, pause/resume, mark sold out, close/reopen, delete**; spec sheet (print/PDF); **download all as CSV** |
| Add / edit | `/trader/machines/new` | Type, brand, model, year, condition, warranty, price, stock, offers (sale/financing/rental), region/district/GPS, description, any number of spec rows, up to 8 photos (remove old ones), PDF brochure |
| Quote inbox | `/trader/quotes` | Filter by status/type/buyer; **send or update a quotation** (price, validity, message), **decline with a reason**, printable quotation (PDF), **download all as CSV** |
| Business profile | `/trader/profile` | Name, about, licence, services, phone/WhatsApp/email/website, address, hours; shown to buyers and printed on quotations |
| Ask AI | `/me/ask` | Same live, stoppable, deletable AI chat as every role; in Trader mode it knows your catalogue size and open requests and helps write listings and replies. Buttons on the form and inbox open it with the question already typed |
| Messages, wallet | `/me/chat`, `/me/wallet` | Shared pages |
| Machinery market (everyone) | `/machinery` | Search by text/type/condition/offer/region, machine page, **Ask the seller** (price, financing, rental), `/machinery/requests` to follow answers, withdraw, print the quotation |

## Rules
- A listing needs a photo and a verified identity (NIDA) before it can be submitted; admin review makes it live (BR-07). Editing a live listing keeps it live.
- A listing with open requests cannot be closed or deleted. Delete is a soft delete: past quotes stay in the inbox history.
- Stock 0 sets the listing to sold out; adding stock brings it back.
- Financing and rental requests need the seller to offer them **and** the `financing` / `rental` feature flags on (`php artisan neas:flag financing on`). The whole market can be switched off with the `machinery` flag (migration turns it on).
- A quotation is an offer, not an order or a payment. Money for machinery is agreed between the parties.
- CSV downloads neutralise spreadsheet formulas; photos are public catalogue images, brochures too.

## Demo data
The workspace shows only the owner's real records. To clear what the local demo seeders created:
`php artisan neas:purge-demo` (counts only) then `php artisan neas:purge-demo --force` (add `--users` to also remove demo accounts that have no orders, deliveries or ledger entries).
`DatabaseSeeder` never seeds demo data in production.
