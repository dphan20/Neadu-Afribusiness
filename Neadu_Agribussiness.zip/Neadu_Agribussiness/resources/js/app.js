// Small progressive enhancements. No framework and no HTTP library: pages are server-rendered, so the bundle stays tiny.

// Stops double-submits (a second tap on "Pay" or "Place order" must never run twice).
document.addEventListener('submit', (event) => {
    const form = event.target;
    // An inline confirm() that was cancelled has already called preventDefault by the time the event bubbles here.
    if (event.defaultPrevented || !(form instanceof HTMLFormElement) || form.method.toLowerCase() !== 'post' || form.hasAttribute('data-no-lock')) {
        return;
    }
    // Disable after the browser has read the form (a disabled submit button would not send its own name/value).
    setTimeout(() => {
        form.querySelectorAll('button:not([type="button"]), input[type="submit"]').forEach((button) => {
            button.setAttribute('aria-busy', 'true');
            button.disabled = true;
        });
    }, 0);
});

// Coming back with the browser's Back button restores the page from cache: unlock the buttons again.
window.addEventListener('pageshow', (event) => {
    if (event.persisted) {
        document.querySelectorAll('button[aria-busy="true"]').forEach((button) => {
            button.removeAttribute('aria-busy');
            button.disabled = false;
        });
    }
});
