import { CircleCheck, Clock, ShieldCheck, TriangleAlert, Truck, Undo2 } from 'lucide-react';

const MAP = {
  pending: { cls: 'border-warning text-warning', Icon: Clock },
  held: { cls: 'border-primary text-primary', Icon: ShieldCheck },
  in_transit: { cls: 'border-water text-water', Icon: Truck },
  delivered: { cls: 'border-success text-success', Icon: CircleCheck },
  released: { cls: 'border-success text-success', Icon: CircleCheck },
  disputed: { cls: 'border-error text-error', Icon: TriangleAlert },
  refunded: { cls: 'border-text-muted text-text-muted', Icon: Undo2 },
} as const;

export type PillState = keyof typeof MAP;

/** Icon + word + colour, never colour alone (FE-09). `label` is a translated string from the server. */
export default function StatusPill({ state, label }: { state: PillState; label: string }) {
  const { cls, Icon } = MAP[state];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-sm font-medium ${cls}`}>
      <Icon size={20} strokeWidth={2} aria-hidden="true" />
      {label}
    </span>
  );
}
