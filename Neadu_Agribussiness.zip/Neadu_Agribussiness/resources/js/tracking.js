// S-18 live tracking (LOG-04, TECH-08): Leaflet map + Laravel Echo over Reverb. Loaded only on the buyer's tracking page.
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import Echo from 'laravel-echo';
import Pusher from 'pusher-js';

window.Pusher = Pusher;

const root = document.getElementById('live-map');

if (root) {
    const cfg = JSON.parse(root.dataset.config ?? '{}');
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const tr = cfg.text ?? {};

    const map = L.map(root, { zoomControl: true, attributionControl: true });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18,
        attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map);

    const route = L.polyline(cfg.points ?? [], { color: '#1B6B3A', weight: 5, opacity: 0.9 }).addTo(map);
    const stop = (pos, label, color) => L.circleMarker(pos, { radius: 8, color: '#fff', weight: 3, fillColor: color, fillOpacity: 1 }).bindTooltip(label).addTo(map);
    stop(cfg.pickup, tr.pickup ?? 'Pickup', '#7A5C2E');
    stop(cfg.drop, tr.drop ?? 'Drop-off', '#1E6FA8');

    const vehicleIcon = L.divIcon({
        className: 'live-vehicle-wrap',
        html: '<span class="live-vehicle" aria-hidden="true"></span>',
        iconSize: [26, 26],
        iconAnchor: [13, 13],
    });
    const last = (cfg.points ?? []).at(-1) ?? null;
    let vehicle = last ? L.marker(last, { icon: vehicleIcon, title: tr.vehicle ?? 'Vehicle' }).addTo(map) : null;

    const fit = () => {
        const bounds = L.latLngBounds([cfg.pickup, cfg.drop, ...(cfg.points ?? [])]);
        map.fitBounds(bounds, { padding: [30, 30], maxZoom: 15 });
    };
    last ? map.setView(last, 14) : fit();

    // Slide the marker between two fixes in about 200 ms; jump straight there when the person asked for reduced motion.
    let frame = 0;
    const moveVehicle = (to) => {
        if (!vehicle) {
            vehicle = L.marker(to, { icon: vehicleIcon, title: tr.vehicle ?? 'Vehicle' }).addTo(map);
            return;
        }
        const from = vehicle.getLatLng();
        cancelAnimationFrame(frame);
        if (reduceMotion) {
            vehicle.setLatLng(to);
            return;
        }
        const started = performance.now();
        const duration = 200;
        const step = (now) => {
            const t = Math.min(1, (now - started) / duration);
            vehicle.setLatLng([from.lat + (to[0] - from.lat) * t, from.lng + (to[1] - from.lng) * t]);
            if (t < 1) {
                frame = requestAnimationFrame(step);
            }
        };
        frame = requestAnimationFrame(step);
    };

    const statusLine = document.getElementById('live-last');
    const onLocation = (e) => {
        const pos = [Number(e.lat), Number(e.lng)];
        route.addLatLng(pos);
        moveVehicle(pos);
        if (!map.getBounds().contains(pos)) {
            map.panTo(pos, { animate: !reduceMotion });
        }
        if (statusLine) {
            statusLine.textContent = (tr.lastUpdate ?? 'Last update :time').replace(':time', new Date(e.recorded_at).toLocaleTimeString());
        }
        if (e.status) {
            onStatus(e);
        }
    };

    const steps = [...document.querySelectorAll('#track-steps li')];
    const flow = steps.map((li) => li.dataset.step);
    const onStatus = (e) => {
        const idx = flow.indexOf(e.status);
        steps.forEach((li, i) => {
            li.className = i < idx ? 'done' : i === idx ? 'now' : '';
            li.toggleAttribute('aria-current', i === idx);
        });
        const label = document.getElementById('track-status');
        if (label && tr.steps?.[e.status]) {
            label.textContent = tr.steps[e.status];
        }
    };

    // Offline banner: shown whenever the socket is not connected; Pusher reconnects on its own.
    const banner = document.getElementById('live-offline');
    const setOffline = (off) => {
        if (!banner) {
            return;
        }
        banner.hidden = !off;
        banner.textContent = off ? (tr.offline ?? 'Reconnecting…') : '';
    };

    const rt = cfg.realtime ?? {};
    if (rt.enabled && rt.key) {
        const echo = new Echo({
            broadcaster: 'reverb',
            key: rt.key,
            wsHost: rt.host,
            wsPort: rt.port,
            wssPort: rt.port,
            forceTLS: rt.scheme === 'https',
            enabledTransports: ['ws', 'wss'],
        });
        echo.private(`delivery.${cfg.uuid}`)
            .listen('.delivery.location.updated', onLocation)
            .listen('.delivery.status.changed', onStatus);

        const connection = echo.connector.pusher.connection;
        connection.bind('state_change', ({ current }) => setOffline(current !== 'connected'));
        window.addEventListener('offline', () => setOffline(true));
    } else if (banner) {
        banner.hidden = false;
        banner.textContent = tr.unavailable ?? '';
    }
}
