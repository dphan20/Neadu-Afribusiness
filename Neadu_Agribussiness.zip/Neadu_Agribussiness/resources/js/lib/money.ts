/** Minor units (TZS) to display text. Tabular figures come from the body font setting. */
export const formatTzs = (minor: number): string =>
  `${new Intl.NumberFormat('en-TZ', { maximumFractionDigits: 0 }).format(Math.trunc(minor / 100))} TZS`;
