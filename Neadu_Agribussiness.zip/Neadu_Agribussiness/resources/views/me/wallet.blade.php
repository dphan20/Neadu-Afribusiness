@extends('producer.layout')
@section('title', 'Wallet')
@section('heading', 'Wallet & payouts')
@section('lead', 'Your earnings, and how to withdraw them.')
@section('body')
<div class="p-card"><span class="p-muted">Available</span><h2 style="font-size:36px">TSh {{ number_format(intdiv($balance,100)) }}</h2></div>
<form class="p-card pf" method="post" action="{{ route('me.payout') }}">@csrf<h3>Request a payout</h3>
<div class="row"><div><label for="amount">Amount (TSh)</label><input id="amount" name="amount" inputmode="numeric" required></div>
<div><label for="method">Send to</label><select id="method" name="method"><option value="mpesa">M-Pesa</option><option value="tigopesa">Mixx by Yas</option><option value="airtelmoney">Airtel Money</option><option value="halopesa">HaloPesa</option><option value="bank">Bank account</option></select></div>
<div><label for="destination">Phone or account number</label><input id="destination" name="destination" value="{{ old('destination', auth()->user()->phone) }}" required></div></div>
<div class="p-actions"><button class="button button-primary">Request payout</button></div><p class="p-muted">Payouts need a verified identity.</p></form>
@if($payouts->isNotEmpty())<h3>Payout requests</h3>@foreach($payouts as $p)<div class="p-card">TSh {{ number_format(intdiv($p->amount_minor,100)) }} · {{ strtoupper($p->method) }} · <span class="p-tag">{{ ucfirst($p->status) }}</span> {{ $p->reason }} <span class="p-muted">{{ $p->created_at->format('d-m-Y') }}</span></div>@endforeach @endif
<h3>History</h3>
<div class="table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Note</th><th>In</th><th>Out</th></tr></thead><tbody>
@forelse($entries as $e)<tr><td>{{ $e->created_at?->format('d-m-Y') }}</td><td>{{ $e->memo }}</td><td>{{ $e->credit_minor ? 'TSh '.number_format(intdiv($e->credit_minor,100)) : '' }}</td><td>{{ $e->debit_minor ? 'TSh '.number_format(intdiv($e->debit_minor,100)) : '' }}</td></tr>@empty<tr><td colspan="4">No transactions yet.</td></tr>@endforelse</tbody></table></div>
@endsection
