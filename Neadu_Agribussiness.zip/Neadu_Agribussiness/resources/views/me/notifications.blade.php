@extends('producer.layout')
@section('title', 'Notifications')
@section('heading', 'Notifications')
@section('lead', 'Updates about your orders, payments and deliveries.')
@section('body')
@forelse($items as $n)<div class="p-card"><b>{{ $n->content['message'] ?? $n->type }}</b><p class="p-muted">{{ $n->created_at->format('d-m-Y H:i') }} · {{ str_replace('_',' ',$n->channel) }}</p></div>@empty<div class="p-card">You have no notifications.</div>@endforelse
@endsection
