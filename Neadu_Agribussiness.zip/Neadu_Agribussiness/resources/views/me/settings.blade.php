@extends('producer.layout')
@section('title', 'Settings')
@section('heading', 'Settings')
@section('lead', 'Language, security and your data.')
@section('body')
<form class="p-card pf" method="post" action="{{ route('me.settings.update') }}">@csrf @method('PUT')
<label for="name">Name</label><input id="name" name="name" value="{{ old('name',$user->name) }}" required>
<label for="language">Language</label><select id="language" name="language"><option value="sw" @selected($user->language==='sw')>Kiswahili</option><option value="en" @selected($user->language==='en')>English</option></select>
<div class="p-actions"><button class="button button-primary">Save</button></div></form>
<form class="p-card pf" method="post" action="{{ route('me.pin') }}">@csrf <h3>Change password</h3>
<label for="cp">Current password</label><input id="cp" name="current_pin" type="password" required>
<div class="row"><div><label for="np">New password (8+ characters)</label><input id="np" name="pin" type="password" required></div><div><label for="npc">Confirm new password</label><input id="npc" name="pin_confirmation" type="password" required></div></div>
<div class="p-actions"><button class="button button-primary">Change password</button></div></form>
<div class="p-card pf"><h3>Your data</h3><p class="p-muted">Download everything we hold about you, or delete your account. Financial records are kept as the law requires.</p>
<div class="p-actions"><a class="button button-outline" href="{{ route('me.export') }}">Download my data</a></div>
<form method="post" action="{{ route('me.delete') }}" onsubmit="return confirm('Delete your account for good?')">@csrf @method('DELETE')<label for="dp">Enter your password to delete your account</label><input id="dp" name="pin" type="password" required><div class="p-actions"><button class="button button-danger-quiet">Delete my account</button></div></form></div>
@endsection
