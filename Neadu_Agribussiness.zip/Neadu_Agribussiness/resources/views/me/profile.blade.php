@extends('producer.layout')
@section('title', 'My profile')
@section('heading', $user->name)
@section('lead', 'Your public profile and verification.')
@section('body')
<div class="p-card"><div class="p-actions">@foreach($roles as $r)<span class="p-tag">{{ $r->label() }}</span>@endforeach
@if($expert && $user->isIdentityVerified())<span class="p-tag">✓ Verified expert</span>@endif</div>
<p>Phone: {{ $user->phone }} {{ $user->phone_verified_at ? '✓' : '(not verified)' }} · Identity: {{ $user->isIdentityVerified() ? '✓ verified ('.$user->maskedNida().')' : 'not verified' }} · Level: {{ $user->verification_level }}</p>
<p>{{ $rating ? '★ '.$rating.' from '.$ratingCount.' order ratings' : 'No order ratings yet' }}{{ $tourRating ? ' · Tours ★ '.$tourRating : '' }}</p>
@unless($user->isIdentityVerified())<a class="button button-primary" href="{{ route('producer.identity') }}">Verify identity</a>@endunless</div>
<form class="p-card pf" method="post" enctype="multipart/form-data" action="{{ route('me.documents.store') }}">@csrf<h3>Send a document for review</h3>
<div class="row"><div><label for="kind">Document</label><select id="kind" name="kind"><option value="id_document">ID document</option><option value="business_licence">Business licence</option><option value="professional_certificate">Professional certificate</option></select></div>
<div><label for="file">File (photo or PDF)</label><input id="file" name="file" type="file" accept="image/*,application/pdf" capture="environment" required></div></div><div class="p-actions"><button class="button button-primary">Send</button></div></form>
@foreach($docs as $d)<div class="p-card">{{ str_replace('_',' ',$d->kind) }} · <span class="p-tag">{{ ucfirst($d->status) }}</span> {{ $d->reason }}</div>@endforeach
@endsection
