{{-- Shared Ask AI composer (dialog + page). Keeps the data-ask-* and data-pp-* hooks used by the scripts. $id = unique prefix --}}
<div class="ai-composer" data-pp>
    <input type="file" name="photo" accept="image/*" hidden data-pp-file>
    <input type="file" accept="image/*" capture="environment" hidden data-pp-cam>
    <span data-pp-name hidden></span>
    <div class="ai-box">
        <div class="ai-thumb-wrap" data-pp-wrap hidden><img data-pp-preview alt="Selected photo" hidden><button type="button" class="ai-thumb-x" data-pp-clear aria-label="Remove photo">&times;</button></div>
        <textarea id="{{ $id }}-q" name="question" rows="2" maxlength="1000" required data-ai-input
            placeholder="Ask anything: a sick crop, a price, a machine, a plot of land…">{{ $value ?? '' }}</textarea>
        <div class="ai-tools">
            <button type="button" class="ai-icon" data-pp-upload title="Upload a photo" aria-label="Upload a photo">
                <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="m21 16-5-5-8 8"/></svg></button>
            <button type="button" class="ai-icon" data-pp-camera title="Take a photo" aria-label="Take a photo">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13" r="3.5"/></svg></button>
            <span class="ai-sep" aria-hidden="true"></span>
            <button type="button" class="ai-mic" data-voice="#{{ $id }}-q" aria-pressed="false" title="Record your question">
                <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg><span>Record</span></button>
            <button type="button" class="ai-lang" data-voice-lang title="Voice language">SW</button>
            <button class="ai-send" type="submit" data-ask-submit>Ask
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>
        </div>
    </div>
    <span class="ai-status" role="status" aria-live="polite" data-ask-status></span>
</div>
