<div class="pp" data-pp>
    <input type="file" name="photo" accept="image/*" hidden data-pp-file>
    <input type="file" accept="image/*" capture="environment" hidden data-pp-cam>
    <div class="pp-actions">
        <button type="button" class="button button-outline button-small" data-pp-upload>📁 Upload photo</button>
        <button type="button" class="button button-outline button-small" data-pp-camera>📷 Take photo</button>
        <span class="p-muted" data-pp-name>No photo chosen. You can also drop an image here.</span>
    </div>
    <img data-pp-preview alt="Selected photo preview" hidden style="max-width:200px;max-height:160px;border-radius:12px;margin-top:8px">
</div>
