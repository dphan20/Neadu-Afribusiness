@extends('producer.layout')
@section('title', 'Help')
@section('heading', 'Help & support')
@section('lead', 'Answers to common questions.')
@section('body')
@foreach([
 ['How does escrow work?', 'The buyer pays into escrow. The money is released to the seller only after the buyer confirms receipt, or automatically 48 hours after delivery. If there is a problem, either side can open a dispute and an admin decides within 5 working days.'],
 ['Why must I verify my identity?', 'Listing, shipping and receiving payouts need a verified NIDA number. This protects every buyer and seller on NeAS.'],
 ['What does NeAS charge?', 'A platform fee is taken from the seller\'s payout. The current rate is set by NeAS and shown on every order and receipt.'],
 ['How do I get paid?', 'Open Wallet & payouts, request a payout to mobile money or bank. An admin reviews and pays it.'],
 ['I have no smartphone.', 'Producers can use USSD and SMS to check prices, weather and orders, and to accept orders with their PIN.'],
] as [$q,$a])<div class="p-card"><b>{{ $q }}</b><p>{{ $a }}</p></div>@endforeach
<div class="p-card"><b>Still stuck?</b><p>Email <a href="mailto:support@neas.example">support@neas.example</a> and include your phone number.</p></div>
@endsection
