@extends('producer.layout')
@section('title', 'Storage receipt')
@section('heading', 'Storage receipt '.$b->receipt_no)
@section('lead', 'Digital proof that your produce was received (STO-04).')
@section('body')
<article class="p-card" style="max-width:640px;line-height:1.8">
<h3>{{ $b->facilityListing->title }}</h3>
<p><b>Depositor:</b> {{ $b->user->name }}<br><b>Warehouse owner:</b> {{ $b->facilityListing->owner->name }}<br>
<b>Produce:</b> {{ $b->produce_note }} · grade {{ $b->grade }}<br><b>Quantity booked:</b> {{ \App\Support\Quantity::pretty($b->quantity_kg) }} kg<br>
<b>Period:</b> {{ $b->starts_on }} → {{ $b->ends_on }}<br><b>Received:</b> {{ $b->received_at?->format('d-m-Y H:i') }}<br>
<b>Charge:</b> TSh {{ number_format(intdiv($b->price_minor,100)) }} ({{ $b->payment_method==='invoice' ? 'monthly invoice' : 'escrow' }})</p>
<div class="p-actions"><button class="button button-primary" onclick="window.print()">Print</button></div></article>
@endsection
