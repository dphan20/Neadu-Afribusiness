@extends('producer.layout')
@section('title', 'Ask AI')
@section('heading', 'Ask AI')
@section('lead', 'Speak, type or add a photo. Answers come in Kiswahili or English.')
@section('body')
@unless ($ready)<div class="p-card"><p class="p-muted">AI is not set up yet. Add <code>GEMINI_API_KEY</code> to the .env file and restart the server.</p></div>@endunless
<form class="ai-page-card" method="post" enctype="multipart/form-data" action="{{ route('me.ask.send') }}" data-ask-form data-ask-stream="#ask-out" data-ask-url="{{ $streamUrl }}">@csrf
    <div class="ai-head ai-head-page">
        <span class="ai-badge">@include('layouts.partials.icon-sparkles')</span>
        <div><h2>What would you like to know?</h2><p>Crops, animals, fish, produce, machines, land and prices.</p></div>
    </div>
    @include('me.partials.ai-composer', ['id' => 'ask', 'value' => old('question', request('q'))])
    @error('question')<span class="ai-status is-error">{{ $message }}</span>@enderror
    @error('photo')<span class="ai-status is-error">{{ $message }}</span>@enderror
    <div class="ai-chips ai-chips-page">
        <button type="button" data-ai-suggest="What is wrong with these maize leaves? I will add a photo.">Sick crop</button>
        <button type="button" data-ai-suggest="Is this tractor worth buying? I will add a photo.">Check a machine</button>
        <button type="button" data-ai-suggest="Bei ya mahindi leo ni kiasi gani?">Bei ya mahindi</button>
        <button type="button" data-ai-suggest="How do I dry and store maize to avoid losses?">Storing harvest</button>
    </div>
    <p class="ai-note">AI can be wrong. For disease, chemicals and dosing, check with an extension officer or vet.</p>
</form>
<div id="ask-out" class="ai-out"></div>
@if ($history->isNotEmpty())
<div class="ai-history-bar"><h2>Your earlier questions</h2>
<form method="post" action="{{ route('me.ask.clear') }}" data-ask-delete-all>@csrf @method('DELETE')
    <button class="button button-quiet button-small" type="submit">Delete all answers</button>
</form></div>
@endif
@foreach ($history as $q)
<article class="p-card ai-item" data-ask-card @if (session('answered') === $q->uuid) id="latest" @endif>
    <p class="p-muted">{{ $q->created_at?->format('d-m-Y H:i') }}</p>
    <p class="ai-q"><b>{{ $q->question }}</b></p>
    @if ($q->photo_path)<img src="{{ route('me.ask.photo', $q) }}" alt="Your photo" style="max-width:240px;border-radius:12px" loading="lazy">@endif
    <div class="ai-answer" data-md>{{ $q->answer }}</div>
    <form method="post" action="{{ route('me.ask.destroy', $q) }}" data-ask-delete class="p-actions">@csrf @method('DELETE')
        <button class="button button-quiet button-small" type="submit">Delete</button>
    </form>
</article>
@endforeach
@if ($history->isEmpty())<p class="p-muted">Your questions and answers will appear here.</p>@endif
<script>(function () { var latest = document.getElementById('latest'); if (latest) { latest.scrollIntoView({block: 'start'}); } })();</script>
@endsection
