@extends('layouts.app')
@section('title', 'Verify certificate')
@section('content')
<main class="workspace-main" style="max-width:640px;margin:40px auto;padding:0 16px">
    <section class="panel">
        <span class="eyebrow">CERTIFICATE CHECK</span>
        @if ($booking)
            <h1 style="margin:8px 0">✓ Genuine certificate</h1>
            <dl style="display:grid;grid-template-columns:140px 1fr;gap:8px;margin:0"><dt>Certificate no.</dt><dd><b>{{ $booking->certificate_no }}</b></dd><dt>Awarded to</dt><dd>{{ $booking->attendee?->name }}</dd>
                <dt>Tour</dt><dd>{{ $booking->tour->listing->title }}</dd><dt>Date</dt><dd>{{ $booking->tour->starts_at->format('d M Y') }}</dd><dt>Organiser</dt><dd>{{ $booking->tour->listing->owner?->name }}</dd><dt>Issued</dt><dd>{{ $booking->certificate_issued_at?->format('d M Y') }}</dd></dl>
        @else
            <h1 style="margin:8px 0">No certificate found</h1><p>We could not find a certificate with the number <b>{{ $number }}</b>. Check the number and try again.</p>
        @endif
    </section>
</main>
@endsection
