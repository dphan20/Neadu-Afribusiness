@extends('producer.layout')
@section('title', 'My land enquiries')
@section('heading', 'My enquiries')
@section('lead', 'Messages, visits and offers you sent to land owners.')
@section('body')
@forelse($items as $e)<div class="p-card"><b>{{ $e->listing->title }}</b> <span class="p-tag">{{ ucfirst($e->kind) }} · {{ ucfirst($e->status) }}</span>
<p class="p-muted">@if($e->kind==='visit')Visit {{ $e->visit_on?->format('d-m-Y') }} · @elseif($e->kind==='offer')Offer TSh {{ number_format(intdiv((int) $e->offer_minor,100)) }} · @endif{{ $e->message }}</p>@if($e->reply)<p>Owner: {{ $e->reply }}</p>@endif</div>
@empty<div class="p-card">Nothing sent yet. <a href="{{ route('land.index') }}">Browse land</a>.</div>@endforelse
@endsection
