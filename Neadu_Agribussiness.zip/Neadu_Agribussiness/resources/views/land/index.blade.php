@extends('producer.layout')
@section('title', 'Land')
@section('heading', 'Land and sites')
@section('lead', 'Farmland and sites to lease or buy. Look for the Verified badge: the NeAS team checked the title document.')
@section('head-action')<a class="button button-outline" href="{{ route('land.enquiries') }}">My enquiries</a>@endsection
@section('body')
<form class="p-card pf" method="get"><div class="row">
<div><label for="region_id">Region</label><select id="region_id" name="region_id"><option value="">Any</option>@foreach($regions as $r)<option value="{{ $r->id }}" @selected(($f['region_id'] ?? '')==$r->id)>{{ $r->name }}</option>@endforeach</select></div>
<div><label for="site_type">Site</label><select id="site_type" name="site_type"><option value="">Any</option>@foreach(['farmland'=>'Farmland','factory'=>'Factory','service_centre'=>'Service centre'] as $k=>$v)<option value="{{ $k }}" @selected(($f['site_type'] ?? '')===$k)>{{ $v }}</option>@endforeach</select></div>
<div><label for="tenure">Offer</label><select id="tenure" name="tenure"><option value="">Lease or sale</option><option value="lease" @selected(($f['tenure'] ?? '')==='lease')>Lease</option><option value="sale" @selected(($f['tenure'] ?? '')==='sale')>Sale</option></select></div>
<div><label for="min_acres">Min acres</label><input id="min_acres" name="min_acres" value="{{ $f['min_acres'] ?? '' }}"></div></div>
<label class="check"><input type="checkbox" name="verified" value="1" @checked(request()->boolean('verified'))> Verified only</label>
<div class="p-actions"><button class="button button-primary">Search</button></div></form>
<div class="p-grid">@forelse($lands as $l)
<a class="p-card" style="display:block;text-decoration:none;color:inherit" href="{{ route('land.show',$l) }}">
@if($l->photos)<img src="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($l->photos[0]) }}" alt="" style="width:100%;height:130px;object-fit:cover;border-radius:10px">@endif
<b>{{ $l->title }}</b> @if($l->verified)<span class="p-tag">✓ Verified</span>@endif
<p class="p-muted">{{ $l->land->size_acres }} acres · {{ ucfirst(str_replace('_',' ',$l->land->site_type)) }} · {{ $l->region?->name }}</p>
<b>TSh {{ number_format(intdiv($l->price_minor,100)) }}</b> <span class="p-muted">{{ $l->land->tenure==='lease' ? 'per '.($l->land->rent_period ?? 'month') : 'sale price' }}</span></a>
@empty<div class="p-card">No land matches yet.</div>@endforelse</div>
@endsection
