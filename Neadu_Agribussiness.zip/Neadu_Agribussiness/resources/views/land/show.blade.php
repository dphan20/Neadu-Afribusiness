@extends('producer.layout')
@section('title', $l->title)
@section('heading', $l->title)
@section('lead', ($l->region?->name ?? '').' · '.($l->district?->name ?? ''))
@section('body')
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
<div class="p-card">@foreach($l->photos ?? [] as $p)<img src="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($p) }}" alt="" style="height:140px;border-radius:10px;margin-right:8px">@endforeach
<p>@if($l->verified)<span class="p-tag">✓ Verified by NeAS</span>@else<span class="p-tag">Not verified yet</span>@endif</p>
<dl><dt class="p-muted">Site</dt><dd>{{ ucfirst(str_replace('_',' ',$land->site_type)) }}, {{ $land->size_acres }} acres</dd>
<dt class="p-muted">Offer</dt><dd>{{ $land->tenure==='lease' ? 'Lease, TSh '.number_format(intdiv($l->price_minor,100)).' per '.($land->rent_period ?? 'month') : 'Sale, TSh '.number_format(intdiv($l->price_minor,100)) }}</dd>
<dt class="p-muted">Soil · Water · Road</dt><dd>{{ $land->soil ?: '—' }} · {{ $land->water ?: '—' }} · {{ $land->road_access ? 'Road access' : 'No road access' }}</dd>
<dt class="p-muted">Owner</dt><dd>{{ $l->owner->name }}</dd></dl></div>
@if($l->user_id !== auth()->id() && $l->status==='active')
<form class="p-card pf" method="post" action="{{ route('land.enquire',$l) }}">@csrf<h3>Contact the owner</h3>
<label for="kind">I want to</label><select id="kind" name="kind"><option value="message">Send a message</option><option value="visit">Request a site visit</option><option value="offer">Make an offer</option></select>
<label for="message">Message</label><textarea id="message" name="message">{{ old('message') }}</textarea>
<div class="row"><div><label for="visit_on">Visit date</label><input id="visit_on" name="visit_on" type="date" value="{{ old('visit_on') }}"></div><div><label for="offer">Offer (TSh)</label><input id="offer" name="offer" value="{{ old('offer') }}"></div></div>
<div class="p-actions"><button class="button button-primary">Send</button></div></form>
<form method="post" action="{{ route('me.chat.listing',$l) }}">@csrf<button class="button button-outline">Chat with the owner</button></form>@endif
@endsection
