@extends('producer.layout')
@section('title', 'Storage bookings')
@section('heading', 'Booking requests')
@section('lead', 'Accept or decline by quantity and period. Escrow payments are paid to you after the period ends.')
@section('body')
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
@php($rec = \App\Models\FeatureFlag::isEnabled('storage_receipt'))
@forelse($bookings as $b)
<div class="p-card"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><b>{{ $b->user->name }} · {{ $b->facilityListing->title }}</b><span class="p-tag">{{ ucfirst($b->status) }}</span></div>
<p class="p-muted">{{ \App\Support\Quantity::pretty($b->quantity_kg) }} kg · {{ $b->starts_on }} → {{ $b->ends_on }} · TSh {{ number_format(intdiv($b->price_minor,100)) }} · {{ $b->payment_method==='invoice' ? 'Monthly invoice' : 'Escrow' }} ({{ $b->payment_state }})@if($b->decline_reason) · Declined: {{ $b->decline_reason }}@endif @if($b->receipt_no)· Receipt <a href="{{ route('me.storage.receipt',$b) }}">{{ $b->receipt_no }}</a>@endif</p>
@if($b->status==='requested')
<form class="pf" method="post" action="{{ route('warehouse.bookings.decline',$b) }}">@csrf<div class="p-actions">
<button class="button button-primary button-small" formaction="{{ route('warehouse.bookings.accept',$b) }}">Accept</button>
<input name="reason" placeholder="Reason if declining" style="max-width:260px"><button class="button button-danger-quiet button-small">Decline</button></div></form>
@elseif($b->status==='accepted')
@if($b->payment_method==='invoice' && $b->payment_state==='invoiced')<form method="post" action="{{ route('warehouse.bookings.invoice',$b) }}" class="p-actions">@csrf<button class="button button-outline button-small">Mark invoice paid</button></form>@endif
@if($rec)<form class="pf" method="post" action="{{ route('warehouse.bookings.receipt',$b) }}">@csrf<div class="row"><div><label>Produce received</label><input name="produce_note" value="{{ $b->produce_note }}" required></div><div><label>Grade</label><input name="grade" value="{{ $b->grade }}" required></div></div>
<div class="p-actions"><button class="button button-outline button-small">{{ $b->receipt_no ? 'Update receipt' : 'Issue receipt' }}</button></div></form>@endif
@endif</div>
@empty<div class="p-card">No booking requests yet.</div>@endforelse
@endsection
