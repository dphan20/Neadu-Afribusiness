@extends('producer.layout')
@section('title', $listing ? 'Edit facility' : 'Add facility')
@section('heading', $listing ? 'Edit facility' : 'Add a storage facility')
@section('lead', 'Tell producers what you store, how much, in what conditions and at what rate.')
@section('body')
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
<form class="p-card pf" method="post" enctype="multipart/form-data" action="{{ $listing ? route('warehouse.facilities.update',$listing) : route('warehouse.facilities.store') }}">@csrf @if($listing)@method('PUT')@endif
<label for="title">Name</label><input id="title" name="title" value="{{ old('title',$listing?->title) }}" required>
<div class="row"><div><label for="facility_type">Type</label><select id="facility_type" name="facility_type">@foreach($types as $k=>$v)<option value="{{ $k }}" @selected(old('facility_type',$facility?->facility_type)===$k)>{{ $v }}</option>@endforeach</select></div>
<div><label for="capacity_kg">Capacity (kg)</label><input id="capacity_kg" name="capacity_kg" type="number" step="1" value="{{ old('capacity_kg',$facility ? (int) $facility->capacity_kg : '') }}" required></div>
<div><label for="rate">Rate (TSh per kg per day)</label><input id="rate" name="rate" value="{{ old('rate',$listing ? number_format($listing->price_minor/100,2,'.','') : '') }}" required></div></div>
<div class="row"><div><label for="region_id">Region</label><select id="region_id" name="region_id">@foreach($regions as $r)<option value="{{ $r->id }}" @selected(old('region_id',$listing?->region_id)==$r->id)>{{ $r->name }}</option>@endforeach</select></div>
<div><label for="district_id">District</label><select id="district_id" name="district_id">@foreach($districts as $d)<option value="{{ $d->id }}" data-region="{{ $d->region_id }}" @selected(old('district_id',$listing?->district_id)==$d->id)>{{ $d->name }}</option>@endforeach</select></div>
<div><label for="lat">Latitude (optional)</label><input id="lat" name="lat" value="{{ old('lat',$listing?->lat) }}"></div><div><label for="lng">Longitude (optional)</label><input id="lng" name="lng" value="{{ old('lng',$listing?->lng) }}"></div></div>
<label>Conditions</label><div>@foreach($conditions as $k=>$v)<label class="check"><input type="checkbox" name="conditions[]" value="{{ $k }}" @checked(in_array($k, old('conditions',$facility?->conditions ?? []), true))> {{ $v }}</label>@endforeach</div>
<label for="security">Security</label><textarea id="security" name="security">{{ old('security',$facility?->security) }}</textarea>
<label for="photos">Photos</label><input id="photos" name="photos[]" type="file" accept="image/*" capture="environment" multiple @if(!$listing) required @endif>
<div class="p-actions"><button class="button button-primary" name="submit" value="1">Submit for review</button><button class="button button-outline" name="submit" value="0">Save draft</button></div></form>
<script>const rg=document.getElementById('region_id'),ds=document.getElementById('district_id');function f(){[...ds.options].forEach(o=>o.hidden=o.dataset.region!==rg.value);if(ds.selectedOptions[0]?.hidden)ds.value=[...ds.options].find(o=>!o.hidden)?.value}rg.addEventListener('change',f);f();</script>
@endsection
