@extends('producer.layout')
@section('title', 'My facilities')
@section('heading', 'My storage facilities')
@section('lead', 'Rates are per kg per day. Producers book space; you accept or decline.')
@section('head-action')<a class="button button-primary" href="{{ route('warehouse.facilities.create') }}">Add facility</a>@endsection
@section('body')
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
@forelse($facilities as $f)
<div class="p-card"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><b>{{ $f->title }}</b><span class="p-tag">{{ ucfirst(str_replace('_',' ',$f->status)) }}</span></div>
<p class="p-muted">{{ \App\Http\Controllers\Warehouse\WarehouseController::TYPES[$f->storage?->facility_type] ?? '—' }} · {{ number_format((float) $f->storage?->capacity_kg) }} kg · TSh {{ number_format($f->price_minor/100,2) }} per kg per day · {{ $f->region?->name }}
@if($f->storage?->conditions) · {{ implode(', ', array_map(fn($c)=>\App\Http\Controllers\Warehouse\WarehouseController::CONDITIONS[$c] ?? $c, $f->storage->conditions)) }}@endif
@if($f->moderation_note) · Review note: {{ $f->moderation_note }}@endif @if(($pending[$f->id] ?? 0)>0)· <a href="{{ route('warehouse.bookings') }}">{{ $pending[$f->id] }} requests waiting</a>@endif</p>
<div class="p-actions"><a class="button button-outline button-small" href="{{ route('warehouse.facilities.edit',$f) }}">Edit</a>
@if($f->status==='active')<form method="post" action="{{ route('warehouse.facilities.status',[$f,'pause']) }}">@csrf<button class="button button-outline button-small">Pause</button></form>@endif
@if($f->status==='paused')<form method="post" action="{{ route('warehouse.facilities.status',[$f,'resume']) }}">@csrf<button class="button button-outline button-small">Resume</button></form>@endif
@if($f->status!=='closed')<form method="post" action="{{ route('warehouse.facilities.status',[$f,'close']) }}">@csrf<button class="button button-danger-quiet button-small">Close</button></form>@endif</div></div>
@empty<div class="p-card">No facilities yet.</div>@endforelse
@endsection
