@extends('producer.layout')
@section('title', $listing ? 'Edit land' : 'Add land')
@section('heading', $listing ? 'Edit land' : 'Add land or a site')
@section('lead', 'Editing a verified listing sends it back for review (BR-08).')
@section('body')
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
<form class="p-card pf" method="post" enctype="multipart/form-data" action="{{ $listing ? route('landowner.land.update',$listing) : route('landowner.land.store') }}">@csrf @if($listing)@method('PUT')@endif
<label for="title">Title</label><input id="title" name="title" value="{{ old('title',$listing?->title) }}" required>
<div class="row"><div><label for="site_type">Type of site</label><select id="site_type" name="site_type">@foreach(['farmland'=>'Farmland','factory'=>'Factory site','service_centre'=>'Service centre'] as $k=>$v)<option value="{{ $k }}" @selected(old('site_type',$land?->site_type)===$k)>{{ $v }}</option>@endforeach</select></div>
<div><label for="size_acres">Size (acres)</label><input id="size_acres" name="size_acres" type="number" step="0.01" value="{{ old('size_acres',$land?->size_acres) }}" required></div></div>
<div class="row"><div><label for="region_id">Region</label><select id="region_id" name="region_id">@foreach($regions as $r)<option value="{{ $r->id }}" @selected(old('region_id',$listing?->region_id)==$r->id)>{{ $r->name }}</option>@endforeach</select></div>
<div><label for="district_id">District</label><select id="district_id" name="district_id">@foreach($districts as $d)<option value="{{ $d->id }}" data-region="{{ $d->region_id }}" @selected(old('district_id',$listing?->district_id)==$d->id)>{{ $d->name }}</option>@endforeach</select></div>
<div><label for="lat">Latitude (optional)</label><input id="lat" name="lat" value="{{ old('lat',$listing?->lat) }}"></div><div><label for="lng">Longitude (optional)</label><input id="lng" name="lng" value="{{ old('lng',$listing?->lng) }}"></div></div>
<div class="row"><div><label for="tenure">Offer</label><select id="tenure" name="tenure"><option value="lease" @selected(old('tenure',$land?->tenure)==='lease')>Lease (rent)</option><option value="sale" @selected(old('tenure',$land?->tenure)==='sale')>Sale</option></select></div>
<div id="period"><label for="rent_period">Rent is per</label><select id="rent_period" name="rent_period"><option value="month" @selected(old('rent_period',$land?->rent_period)==='month')>Month</option><option value="year" @selected(old('rent_period',$land?->rent_period)==='year')>Year</option></select></div>
<div><label for="price">Price or rent (TSh)</label><input id="price" name="price" value="{{ old('price',$listing ? number_format($listing->price_minor/100,2,'.','') : '') }}" required></div></div>
<div class="row"><div><label for="soil">Soil</label><input id="soil" name="soil" value="{{ old('soil',$land?->soil) }}"></div><div><label for="water">Water source</label><input id="water" name="water" value="{{ old('water',$land?->water) }}"></div></div>
<label class="check"><input type="hidden" name="road_access" value="0"><input type="checkbox" name="road_access" value="1" @checked(old('road_access',$land?->road_access))> Road access</label>
<label for="photos">Photos</label><input id="photos" name="photos[]" type="file" accept="image/*" capture="environment" multiple>
<label for="title_document">Title or ownership document (PDF or photo, kept private)</label><input id="title_document" name="title_document" type="file" accept=".pdf,image/*">
@foreach($docs as $d)<p class="p-muted">Uploaded {{ $d->created_at->format('d-m-Y') }}: {{ ucfirst($d->status) }}@if($d->reason) — {{ $d->reason }}@endif</p>@endforeach
<div class="p-actions"><button class="button button-primary" name="submit" value="1">Submit for review</button><button class="button button-outline" name="submit" value="0">Save draft</button></div></form>
<script>const rg=document.getElementById('region_id'),ds=document.getElementById('district_id'),tn=document.getElementById('tenure'),pd=document.getElementById('period');function f(){[...ds.options].forEach(o=>o.hidden=o.dataset.region!==rg.value);if(ds.selectedOptions[0]?.hidden)ds.value=[...ds.options].find(o=>!o.hidden)?.value}rg.addEventListener('change',f);f();function t(){pd.style.display=tn.value==='lease'?'':'none'}tn.addEventListener('change',t);t();</script>
@endsection
