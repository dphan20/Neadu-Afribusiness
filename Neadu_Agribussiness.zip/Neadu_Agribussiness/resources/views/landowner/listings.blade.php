@extends('producer.layout')
@section('title', 'My land')
@section('heading', 'My land and sites')
@section('lead', 'Farmland, factory and service-centre sites. Land shows as Verified once the NeAS team approves your title document.')
@section('head-action')<a class="button button-primary" href="{{ route('landowner.land.create') }}">Add land</a>@endsection
@section('body')
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
@forelse($lands as $l)
@php($land = $l->land)
<div class="p-card"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><b>{{ $l->title }}</b>
<span><span class="p-tag">{{ ucfirst(str_replace('_',' ',$l->status)) }}</span> @if($l->verified)<span class="p-tag">✓ Verified</span>@endif</span></div>
<p class="p-muted">{{ ucfirst(str_replace('_',' ',$land?->site_type ?? 'farmland')) }} · {{ $land?->size_acres }} acres · {{ $land?->tenure === 'lease' ? 'Lease, TSh '.number_format(intdiv($l->price_minor,100)).' per '.($land->rent_period ?? 'month') : 'Sale, TSh '.number_format(intdiv($l->price_minor,100)) }} · {{ $l->region?->name }}</p>
@php($d = ($docs[$l->id] ?? collect())->first())
<p class="p-muted">Title document: @if($d){{ ucfirst($d->status) }}@if($d->status==='rejected' && $d->reason) — {{ $d->reason }}@endif @else <b>not uploaded</b>@endif
@if($l->moderation_note) · Review note: {{ $l->moderation_note }}@endif @if(($open[$l->id] ?? 0) > 0)· <a href="{{ route('landowner.enquiries') }}">{{ $open[$l->id] }} open enquiries</a>@endif</p>
<div class="p-actions"><a class="button button-outline button-small" href="{{ route('landowner.land.edit',$l) }}">Edit</a>
@if($l->status==='active')<a class="button button-outline button-small" href="{{ route('land.show',$l) }}">View public page</a>@endif
@if($l->status!=='closed')<form method="post" action="{{ route('landowner.land.close',$l) }}">@csrf<button class="button button-danger-quiet button-small">Close</button></form>@endif</div></div>
@empty<div class="p-card">You have not listed any land yet.</div>@endforelse
@endsection
