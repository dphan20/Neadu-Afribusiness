@extends('producer.layout')
@section('title', 'Land enquiries')
@section('heading', 'Enquiries on your land')
@section('lead', 'Messages, site-visit requests and offers. Offers are recorded in NeAS; the legal lease is signed outside NeAS.')
@section('body')
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
@forelse($items as $e)
<div class="p-card"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><b>{{ $e->user->name }} · {{ $e->listing->title }}</b><span class="p-tag">{{ ucfirst($e->kind) }} · {{ ucfirst($e->status) }}</span></div>
<p>@if($e->kind==='visit')Wants to visit on <b>{{ $e->visit_on?->format('d-m-Y') }}</b>.@elseif($e->kind==='offer')Offers <b>TSh {{ number_format(intdiv((int) $e->offer_minor,100)) }}</b>.@endif {{ $e->message }}</p>
<p class="p-muted">{{ $e->created_at->diffForHumans() }}@if($e->reply) · You replied: {{ $e->reply }}@endif</p>
@if($e->status==='open' || ! $e->reply)
<form class="pf" method="post" action="{{ route('landowner.enquiries.reply',$e) }}">@csrf<label for="r{{ $e->id }}">Reply</label><textarea id="r{{ $e->id }}" name="reply" required></textarea>
<div class="p-actions">@if($e->kind!=='message')<button class="button button-primary button-small" name="decision" value="accepted">{{ $e->kind==='offer' ? 'Accept offer' : 'Accept visit' }}</button><button class="button button-danger-quiet button-small" name="decision" value="declined">Decline</button>@else<button class="button button-primary button-small">Send reply</button>@endif</div></form>@endif
@if($e->kind==='offer' && $e->status==='accepted' && $e->listing->land?->tenure==='lease' && \App\Models\FeatureFlag::isEnabled('contracts'))<div class="p-actions"><a class="button button-outline button-small" href="{{ route('landowner.enquiries.lease',$e) }}">Lease draft</a></div>@endif
<form method="post" action="{{ route('me.chat.listing',$e->listing) }}" class="p-actions">@csrf<button class="button button-outline button-small">Open chat</button></form></div>
@empty<div class="p-card">No enquiries yet.</div>@endforelse
@endsection
