@extends('producer.layout')
@section('title', 'Lease draft')
@section('heading', 'Lease draft')
@section('lead', 'A starting template built from the accepted offer. NeAS does not execute leases: have it checked and signed outside the platform (LND-05).')
@section('body')
<article class="p-card" style="max-width:760px;line-height:1.7">
<h2 style="text-align:center">LEASE AGREEMENT (DRAFT)</h2>
<p>This draft is made on ____ / ____ / ________ between <b>{{ $l->owner->name }}</b> (the Lessor) and <b>{{ $e->user->name }}</b> (the Lessee).</p>
<p><b>1. Land.</b> {{ $l->title }}, {{ $l->region?->name }}, about {{ $land->size_acres }} acres, used as {{ str_replace('_',' ',$land->site_type) }}.</p>
<p><b>2. Rent.</b> TSh {{ number_format(intdiv((int) $e->offer_minor,100)) }} per {{ $land->rent_period ?? 'month' }}, payable ____________.</p>
<p><b>3. Term.</b> From ____ / ____ / ________ for ____ years, renewable by written agreement.</p>
<p><b>4. Use.</b> The Lessee will use the land only for ______________ and keep it in good condition.</p>
<p><b>5. Ending.</b> Either party may end the lease with ____ days' written notice.</p>
<p><b>6. Disputes.</b> The parties will first try to agree; otherwise they go to the local land authority or court.</p>
<p style="margin-top:28px">Lessor: ______________________ &nbsp; Lessee: ______________________</p>
<p class="p-muted">This is a template, not legal advice. NeAS is not a party to the lease.</p>
<div class="p-actions"><button class="button button-primary" onclick="window.print()">Print</button></div></article>
@endsection
