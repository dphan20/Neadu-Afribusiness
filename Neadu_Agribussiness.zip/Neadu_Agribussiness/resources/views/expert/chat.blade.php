@extends('expert.layout')
@section('title', 'Chat')
@section('expert')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('expert.chat') }}">← Messages</a><span class="eyebrow">S-42 · COM-01/02</span><h1>{{ $other?->name ?? 'Conversation' }}</h1><p>{{ $case ? 'About case: '.$case->subject : '' }}</p></div>
    <div class="by-row">@if ($case)<a class="button button-outline button-small" href="{{ route('expert.cases.show', $case) }}">Open case</a>@endif
        @if ($voice)<form method="post" action="{{ route('expert.chat.call', $conversation) }}">@csrf<button class="button button-outline button-small">📞 Request voice call</button></form>@if ($other?->phone)<a class="button button-primary button-small" href="tel:+{{ ltrim($other->phone, '+') }}">Call now</a>@endif @endif</div></div>
<section class="panel">
    @include('partials.chat-toolbar', ['area' => 'me', 'conversation' => $conversation])
    <div style="display:grid;gap:8px;min-height:240px;max-height:55vh;overflow:auto">
        @php($thread = $conversation->messagesFor(auth()->user()))
        @forelse ($thread as $m)@include('partials.chat-bubble', ['m' => $m, 'bubble' => 'by-msg', 'area' => 'me'])
        @empty<p class="compact-copy">No messages yet. Introduce yourself and ask for any extra photos you need.</p>@endforelse
        <span id="latest"></span></div>
    <form method="post" action="{{ route('expert.chat.send', $conversation) }}" enctype="multipart/form-data" class="by-form" style="margin-top:14px">@csrf
        <textarea name="body" placeholder="Write a message…" maxlength="2000"></textarea>
        <div class="by-row"><input type="file" name="photo" accept="image/*" style="width:auto;min-height:0;border:0"><button class="button button-primary button-small">Send</button></div></form>
</section>
@endsection
