@extends('producer.layout')
@section('title', 'Case queue')
@section('heading', 'Expert case queue')
@section('lead', 'Producers who asked for your help. Unanswered cases come first.')
@section('body')
<p class="p-muted">{{ $rating ? '★ '.$rating.' from '.$ratingCount.' producer ratings' : 'No ratings yet' }} · <a href="{{ route('advice.feed') }}">Advice feed</a> · <a href="{{ route('me.wallet') }}">Consultation earnings</a></p>
@forelse($cases as $c)<a class="p-card" style="display:block" href="{{ route('expert.case',$c) }}"><b>{{ $c->subject }}</b> <span class="p-tag">{{ $c->expert_reply ? 'Answered' : 'Needs reply' }}</span><p class="p-muted">{{ $c->user?->name }} · AI said: {{ $c->result }} ({{ $c->confidence }}%) · {{ $c->created_at->format('d-m-Y') }}</p></a>@empty<div class="p-card">No cases yet.</div>@endforelse
@endsection
