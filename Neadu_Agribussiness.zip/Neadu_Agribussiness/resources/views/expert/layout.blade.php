@extends('layouts.app')

@section('content')
@php($navItems = [
    ['expert.dashboard', 'Overview'], ['expert.cases', 'Case queue'], ['expert.consultations', 'Consultations'], ['expert.advice', 'My advice'],
    ['expert.chat', 'Messages'], ['expert.earnings', 'Earnings'], ['expert.profile', 'Profile & badge'],
])
<main class="workspace-shell">
    <aside class="workspace-sidebar">
        <div class="workspace-person">
            <span class="avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</span>
            <span><b>{{ auth()->user()->name }}</b><small>{{ \App\Enums\UserRole::Expert->label() }}</small></span>
        </div>
        <nav class="workspace-nav" aria-label="Expert navigation">
            @foreach ($navItems as $i => [$route, $label])
                <a class="{{ request()->routeIs($route.'*') && ($route !== 'expert.dashboard' || request()->routeIs('expert.dashboard')) ? 'active' : '' }}" href="{{ route($route) }}"><span class="nav-mark">{{ str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) }}</span>{{ $label }}</a>
            @endforeach
        </nav>
    </aside>
    <section class="workspace-main">
        @if (session('error'))<div class="flash flash-error" role="alert" style="margin:0 0 14px">{{ session('error') }}</div>@endif
        @yield('expert')
    </section>
</main>
@endsection
