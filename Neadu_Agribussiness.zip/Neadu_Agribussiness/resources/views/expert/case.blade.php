@extends('expert.layout')
@section('title', $case->subject)
@section('expert')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('expert.cases') }}">← Case queue</a><span class="eyebrow">S-37 · DIA-03</span><h1>{{ $case->subject }}</h1>
    <p>From {{ $case->producer?->name ?? 'a producer' }} · {{ ucfirst($case->domain ?? 'crop') }} · {{ ucfirst(str_replace('_', ' ', $case->status)) }}</p></div></div>
@if (session('status'))<div class="flash" role="status" style="margin-bottom:14px">{{ session('status') }}</div>@endif
@error('expert_reply')<div class="flash flash-error" role="alert" style="margin-bottom:14px">{{ $message }}</div>@enderror

<div class="two">
<section class="panel">
    <div class="panel-heading"><div><span class="eyebrow">AI RESULT</span><h2>{{ $case->ai_result ?? $case->result }}</h2></div></div>
    @if ($case->photo_path)<img src="{{ route('expert.cases.photo', $case->uuid) }}" alt="Case photo" style="max-width:320px;border-radius:12px;margin-bottom:10px">@endif
    <p>Confidence {{ $case->confidence ?? '—' }}%</p>
    @if ($case->treatment)<p>{{ $case->treatment }}</p>@endif
    @if ($case->prevention)<p class="compact-copy">{{ $case->prevention }}</p>@endif
    @if ($case->result !== ($case->ai_result ?? $case->result))<p class="compact-copy"><b>Corrected to:</b> {{ $case->result }}</p>@endif
</section>

<section class="panel">
    @if (! $mine)
        <div class="panel-heading"><div><span class="eyebrow">WAITING IN QUEUE</span><h2>Take this case</h2></div></div>
        <p class="compact-copy">Once you take it, no other expert can see or answer it.</p>
        <form method="post" action="{{ route('expert.cases.claim', $case->uuid) }}">@csrf<button class="button button-primary">Take this case</button></form>
    @else
        <div class="panel-heading"><div><span class="eyebrow">YOUR REPLY</span><h2>{{ $case->status === 'answered' ? 'Update reply' : 'Reply to the producer' }}</h2></div></div>
        <form method="post" action="{{ route('expert.cases.reply', $case->uuid) }}" class="by-form">@csrf
            <label>Advice (Kiswahili or English)<textarea name="expert_reply" required minlength="10" maxlength="3000">{{ old('expert_reply', $case->expert_reply) }}</textarea></label>
            <label>Corrected diagnosis (only if the AI was wrong)<input name="corrected_result" maxlength="160" value="{{ old('corrected_result') }}"></label>
            <button class="button button-primary">{{ $case->status === 'answered' ? 'Update reply' : 'Send reply' }}</button>
        </form>
        <form method="post" action="{{ route('expert.chat.start') }}" style="margin-top:10px">@csrf<input type="hidden" name="case" value="{{ $case->uuid }}"><button class="button button-outline button-small">Chat with producer</button></form>
    @endif
</section>
</div>

@if ($mine && $feedbackEnabled)
<section class="panel" style="margin-top:14px">
    <div class="panel-heading"><div><span class="eyebrow">DIA-05</span><h2>Rate the AI result</h2></div></div>
    <form method="post" action="{{ route('expert.cases.feedback', $case->uuid) }}" class="by-form">@csrf
        <label>Verdict<select name="verdict">@foreach (['correct' => 'Correct', 'partial' => 'Partly correct', 'incorrect' => 'Incorrect'] as $k => $v)<option value="{{ $k }}" @selected(($myCorrection?->verdict) === $k)>{{ $v }}</option>@endforeach</select></label>
        <label>Correct diagnosis (if not correct)<input name="corrected_result" maxlength="160" value="{{ old('corrected_result', $myCorrection?->corrected_result) }}"></label>
        <label>Notes<textarea name="notes" maxlength="1000">{{ old('notes', $myCorrection?->notes) }}</textarea></label>
        <button class="button button-outline">Save assessment</button>
    </form>
</section>
@endif

@if ($mine)
<section class="panel" style="margin-top:14px">
    <div class="panel-heading"><div><span class="eyebrow">PAID CONSULTATION</span><h2>Offer a follow-up</h2></div></div>
    @if ($consultation)<p class="compact-copy">Latest offer: {{ $consultation->topic }} · {{ ucfirst($consultation->status) }} · <a class="text-link" href="{{ route('expert.consultations') }}">Manage</a></p>@endif
    <form method="post" action="{{ route('expert.cases.consultation', $case->uuid) }}" class="by-form">@csrf
        <label>Topic<input name="topic" required maxlength="160" value="{{ old('topic', 'Follow up: '.$case->subject) }}"></label>
        <div class="two"><label>Mode<select name="mode"><option value="chat">Chat</option><option value="voice">Voice</option></select></label>
        <label>Fee (TZS)<input type="number" name="fee" min="500" max="5000000" required value="{{ old('fee', intdiv($fee, 100)) }}"></label></div>
        <button class="button button-outline">Offer consultation</button>
    </form>
</section>
@endif
@endsection
