@extends('expert.layout')
@section('title', 'Consultations')
@section('expert')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('expert.dashboard') }}">← Overview</a><span class="eyebrow">EARN · CONSULTATIONS</span><h1>Consultations</h1><p>Paid advice sessions. The fee is held in escrow and released to you when you complete the session (platform fee {{ $feeBps / 100 }}%).</p></div></div>
<section class="panel data-panel">
    @if ($items->isEmpty())<div class="empty-state"><span class="empty-mark">0</span><h3>No consultations yet</h3><p>Producers can request one, or you can offer one from a case.</p></div>
    @else<div class="table-wrap"><table class="data-table"><thead><tr><th>Topic</th><th>Producer</th><th>Mode</th><th>Fee</th><th>Status</th><th>Payment</th><th></th></tr></thead><tbody>
        @foreach ($items as $c)<tr><td><b>{{ $c->topic }}</b>@if ($c->diagnosisCase)<br><small><a class="text-link" href="{{ route('expert.cases.show', $c->diagnosisCase) }}">Case: {{ $c->diagnosisCase->subject }}</a></small>@endif</td><td>{{ $c->producer?->name }}</td><td>{{ ucfirst($c->mode) }}</td><td>{{ \App\Support\Money::tzs($c->fee_minor) }}</td>
        <td><span class="by-chip st-{{ $c->status === 'completed' ? 'released' : ($c->status === 'declined' ? 'refunded' : 'pending') }}">{{ ucfirst($c->status) }}</span></td><td>{{ ucfirst($c->payment_state) }}</td>
        <td><div class="by-row">
            @if ($c->status === 'requested')
                <form method="post" action="{{ route('expert.consultations.respond', $c->uuid) }}">@csrf<input type="hidden" name="action" value="accept"><button class="button button-tiny button-primary">Accept</button></form>
                <form method="post" action="{{ route('expert.consultations.respond', $c->uuid) }}">@csrf<input type="hidden" name="action" value="decline"><button class="button button-tiny button-danger-quiet">Decline</button></form>
            @elseif ($c->status === 'accepted')
                <form method="post" action="{{ route('expert.consultations.complete', $c->uuid) }}" onsubmit="return confirm('Mark as completed and release the fee to your balance?')">@csrf<button class="button button-tiny button-primary" @disabled($c->payment_state !== 'held')>Complete</button></form>
                @if ($simulate && $c->payment_state === 'unpaid')<form method="post" action="{{ route('expert.consultations.simulate') }}">@csrf<input type="hidden" name="action" value="pay"><input type="hidden" name="uuid" value="{{ $c->uuid }}"><button class="button button-tiny button-outline">Demo: producer pays</button></form>@endif
            @elseif ($c->status === 'completed' && $simulate)
                <form method="post" action="{{ route('expert.consultations.simulate') }}">@csrf<input type="hidden" name="action" value="review"><input type="hidden" name="uuid" value="{{ $c->uuid }}"><button class="button button-tiny button-outline">Demo: producer rates</button></form>
            @endif</div></td></tr>@endforeach
    </tbody></table></div>@endif
</section>
@if ($simulate)<section class="by-demo" style="margin-top:14px"><b>Demo mode</b> — acts as a producer until the producer app is connected. <form method="post" action="{{ route('expert.consultations.simulate') }}" style="display:inline">@csrf<input type="hidden" name="action" value="request"><button class="button button-tiny button-outline">Simulate a consultation request</button></form></section>@endif
@endsection
