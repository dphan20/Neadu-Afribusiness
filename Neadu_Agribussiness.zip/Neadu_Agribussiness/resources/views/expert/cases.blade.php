@extends('expert.layout')
@section('title', 'Case queue')
@section('expert')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('expert.dashboard') }}">← Overview</a><span class="eyebrow">S-37 · DIA-03</span><h1>Case queue</h1><p>Cases the AI could not settle. Take one, review the AI result and reply.</p></div></div>
<section class="panel data-panel">
    <div class="by-row" style="padding:12px 16px;border-bottom:1px solid var(--color-border)">
        @foreach (['new' => 'New', 'mine' => 'My open cases', 'answered' => 'Answered'] as $k => $label)
            <a class="button button-small {{ $tab === $k ? 'button-primary' : 'button-outline' }}" href="{{ route('expert.cases', array_filter(['tab' => $k, 'domain' => $f['domain'] ?? null, 'q' => $f['q'] ?? null])) }}">{{ $label }} ({{ $counts[$k] }})</a>
        @endforeach
    </div>
    <form method="get" class="filter-bar"><input type="hidden" name="tab" value="{{ $tab }}">
        <label class="filter-search"><span class="sr-only">Search</span><input name="q" value="{{ $f['q'] ?? '' }}" placeholder="Search subject or AI result"></label>
        <label><span class="sr-only">Domain</span><select name="domain"><option value="">All domains</option>@foreach (\App\Http\Controllers\ExpertController::DOMAINS as $k => $v)<option value="{{ $k }}" @selected(($f['domain'] ?? '') === $k)>{{ $v }}</option>@endforeach</select></label>
        <button class="button button-primary button-small">Filter</button></form>
    @if ($cases->isEmpty())<div class="empty-state"><span class="empty-mark">0</span><h3>No cases here</h3><p>{{ $tab === 'new' ? 'Nothing is waiting for review right now.' : 'Nothing in this list yet.' }}</p></div>
    @else<div class="table-wrap"><table class="data-table"><thead><tr><th>Subject</th><th>Domain</th><th>AI result</th><th>Confidence</th><th>Producer</th><th>Received</th><th></th></tr></thead><tbody>
        @foreach ($cases as $c)<tr><td><b>{{ $c->subject }}</b></td><td>{{ \App\Http\Controllers\ExpertController::DOMAINS[$c->domain] ?? $c->domain }}</td><td>{{ $c->result ?? '—' }}</td>
        <td>@if ($c->confidence !== null)<span class="by-chip {{ $c->confidence < 60 ? 'st-pending' : '' }}">{{ $c->confidence }}%</span>@else — @endif</td><td>{{ $c->producer?->name }}</td><td>{{ $c->created_at?->diffForHumans() }}</td>
        <td><a class="button button-tiny button-primary" href="{{ route('expert.cases.show', $c) }}">{{ $tab === 'new' ? 'Review' : 'Open' }}</a></td></tr>@endforeach
    </tbody></table></div>@endif
</section>
@endsection
