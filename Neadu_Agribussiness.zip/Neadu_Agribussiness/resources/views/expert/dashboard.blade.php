@extends('expert.layout')
@section('title', 'Expert workspace')
@section('expert')
<div class="workspace-heading"><div><span class="eyebrow">Mtaalamu</span><h1>Karibu, {{ explode(' ', auth()->user()->name)[0] }}</h1><p>Review escalated cases, advise producers and earn from consultations.</p></div>
    <span class="by-chip" style="font-size:14px">{{ $badge['label'] }}</span></div>
<div class="metric-grid">
    @foreach ($metrics as $m)<article class="metric-card metric-{{ $m['tone'] }}"><span class="metric-label">{{ $m['label'] }}</span><strong>{{ $m['value'] }}</strong><span class="metric-caption">Expert workspace</span></article>@endforeach
</div>
<div class="workspace-columns">
    <section class="panel panel-main">
        <div class="panel-heading"><div><span class="eyebrow">S-37 · ESCALATED BY AI</span><h2>Newest cases waiting</h2></div><a class="text-link" href="{{ route('expert.cases') }}">Open queue →</a></div>
        @forelse ($queue as $c)
            <a href="{{ route('expert.cases.show', $c) }}" style="display:flex;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid var(--color-border)">
                <span><b>{{ $c->subject }}</b><br><small>AI: {{ $c->result ?? 'No result' }}{{ $c->confidence !== null ? ' · '.$c->confidence.'%' : '' }}</small></span><span><small>{{ $c->created_at?->diffForHumans() }}</small></span></a>
        @empty<div class="empty-state"><span class="empty-mark">✓</span><h3>Queue is clear</h3><p>New escalated cases appear here.</p></div>@endforelse
    </section>
    <aside class="panel guidance-panel"><span class="guidance-icon">E</span><span class="eyebrow">CONSULTATIONS</span><h2>Needs you</h2>
        @forelse ($consultations as $c)<p><a class="text-link" href="{{ route('expert.consultations') }}">{{ $c->topic }}</a><br><small>{{ $c->producer?->name }} · {{ ucfirst($c->status) }}</small></p>@empty<p class="compact-copy">No open consultation requests.</p>@endforelse
        <p class="compact-copy">{{ $badge['hint'] }}</p>
    </aside>
</div>
@endsection
