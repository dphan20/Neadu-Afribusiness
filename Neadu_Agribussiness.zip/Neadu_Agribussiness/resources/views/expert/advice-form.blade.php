@extends('expert.layout')
@section('title', $post ? 'Edit advice' : 'Write advice')
@section('expert')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('expert.advice') }}">← My advice</a><span class="eyebrow">PUBLISH ADVICE</span><h1>{{ $post ? 'Edit advice' : 'Write advice' }}</h1></div></div>
@error('intent')<div class="flash flash-error" role="alert" style="margin-bottom:14px">{{ $message }}</div>@enderror
<section class="panel" style="max-width:820px">
    <form method="post" action="{{ $post ? route('expert.advice.update', $post->uuid) : route('expert.advice.store') }}" class="by-form">@csrf @if ($post) @method('PUT') @endif
        <label>Title<input name="title" required maxlength="160" value="{{ old('title', $post?->title) }}"></label>
        <div class="two"><label>Domain<select name="domain">@foreach (\App\Http\Controllers\ExpertController::DOMAINS as $k => $v)<option value="{{ $k }}" @selected(old('domain', $post?->domain) === $k)>{{ $v }}</option>@endforeach</select></label>
            <label>Language<select name="language"><option value="sw" @selected(old('language', $post?->language) === 'sw')>Kiswahili</option><option value="en" @selected(old('language', $post?->language) === 'en')>English</option></select></label></div>
        <div class="two"><label>Crop (optional)<select name="crop_id"><option value="">—</option>@foreach ($crops as $c)<option value="{{ $c->id }}" @selected((string) old('crop_id', $post?->crop_id) === (string) $c->id)>{{ $c->name_en }} / {{ $c->name_sw }}</option>@endforeach</select></label>
            <label>Region (optional)<select name="region_id"><option value="">All regions</option>@foreach ($regions as $r)<option value="{{ $r->id }}" @selected((string) old('region_id', $post?->region_id) === (string) $r->id)>{{ $r->name }}</option>@endforeach</select></label></div>
        <label>Advice<textarea name="body" required minlength="30" maxlength="8000" style="min-height:260px">{{ old('body', $post?->body) }}</textarea></label>
        <div class="by-row"><button class="button button-outline" name="intent" value="draft">Save draft</button><button class="button button-primary" name="intent" value="publish" @disabled(! $verified)>Publish</button></div>
        @unless ($verified)<p class="compact-copy">Publishing is available once your identity is verified.</p>@endunless
    </form>
</section>
@endsection
