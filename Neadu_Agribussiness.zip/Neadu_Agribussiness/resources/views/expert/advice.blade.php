@extends('expert.layout')
@section('title', 'My advice')
@section('expert')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('expert.dashboard') }}">← Overview</a><span class="eyebrow">PUBLISH ADVICE</span><h1>My advice</h1><p>Tips every signed-in user can read in the <a class="text-link" href="{{ route('advice.feed') }}">advice feed</a>.</p></div>
    <a class="button button-primary" href="{{ route('expert.advice.create') }}">Write advice</a></div>
@if (session('status'))<div class="flash" role="status" style="margin-bottom:14px">{{ session('status') }}</div>@endif
@unless ($verified)<div class="flash" style="margin-bottom:14px">Drafts are always allowed. Publishing needs a verified identity.</div>@endunless
@forelse ($posts as $p)
<section class="panel" style="margin-bottom:12px">
    <b>{{ $p->title }}</b> <span class="p-tag">{{ ucfirst($p->domain) }}</span> <span class="p-tag">{{ ucfirst($p->status) }}</span>
    @if ($p->crop)<span class="p-tag">{{ $p->crop->name_en }}</span>@endif
    <p class="compact-copy">{{ \Illuminate\Support\Str::limit($p->body, 220) }}</p>
    <div class="by-row">
        <a class="button button-outline button-small" href="{{ route('expert.advice.edit', $p->uuid) }}">Edit</a>
        <form method="post" action="{{ route('expert.advice.toggle', $p->uuid) }}">@csrf<button class="button button-outline button-small">{{ $p->status === 'published' ? 'Unpublish' : 'Publish' }}</button></form>
        <form method="post" action="{{ route('expert.advice.delete', $p->uuid) }}" onsubmit="return confirm('Delete this advice?')">@csrf @method('DELETE')<button class="button button-danger-quiet button-small">Delete</button></form>
    </div>
</section>
@empty
<div class="empty-state"><span class="empty-mark">✎</span><h3>No advice yet</h3><p>Write your first tip for producers.</p></div>
@endforelse
@endsection
