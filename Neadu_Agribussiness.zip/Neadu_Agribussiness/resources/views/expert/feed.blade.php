@extends('producer.layout')
@section('title', 'Advice')
@section('heading', 'Expert advice')
@section('lead', 'Tips from verified agricultural, livestock and fisheries experts.')
@section('body')
@forelse($posts as $p)<div class="p-card"><b>{{ $p->title }}</b> <span class="p-tag">{{ ucfirst($p->domain) }}</span>@if($p->crop) <span class="p-tag">{{ $p->crop->name_en }}</span>@endif<p>{{ $p->body }}</p><p class="p-muted">{{ $p->expert?->name }} · {{ $p->published_at?->format('d-m-Y') }}</p></div>@empty<div class="p-card">No advice has been published yet.</div>@endforelse
{{ $posts->links() }}
@endsection
