@extends('expert.layout')
@section('title', 'Messages')
@section('expert')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('expert.dashboard') }}">← Overview</a><span class="eyebrow">S-42 · COM-01</span><h1>Messages</h1><p>Chat with producers about their cases.</p></div></div>
<p><a class="button button-primary button-small" href="{{ route('me.chat.new') }}">✉ {{ __('chat.new_message') }}</a></p>
<section class="panel">
    @forelse ($conversations as $c)@php($other = $c->participants->firstWhere('id', '!=', auth()->id()))@php($last = $c->messages->last())
        <a href="{{ route('expert.chat.show', $c) }}" style="display:flex;justify-content:space-between;gap:10px;padding:12px 0;border-bottom:1px solid var(--color-border)">
            <span><b>{{ $other?->name ?? 'Conversation' }}</b><br><small>{{ $c->diagnosis_case_id && isset($cases[$c->diagnosis_case_id]) ? 'Case · '.$cases[$c->diagnosis_case_id]->subject : '' }}</small></span>
            <span style="text-align:right"><small>{{ $last ? ($last->kind === 'call' ? '📞 Call request' : \Illuminate\Support\Str::limit($last->body ?? '📷 Photo', 40)) : 'No messages yet' }}</small><br><small>{{ $c->updated_at?->diffForHumans() }}</small></span></a>
    @empty<div class="empty-state"><span class="empty-mark">✉</span><h3>No conversations</h3><p>Open a case you have taken and choose “Chat with producer”.</p><a class="button button-primary button-small" href="{{ route('expert.cases') }}">Case queue</a></div>@endforelse
</section>
@endsection
