@extends('expert.layout')
@section('title', 'Profile & badge')
@section('expert')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('expert.dashboard') }}">← Overview</a><span class="eyebrow">S-44 · ACC-05</span><h1>Profile &amp; badge</h1><p>What producers see when they choose an expert.</p></div></div>
<div class="by-split">
    <div class="by-stack">
        <section class="panel">
            <div class="by-row" style="gap:14px"><span class="avatar" style="width:56px;height:56px;font-size:24px">{{ strtoupper(substr($me->name, 0, 1)) }}</span>
                <span><b style="font-size:18px">{{ $me->name }}</b><br><span class="by-chip">{{ $me->isIdentityVerified() ? '✓ ' : '' }}{{ $badge['label'] }}</span></span></div>
            <p class="compact-copy" style="margin-top:10px">{{ $badge['hint'] }}</p>
            <dl class="by-kv" style="margin-top:12px"><dt>Rating</dt><dd>@if ($stats['reviews'])<span class="by-stars">{{ str_repeat('★', (int) round($stats['avg'])) }}{{ str_repeat('☆', 5 - (int) round($stats['avg'])) }}</span> {{ $stats['avg'] }} ({{ $stats['reviews'] }})@else No ratings yet @endif</dd>
                <dt>Cases answered</dt><dd>{{ $stats['answered'] }}</dd><dt>Consultations</dt><dd>{{ $stats['consultations'] }}</dd></dl>
        </section>
        <section class="panel data-panel"><div class="panel-heading"><div><span class="eyebrow">REVIEWS</span><h2>What producers say</h2></div></div>
            @forelse ($reviews as $r)<div style="padding:12px 16px;border-bottom:1px solid var(--color-border)"><span class="by-stars">{{ str_repeat('★', $r->stars) }}{{ str_repeat('☆', 5 - $r->stars) }}</span> <small>{{ $r->producer?->name }} · {{ $r->created_at?->format('d M Y') }}</small><p style="margin:4px 0 0">{{ $r->comment }}</p></div>
            @empty<div class="empty-state"><h3>No reviews yet</h3><p>Ratings appear after producers review a case or consultation.</p></div>@endforelse</section>
    </div>
    <aside class="panel"><span class="eyebrow">EDIT PROFILE</span>
        <form method="post" action="{{ route('expert.profile.update') }}" enctype="multipart/form-data" class="by-form" style="margin-top:8px">@csrf
            <label>Specialties</label>
            <div class="by-row">@foreach (\App\Http\Controllers\ExpertController::DOMAINS as $k => $v)<label style="display:flex;gap:6px;align-items:center;font-weight:500"><input type="checkbox" name="specialties[]" value="{{ $k }}" style="width:auto;min-height:0" @checked(in_array($k, old('specialties', $data['specialties'] ?? []), true))> {{ $v }}</label>@endforeach</div>
            @error('specialties')<small style="color:var(--color-error)">{{ $message }}</small>@enderror
            <label>About you<textarea name="bio" maxlength="800">{{ old('bio', $data['bio'] ?? '') }}</textarea></label>
            <div class="two"><label>Years of experience<input type="number" name="years" min="0" max="60" value="{{ old('years', $data['years'] ?? '') }}"></label><label>Consultation fee (TZS)<input type="number" name="fee" min="500" step="any" required value="{{ old('fee', intdiv((int) ($data['fee_minor'] ?? 500000), 100)) }}"></label></div>
            <label>Home region<select name="region_id"><option value="">—</option>@foreach ($regions as $r)<option value="{{ $r->id }}">{{ $r->name }}</option>@endforeach</select></label>
            <label>Credentials (PDF or photo, up to 5)<input type="file" name="credentials[]" multiple accept=".pdf,image/*"></label>
            <p class="compact-copy">{{ count($credentials) }} document(s) on file. Documents are stored privately and only used for verification.</p>
            <button class="button button-primary button-full">Save profile</button></form></aside>
</div>
@endsection
