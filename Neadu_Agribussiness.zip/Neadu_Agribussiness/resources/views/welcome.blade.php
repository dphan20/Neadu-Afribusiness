@extends('layouts.app')

@section('title', 'Trade agricultural produce with confidence')
@section('meta_description', 'Sell and buy crops, livestock and fish across Tanzania with verified participants, escrow-protected payments, transport, storage and expert advice in Kiswahili and English.')

@push('head')
<link rel="stylesheet" href="{{ asset('css/landing.css') }}?v={{ filemtime(public_path('css/landing.css')) }}">
<script type="application/ld+json">{!! json_encode([
    '@context' => 'https://schema.org',
    '@graph' => [
        ['@type' => 'Organization', 'name' => 'NeAS - Neadu Agribusiness System', 'url' => route('home'), 'areaServed' => 'TZ',
            'description' => 'Agribusiness marketplace connecting Tanzanian farmers, buyers, transporters, warehouses and experts with escrow payments.'],
        ['@type' => 'WebSite', 'name' => 'NeAS', 'url' => route('home'), 'inLanguage' => ['sw', 'en']],
    ],
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>
@endpush

@php
    $roleInfo = [
        'P' => ['sprout', 'List crops, livestock and fish. Reply to orders and get paid through escrow.'],
        'B' => ['cart', 'Find verified sellers, order, pay into escrow and track the delivery.'],
        'E' => ['sparkle', 'Answer farmers\' cases, publish advice and earn consultation fees.'],
        'G' => ['book', 'Run agri-tours and training. Issue certificates to attendees.'],
        'T' => ['truck', 'Take delivery jobs, share live location and get paid on delivery.'],
        'L' => ['map', 'List farmland and sites for lease. Receive enquiries and offers.'],
        'W' => ['box', 'List storage space, accept bookings and issue receipts.'],
        'R' => ['chart', 'Trade in volume, or offer agri-technology and machinery, to farmers and buyers.'],
    ];
    $autoHours = (int) config('neas.order.auto_release_hours', 48);
@endphp

@section('content')
<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">
    <defs>
        <symbol id="i-sprout" viewBox="0 0 24 24"><path d="M12 21v-8M12 13c0-4 3-6 7-6 0 4-3 6-7 6zM12 15c0-3-2-5-6-5 0 3 2 5 6 5z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></symbol>
        <symbol id="i-cart" viewBox="0 0 24 24"><path d="M3 4h2l2.4 10.2a1 1 0 001 .8h8.5a1 1 0 001-.8L20 8H6.2M9.5 20h.01M17 20h.01" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></symbol>
        <symbol id="i-sparkle" viewBox="0 0 24 24"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></symbol>
        <symbol id="i-book" viewBox="0 0 24 24"><path d="M4 5.5A2.5 2.5 0 016.5 3H20v15H6.5A2.5 2.5 0 004 20.5zM4 20.5A2.5 2.5 0 006.5 23H20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></symbol>
        <symbol id="i-truck" viewBox="0 0 24 24"><path d="M2 6h11v10H2zM13 10h4l3 3v3h-7zM6.5 19.5h.01M17 19.5h.01" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></symbol>
        <symbol id="i-map" viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-11.5A7 7 0 005 9.5C5 14.8 12 21 12 21zM12 12a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></symbol>
        <symbol id="i-box" viewBox="0 0 24 24"><path d="M3 8l9-5 9 5v8l-9 5-9-5zM3 8l9 5 9-5M12 13v8" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></symbol>
        <symbol id="i-chart" viewBox="0 0 24 24"><path d="M4 20V4M4 20h16M8 16v-4M12 16V8M16 16v-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></symbol>
        <symbol id="i-shield" viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6zM8.5 12l2.5 2.5 4.5-5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></symbol>
        <symbol id="i-sun" viewBox="0 0 24 24"><path d="M12 4V2M12 22v-2M4 12H2M22 12h-2M6.3 6.3L4.9 4.9M19.1 19.1l-1.4-1.4M17.7 6.3l1.4-1.4M4.9 19.1l1.4-1.4M12 17a5 5 0 100-10 5 5 0 000 10z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></symbol>
        <symbol id="i-check" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></symbol>
    </defs>
</svg>

<main class="lp">
    {{-- 1. HERO: what it is, who it is for, what to do next --}}
    <section class="lp-hero">
        <div class="lp-hero-copy">
            <span class="lp-eyebrow">Tanzania's connected agriculture network</span>
            <h1>Sell, buy and move farm produce <em>safely</em>.</h1>
            <p class="lp-lead">NeAS brings farmers, buyers, transporters, storage owners and experts into one platform. Every order is paid through escrow, so money moves only when the goods arrive.</p>
            <div class="lp-actions">
                <a class="button button-primary" href="{{ route('register') }}">Create free account</a>
                <a class="button button-outline" href="{{ route('login') }}">Sign in</a>
                <button type="button" class="button button-quiet" data-pwa-install hidden>Install app</button>
            </div>
            <ul class="lp-checks">
                <li><svg><use href="#i-check"/></svg> Verified participants</li>
                <li><svg><use href="#i-check"/></svg> Escrow-protected payments</li>
                <li><svg><use href="#i-check"/></svg> Kiswahili and English</li>
            </ul>
        </div>
        <div class="lp-hero-visual">@include('partials.landing-slideshow')</div>
    </section>

    {{-- 2. Page map: lets a visitor jump straight to what they care about --}}
    <nav class="lp-jump" aria-label="On this page">
        <a href="#how">How it works</a><a href="#escrow">Payment protection</a><a href="#roles">Who it is for</a><a href="#features">Features</a><a href="#faq">Questions</a>
    </nav>

    {{-- 3. HOW IT WORKS: the whole journey in four steps --}}
    <section class="lp-section" id="how" aria-labelledby="how-t">
        <header class="lp-head"><span class="lp-eyebrow">HOW IT WORKS</span><h2 id="how-t">From sign-up to payout in four steps</h2></header>
        <ol class="lp-steps">
            <li><span class="lp-n">1</span><h3>Create your account</h3><p>Register with your phone number and choose your role. You can add more roles later and switch workspaces.</p></li>
            <li><span class="lp-n">2</span><h3>Get verified</h3><p>Confirm your identity once. Verified accounts can publish listings, accept orders and withdraw money.</p></li>
            <li><span class="lp-n">3</span><h3>List, find, order</h3><p>Producers list produce. Buyers search, compare and order. Add transport or storage in the same order.</p></li>
            <li><span class="lp-n">4</span><h3>Pay safely, get paid</h3><p>The buyer pays into escrow. After delivery is confirmed, the seller is paid to mobile money or bank.</p></li>
        </ol>
    </section>

    {{-- 4. ESCROW: the one thing buyers and sellers worry about, shown step by step --}}
    <section class="lp-section lp-tint" id="escrow" aria-labelledby="esc-t">
        <header class="lp-head"><span class="lp-eyebrow">PAYMENT PROTECTION</span><h2 id="esc-t">How your money is protected</h2>
            <p>NeAS holds the payment until the goods are delivered. Neither side has to trust the other first.</p></header>
        <ol class="lp-flow">
            <li><b>Buyer pays</b><span>Mobile money or bank, into escrow</span></li>
            <li><b>NeAS holds it</b><span>The seller sees the payment is secured</span></li>
            <li><b>Goods delivered</b><span>By the seller or a booked transporter</span></li>
            <li><b>Buyer confirms</b><span>Or it releases automatically after {{ $autoHours }} hours</span></li>
            <li><b>Seller is paid</b><span>Minus a small platform fee</span></li>
        </ol>
        <p class="lp-note"><svg><use href="#i-shield"/></svg> Something wrong? Open a dispute with photos. The money stays held until an administrator decides, within {{ (int) config('neas.dispute.decide_working_days', 5) }} working days.</p>
    </section>

    {{-- 5. ROLES --}}
    <section class="lp-section" id="roles" aria-labelledby="roles-t">
        <header class="lp-head"><span class="lp-eyebrow">WHO IT IS FOR</span><h2 id="roles-t">One platform, eight ways to take part</h2>
            <p>Pick the role that matches your work. Many people use more than one.</p></header>
        <div class="lp-roles">
            @foreach (\App\Enums\UserRole::cases() as $role)
                @continue($role === \App\Enums\UserRole::Admin)
                @php([$icon, $text] = $roleInfo[$role->value] ?? ['sprout', ''])
                <article class="lp-role">
                    <svg class="lp-ico"><use href="#i-{{ $icon }}"/></svg>
                    <h3>{{ $role->label() }} <small>{{ $role->swahiliLabel() }}</small></h3>
                    <p>{{ $text }}</p>
                </article>
            @endforeach
        </div>
        <p class="lp-center"><a class="button button-primary" href="{{ route('register') }}">Choose your role and start</a></p>
    </section>

    {{-- 6. FEATURES --}}
    <section class="lp-section lp-tint" id="features" aria-labelledby="feat-t">
        <header class="lp-head"><span class="lp-eyebrow">WHAT YOU GET</span><h2 id="feat-t">Everything around the sale, in one place</h2></header>
        <div class="lp-features">
            <article><svg class="lp-ico"><use href="#i-cart"/></svg><h3>Marketplace</h3><p>Search produce by crop, region and price. Save favourites and set price alerts.</p></article>
            <article><svg class="lp-ico"><use href="#i-shield"/></svg><h3>Escrow and disputes</h3><p>Payments are held, tracked and released by clear rules. Every step is recorded.</p></article>
            <article><svg class="lp-ico"><use href="#i-truck"/></svg><h3>Transport with live tracking</h3><p>Book a verified transporter and follow the delivery on a map.</p></article>
            <article><svg class="lp-ico"><use href="#i-box"/></svg><h3>Storage and land</h3><p>Find warehouses, cold rooms and farmland, with documents checked by NeAS.</p></article>
            <article><svg class="lp-ico"><use href="#i-sparkle"/></svg><h3>AI crop and animal help</h3><p>Send a photo, get an answer in Kiswahili, and escalate to a human expert when unsure.</p></article>
            <article><svg class="lp-ico"><use href="#i-sun"/></svg><h3>Weather and prices</h3><p>Local forecasts, severe weather alerts and current market prices for your region.</p></article>
        </div>
    </section>

    {{-- 7. REAL PICTURES --}}
    @include('partials.landing-gallery')

    {{-- 8. QUESTIONS --}}
    <section class="lp-section" id="faq" aria-labelledby="faq-t">
        <header class="lp-head"><span class="lp-eyebrow">QUESTIONS</span><h2 id="faq-t">Before you sign up</h2></header>
        <div class="lp-faq">
            <details><summary>Who can join?</summary><p>Producers, buyers, traders, transporters, experts, trainers, land owners and warehouse owners. Registration needs a phone number.</p></details>
            <details><summary>When does the seller get paid?</summary><p>After the buyer confirms delivery, or automatically {{ $autoHours }} hours after delivery if the buyer does not respond and there is no dispute.</p></details>
            <details><summary>Does it work on my phone?</summary><p>Yes. NeAS is built for phones and can be installed on your home screen like an app. Payments and orders need an internet connection.</p></details>
            <details><summary>Which languages are supported?</summary><p>Kiswahili and English, including the AI assistant and crop diagnosis.</p></details>
            <details><summary>What does it cost?</summary><p>Creating an account is free. A small platform fee is deducted from completed orders. The exact fee is shown before you confirm.</p></details>
        </div>
    </section>

    {{-- 9. FINAL CALL TO ACTION --}}
    <section class="lp-cta">
        <div><h2>Ready to trade with confidence?</h2><p>Create your account in a few minutes.</p></div>
        <div class="lp-actions"><a class="button button-gold" href="{{ route('register') }}">Get started</a><button type="button" class="button button-glass" data-pwa-install hidden>Install app</button></div>
    </section>
</main>
@endsection
