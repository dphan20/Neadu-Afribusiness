{{-- PWA: manifest, icons, theme. The script/styles are plain files in /public so the service worker can precache them. --}}
<link rel="manifest" href="{{ asset('manifest.webmanifest') }}">
<link rel="icon" type="image/png" sizes="32x32" href="{{ asset('icons/favicon-32.png') }}">
<link rel="apple-touch-icon" href="{{ asset('icons/apple-touch-icon.png') }}">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="NeAS">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="stylesheet" href="{{ asset('css/pwa.css') }}?v={{ filemtime(public_path('css/pwa.css')) }}">
<script src="{{ asset('js/pwa.js') }}?v={{ filemtime(public_path('js/pwa.js')) }}" defer></script>
{{-- Keep the browser's install event: it fires once, possibly before pwa.js runs. --}}
<script>window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); window.__neasInstall = e; });</script>
<link rel="stylesheet" href="/css/ai.css?v={{ filemtime(public_path('css/ai.css')) }}">
<script src="/js/voice.js?v={{ filemtime(public_path('js/voice.js')) }}" defer></script>
<script src="/js/ai.js?v={{ filemtime(public_path('js/ai.js')) }}" defer></script>
