@php
        $manifestPath = public_path('build/manifest.json');
        $manifest = is_file($manifestPath) ? json_decode(file_get_contents($manifestPath), true) : [];
        $hotFile = public_path('hot');
        $hotServer = is_file($hotFile) ? trim(file_get_contents($hotFile)) : '';
        $hotHost = $hotServer !== '' ? parse_url($hotServer, PHP_URL_HOST) : null;
        $usableHotServer = $hotHost !== null && ! in_array(trim($hotHost, '[]'), ['::', '0.0.0.0'], true);
    @endphp
    @if ($usableHotServer)
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @elseif (isset($manifest['resources/css/app.css']['file'], $manifest['resources/js/app.js']['file']))
        <link rel="stylesheet" href="{{ asset('build/'.$manifest['resources/css/app.css']['file']) }}">
        <script type="module" src="{{ asset('build/'.$manifest['resources/js/app.js']['file']) }}"></script>
    @endif
