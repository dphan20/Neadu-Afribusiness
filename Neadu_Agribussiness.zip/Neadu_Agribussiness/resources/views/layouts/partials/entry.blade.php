@php
    // Loads one extra Vite entry (and the CSS it imports) on pages that need it. Same dev/build logic as layouts.partials.assets.
    $entryManifestPath = public_path('build/manifest.json');
    $entryManifest = is_file($entryManifestPath) ? json_decode(file_get_contents($entryManifestPath), true) : [];
    $entryHot = public_path('hot');
    $entryHotServer = is_file($entryHot) ? trim(file_get_contents($entryHot)) : '';
    $entryHotHost = $entryHotServer !== '' ? parse_url($entryHotServer, PHP_URL_HOST) : null;
    $entryUsesHot = $entryHotHost !== null && ! in_array(trim($entryHotHost, '[]'), ['::', '0.0.0.0'], true);
@endphp
@if ($entryUsesHot)
    @vite([$entry])
@elseif (isset($entryManifest[$entry]['file']))
    @foreach (($entryManifest[$entry]['css'] ?? []) as $entryCss)
        <link rel="stylesheet" href="{{ asset('build/'.$entryCss) }}">
    @endforeach
    <script type="module" src="{{ asset('build/'.$entryManifest[$entry]['file']) }}"></script>
@endif
