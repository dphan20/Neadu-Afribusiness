@auth
@unless (request()->routeIs('me.ask'))
<button type="button" class="ai-fab" data-ai-open aria-haspopup="dialog" aria-label="Ask AI">@include('layouts.partials.icon-sparkles')<span>Ask AI</span></button>
<dialog class="ai-dialog" id="ai-dialog" aria-labelledby="ai-title">
    <form class="ai-form" method="post" action="{{ route('me.ask.send') }}" enctype="multipart/form-data" data-ask-stream="#ai-out" data-ask-url="{{ route('me.ask.stream') }}">
        @csrf
        <input type="hidden" name="page" value="{{ request()->path() }}">
        <header class="ai-head">
            <span class="ai-badge">@include('layouts.partials.icon-sparkles')</span>
            <div><h2 id="ai-title">NeAS AI</h2><p>Ask in Kiswahili or English</p></div>
            <button type="button" class="ai-x" data-ai-close aria-label="Close">&times;</button>
        </header>
        <div class="ai-thread" id="ai-out" aria-live="polite">
            <div class="ai-empty">
                <b>How can I help?</b>
                <div class="ai-chips">
                    <button type="button" data-ai-suggest="What is wrong with my crop? I will add a photo.">Sick crop</button>
                    <button type="button" data-ai-suggest="Bei ya mahindi leo ni kiasi gani?">Bei ya mahindi</button>
                    <button type="button" data-ai-suggest="How can I store my harvest to avoid losses?">Storing harvest</button>
                    <button type="button" data-ai-suggest="Ninawezaje kupata mnunuzi wa mazao yangu?">Find a buyer</button>
                </div>
            </div>
        </div>
        @include('me.partials.ai-composer', ['id' => 'ai'])
        <footer class="ai-foot"><a href="{{ route('me.ask') }}">All my answers</a><span>AI can be wrong. Check medicine and dosing with an expert.</span></footer>
    </form>
</dialog>
@endunless
@endauth
