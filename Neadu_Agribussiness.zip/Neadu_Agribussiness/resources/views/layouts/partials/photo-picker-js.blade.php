@auth
<script>
(function () {
    function setFile(box, file) {
        if (!file || !/^image\//.test(file.type)) { return; }
        var dt = new DataTransfer(); dt.items.add(file);
        box.querySelector('[data-pp-file]').files = dt.files;
        box.querySelector('[data-pp-name]').textContent = file.name + ' (' + Math.round(file.size / 1024) + ' KB)';
        var img = box.querySelector('[data-pp-preview]');
        img.src = URL.createObjectURL(file); img.hidden = false; var wrap = box.querySelector('[data-pp-wrap]'); if (wrap) { wrap.hidden = false; }
    }

    var camDialog, camStream, camTarget;
    function closeCam() { if (camStream) { camStream.getTracks().forEach(function (t) { t.stop(); }); camStream = null; } if (camDialog && camDialog.open) { camDialog.close(); } }
    function openWebcam(box) {
        camTarget = box;
        if (!camDialog) {
            camDialog = document.createElement('dialog'); camDialog.className = 'pp-cam';
            camDialog.innerHTML = '<div><video autoplay playsinline muted></video><div style="display:flex;gap:8px;justify-content:flex-end"><button type="button" class="button button-quiet" data-cam-cancel>Cancel</button><button type="button" class="button button-primary" data-cam-snap>Capture</button></div></div>';
            document.body.appendChild(camDialog);
            camDialog.addEventListener('close', closeCam);
            camDialog.querySelector('[data-cam-cancel]').onclick = closeCam;
            camDialog.querySelector('[data-cam-snap]').onclick = function () {
                var v = camDialog.querySelector('video'), c = document.createElement('canvas');
                var s = Math.min(1, 1280 / Math.max(v.videoWidth, v.videoHeight)); c.width = v.videoWidth * s; c.height = v.videoHeight * s;
                c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
                c.toBlob(function (b) { if (b) { setFile(camTarget, new File([b], 'camera-' + Date.now() + '.jpg', { type: 'image/jpeg' })); } closeCam(); }, 'image/jpeg', 0.85);
            };
        }
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false }).then(function (stream) {
            camStream = stream; camDialog.querySelector('video').srcObject = stream; camDialog.showModal();
        }).catch(function () { alert('Camera is blocked or not found. Allow camera access in the browser, or use Upload photo.'); });
    }

    document.addEventListener('click', function (e) {
        var box = e.target.closest('[data-pp]'); if (!box) { return; }
        if (e.target.closest('[data-pp-clear]')) { box.querySelector('[data-pp-file]').value = ''; box.querySelector('[data-pp-preview]').hidden = true; var w = box.querySelector('[data-pp-wrap]'); if (w) { w.hidden = true; } return; }
        if (e.target.closest('[data-pp-upload]')) { box.querySelector('[data-pp-file]').click(); }
        if (e.target.closest('[data-pp-camera]')) {
            var touch = window.matchMedia && matchMedia('(pointer:coarse)').matches;
            if (!touch && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) { openWebcam(box); } else { box.querySelector('[data-pp-cam]').click(); }
        }
    });
    document.addEventListener('change', function (e) {
        var box = e.target.closest && e.target.closest('[data-pp]'); if (!box) { return; }
        if (e.target.matches('[data-pp-cam]') && e.target.files[0]) { setFile(box, e.target.files[0]); }
        if (e.target.matches('[data-pp-file]') && e.target.files[0]) { setFile(box, e.target.files[0]); }
    });
    ['dragover', 'dragleave', 'drop'].forEach(function (n) {
        document.addEventListener(n, function (e) {
            var box = e.target.closest && e.target.closest('[data-pp]'); if (!box) { return; }
            e.preventDefault(); box.classList.toggle('is-over', n === 'dragover');
            if (n === 'drop' && e.dataTransfer.files[0]) { setFile(box, e.dataTransfer.files[0]); }
        });
    });
})();

// Ask AI: the answer is written on screen as it is produced (first words in about a second), can be stopped, and can be deleted.
(function () {
    var token = function () { var m = document.querySelector('meta[name="csrf-token"]'); return m ? m.content : ''; };
    var canStream = window.fetch && window.ReadableStream && window.TextDecoder && window.AbortController;

    function el(tag, cls, text) { var e = document.createElement(tag); if (cls) { e.className = cls; } if (text) { e.textContent = text; } return e; }

    // Smaller photos upload faster: scale big pictures down to 1024 px before sending.
    function shrink(file) {
        return new Promise(function (resolve) {
            if (!file || file.size < 400000 || !/^image\/(jpeg|png|webp)/.test(file.type)) { return resolve(file); }
            var img = new Image(), url = URL.createObjectURL(file);
            img.onload = function () {
                var s = Math.min(1, 1024 / Math.max(img.width, img.height)), c = document.createElement('canvas');
                c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
                c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
                c.toBlob(function (b) { resolve(b && b.size < file.size ? new File([b], 'photo.jpg', { type: 'image/jpeg' }) : file); }, 'image/jpeg', 0.8);
            };
            img.onerror = function () { URL.revokeObjectURL(url); resolve(file); };
            img.src = url;
        });
    }

    function del(url, card) {
        return fetch(url, { method: 'DELETE', credentials: 'same-origin', headers: { 'X-CSRF-TOKEN': token(), 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { if (r.ok && card) { card.remove(); } return r.ok; });
    }

    function deleteButton(card, url) {
        var b = el('button', 'button button-quiet button-small', 'Delete'); b.type = 'button';
        b.addEventListener('click', function () { if (confirm('Delete this question and answer?')) { b.disabled = true; del(url, card).then(function (ok) { if (!ok) { b.disabled = false; } }); } });
        return b;
    }

    document.addEventListener('submit', function (e) {
        var f = e.target;
        if (!(f instanceof HTMLFormElement) || e.defaultPrevented) { return; }

        // Delete one / delete all (work without JavaScript too: they are normal DELETE forms)
        if (f.hasAttribute('data-ask-delete') || f.hasAttribute('data-ask-delete-all')) {
            if (!canStream) { return; }
            e.preventDefault();
            var all = f.hasAttribute('data-ask-delete-all');
            if (!confirm(all ? 'Delete ALL your questions and answers? This cannot be undone.' : 'Delete this question and answer?')) { return; }
            del(f.action, all ? null : f.closest('[data-ask-card]')).then(function (ok) {
                if (ok && all) { document.querySelectorAll('[data-ask-card]').forEach(function (c) { c.remove(); }); f.remove(); }
            });
            return;
        }

        if (!f.hasAttribute('data-ask-stream') || !canStream) { return; } // no streaming support: the normal form post still works
        e.preventDefault();

        var question = (f.querySelector('[name=question]').value || '').trim();
        var out = document.querySelector(f.getAttribute('data-ask-stream'));
        var submit = f.querySelector('[data-ask-submit]'), status = f.querySelector('[data-ask-status]');
        if (question.length < 3 || !out) { if (status) { status.textContent = 'Please write your question.'; } return; }
        if (f.__asking) { return; }
        f.__asking = true; submit.disabled = true;

        var fd = new FormData(f), photo = fd.get('photo');
        var hasPhoto = photo && photo.size > 0;
        var card = el('article', 'p-card ai-item'); card.setAttribute('data-ask-card', '');
        card.appendChild(el('p', 'p-muted ai-when', 'Just now'));
        var q = el('p', 'ai-q'); q.appendChild(el('b', '', question)); card.appendChild(q);
        if (hasPhoto) { var im = el('img'); im.alt = 'Your photo'; im.className = 'ai-q-photo'; im.src = URL.createObjectURL(photo); card.appendChild(im); }
        var ans = el('div', 'ai-answer'), raw = ''; card.appendChild(ans);
        var bar = el('div', 'p-actions'), state = el('span', 'p-muted', 'Thinking…'), stop = el('button', 'button button-outline button-small', '■ Stop');
        state.setAttribute('role', 'status'); state.setAttribute('aria-live', 'polite'); stop.type = 'button';
        bar.appendChild(state); bar.appendChild(stop); card.appendChild(bar);
        out.insertBefore(card, out.firstChild); card.scrollIntoView({ block: 'nearest' });

        var ctl = new AbortController(), deleteUrl = null, finished = false;
        stop.addEventListener('click', function () { ctl.abort(); });

        function finish(label, keep) {
            if (finished) { return; } finished = true;
            f.__asking = false; submit.disabled = false; stop.remove();
            state.textContent = label;
            if (!keep || !ans.textContent) { if (!ans.textContent) { card.remove(); } return; }
            if (deleteUrl) { bar.appendChild(deleteButton(card, deleteUrl)); }
        }

        shrink(hasPhoto ? photo : null).then(function (small) {
            if (hasPhoto) { fd.set('photo', small, small.name || 'photo.jpg'); } else { fd.delete('photo'); }
            return fetch(f.getAttribute('data-ask-url'), {
                method: 'POST', body: fd, signal: ctl.signal, credentials: 'same-origin',
                headers: { 'X-CSRF-TOKEN': token(), 'Accept': 'text/event-stream', 'X-Requested-With': 'XMLHttpRequest' }
            });
        }).then(function (res) {
            if (!res.ok) {
                return res.json().catch(function () { return {}; }).then(function (j) {
                    var msg = res.status === 422 ? ((j.errors && Object.values(j.errors)[0][0]) || 'Please check your question.')
                        : res.status === 429 ? 'Too many questions. Please wait a minute.'
                        : res.status === 419 ? 'Your session expired. Reload the page and try again.' : 'The AI service had a problem. Please try again.';
                    ans.textContent = ''; card.remove(); f.__asking = false; submit.disabled = false; finished = true;
                    if (status) { status.textContent = msg; }
                });
            }
            var reader = res.body.getReader(), dec = new TextDecoder(), buf = '';
            if (status) { status.textContent = ''; }
            function pump() {
                return reader.read().then(function (r) {
                    if (r.done) { return finish('Done', true); }
                    buf += dec.decode(r.value, { stream: true }).replace(/\r\n/g, '\n');
                    var i;
                    while ((i = buf.indexOf('\n\n')) !== -1) {
                        var line = buf.slice(0, i); buf = buf.slice(i + 2);
                        if (line.indexOf('data:') !== 0) { continue; }
                        var m; try { m = JSON.parse(line.slice(5)); } catch (x) { continue; }
                        if (m.start) { deleteUrl = m.delete; }
                        if (m.t) { raw += m.t; ans.innerHTML = window.NeasMd ? NeasMd.html(raw) : ''; if (!window.NeasMd) { ans.textContent = raw; } state.textContent = 'Answering…'; var th = card.closest('.ai-thread'); if (th) { th.scrollTop = th.scrollHeight; } }
                        if (m.error) { ans.textContent = ''; card.remove(); finished = true; f.__asking = false; submit.disabled = false; if (status) { status.textContent = m.error; } return reader.cancel(); }
                        if (m.done) { finish('Done', true); }
                    }
                    return pump();
                });
            }
            return pump();
        }).catch(function (err) {
            if (err && err.name === 'AbortError') { finish('Stopped', true); }
            else { finish('Connection lost', true); }
        });
        f.reset();
        var pv = f.querySelector('[data-pp-preview]'); if (pv) { pv.hidden = true; } var pw = f.querySelector('[data-pp-wrap]'); if (pw) { pw.hidden = true; }
        var nm = f.querySelector('[data-pp-name]'); if (nm) { nm.textContent = 'No photo chosen. You can also drop an image here.'; }
    });
})();
</script>
<style>.ai-spin{width:38px;height:38px;margin:0 auto;border:4px solid rgba(27,107,58,.2);border-top-color:var(--primary,#1B6B3A);border-radius:50%;animation:ai-rot .9s linear infinite}@keyframes ai-rot{to{transform:rotate(360deg)}}@media (prefers-reduced-motion:reduce){.ai-spin{animation-duration:3s}}</style>
@endauth
