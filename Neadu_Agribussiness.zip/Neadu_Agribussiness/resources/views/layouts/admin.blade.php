<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="robots" content="noindex,nofollow">
    <title>@yield('title', 'Console') · NeAS Console</title>
    @include('layouts.partials.assets')
    @stack('head')
</head>
<body>
    <header class="site-header">
        <a class="brand" href="{{ route('admin.dashboard') }}" aria-label="NeAS console">
            <span class="brand-mark">N</span><span>NeAS Console<small>Staff only</small></span>
        </a>
        <div class="header-actions">
            <span class="header-link">{{ auth('admin')->user()?->name }}</span>
            <form method="post" action="{{ route('admin.logout') }}">@csrf<button class="button button-quiet button-small" type="submit">Sign out</button></form>
        </div>
    </header>
    @if (session('status') && ! View::hasSection('admin_body'))<div class="flash flash-success" role="status">{{ session('status') }}</div>@endif
    @if ($errors->any() && ! View::hasSection('admin_body'))
        <div class="flash flash-error" role="alert"><ul>@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
    @endif
    @yield('content')
</body>
</html>
