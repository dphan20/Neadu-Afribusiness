@extends('producer.layout')
@section('title', 'Quote inbox')
@section('heading', 'Quote inbox')
@section('lead', 'Price, financing and rental requests from buyers. Reply with a price and a validity period; the buyer gets a printable quotation.')
@section('head-action')<a class="button button-outline" href="{{ route('trader.quotes.export') }}">Download all (CSV)</a>@endsection
@section('body')
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
<form class="p-card" method="get" action="{{ route('trader.quotes') }}" style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">
<div><label for="q">Search</label><input id="q" name="q" value="{{ $q }}" placeholder="Buyer or machine"></div>
<div><label for="status">Status</label><select id="status" name="status"><option value="">All</option>@foreach(['open'=>'Waiting for you','quoted'=>'Quoted','declined'=>'Declined','withdrawn'=>'Withdrawn'] as $k=>$v)<option value="{{ $k }}" @selected($status===$k)>{{ $v }}</option>@endforeach</select></div>
<div><label for="kind">Type</label><select id="kind" name="kind"><option value="">All</option>@foreach(['quote'=>'Price','financing'=>'Financing','rental'=>'Rental'] as $k=>$v)<option value="{{ $k }}" @selected($kind===$k)>{{ $v }}</option>@endforeach</select></div>
<button class="button button-outline">Filter</button></form>
@forelse($quotes as $r)
<div class="p-card"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><b>{{ $r->listing?->title }} × {{ $r->quantity }}</b><span class="p-tag">{{ ucfirst($r->status) }}</span></div>
<p class="p-muted">{{ $r->reference() }} · {{ ucfirst($r->kind) }}@if($r->months) for {{ $r->months }} months @endif · from {{ $r->user?->name }} · {{ $r->created_at?->format('d-m-Y H:i') }}</p>
@if($r->message)<p>“{{ $r->message }}”</p>@endif
@if($r->status==='quoted')<p>Quoted <b>TSh {{ number_format($r->quoted_minor/100) }}</b>, valid until {{ $r->valid_until?->format('d-m-Y') }}. @if($r->reply)<br>{{ $r->reply }}@endif</p>@endif
@if($r->status==='declined')<p class="p-muted">Declined: {{ $r->decline_reason }}</p>@endif
<div class="p-actions">
@if($r->status==='quoted')<a class="button button-outline button-small" href="{{ route('machinery.quotes.document',$r) }}" target="_blank" rel="noopener">Quotation (PDF)</a>@endif
<a class="button button-outline button-small" href="{{ route('me.ask',['q'=>'Help me reply professionally to a '.$r->kind.' request for '.$r->listing?->title.' (quantity '.$r->quantity.'). Buyer message: '.\Illuminate\Support\Str::limit((string) $r->message, 200)]) }}" target="_blank" rel="noopener">Ask AI for a reply</a></div>
@if(in_array($r->status,['open','quoted'],true))
<form method="post" action="{{ route('trader.quotes.reply',$r) }}" class="pf" style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:end">@csrf
<div><label>Total price (TSh)</label><input name="price" inputmode="decimal" value="{{ $r->quoted_minor ? number_format($r->quoted_minor/100,2,'.','') : '' }}" required></div>
<div><label>Valid for (days)</label><input name="valid_days" type="number" min="1" max="90" value="14" required style="width:90px"></div>
<div style="flex:1;min-width:200px"><label>Message to the buyer</label><input name="message" maxlength="1000" value="{{ $r->reply }}"></div>
<button class="button button-primary button-small">{{ $r->status==='quoted' ? 'Update quotation' : 'Send quotation' }}</button></form>
<form method="post" action="{{ route('trader.quotes.decline',$r) }}" style="margin-top:6px;display:flex;gap:8px;flex-wrap:wrap">@csrf<input name="reason" placeholder="Reason for declining" maxlength="200" required style="min-width:220px"><button class="button button-danger-quiet button-small">Decline</button></form>
@endif</div>
@empty<div class="p-card"><b>No requests found.</b><p class="p-muted">When buyers ask for a price, financing or rental on your live machinery, it appears here and you get a notification.</p></div>@endforelse
{{ $quotes->onEachSide(1)->links() }}
@endsection
