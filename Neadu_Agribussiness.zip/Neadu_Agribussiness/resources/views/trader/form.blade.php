@extends('producer.layout')
@section('title', $listing ? 'Edit machinery' : 'Add machinery')
@section('heading', $listing ? 'Edit '.$listing->title : 'Add machinery or technology')
@section('lead', 'Clear photos, an honest description and the real price get the most requests.')
@section('body')
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
@if($listing && $listing->moderation_note)<div class="flash flash-error">Reviewer note: {{ $listing->moderation_note }}</div>@endif
@php
$T = \App\Http\Controllers\Trader\TraderController::class;
$specs = old('spec_key') !== null
    ? collect(old('spec_key'))->map(fn ($k, $i) => ['k' => $k, 'v' => (old('spec_value')[$i] ?? '')])->all()
    : ($machine?->specs ?? []);
@endphp
<form class="p-card pf" method="post" enctype="multipart/form-data" action="{{ $listing ? route('trader.machines.update',$listing) : route('trader.machines.store') }}">@csrf @if($listing)@method('PUT')@endif
<label for="title">Listing title</label><input id="title" name="title" value="{{ old('title',$listing?->title) }}" maxlength="120" required placeholder="e.g. Massey Ferguson 290 tractor, 2019">
<div class="row">
<div><label for="category">Type</label><select id="category" name="category">@foreach($T::CATEGORIES as $k=>$v)<option value="{{ $k }}" @selected(old('category',$machine?->category)===$k)>{{ $v }}</option>@endforeach</select></div>
<div><label for="sector">For</label><select id="sector" name="sector">@foreach($T::SECTORS as $k=>$v)<option value="{{ $k }}" @selected(old('sector',$machine?->sector)===$k)>{{ $v }}</option>@endforeach</select></div>
<div><label for="condition">Condition</label><select id="condition" name="condition">@foreach($T::CONDITIONS as $k=>$v)<option value="{{ $k }}" @selected(old('condition',$machine?->machine_condition)===$k)>{{ $v }}</option>@endforeach</select></div></div>
<div class="row">
<div><label for="brand">Brand</label><input id="brand" name="brand" value="{{ old('brand',$machine?->brand) }}" maxlength="80"></div>
<div><label for="model">Model</label><input id="model" name="model" value="{{ old('model',$machine?->model) }}" maxlength="80"></div>
<div><label for="year">Year</label><input id="year" name="year" type="number" min="1980" max="{{ date('Y')+1 }}" value="{{ old('year',$machine?->year) }}"></div>
<div><label for="warranty">Warranty</label><input id="warranty" name="warranty" value="{{ old('warranty',$machine?->warranty) }}" maxlength="120" placeholder="e.g. 12 months parts and labour"></div></div>
<div class="row">
<div><label for="price">Price (TSh)</label><input id="price" name="price" inputmode="decimal" value="{{ old('price',$listing ? number_format($listing->price_minor/100,2,'.','') : '') }}" required></div>
<div><label for="stock">Units in stock</label><input id="stock" name="stock" type="number" min="0" max="100000" value="{{ old('stock',$machine?->stock ?? 1) }}" required></div></div>
<label>What you offer</label><div>@foreach($T::OFFERS as $k=>$v)@continue(($k==='financing' && ! $financing) || ($k==='rental' && ! $rental))<label class="check"><input type="checkbox" name="offers[]" value="{{ $k }}" @checked(in_array($k, old('offers',$machine?->offers ?? ['sale']), true))> {{ $v }}</label>@endforeach</div>
@if($rental)<div><label for="rental_rate">Rental rate (TSh per day, if you rent it out)</label><input id="rental_rate" name="rental_rate" inputmode="decimal" value="{{ old('rental_rate',$machine?->rental_rate_minor ? number_format($machine->rental_rate_minor/100,2,'.','') : '') }}"></div>@endif
<div class="row">
<div><label for="region_id">Region</label><select id="region_id" name="region_id">@foreach($regions as $r)<option value="{{ $r->id }}" @selected(old('region_id',$listing?->region_id)==$r->id)>{{ $r->name }}</option>@endforeach</select></div>
<div><label for="district_id">District</label><select id="district_id" name="district_id">@foreach($districts as $d)<option value="{{ $d->id }}" data-region="{{ $d->region_id }}" @selected(old('district_id',$listing?->district_id)==$d->id)>{{ $d->name }}</option>@endforeach</select></div>
<div><label for="lat">Latitude (optional)</label><input id="lat" name="lat" value="{{ old('lat',$listing?->lat) }}"></div><div><label for="lng">Longitude (optional)</label><input id="lng" name="lng" value="{{ old('lng',$listing?->lng) }}"></div></div>
<label for="description">Description</label><textarea id="description" name="description" rows="5" maxlength="2000" placeholder="What it does, what is included, who it suits, delivery and after-sales support.">{{ old('description',$machine?->description) }}</textarea>
<p class="p-muted"><a href="{{ route('me.ask',['q'=>'Write a clear, honest listing description for '.($listing?->title ?? 'my machine').'. Ask me for any details you need.']) }}" target="_blank" rel="noopener">Ask AI to help write this</a></p>
<label>Specifications</label>
<div id="specs">@foreach($specs ?: [['k'=>'','v'=>'']] as $s)<div class="row spec-row"><div><input name="spec_key[]" value="{{ $s['k'] }}" placeholder="e.g. Engine power" maxlength="60"></div><div><input name="spec_value[]" value="{{ $s['v'] }}" placeholder="e.g. 75 hp" maxlength="120"></div></div>@endforeach</div>
<p><button type="button" class="button button-outline button-small" id="add-spec">Add a specification</button></p>
@if($listing && $listing->photos)<label>Current photos (tick to remove)</label><div style="display:flex;gap:10px;flex-wrap:wrap">@foreach($listing->photos as $p)<label class="check" style="display:block"><img src="{{ asset('storage/'.$p) }}" alt="" style="width:110px;height:80px;object-fit:cover;border-radius:8px;display:block"><input type="checkbox" name="remove_photos[]" value="{{ $p }}"> Remove</label>@endforeach</div>@endif
<label for="photos">Add photos (up to 8 in total)</label><input id="photos" name="photos[]" type="file" accept="image/jpeg,image/png,image/webp" multiple>
<label for="brochure">Brochure or manual (PDF, optional)</label><input id="brochure" name="brochure" type="file" accept="application/pdf">
@if($machine?->brochure_path)<label class="check"><input type="checkbox" name="remove_brochure" value="1"> Remove the current brochure (<a href="{{ asset('storage/'.$machine->brochure_path) }}" target="_blank" rel="noopener">view</a>)</label>@endif
<div class="p-actions"><button class="button button-primary" name="submit" value="1">{{ $listing && $listing->status==='active' ? 'Save changes' : 'Submit for review' }}</button>@unless($listing && $listing->status==='active')<button class="button button-outline" name="submit" value="0">Save draft</button>@endunless<a class="button button-outline" href="{{ route('trader.machines') }}">Cancel</a></div></form>
<script>
const rg=document.getElementById('region_id'),ds=document.getElementById('district_id');function f(){[...ds.options].forEach(o=>o.hidden=o.dataset.region!==rg.value);if(ds.selectedOptions[0]?.hidden)ds.value=[...ds.options].find(o=>!o.hidden)?.value}rg.addEventListener('change',f);f();
document.getElementById('add-spec').addEventListener('click',()=>{const w=document.getElementById('specs');if(w.children.length>=20)return;const r=w.children[0].cloneNode(true);r.querySelectorAll('input').forEach(i=>i.value='');w.appendChild(r)});
</script>
@endsection
