@extends('producer.layout')
@section('title', 'Trader overview')
@section('heading', 'Your machinery business')
@section('lead', 'Everything you list, every request you receive, and what to do next.')
@section('head-action')<a class="button button-primary" href="{{ route('trader.machines.create') }}">Add machinery</a>@endsection
@section('body')
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
<div class="metric-grid">
<article class="metric-card metric-green"><span class="metric-label">Live listings</span><strong>{{ $counts['active'] ?? 0 }}</strong></article>
<article class="metric-card metric-gold"><span class="metric-label">Drafts and in review</span><strong>{{ ($counts['draft'] ?? 0) + ($counts['pending_review'] ?? 0) + ($counts['rejected'] ?? 0) }}</strong></article>
<article class="metric-card metric-red"><span class="metric-label">Requests waiting for you</span><strong>{{ $open }}</strong></article>
<article class="metric-card metric-blue"><span class="metric-label">Quoted this month (TSh)</span><strong>{{ number_format(intdiv($quotedMonth, 100)) }}</strong></article>
</div>

@if(! auth()->user()->isIdentityVerified() || ! $profileDone || $total === 0)
<div class="p-card"><b>Get ready to sell</b>
<p class="p-muted">
@unless(auth()->user()->isIdentityVerified())· <a href="{{ route('me.identity') }}">Verify your identity (NIDA)</a>: needed before a listing can go live.<br>@endunless
@unless($profileDone)· <a href="{{ route('trader.profile') }}">Complete your business profile</a>: buyers see your name and contact.<br>@endunless
@if($total === 0)· <a href="{{ route('trader.machines.create') }}">Add your first machine or technology</a>.@endif
</p></div>
@endif

<section class="p-card"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><b>Latest requests</b><a href="{{ route('trader.quotes') }}">Open the inbox</a></div>
@forelse($recent as $r)
<div style="padding:10px 0;border-top:1px solid var(--color-border)"><b>{{ $r->user?->name }}</b> · {{ ucfirst($r->kind) }} · {{ $r->listing?->title }} × {{ $r->quantity }}
<span class="p-tag">{{ ucfirst($r->status) }}</span><br><small class="p-muted">{{ $r->created_at?->diffForHumans() }}</small></div>
@empty<p class="p-muted">No requests yet. Buyers find you in the machinery market once a listing is live.</p>@endforelse</section>

<section class="p-card"><b>Work faster</b>
<div class="p-actions">
<a class="button button-outline button-small" href="{{ route('trader.machines') }}">My machinery</a>
<a class="button button-outline button-small" href="{{ route('trader.quotes') }}">Quote inbox</a>
<a class="button button-outline button-small" href="{{ route('trader.profile') }}">Business profile</a>
<a class="button button-outline button-small" href="{{ route('me.ask', ['q' => 'Help me write a clear, honest listing description for a machine I sell. Ask me for the details you need.']) }}">Ask AI to write a listing</a>
<a class="button button-outline button-small" href="{{ route('me.chat.index') }}">Messages</a>
<a class="button button-outline button-small" href="{{ route('me.wallet') }}">Wallet</a>
</div></section>
@endsection
