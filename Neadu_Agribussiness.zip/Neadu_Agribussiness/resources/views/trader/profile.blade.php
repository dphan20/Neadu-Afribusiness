@extends('producer.layout')
@section('title', 'Business profile')
@section('heading', 'Business profile')
@section('lead', 'Buyers see this on your machinery pages and on every quotation.')
@section('body')
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
@php
$b = $profile->business ?? [];
$T = \App\Http\Controllers\Trader\TraderController::class;
@endphp
<form class="p-card pf" method="post" action="{{ route('trader.profile.update') }}">@csrf @method('PUT')
<label for="name">Business name</label><input id="name" name="name" value="{{ old('name',$b['name'] ?? '') }}" maxlength="120" required>
<label for="about">About your business</label><textarea id="about" name="about" rows="4" maxlength="1500">{{ old('about',$b['about'] ?? '') }}</textarea>
<div class="row"><div><label for="licence">Business licence number (optional)</label><input id="licence" name="licence" value="{{ old('licence',$b['licence'] ?? '') }}" maxlength="60"></div>
<div><label for="since">In business since</label><input id="since" name="since" type="number" min="1950" max="{{ date('Y') }}" value="{{ old('since',$b['since'] ?? '') }}"></div></div>
<label>Services</label><div>@foreach($T::SERVICES as $k=>$v)<label class="check"><input type="checkbox" name="services[]" value="{{ $k }}" @checked(in_array($k, old('services',$b['services'] ?? []), true))> {{ $v }}</label>@endforeach</div>
<div class="row"><div><label for="phone">Business phone</label><input id="phone" name="phone" value="{{ old('phone',$b['phone'] ?? '') }}" required></div>
<div><label for="whatsapp">WhatsApp (optional)</label><input id="whatsapp" name="whatsapp" value="{{ old('whatsapp',$b['whatsapp'] ?? '') }}"></div>
<div><label for="email">Email (optional)</label><input id="email" name="email" type="email" value="{{ old('email',$b['email'] ?? '') }}"></div>
<div><label for="website">Website (optional)</label><input id="website" name="website" type="url" value="{{ old('website',$b['website'] ?? '') }}"></div></div>
<div class="row"><div><label for="region_id">Region</label><select id="region_id" name="region_id"><option value="">—</option>@foreach($regions as $r)<option value="{{ $r->id }}" @selected(old('region_id',$profile->region_id)==$r->id)>{{ $r->name }}</option>@endforeach</select></div>
<div><label for="district_id">District</label><select id="district_id" name="district_id"><option value="">—</option>@foreach($districts as $d)<option value="{{ $d->id }}" data-region="{{ $d->region_id }}" @selected(old('district_id',$profile->district_id)==$d->id)>{{ $d->name }}</option>@endforeach</select></div></div>
<label for="address">Shop address</label><input id="address" name="address" value="{{ old('address',$b['address'] ?? '') }}" maxlength="200">
<label for="hours">Opening hours</label><input id="hours" name="hours" value="{{ old('hours',$b['hours'] ?? '') }}" maxlength="120" placeholder="Mon-Sat 08:00-17:00">
<div class="p-actions"><button class="button button-primary">Save profile</button></div></form>
<script>const rg=document.getElementById('region_id'),ds=document.getElementById('district_id');function f(){[...ds.options].forEach(o=>o.hidden=o.value!==''&&o.dataset.region!==rg.value);if(ds.selectedOptions[0]?.hidden)ds.value=''}rg.addEventListener('change',f);f();</script>
@endsection
