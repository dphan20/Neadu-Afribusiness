@extends('producer.layout')
@section('title', 'My machinery')
@section('heading', 'My machinery and technology')
@section('lead', 'Add, edit, pause, copy, delete and download your listings.')
@section('head-action')<a class="button button-primary" href="{{ route('trader.machines.create') }}">Add machinery</a>@endsection
@section('body')
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
<form class="p-card" method="get" action="{{ route('trader.machines') }}" style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">
<div><label for="q">Search</label><input id="q" name="q" value="{{ $q }}" placeholder="Name, brand or model"></div>
<div><label for="status">Status</label><select id="status" name="status"><option value="">All</option>@foreach(['active'=>'Live','draft'=>'Draft','pending_review'=>'In review','rejected'=>'Rejected','paused'=>'Paused','sold_out'=>'Sold out','closed'=>'Closed'] as $k=>$v)<option value="{{ $k }}" @selected($status===$k)>{{ $v }}</option>@endforeach</select></div>
<button class="button button-outline">Filter</button>
<a class="button button-outline" href="{{ route('trader.machines.export') }}">Download all (CSV)</a></form>
@forelse($machines as $m)
@php($mc = $m->machine)
<div class="p-card"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><b>{{ $m->title }}</b><span class="p-tag">{{ ucfirst(str_replace('_',' ',$m->status)) }}</span></div>
<p class="p-muted">{{ \App\Http\Controllers\Trader\TraderController::CATEGORIES[$mc?->category] ?? 'Equipment' }}@if($mc?->brand) · {{ $mc->brand }} {{ $mc->model }}@endif · {{ \App\Http\Controllers\Trader\TraderController::CONDITIONS[$mc?->machine_condition] ?? '' }} · TSh {{ number_format($m->price_minor/100) }} · {{ $mc?->stock ?? 0 }} in stock · {{ implode(', ', array_map(fn($o)=>\App\Http\Controllers\Trader\TraderController::OFFERS[$o] ?? $o, $mc?->offers ?? [])) }} · {{ $m->region?->name }}
@if($m->moderation_note) · Review note: {{ $m->moderation_note }}@endif
@if($m->open_quotes>0) · <a href="{{ route('trader.quotes',['status'=>'open','q'=>$m->title]) }}">{{ $m->open_quotes }} request(s) waiting</a>@endif</p>
<div class="p-actions">
<a class="button button-outline button-small" href="{{ route('trader.machines.edit',$m) }}">Edit</a>
<a class="button button-outline button-small" href="{{ route('machinery.sheet',$m) }}" target="_blank" rel="noopener">Spec sheet (PDF)</a>
<form method="post" action="{{ route('trader.machines.duplicate',$m) }}">@csrf<button class="button button-outline button-small">Copy</button></form>
@if($m->status==='active')<form method="post" action="{{ route('trader.machines.status',[$m,'pause']) }}">@csrf<button class="button button-outline button-small">Pause</button></form>
<form method="post" action="{{ route('trader.machines.status',[$m,'soldout']) }}">@csrf<button class="button button-outline button-small">Mark sold out</button></form>@endif
@if($m->status==='paused')<form method="post" action="{{ route('trader.machines.status',[$m,'resume']) }}">@csrf<button class="button button-outline button-small">Resume</button></form>@endif
@if($m->status==='closed')<form method="post" action="{{ route('trader.machines.status',[$m,'reopen']) }}">@csrf<button class="button button-outline button-small">Reopen as draft</button></form>@endif
@if($m->status!=='closed')<form method="post" action="{{ route('trader.machines.status',[$m,'close']) }}">@csrf<button class="button button-danger-quiet button-small">Close</button></form>@endif
<form method="post" action="{{ route('trader.machines.destroy',$m) }}" onsubmit="return confirm('Delete this listing? Past quotes stay in your inbox history.')">@csrf @method('DELETE')<button class="button button-danger-quiet button-small">Delete</button></form>
</div></div>
@empty<div class="p-card"><b>No machinery yet.</b><p class="p-muted">Add a tractor, pump, dryer, sensor or software you sell, with photos, price and specifications. Buyers will ask you for quotes here.</p><a class="button button-primary" href="{{ route('trader.machines.create') }}">Add machinery</a></div>@endforelse
{{ $machines->onEachSide(1)->links() }}
@endsection
