@extends('layouts.app')

@section('content')
@php
$activeRole = \App\Support\RoleNav::activeRole();
$nav = \App\Support\RoleNav::for(\App\Enums\UserRole::Transporter);
@endphp
<main class="workspace-shell">
    <aside class="workspace-sidebar">
        <div class="workspace-person">
            <span class="avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</span>
            <span><b>{{ auth()->user()->name }}</b><small>{{ \App\Enums\UserRole::Transporter->label() }}</small></span>
        </div>
        <nav class="workspace-nav" aria-label="Transporter navigation">
            @foreach ($nav as $i => [$route, $label])
                <a class="{{ request()->routeIs($route.'*') ? 'active' : '' }}" href="{{ route($route) }}"><span class="nav-mark">{{ str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) }}</span>{{ $label }}</a>
            @endforeach
        </nav>
    </aside>
    <section class="workspace-main">
        <div class="tr" style="max-width:none;padding:0">@yield('body')</div>
    </section>
</main>
@endsection
