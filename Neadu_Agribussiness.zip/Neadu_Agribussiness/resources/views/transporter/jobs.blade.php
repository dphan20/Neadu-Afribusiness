@extends('transporter.layout')

@section('title', 'Jobs')

@section('body')
<h1>Available jobs</h1>
<p class="tr-lead">Open transport jobs and requests sent to you, with distance and price.</p>

@unless ($identityVerified)
    <div class="tr-alert">Verify your identity (NIDA) to accept jobs. <a href="{{ route('transporter.identity') }}">Verify now</a></div>
@endunless
@if (! $hasAnyVehicle)
    <div class="tr-alert">Register a vehicle to accept jobs. <a href="{{ route('transporter.vehicles') }}">Add a vehicle</a></div>
@elseif ($vehicles->isEmpty())
    <div class="tr-alert">None of your vehicles is verified yet. Jobs are shown, but you can accept only after the NeAS team approves a vehicle.</div>
@endif
@error('job')<div class="tr-alert">{{ $message }}</div>@enderror

<div class="tr-row" style="margin-bottom:12px">
    <span class="tr-muted">{{ $jobs->count() }} {{ \Illuminate\Support\Str::plural('job', $jobs->count()) }}</span>
    <span>
        Sort:
        <a href="{{ route('transporter.jobs', ['sort' => 'new']) }}" @if ($sort === 'new') style="font-weight:700" @endif>Newest</a> ·
        <a href="{{ route('transporter.jobs', ['sort' => 'price']) }}" @if ($sort === 'price') style="font-weight:700" @endif>Highest price</a> ·
        <a href="{{ route('transporter.jobs', ['sort' => 'distance']) }}" @if ($sort === 'distance') style="font-weight:700" @endif>Shortest</a>
    </span>
</div>

@forelse ($jobs as $j)
    @php($d = $j['delivery'])
    <div class="tr-card">
        <div class="tr-row">
            <b>{{ $d->order?->listing?->title ?? 'Delivery' }}</b>
            <span class="tr-chip {{ $j['direct'] ? 'info' : '' }}">{{ $j['direct'] ? 'Request for you' : 'Open job' }}</span>
        </div>
        <div class="tr-kv">
            <div><small>Distance</small><b>{{ number_format($j['km'], 1) }} km</b></div>
            <div><small>Price</small><b>TSh {{ number_format($j['price'] / 100) }}</b></div>
            <div><small>Load</small><b>{{ $j['weight'] !== null ? number_format($j['weight']).' kg' : 'Not weighed' }}</b></div>
            <div><small>Per km</small><b>{{ $j['per_km'] !== null ? 'TSh '.number_format($j['per_km']) : '—' }}</b></div>
        </div>
        <p class="tr-muted">
            Pickup: {{ $d->order?->listing?->region?->name ?? 'see map' }}
            (<a target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query={{ $d->pickup_lat }},{{ $d->pickup_lng }}">map</a>)
            → Drop-off:
            <a target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query={{ $d->drop_lat }},{{ $d->drop_lng }}">{{ number_format($d->drop_lat, 3) }}, {{ number_format($d->drop_lng, 3) }}</a>
        </p>

        @if ($vehicles->isNotEmpty() && $j['fits']->isEmpty())
            <p class="tr-muted" style="color:var(--color-error)">This load is heavier than any of your verified vehicles can carry.</p>
        @elseif ($vehicles->isNotEmpty())
            <form class="tr-form" method="post" action="{{ route('transporter.jobs.accept', $d) }}">
                @csrf
                <div class="tr-two">
                    <div><label for="v-{{ $d->uuid }}">Vehicle</label>
                        <select id="v-{{ $d->uuid }}" name="vehicle">@foreach ($j['fits'] as $v)<option value="{{ $v->uuid }}">{{ $v->typeLabel() }} · {{ str_starts_with($v->plate, 'BIC-') ? 'no plate' : $v->plate }} · {{ number_format((float) $v->capacity_kg) }} kg</option>@endforeach</select></div>
                    <div class="tr-actions" style="align-items:flex-end;margin:0">
                        <button class="button button-primary" type="submit">Accept job</button>
                        @if ($j['direct'])
                            <button class="button button-outline" type="submit" formaction="{{ route('transporter.jobs.release', $d) }}">Decline</button>
                        @endif
                    </div>
                </div>
            </form>
        @endif
    </div>
@empty
    <div class="tr-card tr-empty">No open jobs right now. New jobs appear here when a producer or buyer books delivery.</div>
@endforelse
@endsection
