@extends('transporter.layout')

@section('title', 'Vehicles')

@section('body')
<h1>My vehicles</h1>
<p class="tr-lead">Register your truck, pickup, motorbike or bicycle. The NeAS team verifies each one before it can take jobs.</p>

<div class="tr-card tr-form">
    <h2>Register a vehicle</h2>
    @error('vehicle')<div class="tr-alert">{{ $message }}</div>@enderror
    <form method="post" action="{{ route('transporter.vehicles.store') }}" enctype="multipart/form-data">
        @csrf
        <div class="tr-two">
            <div><label for="type">Vehicle type</label>
                <select id="type" name="type" required>
                    @foreach ($types as $t)<option value="{{ $t->value }}" @selected(old('type') === $t->value)>{{ $t->label() }} ({{ $t->swahiliLabel() }}), up to {{ number_format($t->maxCapacityKg()) }} kg</option>@endforeach
                </select></div>
            <div><label for="capacity_kg">Capacity (kg)</label><input id="capacity_kg" name="capacity_kg" type="number" step="1" min="1" value="{{ old('capacity_kg') }}" required>
                @error('capacity_kg')<span class="tr-muted" style="color:var(--color-error)">{{ $message }}</span>@enderror</div>
            <div><label for="plate">Number plate <span class="tr-muted">(not needed for bicycles)</span></label><input id="plate" name="plate" value="{{ old('plate') }}" placeholder="T 123 ABC" autocapitalize="characters">
                @error('plate')<span class="tr-muted" style="color:var(--color-error)">{{ $message }}</span>@enderror</div>
            <div><label for="licence">Driving licence number <span class="tr-muted">(not needed for bicycles)</span></label><input id="licence" name="licence" value="{{ old('licence') }}">
                @error('licence')<span class="tr-muted" style="color:var(--color-error)">{{ $message }}</span>@enderror</div>
        </div>
        <label for="photo">Vehicle photo</label>
        <input id="photo" name="photo" type="file" accept="image/*" capture="environment" required>
        @error('photo')<span class="tr-muted" style="color:var(--color-error)">{{ $message }}</span>@enderror
        <div class="tr-actions"><button class="button button-primary" type="submit">Submit for verification</button></div>
    </form>
</div>

@forelse ($vehicles as $v)
    @php($chip = ['verified' => '', 'pending' => 'warn', 'rejected' => 'bad'][$v->verification_status] ?? 'warn')
    <div class="tr-card">
        <div class="tr-row">
            <div style="display:flex;gap:12px;align-items:center">
                @if ($v->photo_path)<img class="tr-thumb" src="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($v->photo_path) }}" alt="Photo of {{ $v->plate }}">@endif
                <div><b>{{ $v->typeLabel() }}</b> · {{ str_starts_with($v->plate, 'BIC-') ? 'No plate' : $v->plate }}<br>
                    <span class="tr-muted">Up to {{ number_format((float) $v->capacity_kg) }} kg</span></div>
            </div>
            <span class="tr-chip {{ $chip }}">{{ ucfirst($v->verification_status) }}</span>
        </div>
        @if ($v->verification_status === 'rejected' && $v->reject_reason)<p class="tr-muted" style="color:var(--color-error)">Reason: {{ $v->reject_reason }}. Correct the details below to submit again.</p>@endif

        @if ($v->isVerified())<p class="tr-muted">You can edit this vehicle at any time. Changing the type, plate, licence, photo or raising the capacity sends it for verification again.</p>@endif
        <details class="tr-more tr-form">
                <summary>Edit details</summary>
                <form method="post" action="{{ route('transporter.vehicles.update', $v) }}" enctype="multipart/form-data">
                    @csrf @method('PUT')
                    <div class="tr-two">
                        <div><label>Type</label><select name="type">@foreach ($types as $t)<option value="{{ $t->value }}" @selected($v->type === $t->value)>{{ $t->label() }}</option>@endforeach</select></div>
                        <div><label>Capacity (kg)</label><input name="capacity_kg" type="number" min="1" value="{{ (int) $v->capacity_kg }}" required></div>
                        <div><label>Number plate</label><input name="plate" value="{{ str_starts_with($v->plate, 'BIC-') ? '' : $v->plate }}"></div>
                        <div><label>Driving licence number</label><input name="licence" value="{{ $v->licence_document }}"></div>
                    </div>
                    <label>Replace photo (optional)</label><input name="photo" type="file" accept="image/*">
                    <div class="tr-actions"><button class="button button-primary button-small" type="submit">Save changes</button></div>
                </form>
        </details>
        <form class="tr-form inline" method="post" action="{{ route('transporter.vehicles.destroy', $v) }}" onsubmit="return confirm('Remove this vehicle?')" style="margin-top:8px;display:block">
            @csrf @method('DELETE')<button class="button button-danger-quiet button-small" type="submit">Remove</button>
        </form>
    </div>
@empty
    <div class="tr-card tr-empty">No vehicles yet. Register one above to start taking jobs.</div>
@endforelse
@endsection
