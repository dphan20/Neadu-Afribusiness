@extends('transporter.layout')

@section('title', 'Earnings')

@section('body')
<h1>Earnings</h1>
<p class="tr-lead">Transport fees are held in escrow when you accept a job and released to you when the delivery is confirmed.</p>
<div class="tr-card tr-stat"><small>Balance</small><b>TSh {{ number_format($balance / 100) }}</b></div>
<div class="tr-card">
    <h2>Ledger</h2>
    @if ($entries->isEmpty())
        <div class="tr-empty">No payments yet. Complete a delivery to see it here.</div>
    @else
        <ul class="tr-list">
            @foreach ($entries as $e)
                <li class="tr-row">
                    <span>{{ $e->memo ?? 'Transport payout' }}<br><span class="tr-muted">{{ $e->created_at?->format('d M Y H:i') }}</span></span>
                    <b>{{ $e->credit_minor > 0 ? '+' : '−' }} TSh {{ number_format(max($e->credit_minor, $e->debit_minor) / 100) }}</b>
                </li>
            @endforeach
        </ul>
    @endif
</div>
@endsection
