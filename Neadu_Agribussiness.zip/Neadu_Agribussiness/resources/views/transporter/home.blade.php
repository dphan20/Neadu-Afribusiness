@extends('transporter.layout')

@section('title', 'Transporter')

@section('body')
<h1>Transporter workspace</h1>
<p class="tr-lead">Find jobs, drive trips and get paid from escrow when the goods are delivered.</p>

@unless ($identityVerified)
    <div class="tr-alert">Verify your identity (NIDA) to accept jobs. <a href="{{ route('transporter.identity') }}">Verify now</a></div>
@endunless
@if ($vehicles->isEmpty())
    <div class="tr-alert">Register a vehicle first. <a href="{{ route('transporter.vehicles') }}">Add a vehicle</a></div>
@elseif ($verifiedVehicles === 0)
    <div class="tr-alert">Your vehicle is waiting for verification by the NeAS team. You can accept jobs as soon as it is approved.</div>
@endif

<div class="tr-grid">
    <div class="tr-card tr-stat"><small>Open jobs for you</small><b>{{ $openJobs }}</b><a href="{{ route('transporter.jobs') }}">See jobs →</a></div>
    <div class="tr-card tr-stat"><small>Active trips</small><b>{{ $trips->count() }}</b><a href="{{ route('transporter.trips') }}">My trips →</a></div>
    <div class="tr-card tr-stat"><small>Verified vehicles</small><b>{{ $verifiedVehicles }} / {{ $vehicles->count() }}</b><a href="{{ route('transporter.vehicles') }}">Vehicles →</a></div>
    <div class="tr-card tr-stat"><small>Earnings (paid out)</small><b>TSh {{ number_format($balance / 100) }}</b><a href="{{ route('transporter.earnings') }}">Earnings →</a></div>
</div>

@if ($trips->isNotEmpty())
    <div class="tr-card">
        <h2>Continue your trip</h2>
        <ul class="tr-list">
            @foreach ($trips as $t)
                <li class="tr-row">
                    <span><b>{{ $t->order?->listing?->title ?? 'Delivery' }}</b>
                        <span class="tr-chip info">{{ $transport->step($t)['label'] }}</span><br>
                        <span class="tr-muted">{{ number_format($transport->distanceKm($t), 1) }} km · TSh {{ number_format((int) $t->price_minor / 100) }}</span></span>
                    <a class="button button-primary" href="{{ route('transporter.trips.show', $t) }}">Open trip mode</a>
                </li>
            @endforeach
        </ul>
    </div>
@endif

@if ($backhaul->isNotEmpty())
    <div class="tr-card">
        <h2>Heading back? Jobs near your drop-off</h2>
        <p class="tr-muted">Back-haul (LOG-09): pick up a load on the way home instead of driving empty.</p>
        <ul class="tr-list">
            @foreach ($backhaul as $b)
                <li class="tr-row">
                    <span><b>{{ $b['delivery']->order?->listing?->title ?? 'Delivery' }}</b>
                        <span class="tr-muted"><br>Pickup {{ $b['empty_km'] }} km from where you finished · {{ number_format($transport->distanceKm($b['delivery']), 1) }} km job · TSh {{ number_format((int) $b['delivery']->price_minor / 100) }}</span></span>
                    <a class="button button-outline button-small" href="{{ route('transporter.jobs') }}">View job</a>
                </li>
            @endforeach
        </ul>
    </div>
@endif
@endsection
