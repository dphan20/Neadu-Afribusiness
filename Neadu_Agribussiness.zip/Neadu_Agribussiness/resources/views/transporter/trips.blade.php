@extends('transporter.layout')

@section('title', 'My trips')

@section('body')
<h1>My trips</h1>
<p class="tr-lead">Open a trip to use driver mode.</p>
@error('job')<div class="tr-alert">{{ $message }}</div>@enderror

<div class="tr-card">
    <h2>Active</h2>
    @forelse ($active as $t)
        <div class="tr-row" style="padding:8px 0">
            <span><b>{{ $t->order?->listing?->title ?? 'Delivery' }}</b> <span class="tr-chip info">{{ \App\Services\TransportService::STEPS[$t->status]['label'] ?? $t->status }}</span><br>
                <span class="tr-muted">TSh {{ number_format((int) $t->price_minor / 100) }} · {{ $t->vehicle?->typeLabel() }}</span></span>
            <a class="button button-primary" href="{{ route('transporter.trips.show', $t) }}">Open trip mode</a>
        </div>
    @empty
        <div class="tr-empty">No active trips. <a href="{{ route('transporter.jobs') }}">Find a job</a></div>
    @endforelse
</div>

<div class="tr-card">
    <h2>Completed</h2>
    @forelse ($history as $t)
        <div class="tr-row" style="padding:8px 0;border-top:1px solid var(--color-border)">
            <span><b>{{ $t->order?->listing?->title ?? 'Delivery' }}</b><br>
                <span class="tr-muted">Delivered {{ $t->delivered_at?->format('d M Y H:i') }} · proof: {{ $t->proof_type }}{{ $t->recipient_name ? ' ('.$t->recipient_name.')' : '' }}</span></span>
            <span><b>TSh {{ number_format((int) $t->price_minor / 100) }}</b> <span class="tr-chip">{{ $t->escrow_state === 'released' ? 'Paid' : ucfirst($t->escrow_state) }}</span></span>
        </div>
    @empty
        <div class="tr-empty">Nothing delivered yet.</div>
    @endforelse
</div>
@endsection
