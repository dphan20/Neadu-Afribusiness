@extends('transporter.layout')
@section('title', 'Transport profile')
@section('body')
<h1>Transport profile</h1>
<p class="tr-lead">Producers and buyers see this when you take their delivery. Keep your contact details current.</p>
@if ($errors->any())<div class="tr-alert" role="alert">{{ $errors->first() }}</div>@endif
@php
$b = $profile->business ?? [];
$goods = ['grains' => 'Grains', 'vegetables' => 'Vegetables', 'fruit' => 'Fruit', 'livestock' => 'Livestock', 'fish' => 'Fish', 'fertiliser' => 'Fertiliser and inputs', 'machinery' => 'Machinery', 'other' => 'Other'];
@endphp
<form class="tr-card tr-form" method="post" action="{{ route('transporter.profile.update') }}">@csrf @method('PUT')
    <div class="tr-two">
        <div><label for="name">Name or company</label><input id="name" name="name" value="{{ old('name', $b['name'] ?? auth()->user()->name) }}" maxlength="120" required></div>
        <div><label for="phone">Phone</label><input id="phone" name="phone" value="{{ old('phone', $b['phone'] ?? auth()->user()->phone) }}" required></div>
        <div><label for="whatsapp">WhatsApp (optional)</label><input id="whatsapp" name="whatsapp" value="{{ old('whatsapp', $b['whatsapp'] ?? '') }}"></div>
        <div><label for="email">Email (optional)</label><input id="email" name="email" type="email" value="{{ old('email', $b['email'] ?? '') }}"></div>
        <div><label for="region_id">Base region</label><select id="region_id" name="region_id"><option value="">—</option>@foreach ($regions as $r)<option value="{{ $r->id }}" @selected(old('region_id', $profile->region_id) == $r->id)>{{ $r->name }}</option>@endforeach</select></div>
        <div><label for="district_id">Base district</label><select id="district_id" name="district_id"><option value="">—</option>@foreach ($districts as $d)<option value="{{ $d->id }}" data-region="{{ $d->region_id }}" @selected(old('district_id', $profile->district_id) == $d->id)>{{ $d->name }}</option>@endforeach</select></div>
    </div>
    <label>Goods you carry</label>
    <div>@foreach ($goods as $k => $v)<label class="check"><input type="checkbox" name="goods[]" value="{{ $k }}" @checked(in_array($k, old('goods', $b['goods'] ?? []), true))> {{ $v }}</label> @endforeach</div>
    <label for="hours">Available hours</label><input id="hours" name="hours" value="{{ old('hours', $b['hours'] ?? '') }}" maxlength="120" placeholder="Mon-Sat 06:00-20:00">
    <label for="about">About you and your service</label><textarea id="about" name="about" rows="4" maxlength="1000">{{ old('about', $b['about'] ?? '') }}</textarea>
    <div class="tr-actions"><button class="button button-primary" type="submit">Save profile</button></div>
</form>
<script>const rg=document.getElementById('region_id'),ds=document.getElementById('district_id');function f(){[...ds.options].forEach(o=>o.hidden=o.value!==''&&o.dataset.region!==rg.value);if(ds.selectedOptions[0]?.hidden)ds.value=''}rg.addEventListener('change',f);f();</script>
@endsection
