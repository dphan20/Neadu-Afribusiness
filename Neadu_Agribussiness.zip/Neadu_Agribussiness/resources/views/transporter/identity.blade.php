@extends('transporter.layout')

@section('title', 'Verify identity')

@section('body')
<h1>Verify your identity</h1>
<p class="tr-lead">Required before you accept jobs and receive transport payments.</p>
<div class="tr-card tr-form">
    @if ($user->isIdentityVerified())
        <p><span class="tr-chip">Verified</span> NIDA {{ $masked }}</p>
        <a class="button button-primary" href="{{ route('transporter.jobs') }}">Find jobs</a>
    @else
        <form method="post" action="{{ route('transporter.identity.verify') }}">
            @csrf
            <label for="nida">NIDA number (20 digits)</label>
            <input id="nida" name="nida_number" inputmode="numeric" maxlength="20" value="{{ old('nida_number') }}" required>
            @error('nida_number')<p class="tr-muted" style="color:var(--color-error)">{{ $message }}</p>@enderror
            <div class="tr-actions"><button class="button button-primary" type="submit">Verify identity</button></div>
        </form>
    @endif
</div>
@endsection
