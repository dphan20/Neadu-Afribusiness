@extends('transporter.layout')

@section('title', 'Trip')

@section('body')
@php
    $flow = \App\Models\Delivery::FLOW;
    $idx = array_search($delivery->status, $flow, true);
    $idx = $idx === false ? -1 : $idx;
    $toPickup = in_array($delivery->status, ['assigned', 'at_pickup'], true);
    $listing = $delivery->order?->listing;
    $price = (int) $delivery->price_minor;
@endphp
<style>
    .trs-conn { display: flex; align-items: center; gap: 8px; padding: 9px 14px; border-radius: 12px; font-size: 13px; font-weight: 600; background: var(--color-primary-soft); color: var(--color-primary-dark); margin-bottom: 12px; }
    .trs-conn.off { background: var(--color-accent-soft); color: var(--color-warning); }
    .trs-conn i { width: 10px; height: 10px; border-radius: 50%; background: currentColor; flex: none; }
    .trs-steps { list-style: none; display: grid; grid-template-columns: repeat(6, 1fr); gap: 4px; margin: 0 0 14px; padding: 0; }
    .trs-steps li { text-align: center; font-size: 10.5px; font-weight: 700; padding: 8px 2px; border-radius: 8px; background: var(--color-background); color: var(--color-text-muted); border: 1px solid var(--color-border); }
    .trs-steps li.done { background: var(--color-primary-soft); color: var(--color-primary-dark); }
    .trs-steps li.now { background: var(--color-primary); color: #fff; border-color: var(--color-primary); }
    .trs-big { width: 100%; min-height: 84px; border: 0; border-radius: 18px; background: var(--color-primary); color: #fff; font-family: var(--font-heading); font-size: 22px; font-weight: 800; cursor: pointer; box-shadow: 0 10px 24px rgb(27 107 58 / 28%); }
    .trs-big:active { transform: scale(.99); }
    .trs-nav { display: flex; align-items: center; justify-content: center; min-height: 56px; border-radius: 14px; background: var(--color-water); color: #fff; font-weight: 800; font-size: 16px; text-decoration: none; margin: 10px 0 14px; }
    .trs-code { width: 100%; min-height: 70px; text-align: center; letter-spacing: .4em; font-size: 30px; font-weight: 800; border: 2px solid var(--color-border); border-radius: 14px; }
    .trs-sig { width: 100%; height: 150px; border: 1px dashed var(--color-text-muted); border-radius: 12px; background: #fff; touch-action: none; }
    .trs-done { text-align: center; padding: 18px; }
</style>

<a class="back-link" href="{{ route('transporter.trips') }}">← My trips</a>
<div class="tr-row" style="margin:6px 0 10px">
    <h1 style="margin:0">{{ $listing?->title ?? 'Delivery' }}</h1>
    <span class="tr-chip info" id="tr-status">{{ $step['label'] }}</span>
</div>

<div class="trs-conn" id="tr-conn" role="status" aria-live="polite"><i></i><span id="tr-conn-text">Checking connection…</span></div>
@error('trip')<div class="tr-alert">{{ $message }}</div>@enderror
<div class="tr-alert" id="tr-msg" style="display:none"></div>

<ol class="trs-steps" id="trs-steps" aria-label="Trip progress">
    @foreach ($flow as $i => $s)
        <li data-s="{{ $s }}" class="{{ $i < $idx ? 'done' : ($i === $idx ? 'now' : '') }}">{{ $steps[$s]['label'] }}</li>
    @endforeach
</ol>

@if ($delivery->status !== 'delivered')
    <div class="tr-card">
        <small class="tr-muted" id="tr-target-label">{{ $toPickup ? 'NEXT STOP · PICKUP' : 'NEXT STOP · DROP-OFF' }}</small>
        <p style="margin:4px 0 0;font-size:18px;font-weight:700" id="tr-target-name">
            {{ $toPickup ? ($listing?->region?->name ?? 'Pickup point') : 'Drop-off point' }}
        </p>
        <p class="tr-muted" style="margin:2px 0 0">{{ $toPickup ? $delivery->pickup_lat.', '.$delivery->pickup_lng : $delivery->drop_lat.', '.$delivery->drop_lng }}</p>
        <a class="trs-nav" id="tr-nav" target="_blank" rel="noopener" href="{{ $navUrl }}">➤ Navigate (Google Maps)</a>

        <form id="tr-advance" method="post" action="{{ route('transporter.trips.advance', $delivery) }}" style="{{ in_array($delivery->status, ['arrived'], true) ? 'display:none' : '' }}">
            @csrf
            <input type="hidden" name="to" id="tr-to" value="{{ $step['next'] }}">
            <button type="submit" class="trs-big" id="tr-next">{{ $step['action'] }}</button>
        </form>
    </div>

    <div class="tr-card tr-form" id="tr-confirm" style="{{ $delivery->status === 'arrived' ? '' : 'display:none' }}">
        <h2>Confirm delivery</h2>
        <p class="tr-muted">Ask the buyer for the handover code they received in the app. The code proves the goods reached the right person.</p>
        <form method="post" action="{{ route('transporter.trips.code', $delivery) }}" data-needs-online>
            @csrf
            <label for="code">Recipient code</label>
            <input class="trs-code" id="code" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="8" placeholder="••••" @if ($attemptsLeft === 0) disabled @endif>
            @error('code')<p style="color:var(--color-error);font-size:13px">{{ $message }}</p>@enderror
            <div class="tr-actions"><button class="button button-primary" style="min-height:54px;width:100%;font-size:17px" type="submit" @if ($attemptsLeft === 0) disabled @endif>Confirm with code</button></div>
        </form>

        <details class="tr-more" style="margin-top:12px" @if ($attemptsLeft === 0 || $errors->has('proof')) open @endif>
            <summary>No code? Use a photo or signature instead</summary>
            @error('proof')<p style="color:var(--color-error);font-size:13px">{{ $message }}</p>@enderror
            <form method="post" action="{{ route('transporter.trips.proof', $delivery) }}" enctype="multipart/form-data" id="tr-proof" data-needs-online>
                @csrf
                <label for="recipient">Name of the person who received the goods</label>
                <input id="recipient" name="recipient" value="{{ old('recipient') }}" maxlength="120">
                <label for="photo">Photo of the goods being handed over</label>
                <input id="photo" name="photo" type="file" accept="image/*" capture="environment">
                <label>…or the recipient's signature</label>
                <canvas class="trs-sig" id="tr-sig" width="640" height="300"></canvas>
                <input type="hidden" name="signature" id="tr-sig-data">
                <div class="tr-actions">
                    <button class="button button-outline button-small" type="button" id="tr-sig-clear">Clear signature</button>
                    <button class="button button-primary" type="submit">Confirm with proof</button>
                </div>
            </form>
        </details>
    </div>
@else
    <div class="tr-card trs-done">
        <h2>Delivered ✓</h2>
        <p>Proof: {{ $delivery->proof_type }}{{ $delivery->recipient_name ? ' · received by '.$delivery->recipient_name : '' }}</p>
        <p><span class="tr-chip">{{ $delivery->escrow_state === 'released' ? 'Transport fee paid to your earnings' : 'Payment '.$delivery->escrow_state }}</span></p>
        <a class="button button-primary" href="{{ route('transporter.jobs') }}">Find the next job</a>
    </div>
@endif

<div class="tr-card">
    <h2>Cargo and payment</h2>
    <div class="tr-kv">
        <div><small>Goods</small><b>{{ $listing?->produce?->crop?->name_en ?? $listing?->title ?? '—' }}</b></div>
        <div><small>Quantity</small><b>{{ \App\Support\Quantity::pretty($delivery->order?->quantity ?? 0) }} {{ $listing?->produce?->unit?->code }}</b></div>
        <div><small>Weight</small><b>{{ $weight !== null ? number_format($weight).' kg' : '—' }}</b></div>
        <div><small>Distance</small><b>{{ number_format($km, 1) }} km</b></div>
        <div><small>Vehicle</small><b>{{ $delivery->vehicle?->typeLabel() }} {{ $delivery->vehicle && ! str_starts_with($delivery->vehicle->plate, 'BIC-') ? $delivery->vehicle->plate : '' }}</b></div>
        <div><small>Transport fee</small><b>TSh {{ number_format($price / 100) }}</b></div>
    </div>
    <p class="tr-muted">
        @if ($delivery->escrow_state === 'held') Your fee is held in escrow and is released to you as soon as the delivery is confirmed.
        @elseif ($delivery->escrow_state === 'released') Your fee has been released to your earnings.
        @else The fee is placed in escrow when you accept the job. @endif
    </p>
    @if ($delivery->status === 'assigned')
        <form class="tr-form" method="post" action="{{ route('transporter.jobs.release', $delivery) }}" onsubmit="return confirm('Drop this job? It goes back to the open board.')">
            @csrf<button class="button button-danger-quiet button-small" type="submit">Drop this job</button>
        </form>
    @endif
</div>

@if (! empty($delivery->timeline))
    <div class="tr-card">
        <h2>Trip log</h2>
        <ul class="tr-list">
            @foreach (array_reverse($delivery->timeline) as $e)
                <li class="tr-row"><span>{{ $steps[$e['status']]['label'] ?? ucfirst($e['status']) }}</span><span class="tr-muted">{{ \Illuminate\Support\Carbon::parse($e['at'])->format('d M H:i') }}</span></li>
            @endforeach
        </ul>
    </div>
@endif

<script>
(function () {
    var cfg = {
        uuid: @json($delivery->uuid),
        syncUrl: @json(route('transporter.trips.sync', $delivery)),
        token: @json(csrf_token()),
        status: @json($delivery->status),
        steps: @json($steps),
        flow: @json($flow),
        tracking: @json(in_array($delivery->status, \App\Models\Delivery::ACTIVE, true)),
        pickupTarget: @json(['label' => 'NEXT STOP · PICKUP', 'name' => $listing?->region?->name ?? 'Pickup point']),
        dropTarget: @json(['label' => 'NEXT STOP · DROP-OFF', 'name' => 'Drop-off point'])
    };
    var KEY = 'neas.trip.' + cfg.uuid;
    var $ = function (id) { return document.getElementById(id); };
    var lastLat = null, lastLng = null, lastSent = 0, gpsText = 'GPS starting…', busy = false;

    function load() { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } }
    function save(q) { try { localStorage.setItem(KEY, JSON.stringify(q.slice(-500))); } catch (e) {} }
    function say(text) { var m = $('tr-msg'); if (!m) { return; } m.textContent = text; m.style.display = text ? 'block' : 'none'; }

    /* Offline indicator (XDV-09): connection state, GPS state and how many updates wait to sync. */
    function ui() {
        var n = load().length, online = navigator.onLine, box = $('tr-conn');
        if (!box) { return; }
        box.classList.toggle('off', !online);
        $('tr-conn-text').textContent = (online ? 'Online' : 'Offline') + ' · ' + gpsText +
            (n ? ' · ' + n + ' update' + (n === 1 ? '' : 's') + ' saved, ' + (online ? 'syncing…' : 'will sync when you are back online') : '');
    }

    function queue(ev) { var q = load(); q.push(ev); save(q); ui(); }

    function apply(d) {
        cfg.status = d.status;
        var idx = cfg.flow.indexOf(d.status);
        document.querySelectorAll('#trs-steps li').forEach(function (li) {
            var i = cfg.flow.indexOf(li.getAttribute('data-s'));
            li.className = i < idx ? 'done' : (i === idx ? 'now' : '');
        });
        $('tr-status').textContent = d.label;
        var arrived = d.status === 'arrived', toPickup = d.status === 'assigned' || d.status === 'at_pickup';
        if ($('tr-advance')) { $('tr-advance').style.display = arrived ? 'none' : ''; }
        if ($('tr-confirm')) { $('tr-confirm').style.display = arrived ? '' : 'none'; }
        if (d.next) { $('tr-to').value = d.next; $('tr-next').textContent = d.action; }
        var t = toPickup ? cfg.pickupTarget : cfg.dropTarget;
        $('tr-target-label').textContent = t.label; $('tr-target-name').textContent = t.name;
        if (d.nav) { $('tr-nav').href = d.nav; }
    }

    function flush() {
        if (busy || !navigator.onLine) { return; }
        var q = load();
        if (!q.length) { ui(); return; }
        busy = true;
        var batch = q.slice(0, 100), again = false;
        fetch(cfg.syncUrl, {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': cfg.token },
            body: JSON.stringify({ events: batch })
        }).then(function (r) {
            if (r.ok) { return r.json().then(function (d) { save(load().slice(batch.length)); apply(d); say((d.errors || []).join(' ')); again = load().length > 0; }); }
            if (r.status === 419) { say('Your session expired. Reload this page to keep syncing.'); return; }
            if (r.status === 422 || r.status === 403 || r.status === 404) { save(load().slice(batch.length)); }   // unusable batch, never retry it
        }).catch(function () { /* offline or server unreachable: keep the buffer */ }).then(function () {
            busy = false; ui(); if (again) { flush(); }
        });
    }

    /* GeolocationService (LOG-04/05). Uses the Capacitor background plugin inside the native app (XDV-09), the browser otherwise. */
    var Geo = {
        id: null, cap: null,
        start: function (onPos) {
            var cap = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.BackgroundGeolocation;
            if (cap) {
                this.cap = cap;
                cap.addWatcher({ backgroundTitle: 'NeAS trip in progress', backgroundMessage: 'Sharing your location with the buyer.', requestPermissions: true, stale: false, distanceFilter: 30 },
                    function (loc, err) { if (loc) { onPos(loc.latitude, loc.longitude, loc.accuracy, loc.speed); } if (err) { gpsText = 'GPS error'; ui(); } }).then(function (id) { Geo.id = id; });
                return true;
            }
            if (!('geolocation' in navigator)) { gpsText = 'GPS not available'; ui(); return false; }
            this.id = navigator.geolocation.watchPosition(function (p) { onPos(p.coords.latitude, p.coords.longitude, p.coords.accuracy, p.coords.speed); },
                function (e) { gpsText = e.code === 1 ? 'Location permission denied' : 'GPS signal lost'; ui(); },
                { enableHighAccuracy: true, maximumAge: 10000, timeout: 25000 });
            return true;
        },
        stop: function () {
            if (this.cap && this.id) { this.cap.removeWatcher({ id: this.id }); }
            else if (this.id !== null && navigator.geolocation) { navigator.geolocation.clearWatch(this.id); }
        }
    };

    function onPos(lat, lng, accuracy, speed) {
        lastLat = lat; lastLng = lng;
        gpsText = 'GPS on · ' + new Date().toLocaleTimeString();
        var now = Date.now();
        if (now - lastSent >= 15000) { lastSent = now; queue({ type: 'point', lat: lat, lng: lng, t: now, accuracy: typeof accuracy === 'number' ? accuracy : null, speed: typeof speed === 'number' && speed >= 0 ? speed * 3.6 : null }); flush(); } else { ui(); }
    }

    /* Next-step button: works offline by buffering the tap and syncing it later. */
    var form = $('tr-advance');
    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var to = $('tr-to').value;
            if (!to) { return; }
            queue({ type: 'status', to: to, lat: lastLat, lng: lastLng, t: Date.now() });
            var s = cfg.steps[to];
            apply({ status: to, label: s.label, next: s.next, action: s.action });   // optimistic; the server answer replaces it
            flush();
        });
    }

    /* Delivery confirmation must be checked by the server, so it needs a connection. */
    document.querySelectorAll('form[data-needs-online]').forEach(function (f) {
        f.addEventListener('submit', function (e) {
            if (!navigator.onLine) { e.preventDefault(); say('You are offline. Delivery can only be confirmed with a connection; your trip updates are saved.'); }
            else if (f.id === 'tr-proof' && sigDirty) { $('tr-sig-data').value = $('tr-sig').toDataURL('image/png'); }
        });
    });

    /* Signature pad */
    var sigDirty = false, cv = $('tr-sig');
    if (cv) {
        var ctx = cv.getContext('2d'), drawing = false;
        ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.strokeStyle = '#1C2A1F';
        var pos = function (e) { var r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; };
        cv.addEventListener('pointerdown', function (e) { drawing = true; var p = pos(e); ctx.beginPath(); ctx.moveTo(p[0], p[1]); cv.setPointerCapture(e.pointerId); });
        cv.addEventListener('pointermove', function (e) { if (!drawing) { return; } var p = pos(e); ctx.lineTo(p[0], p[1]); ctx.stroke(); sigDirty = true; });
        cv.addEventListener('pointerup', function () { drawing = false; });
        $('tr-sig-clear').addEventListener('click', function () { ctx.clearRect(0, 0, cv.width, cv.height); sigDirty = false; $('tr-sig-data').value = ''; });
    }

    window.addEventListener('online', function () { ui(); flush(); });
    window.addEventListener('offline', ui);
    setInterval(function () { flush(); ui(); }, 20000);

    if (cfg.tracking) { Geo.start(onPos); }
    ui(); flush();
})();
</script>
@endsection
