@extends('legal.layout')

@section('title', 'Cookie Policy · Sera ya Vidakuzi')
@section('meta_description', 'The few cookies and browser storage NeAS uses to keep you signed in and your forms safe. Sera ya Vidakuzi ya NeAS.')

@section('en')
<h1>Cookie Policy</h1>
<p class="legal-meta">Effective {{ config('legal.effective_en') }} · Version {{ config('legal.version') }}</p>

<p>Cookies are small files a website saves in your browser. NeAS uses only the cookies and browser storage it needs to work. We do not use advertising cookies or analytics cookies. Because these are strictly necessary, there is no cookie banner to accept.</p>

<h2>What we use</h2>
<div class="legal-table-wrap">
<table class="legal-table">
    <thead><tr><th scope="col">Name</th><th scope="col">What it does</th><th scope="col">How long</th></tr></thead>
    <tbody>
        <tr><td>Session cookie (its name contains "session")</td><td>Keeps you signed in and remembers your active role while you use NeAS.</td><td>Until you sign out, close the browser, or the session times out.</td></tr>
        <tr><td>XSRF-TOKEN</td><td>Protects forms from being sent by other websites without your knowledge.</td><td>Same as the session.</td></tr>
        <tr><td>Browser storage on the trip page</td><td>Transporters' devices keep location updates during a trip when the signal is lost, and send them when it returns.</td><td>Until the updates are sent.</td></tr>
    </tbody>
</table>
</div>

<h2>Content from other sites</h2>
<p>Pages that show a map load it from OpenStreetMap. OpenStreetMap receives your IP address and the map area, and may set its own cookies. See the OpenStreetMap privacy policy for details.</p>

<h2>Your choices</h2>
<p>You can delete or block cookies in your browser settings. If you block the cookies in the table above, you will not be able to sign in or submit forms. If we ever add analytics or other optional cookies, we will ask for your consent first and update this page.</p>

<h2>Contact</h2>
@include('legal.partials.contact')
@endsection

@section('sw')
<h1>Sera ya Vidakuzi</h1>
<p class="legal-meta">Inaanza kutumika {{ config('legal.effective_sw') }} · Toleo {{ config('legal.version') }}</p>

<p>Vidakuzi ni mafaili madogo ambayo tovuti huyahifadhi kwenye kivinjari chako. NeAS hutumia tu vidakuzi na hifadhi ya kivinjari vinavyohitajika ili ifanye kazi. Hatutumii vidakuzi vya matangazo wala vya uchambuzi wa takwimu. Kwa kuwa ni vya lazima, hakuna bango la kukubali vidakuzi.</p>

<h2>Tunachotumia</h2>
<div class="legal-table-wrap">
<table class="legal-table">
    <thead><tr><th scope="col">Jina</th><th scope="col">Kinafanya nini</th><th scope="col">Kwa muda gani</th></tr></thead>
    <tbody>
        <tr><td>Kidakuzi cha kikao (jina lake lina neno "session")</td><td>Kinakuweka umeingia na kukumbuka jukumu lako linalotumika unapotumia NeAS.</td><td>Hadi utoke, ufunge kivinjari, au kikao kiishe muda.</td></tr>
        <tr><td>XSRF-TOKEN</td><td>Kinalinda fomu zisitumwe na tovuti nyingine bila wewe kujua.</td><td>Sawa na kikao.</td></tr>
        <tr><td>Hifadhi ya kivinjari kwenye ukurasa wa safari</td><td>Vifaa vya wasafirishaji huhifadhi taarifa za mahali wakati wa safari mtandao ukikatika, na kuzituma mtandao ukirudi.</td><td>Hadi taarifa zitumwe.</td></tr>
    </tbody>
</table>
</div>

<h2>Maudhui kutoka tovuti nyingine</h2>
<p>Kurasa zinazoonyesha ramani huipakia kutoka OpenStreetMap. OpenStreetMap hupokea anwani yako ya IP na eneo la ramani, na inaweza kuweka vidakuzi vyake yenyewe. Soma sera ya faragha ya OpenStreetMap kwa maelezo zaidi.</p>

<h2>Uchaguzi wako</h2>
<p>Unaweza kufuta au kuzuia vidakuzi kwenye mipangilio ya kivinjari chako. Ukizuia vidakuzi vilivyo kwenye jedwali hapo juu, hutaweza kuingia wala kutuma fomu. Tukiongeza uchambuzi wa takwimu au vidakuzi vingine vya hiari, tutaomba ridhaa yako kwanza na kusasisha ukurasa huu.</p>

<h2>Mawasiliano</h2>
@include('legal.partials.contact')
@endsection
