@extends('legal.layout')

@section('title', 'Terms of Use · Masharti ya Matumizi')
@section('meta_description', 'The rules for using NeAS: accounts, listings, escrow payments, delivery, disputes and your responsibilities. Masharti ya Matumizi ya NeAS.')

@section('en')
<h1>Terms of Use</h1>
<p class="legal-meta">Effective {{ config('legal.effective_en') }} · Version {{ config('legal.version') }}</p>

<p>These terms are the agreement between you and {{ config('legal.entity') }} ("NeAS", "we", "us") for using the NeAS website, app, SMS and USSD services. By creating an account or using NeAS, you accept these terms and our <a href="{{ route('legal.privacy', ['lang' => 'en']) }}">Privacy Policy</a>. If you do not accept them, please do not use NeAS.</p>

<h2>1. Who can use NeAS</h2>
<ul>
    <li>You must be 18 or over and able to make a binding agreement.</li>
    <li>You must give true information and keep it up to date.</li>
    <li>You must keep your password secret. You are responsible for what happens under your account, so tell us at once if you think someone else has used it.</li>
    <li>Each person may have one account, and one NIDA number can be linked to one account.</li>
    <li>You must pass identity verification before you can sell, ship or list on NeAS.</li>
</ul>

<h2>2. Roles and workspaces</h2>
<p>You can choose one or more roles, such as producer, buyer, transporter, warehouse owner, landowner, trainer or expert. Each role has its own workspace and its own rules, shown in the app.</p>

<h2>3. Listings and conduct</h2>
<p>You agree that you will:</p>
<ul>
    <li>describe produce, services and prices honestly, with true quantities, quality and photos;</li>
    <li>only list things you are allowed to sell, and follow Tanzanian law, including rules on agricultural produce, animals, fish, transport and food safety;</li>
    <li>treat other users with respect.</li>
</ul>
<p>You agree that you will not:</p>
<ul>
    <li>post false, misleading or illegal listings, or fake ratings and reviews;</li>
    <li>take a deal outside NeAS to avoid escrow or fees after meeting on NeAS;</li>
    <li>harass or threaten anyone, or share another person's private data without permission;</li>
    <li>try to break into, overload or copy NeAS, or use it for fraud or money laundering.</li>
</ul>

<h2>4. Orders and escrow payments</h2>
<ul>
    <li>When a buyer places an order, the buyer pays and NeAS holds the money in escrow. The seller does not receive it yet.</li>
    <li>The seller must accept or decline an order within 24 hours. If the seller does not answer, the order is cancelled and the buyer is refunded.</li>
    <li>After delivery, the buyer has 48 hours to confirm that the goods arrived as agreed, or to open a dispute. If the buyer does neither, NeAS releases the money to the seller automatically.</li>
    <li>When the buyer confirms, or the 48 hours pass, the money is released to the seller's wallet, less any fees that applied.</li>
    <li>Fees for NeAS services, transport and storage are shown before you confirm. We will not charge a fee that was not shown to you.</li>
</ul>

<h2>5. Disputes and refunds</h2>
<ul>
    <li>If something is wrong, open a dispute from the order before the 48 hours end. The money stays in escrow while the dispute is open.</li>
    <li>Each side has 3 days to add evidence, such as photos, messages and delivery records.</li>
    <li>NeAS will decide within 5 working days after the evidence period, and may release the money to the seller, refund the buyer, or release part to each side.</li>
    <li>Manual refunds above TZS 500,000 need approval from a second NeAS staff member.</li>
    <li>Our decision does not stop you from going to a court or another body allowed by law.</li>
</ul>

<h2>6. Wallet and payouts</h2>
<p>Money you earn sits in your NeAS wallet until you ask for a payout to your mobile-money account or another payout method offered in the app. Payouts may need extra identity checks, and we may delay or refuse a payout we reasonably believe is linked to fraud or breaks the law. Payment providers may charge their own fees.</p>

<h2>7. Transport, storage and land</h2>
<p>Transporters, warehouse owners and landowners are independent. NeAS connects you and checks the documents they upload, but we do not own the vehicles, stores or land, and we do not control how services are carried out. Delivery is confirmed with the delivery code and proof shown in the app. Keep it safe, and share it only with the person receiving the goods.</p>

<h2>8. Expert advice, AI and weather</h2>
<p>Advice from experts and trainers, answers from Ask AI, crop diagnosis, crop calendars and weather alerts are for general guidance only. They can be wrong or out of date. Check important decisions, such as spraying, planting, harvesting or treating animals, with a qualified person. Photos and questions you send to Ask AI are processed by Google Gemini, as explained in the Privacy Policy.</p>

<h2>9. Ratings and reviews</h2>
<p>Ratings and reviews must be honest and based on a real dealing. We may remove content that is fake, abusive or unlawful, and may suspend accounts that post it.</p>

<h2>10. Your content</h2>
<p>You keep ownership of what you post. You give NeAS permission to store, show and process it so we can run the service, for example showing your listing to buyers. Do not post anything you do not have the right to share.</p>

<h2>11. Suspending or closing an account</h2>
<p>We may limit, suspend or close an account that breaks these terms, puts others at risk, or is needed to follow the law. You can close your own account in Settings once your open orders are finished. Money you are owed will be paid out first, unless it is held for a dispute or a legal reason.</p>

<h2>12. Our responsibility</h2>
<p>NeAS is a platform that connects people. We do not own, inspect or guarantee the produce, services, transport or land that users offer, and we are not a party to the sale between users. We work to keep NeAS available and secure, but we cannot promise it will never be interrupted. To the extent the law allows, NeAS is not liable for losses caused by users, by third-party providers, or by events outside our control, such as network failures, weather or strikes. Nothing in these terms removes any right or liability that cannot lawfully be removed.</p>

<h2>13. Changes</h2>
<p>We may update these terms. We will change the date above and tell you about important changes in the app or by message. If you keep using NeAS after a change takes effect, you accept the new terms.</p>

<h2>14. Governing law</h2>
<p>These terms are governed by the laws of the United Republic of Tanzania, and the courts of Tanzania can hear disputes about them.</p>

<h2>15. Contact</h2>
@include('legal.partials.contact')
@endsection

@section('sw')
<h1>Masharti ya Matumizi</h1>
<p class="legal-meta">Yanaanza kutumika {{ config('legal.effective_sw') }} · Toleo {{ config('legal.version') }}</p>

<p>Masharti haya ni makubaliano kati yako na {{ config('legal.entity') }} ("NeAS", "sisi") kuhusu kutumia tovuti, programu, SMS na huduma za USSD za NeAS. Kwa kufungua akaunti au kutumia NeAS, unakubali masharti haya na <a href="{{ route('legal.privacy', ['lang' => 'sw']) }}">Sera yetu ya Faragha</a>. Usipokubali, tafadhali usitumie NeAS.</p>

<h2>1. Nani anaweza kutumia NeAS</h2>
<ul>
    <li>Lazima uwe na umri wa miaka 18 au zaidi na uweze kufanya makubaliano yanayokufunga kisheria.</li>
    <li>Lazima utoe taarifa za kweli na kuzisasisha.</li>
    <li>Lazima ulinde siri ya nenosiri lako. Unawajibika kwa kinachotokea kwenye akaunti yako, kwa hiyo tuambie mara moja ukidhani mtu mwingine ameitumia.</li>
    <li>Kila mtu anaweza kuwa na akaunti moja, na namba moja ya NIDA inaunganishwa na akaunti moja.</li>
    <li>Lazima ukamilishe uthibitisho wa utambulisho kabla ya kuuza, kusafirisha au kutangaza kwenye NeAS.</li>
</ul>

<h2>2. Majukumu na maeneo ya kazi</h2>
<p>Unaweza kuchagua jukumu moja au zaidi, kama mzalishaji, mnunuzi, msafirishaji, mmiliki wa ghala, mmiliki wa ardhi, mkufunzi au mtaalamu. Kila jukumu lina eneo lake la kazi na kanuni zake, zinazoonyeshwa ndani ya programu.</p>

<h2>3. Matangazo na mwenendo</h2>
<p>Unakubali kwamba:</p>
<ul>
    <li>utaeleza mazao, huduma na bei kwa uaminifu, ukitoa kiasi, ubora na picha za kweli;</li>
    <li>utatangaza tu vitu unavyoruhusiwa kuuza, na utafuata sheria za Tanzania, ikiwemo kanuni kuhusu mazao ya kilimo, wanyama, samaki, usafirishaji na usalama wa chakula;</li>
    <li>utawaheshimu watumiaji wengine.</li>
</ul>
<p>Unakubali kwamba hutafanya yafuatayo:</p>
<ul>
    <li>kuweka matangazo ya uongo, ya kupotosha au haramu, wala makadirio au maoni bandia;</li>
    <li>kuhamishia biashara nje ya NeAS ili kukwepa escrow au ada baada ya kukutana kupitia NeAS;</li>
    <li>kumnyanyasa au kumtishia mtu yeyote, au kushiriki taarifa binafsi za mtu mwingine bila ruhusa;</li>
    <li>kujaribu kuvunja, kuelemea au kunakili NeAS, au kuitumia kwa udanganyifu au utakatishaji fedha.</li>
</ul>

<h2>4. Oda na malipo ya escrow</h2>
<ul>
    <li>Mnunuzi anapoweka oda, analipa na NeAS inashikilia fedha kwenye escrow. Muuzaji hapokei bado.</li>
    <li>Muuzaji lazima akubali au akatae oda ndani ya saa 24. Asipojibu, oda inafutwa na mnunuzi anarejeshewa fedha zake.</li>
    <li>Baada ya kufikishiwa mzigo, mnunuzi ana saa 48 kuthibitisha kwamba bidhaa zimefika kama ilivyokubaliwa, au kufungua mgogoro. Asipofanya lolote kati ya hayo, NeAS inaachilia fedha kwa muuzaji moja kwa moja.</li>
    <li>Mnunuzi akithibitisha, au saa 48 zikipita, fedha zinaachiliwa kwenye pochi ya muuzaji, baada ya kukatwa ada zilizohusika.</li>
    <li>Ada za huduma za NeAS, usafirishaji na uhifadhi zinaonyeshwa kabla hujathibitisha. Hatutakutoza ada ambayo hukuonyeshwa.</li>
</ul>

<h2>5. Migogoro na marejesho</h2>
<ul>
    <li>Kukiwa na tatizo, fungua mgogoro kutoka kwenye oda kabla ya saa 48 kuisha. Fedha zinabaki kwenye escrow wakati mgogoro upo wazi.</li>
    <li>Kila upande una siku 3 kuongeza ushahidi, kama picha, ujumbe na kumbukumbu za usafirishaji.</li>
    <li>NeAS itaamua ndani ya siku 5 za kazi baada ya kipindi cha ushahidi, na inaweza kuachilia fedha kwa muuzaji, kumrudishia mnunuzi, au kuzigawa kati ya pande zote mbili.</li>
    <li>Marejesho ya mkono yanayozidi TZS 500,000 yanahitaji idhini ya mfanyakazi wa pili wa NeAS.</li>
    <li>Uamuzi wetu haukuzuii kwenda mahakamani au kwenye chombo kingine kinachoruhusiwa na sheria.</li>
</ul>

<h2>6. Pochi na malipo ya kutoa</h2>
<p>Fedha unazopata hukaa kwenye pochi yako ya NeAS hadi uombe zitolewe kwenda kwenye akaunti yako ya pesa kwa simu au njia nyingine ya malipo inayotolewa kwenye programu. Kutoa fedha kunaweza kuhitaji ukaguzi wa ziada wa utambulisho, na tunaweza kuchelewesha au kukataa malipo tunayoamini kwa sababu za msingi yanahusiana na udanganyifu au yanavunja sheria. Watoa huduma za malipo wanaweza kutoza ada zao wenyewe.</p>

<h2>7. Usafirishaji, uhifadhi na ardhi</h2>
<p>Wasafirishaji, wamiliki wa ghala na wamiliki wa ardhi ni watu huru. NeAS inawaunganisha na kukagua nyaraka wanazopakia, lakini hatumiliki magari, maghala wala ardhi, na hatudhibiti jinsi huduma zinavyotekelezwa. Usafirishaji unathibitishwa kwa msimbo wa kufikisha na uthibitisho unaoonyeshwa kwenye programu. Uutunze, na uutoe kwa mtu anayepokea mzigo tu.</p>

<h2>8. Ushauri wa wataalamu, AI na hali ya hewa</h2>
<p>Ushauri kutoka kwa wataalamu na wakufunzi, majibu ya Uliza AI, uchunguzi wa mazao, kalenda za mazao na tahadhari za hali ya hewa ni mwongozo wa jumla tu. Vinaweza kuwa na makosa au kupitwa na wakati. Hakiki maamuzi muhimu, kama kunyunyizia dawa, kupanda, kuvuna au kutibu wanyama, na mtu mwenye sifa. Picha na maswali unayotuma kwa Uliza AI huchakatwa na Google Gemini, kama ilivyoelezwa kwenye Sera ya Faragha.</p>

<h2>9. Makadirio na maoni</h2>
<p>Makadirio na maoni lazima yawe ya kweli na yatokane na biashara halisi. Tunaweza kuondoa maudhui bandia, ya matusi au haramu, na kusimamisha akaunti zinazoyaweka.</p>

<h2>10. Maudhui yako</h2>
<p>Unabaki mmiliki wa unachoweka. Unaipa NeAS ruhusa ya kuhifadhi, kuonyesha na kuchakata ili tuweze kuendesha huduma, kwa mfano kuonyesha tangazo lako kwa wanunuzi. Usiweke chochote ambacho huna haki ya kukishiriki.</p>

<h2>11. Kusimamisha au kufunga akaunti</h2>
<p>Tunaweza kupunguza, kusimamisha au kufunga akaunti inayovunja masharti haya, inayohatarisha wengine, au inayohitajika ili kufuata sheria. Unaweza kufunga akaunti yako mwenyewe kwenye Mipangilio mara oda zako zilizo wazi zitakapokamilika. Fedha unazodai zitalipwa kwanza, isipokuwa zimeshikiliwa kwa sababu ya mgogoro au sababu ya kisheria.</p>

<h2>12. Wajibu wetu</h2>
<p>NeAS ni jukwaa linalounganisha watu. Hatumiliki, hatukagui wala hatuhakikishi mazao, huduma, usafirishaji au ardhi vinavyotolewa na watumiaji, na hatuko upande wa mauzo kati ya watumiaji. Tunajitahidi kuiweka NeAS ipatikane na salama, lakini hatuwezi kuahidi kwamba haitakatika. Kwa kiwango kinachoruhusiwa na sheria, NeAS haiwajibiki kwa hasara zinazosababishwa na watumiaji, watoa huduma wengine, au matukio nje ya uwezo wetu, kama hitilafu za mtandao, hali ya hewa au migomo. Hakuna kitu katika masharti haya kinachoondoa haki au wajibu ambao hauwezi kuondolewa kisheria.</p>

<h2>13. Mabadiliko</h2>
<p>Tunaweza kusasisha masharti haya. Tutabadilisha tarehe iliyo juu na kukujulisha mabadiliko muhimu ndani ya programu au kwa ujumbe. Ukiendelea kutumia NeAS baada ya mabadiliko kuanza, unakubali masharti mapya.</p>

<h2>14. Sheria zinazotumika</h2>
<p>Masharti haya yanatawaliwa na sheria za Jamhuri ya Muungano wa Tanzania, na mahakama za Tanzania zinaweza kusikiliza migogoro kuhusu masharti haya.</p>

<h2>15. Mawasiliano</h2>
@include('legal.partials.contact')
@endsection
