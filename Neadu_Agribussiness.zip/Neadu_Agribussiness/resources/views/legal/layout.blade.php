@extends('layouts.app')

@section('robots', 'index,follow')

@section('content')
<main class="legal-page">
    <nav class="legal-tabs" aria-label="{{ $lang === 'sw' ? 'Kurasa za kisheria' : 'Legal pages' }}">
        <ul>
            <li><a href="{{ route('legal.privacy', ['lang' => $lang]) }}" @if (request()->routeIs('legal.privacy')) aria-current="page" @endif>{{ $lang === 'sw' ? 'Sera ya Faragha' : 'Privacy Policy' }}</a></li>
            <li><a href="{{ route('legal.terms', ['lang' => $lang]) }}" @if (request()->routeIs('legal.terms')) aria-current="page" @endif>{{ $lang === 'sw' ? 'Masharti ya Matumizi' : 'Terms of Use' }}</a></li>
            <li><a href="{{ route('legal.cookies', ['lang' => $lang]) }}" @if (request()->routeIs('legal.cookies')) aria-current="page" @endif>{{ $lang === 'sw' ? 'Vidakuzi' : 'Cookies' }}</a></li>
        </ul>
        <ul aria-label="{{ $lang === 'sw' ? 'Lugha' : 'Language' }}">
            <li><a href="{{ url()->current() }}?lang=en" lang="en" hreflang="en" @if ($lang === 'en') aria-current="true" @endif>English</a></li>
            <li><a href="{{ url()->current() }}?lang=sw" lang="sw" hreflang="sw" @if ($lang === 'sw') aria-current="true" @endif>Kiswahili</a></li>
        </ul>
    </nav>
    <article class="legal-doc" lang="{{ $lang }}">
        @if ($lang === 'sw')
            @yield('sw')
        @else
            @yield('en')
        @endif
    </article>
</main>
@endsection
