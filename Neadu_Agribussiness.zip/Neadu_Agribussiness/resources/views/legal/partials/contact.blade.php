@php($legalEmail = (string) config('legal.email'))
@php($legalPhone = (string) config('legal.phone'))
<p>
    <strong>{{ config('legal.entity') }}</strong><br>
    {{ config('legal.address') }}
    @if ($legalEmail !== '')<br>{{ $lang === 'sw' ? 'Barua pepe' : 'Email' }}: <a href="mailto:{{ $legalEmail }}">{{ $legalEmail }}</a>@endif
    @if ($legalPhone !== '')<br>{{ $lang === 'sw' ? 'Simu' : 'Phone' }}: <a href="tel:{{ preg_replace('/\s+/', '', $legalPhone) }}">{{ $legalPhone }}</a>@endif
    @if ($legalEmail === '' && $legalPhone === '')<br>{{ $lang === 'sw' ? 'Tuandikie kupitia ukurasa wa Msaada ndani ya akaunti yako.' : 'Write to us through the Help page inside your account.' }}@endif
</p>
