@extends('legal.layout')

@section('title', 'Privacy Policy · Sera ya Faragha')
@section('meta_description', 'How NeAS collects, uses, shares and protects your personal data, and the choices you have. Sera ya Faragha ya NeAS.')

@section('en')
<h1>Privacy Policy</h1>
<p class="legal-meta">Effective {{ config('legal.effective_en') }} · Version {{ config('legal.version') }}</p>

<p>This policy explains what personal data NeAS collects, why we collect it, who we share it with and what choices you have. It covers the NeAS website and app, and NeAS by SMS and USSD. We handle personal data in line with Tanzania's Personal Data Protection Act, 2022.</p>

<h2>1. Who is responsible</h2>
@include('legal.partials.contact')

<h2>2. What we collect</h2>
<div class="legal-table-wrap">
<table class="legal-table">
    <thead><tr><th scope="col">Data</th><th scope="col">Why we need it</th></tr></thead>
    <tbody>
        <tr><td><strong>Account:</strong> your name, email address and/or phone number, password (kept only as a one-way hash), roles and language.</td><td>To create and protect your account.</td></tr>
        <tr><td><strong>Identity:</strong> your NIDA number (stored encrypted) and documents you upload for checking, such as vehicle or business documents.</td><td>To verify participants and stop duplicate or fake accounts. Verification is needed before you can sell, ship or list.</td></tr>
        <tr><td><strong>Marketplace activity:</strong> listings, orders, contracts, ratings and reviews, disputes and evidence, price alerts and favourites.</td><td>To run the marketplace and settle disagreements.</td></tr>
        <tr><td><strong>Payments:</strong> wallet balance, ledger entries, payout requests and payment references from payment providers.</td><td>To hold money in escrow, pay sellers, and keep the financial records the law requires.</td></tr>
        <tr><td><strong>Location:</strong> pickup and drop-off points, listing and land locations, and the live position of a transporter during a trip.</td><td>For delivery, live tracking and weather alerts for your area.</td></tr>
        <tr><td><strong>Messages:</strong> chats between users and with NeAS staff.</td><td>So you can agree orders, and so we can resolve disputes and safety reports.</td></tr>
        <tr><td><strong>Ask AI and crop diagnosis:</strong> the questions, voice commands and photos you send, and the answers you get.</td><td>To give you advice. These are processed by Google Gemini (see section 4).</td></tr>
        <tr><td><strong>SMS and USSD:</strong> your phone number and the commands you send.</td><td>So you can use NeAS without internet.</td></tr>
        <tr><td><strong>Technical and security data:</strong> IP address, browser and device type, sign-in attempts, and audit logs of sensitive actions.</td><td>To keep NeAS secure and detect fraud and abuse.</td></tr>
    </tbody>
</table>
</div>

<h2>3. How we use your data</h2>
<ul>
    <li>To provide the service: accounts, listings, orders, escrow, delivery, storage and expert advice.</li>
    <li>To verify identity and prevent fraud.</li>
    <li>To send you notices about your orders, payments, deliveries, price alerts and weather alerts.</li>
    <li>To resolve disputes and keep users safe.</li>
    <li>To improve NeAS, including the accuracy of AI answers.</li>
    <li>To meet our legal duties, such as keeping financial records.</li>
</ul>
<p>We do not sell your personal data, and we do not use it for third-party advertising.</p>

<h2>4. Who we share data with</h2>
<ul>
    <li><strong>Other NeAS users</strong>, only what is needed for a deal: your name, role, ratings, listings and the delivery details of an order you take part in. A buyer and seller can see a transporter's live position for their own delivery.</li>
    <li><strong>Payment and mobile-money providers</strong>, to take and send payments.</li>
    <li><strong>SMS and USSD providers</strong>, to deliver messages and menus.</li>
    <li><strong>Google (Gemini)</strong>, which receives the questions and photos you send to Ask AI and crop diagnosis so it can produce an answer.</li>
    <li><strong>Open-Meteo</strong>, which receives the coordinates of the area you ask the weather for, but not your name.</li>
    <li><strong>OpenStreetMap</strong>, whose servers see your IP address and the map area when a map is shown.</li>
    <li><strong>Hosting and technical service providers</strong> who run NeAS for us under confidentiality duties.</li>
    <li><strong>Authorities</strong>, when a law or a court order requires it.</li>
</ul>

<h2>5. Data sent outside Tanzania</h2>
<p>Some providers above, such as Google, OpenStreetMap and Open-Meteo, run servers outside Tanzania. We send them only what is needed for the feature you use, and we choose providers that protect data.</p>

<h2>6. Cookies</h2>
<p>NeAS uses only the cookies it needs to work. See our <a href="{{ route('legal.cookies', ['lang' => 'en']) }}">Cookie Policy</a>.</p>

<h2>7. How long we keep data</h2>
<p>We keep your data while your account is open. If you delete your account, we remove or anonymise your personal details, but we keep order, financial and audit records for as long as the law requires. You can delete your Ask AI history at any time from the Ask AI page. Deleting a chat removes it from your own view.</p>

<h2>8. Your rights</h2>
<p>You may ask to see the personal data we hold about you, correct it, delete it, limit how we use it, object to a use, or withdraw a consent you gave. You can delete your account in Settings once your open orders are finished. You may also complain to the Personal Data Protection Commission of Tanzania. To use any right, contact us using the details in section 1.</p>

<h2>9. Security</h2>
<p>We encrypt NIDA numbers, store passwords only as hashes, use HTTPS, limit who can reach personal data, limit repeated requests, and keep audit logs. No system is perfectly secure. If you suspect a problem with your account, tell us straight away. If a breach affects you, we will tell you and the authorities as the law requires.</p>

<h2>10. Children</h2>
<p>NeAS is for people aged 18 and over. We do not knowingly collect data from children. If you think a child has an account, contact us and we will remove it.</p>

<h2>11. Changes to this policy</h2>
<p>When we change this policy, we will update the date above. For important changes we will also tell you in the app or by message.</p>

<h2>12. Contact</h2>
@include('legal.partials.contact')
@endsection

@section('sw')
<h1>Sera ya Faragha</h1>
<p class="legal-meta">Inaanza kutumika {{ config('legal.effective_sw') }} · Toleo {{ config('legal.version') }}</p>

<p>Sera hii inaeleza NeAS hukusanya taarifa binafsi gani, kwa nini, tunazishiriki na nani, na uchaguzi ulio nao. Inahusu tovuti na programu ya NeAS, pamoja na NeAS kupitia SMS na USSD. Tunashughulikia taarifa binafsi kwa mujibu wa Sheria ya Ulinzi wa Taarifa Binafsi ya Tanzania, 2022.</p>

<h2>1. Nani anawajibika</h2>
@include('legal.partials.contact')

<h2>2. Tunakusanya nini</h2>
<div class="legal-table-wrap">
<table class="legal-table">
    <thead><tr><th scope="col">Taarifa</th><th scope="col">Kwa nini tunazihitaji</th></tr></thead>
    <tbody>
        <tr><td><strong>Akaunti:</strong> jina lako, barua pepe na/au namba ya simu, nenosiri (huhifadhiwa kama alama isiyorudishika), majukumu na lugha.</td><td>Kuunda na kulinda akaunti yako.</td></tr>
        <tr><td><strong>Utambulisho:</strong> namba yako ya NIDA (huhifadhiwa kwa usimbaji fiche) na nyaraka unazopakia ili zikaguliwe, kama nyaraka za gari au biashara.</td><td>Kuthibitisha washiriki na kuzuia akaunti bandia au zinazojirudia. Uthibitisho unahitajika kabla ya kuuza, kusafirisha au kutangaza.</td></tr>
        <tr><td><strong>Shughuli za soko:</strong> matangazo, oda, mikataba, makadirio na maoni, migogoro na ushahidi, tahadhari za bei na vipendwa.</td><td>Kuendesha soko na kutatua kutokubaliana.</td></tr>
        <tr><td><strong>Malipo:</strong> salio la pochi, kumbukumbu za mahesabu, maombi ya malipo na viashiria vya malipo kutoka kwa watoa huduma za malipo.</td><td>Kushikilia fedha kwenye escrow, kulipa wauzaji, na kutunza kumbukumbu za fedha zinazotakiwa na sheria.</td></tr>
        <tr><td><strong>Mahali:</strong> sehemu za kuchukua na kufikisha mzigo, mahali pa matangazo na ardhi, na mahali alipo msafirishaji wakati wa safari.</td><td>Kwa usafirishaji, ufuatiliaji wa moja kwa moja na tahadhari za hali ya hewa kwa eneo lako.</td></tr>
        <tr><td><strong>Ujumbe:</strong> mazungumzo kati ya watumiaji, na kati yako na wafanyakazi wa NeAS.</td><td>Ili mkubaliane kuhusu oda, na ili tutatue migogoro na ripoti za usalama.</td></tr>
        <tr><td><strong>Uliza AI na uchunguzi wa mazao:</strong> maswali, amri za sauti na picha unazotuma, pamoja na majibu unayopata.</td><td>Kukupa ushauri. Hivi huchakatwa na Google Gemini (angalia sehemu ya 4).</td></tr>
        <tr><td><strong>SMS na USSD:</strong> namba yako ya simu na amri unazotuma.</td><td>Ili uweze kutumia NeAS bila intaneti.</td></tr>
        <tr><td><strong>Taarifa za kiufundi na usalama:</strong> anwani ya IP, aina ya kivinjari na kifaa, majaribio ya kuingia, na kumbukumbu za ukaguzi za vitendo nyeti.</td><td>Kuweka NeAS salama na kugundua udanganyifu na matumizi mabaya.</td></tr>
    </tbody>
</table>
</div>

<h2>3. Tunazitumiaje taarifa zako</h2>
<ul>
    <li>Kutoa huduma: akaunti, matangazo, oda, escrow, usafirishaji, uhifadhi na ushauri wa wataalamu.</li>
    <li>Kuthibitisha utambulisho na kuzuia udanganyifu.</li>
    <li>Kukutumia taarifa kuhusu oda, malipo, usafirishaji, tahadhari za bei na hali ya hewa.</li>
    <li>Kutatua migogoro na kuwaweka watumiaji salama.</li>
    <li>Kuboresha NeAS, ikiwemo usahihi wa majibu ya AI.</li>
    <li>Kutimiza wajibu wetu kisheria, kama kutunza kumbukumbu za fedha.</li>
</ul>
<p>Hatuuzi taarifa zako binafsi, na hatuzitumii kwa matangazo ya watu wengine.</p>

<h2>4. Tunashiriki taarifa na nani</h2>
<ul>
    <li><strong>Watumiaji wengine wa NeAS</strong>, kile tu kinachohitajika kwa biashara: jina lako, jukumu, makadirio, matangazo na maelezo ya usafirishaji wa oda unayoshiriki. Mnunuzi na muuzaji wanaweza kuona mahali alipo msafirishaji kwa usafirishaji wao.</li>
    <li><strong>Watoa huduma za malipo na pesa kwa simu</strong>, ili kupokea na kutuma malipo.</li>
    <li><strong>Watoa huduma za SMS na USSD</strong>, ili kufikisha ujumbe na menyu.</li>
    <li><strong>Google (Gemini)</strong>, anayepokea maswali na picha unazotuma kwa Uliza AI na uchunguzi wa mazao ili atoe jibu.</li>
    <li><strong>Open-Meteo</strong>, anayepokea viwianishi vya eneo unalouliza hali ya hewa, lakini si jina lako.</li>
    <li><strong>OpenStreetMap</strong>, ambao seva zao huona anwani yako ya IP na eneo la ramani ramani inapoonyeshwa.</li>
    <li><strong>Watoa huduma wa kuhifadhi na wa kiufundi</strong> wanaoendesha NeAS kwa niaba yetu chini ya wajibu wa usiri.</li>
    <li><strong>Mamlaka</strong>, pale sheria au amri ya mahakama inapohitaji.</li>
</ul>

<h2>5. Taarifa zinazotumwa nje ya Tanzania</h2>
<p>Baadhi ya watoa huduma hapo juu, kama Google, OpenStreetMap na Open-Meteo, wana seva nje ya Tanzania. Tunawatumia kile tu kinachohitajika kwa huduma unayotumia, na tunachagua watoa huduma wanaolinda taarifa.</p>

<h2>6. Vidakuzi</h2>
<p>NeAS hutumia vidakuzi vinavyohitajika ili ifanye kazi tu. Angalia <a href="{{ route('legal.cookies', ['lang' => 'sw']) }}">Sera ya Vidakuzi</a>.</p>

<h2>7. Tunazihifadhi kwa muda gani</h2>
<p>Tunahifadhi taarifa zako wakati akaunti yako ipo. Ukifuta akaunti yako, tunaondoa au kuficha utambulisho wa taarifa zako binafsi, lakini tunaendelea kuhifadhi kumbukumbu za oda, fedha na ukaguzi kwa muda ambao sheria inahitaji. Unaweza kufuta historia yako ya Uliza AI wakati wowote kwenye ukurasa wa Uliza AI. Kufuta mazungumzo huyaondoa kwenye mwonekano wako mwenyewe.</p>

<h2>8. Haki zako</h2>
<p>Unaweza kuomba kuona taarifa binafsi tulizonazo kukuhusu, kuzirekebisha, kuzifuta, kupunguza matumizi yake, kupinga matumizi fulani, au kuondoa ridhaa uliyotoa. Unaweza kufuta akaunti yako kwenye Mipangilio mara oda zako zilizo wazi zitakapokamilika. Pia unaweza kuwasilisha malalamiko kwa Tume ya Ulinzi wa Taarifa Binafsi ya Tanzania. Ili kutumia haki yoyote, wasiliana nasi kwa maelezo ya sehemu ya 1.</p>

<h2>9. Usalama</h2>
<p>Tunasimba namba za NIDA, tunahifadhi nenosiri kama alama zisizorudishika, tunatumia HTTPS, tunapunguza wanaoweza kufikia taarifa binafsi, tunadhibiti maombi yanayojirudia, na tunatunza kumbukumbu za ukaguzi. Hakuna mfumo ulio salama kabisa. Ukishuku tatizo kwenye akaunti yako, tuambie mara moja. Ikitokea uvunjaji wa usalama unaokuathiri, tutakujulisha wewe na mamlaka kama sheria inavyotaka.</p>

<h2>10. Watoto</h2>
<p>NeAS ni kwa watu wenye umri wa miaka 18 na zaidi. Hatukusanyi kwa kujua taarifa za watoto. Ukiamini mtoto ana akaunti, wasiliana nasi na tutaiondoa.</p>

<h2>11. Mabadiliko ya sera hii</h2>
<p>Tunapobadilisha sera hii, tutasasisha tarehe iliyo juu. Kwa mabadiliko muhimu tutakujulisha pia ndani ya programu au kwa ujumbe.</p>

<h2>12. Mawasiliano</h2>
@include('legal.partials.contact')
@endsection
