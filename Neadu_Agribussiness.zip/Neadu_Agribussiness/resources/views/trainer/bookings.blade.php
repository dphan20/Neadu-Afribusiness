@extends('trainer.layout')
@section('title', 'Bookings')
@section('trainer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('trainer.dashboard') }}">← Overview</a><span class="eyebrow">S-28 · TUR-02</span><h1>Bookings &amp; payments</h1><p>Every seat across your tours. Unpaid seats are released automatically when the hold timer ends.</p></div></div>
<section class="panel data-panel">
    <form method="get" class="filter-bar"><label><span class="sr-only">Status</span><select name="status" onchange="this.form.submit()"><option value="">All statuses</option>@foreach (['reserved', 'paid', 'completed', 'expired', 'cancelled', 'refunded'] as $s)<option value="{{ $s }}" @selected($status === $s)>{{ ucfirst($s) }}</option>@endforeach</select></label></form>
    @if ($bookings->isEmpty())<div class="empty-state"><span class="empty-mark">0</span><h3>No bookings</h3><p>Bookings appear once attendees reserve seats.</p></div>
    @else<div class="table-wrap"><table class="data-table"><thead><tr><th>Attendee</th><th>Tour</th><th>Seats</th><th>Amount</th><th>Status</th><th>Hold / paid</th></tr></thead><tbody>
        @foreach ($bookings as $b)<tr><td>{{ $b->attendee?->name }}</td><td><a class="text-link" href="{{ route('trainer.tours.show', $b->tour->listing) }}">{{ $b->tour->listing->title }}</a></td><td>{{ $b->seats }}</td><td>{{ \App\Support\Money::tzs($b->total_minor) }}</td>
        <td><span class="by-chip st-{{ in_array($b->status, ['paid', 'completed'], true) ? 'released' : ($b->status === 'reserved' ? 'pending' : 'refunded') }}">{{ ucfirst($b->status) }}</span></td>
        <td>{{ $b->status === 'reserved' ? 'Pay by '.$b->expires_at?->format('d M H:i') : ($b->paid_at ? 'Paid '.$b->paid_at->format('d M H:i') : '—') }}</td></tr>@endforeach
    </tbody></table></div>@endif
</section>
@endsection
