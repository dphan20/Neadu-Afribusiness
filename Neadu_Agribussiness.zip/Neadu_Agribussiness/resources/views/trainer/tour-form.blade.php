@extends('trainer.layout')
@section('title', $tour ? 'Edit tour' : 'Create tour')
@section('trainer')
@php($it = old('itinerary', $tour?->itinerary ?? [['title' => '', 'details' => '']]))
@php($goals = old('goals', $tour?->learning_goals ?? ['']))
<div class="workspace-heading"><div><a class="back-link" href="{{ $tour ? route('trainer.tours.show', $tour->listing) : route('trainer.tours') }}">← Back</a><span class="eyebrow">S-29 · TUR-01 · R2</span><h1>{{ $tour ? 'Edit tour' : 'Create agri-tour' }}</h1><p>Describe the trip, set the price and seats, and list what attendees will learn.</p></div></div>
@error('intent')<div class="flash flash-error" role="alert" style="margin-bottom:14px">{{ $message }}</div>@enderror
<form method="post" action="{{ $tour ? route('trainer.tours.update', $tour->listing) : route('trainer.tours.store') }}" enctype="multipart/form-data" class="by-form by-split">@csrf @if ($tour) @method('PUT') @endif
    <div class="by-stack">
        <section class="panel by-stack"><span class="eyebrow">BASICS</span>
            <label>Title<input name="title" required maxlength="160" value="{{ old('title', $tour?->listing->title) }}" placeholder="e.g. Avocado farming study tour, Njombe"></label>
            <label>Description<textarea name="description" required minlength="20" maxlength="4000">{{ old('description', $tour?->description) }}</textarea></label>
            <label>Route<input name="route" required maxlength="255" value="{{ old('route', $tour?->route) }}" placeholder="Iringa → Mufindi → Njombe"></label>
            <label>Meeting point<input name="meeting_point" required maxlength="255" value="{{ old('meeting_point', $tour?->meeting_point) }}"></label>
            <div class="two"><label>Starts<input type="datetime-local" name="starts_at" required value="{{ old('starts_at', $tour?->starts_at?->format('Y-m-d\TH:i')) }}"></label><label>Ends<input type="datetime-local" name="ends_at" required value="{{ old('ends_at', $tour?->ends_at?->format('Y-m-d\TH:i')) }}"></label></div>
            @error('starts_at')<small style="color:var(--color-error)">{{ $message }}</small>@enderror @error('ends_at')<small style="color:var(--color-error)">{{ $message }}</small>@enderror</section>
        <section class="panel by-stack"><span class="eyebrow">ITINERARY</span>
            <div id="itinerary" class="by-stack">@foreach ($it as $i => $row)<div class="by-card"><label>Stop / day {{ $i + 1 }}<input name="itinerary[{{ $i }}][title]" required maxlength="120" value="{{ $row['title'] ?? '' }}"></label><label>Details<textarea name="itinerary[{{ $i }}][details]" maxlength="500" style="min-height:60px">{{ $row['details'] ?? '' }}</textarea></label></div>@endforeach</div>
            <button type="button" class="button button-outline button-small" id="addStop" style="width:max-content">+ Add stop</button></section>
        <section class="panel by-stack"><span class="eyebrow">LEARNING GOALS</span>
            <div id="goals" class="by-stack">@foreach ($goals as $g)<input name="goals[]" required maxlength="160" value="{{ $g }}" placeholder="e.g. Grafting and orchard spacing">@endforeach</div>
            <button type="button" class="button button-outline button-small" id="addGoal" style="width:max-content">+ Add goal</button></section>
    </div>
    <aside class="by-stack">
        <section class="panel by-stack"><span class="eyebrow">PRICE &amp; SEATS</span>
            <label>Price per seat (TZS)<input type="number" name="price" min="0" step="any" required value="{{ old('price', $tour ? intdiv($tour->listing->price_minor, 100) : '') }}"></label>
            <label>Seats<input type="number" name="seats" min="1" max="500" required value="{{ old('seats', $tour?->seats) }}"></label>
            @if ($taken)<small class="compact-copy">{{ $taken }} seat(s) already booked, so the price is locked and seats cannot go below that.</small>@endif
            <label>Hold unpaid seats for (minutes)<input type="number" name="hold_minutes" min="10" max="1440" required value="{{ old('hold_minutes', $tour?->hold_minutes ?? 30) }}"></label>
            <p class="compact-copy">TUR-02: a reserved seat is released automatically if it is not paid within this time.</p>
            <label>Region<select name="region_id"><option value="">—</option>@foreach ($regions as $r)<option value="{{ $r->id }}" @selected((string) old('region_id', $tour?->listing->region_id) === (string) $r->id)>{{ $r->name }}</option>@endforeach</select></label>
            <label>Photos (up to 4)<input type="file" name="photos[]" multiple accept="image/*"></label></section>
        <section class="panel by-stack">
            <button class="button button-primary button-full" name="intent" value="submit" @disabled(! $verified)>Save &amp; submit for review</button>
            <button class="button button-outline button-full" name="intent" value="draft">Save as draft</button>
            @unless ($verified)<p class="compact-copy">Submitting needs a verified identity.</p>@endunless
            <p class="compact-copy">Submitted tours are checked before bookings open.</p></section>
    </div>
</form>
<script>
let stops = {{ count($it) }};
document.getElementById('addStop').onclick = () => { const d = document.createElement('div'); d.className = 'by-card';
  d.innerHTML = `<label>Stop / day ${stops + 1}<input name="itinerary[${stops}][title]" required maxlength="120"></label><label>Details<textarea name="itinerary[${stops}][details]" maxlength="500" style="min-height:60px"></textarea></label>`;
  document.getElementById('itinerary').append(d); stops++; };
document.getElementById('addGoal').onclick = () => { const i = document.createElement('input'); i.name = 'goals[]'; i.required = true; i.maxLength = 160; document.getElementById('goals').append(i); };
</script>
@endsection
