@extends('trainer.layout')
@section('title', 'Group messages')
@section('trainer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('trainer.dashboard') }}">← Overview</a><span class="eyebrow">TUR-03</span><h1>Group messages</h1><p>One group chat per tour with all booked attendees.</p></div></div>
<p><a class="button button-primary button-small" href="{{ route('me.chat.new') }}">✉ {{ __('chat.new_message') }}</a></p>
<section class="panel">
    @forelse ($conversations as $c)@php($last = $c->messages->last())
        <a href="{{ route('trainer.chat.show', $c) }}" style="display:flex;justify-content:space-between;gap:10px;padding:12px 0;border-bottom:1px solid var(--color-border)">
            <span><b>{{ $tours[$c->tour_id]->listing->title ?? 'Tour' }}</b><br><small>{{ $c->participants->count() }} participants</small></span>
            <span style="text-align:right"><small>{{ $last ? \Illuminate\Support\Str::limit($last->body ?? '', 40) : 'No messages yet' }}</small><br><small>{{ $c->updated_at?->diffForHumans() }}</small></span></a>
    @empty<div class="empty-state"><span class="empty-mark">✉</span><h3>No group chats</h3><p>Send a message to attendees from a tour page to start one.</p><a class="button button-primary button-small" href="{{ route('trainer.tours') }}">My tours</a></div>@endforelse
</section>
@endsection
