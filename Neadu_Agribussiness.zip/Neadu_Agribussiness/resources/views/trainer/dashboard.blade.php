@extends('trainer.layout')
@section('title', 'Trainer workspace')
@section('trainer')
<div class="workspace-heading"><div><span class="eyebrow">Mwandaaji</span><h1>Karibu, {{ explode(' ', auth()->user()->name)[0] }}</h1><p>Run agri-tours, manage attendees and get paid.</p></div><a class="button button-primary" href="{{ route('trainer.tours.create') }}">Create tour</a></div>
<div class="metric-grid">@foreach ($metrics as $m)<article class="metric-card metric-{{ $m['tone'] }}"><span class="metric-label">{{ $m['label'] }}</span><strong>{{ $m['value'] }}</strong><span class="metric-caption">Trainer workspace</span></article>@endforeach</div>
<div class="workspace-columns">
    <section class="panel panel-main"><div class="panel-heading"><div><span class="eyebrow">UPCOMING</span><h2>Your next tours</h2></div><a class="text-link" href="{{ route('trainer.tours') }}">All tours →</a></div>
        @forelse ($upcoming as $t)<a href="{{ route('trainer.tours.show', $t->listing) }}" style="display:flex;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid var(--color-border)">
            <span><b>{{ $t->listing->title }}</b><br><small>{{ $t->starts_at->format('d M Y H:i') }} · {{ $t->route }}</small></span><span style="text-align:right"><span class="by-chip">{{ $t->seatsTaken() }}/{{ $t->seats }} seats</span><br><small>{{ ucfirst(str_replace('_', ' ', $t->listing->status)) }}</small></span></a>
        @empty<div class="empty-state"><span class="empty-mark">0</span><h3>No tours yet</h3><p>Create your first agri-tour.</p><a class="button button-primary button-small" href="{{ route('trainer.tours.create') }}">Create tour</a></div>@endforelse</section>
    <aside class="panel guidance-panel"><span class="guidance-icon">T</span><span class="eyebrow">ORGANISER</span><h2>Your record</h2>
        <p class="compact-copy">{{ $stats['tours'] }} tour(s) completed · {{ $stats['attendees'] }} attendee(s) trained</p>
        <p>@if ($stats['reviews'])<span class="by-stars">{{ str_repeat('★', (int) round($stats['avg'])) }}{{ str_repeat('☆', 5 - (int) round($stats['avg'])) }}</span> {{ $stats['avg'] }} ({{ $stats['reviews'] }} reviews)@else No reviews yet @endif</p>
        <a class="text-link" href="{{ route('trainer.profile') }}">Organiser profile →</a></aside>
</div>
@endsection
