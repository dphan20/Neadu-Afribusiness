@extends('trainer.layout')
@section('title', $tour->listing->title)
@section('trainer')
@php($ls = $tour->listing->status)
@php($open = $tour->state === 'scheduled')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('trainer.tours') }}">← My agri-tours</a><span class="eyebrow">S-28 · MANAGE TOUR</span><h1>{{ $tour->listing->title }}</h1>
    <p><span class="by-chip st-{{ $tour->state === 'completed' ? 'released' : ($tour->state === 'cancelled' ? 'refunded' : ($ls === 'active' ? 'held' : 'pending')) }}">{{ $tour->state !== 'scheduled' ? ucfirst($tour->state) : ucfirst(str_replace('_', ' ', $ls)) }}</span> &nbsp;{{ $tour->starts_at->format('d M Y H:i') }} → {{ $tour->ends_at?->format('d M H:i') }} · {{ $tour->route }}</p></div>
    <div class="by-row">
        @if ($open)<a class="button button-outline button-small" href="{{ route('trainer.tours.edit', $tour->listing) }}">Edit</a>@endif
        @if ($open && in_array($ls, ['draft', 'rejected'], true))<form method="post" action="{{ route('trainer.tours.submit', $tour->listing) }}">@csrf<button class="button button-primary button-small">Submit for review</button></form>@endif
        @if ($open && in_array($ls, ['active', 'closed'], true))<form method="post" action="{{ route('trainer.tours.sales', $tour->listing) }}">@csrf<button class="button button-outline button-small">{{ $ls === 'active' ? 'Pause bookings' : 'Reopen bookings' }}</button></form>@endif
        @if ($tour->state === 'completed')<a class="button button-primary button-small" href="{{ route('trainer.tours.certificates', $tour->listing) }}" target="_blank">Certificates</a>@endif</div></div>
<div class="metric-grid">
    <article class="metric-card metric-blue"><span class="metric-label">Seats taken</span><strong>{{ $taken }} / {{ $tour->seats }}</strong><span class="metric-caption">{{ $tour->seatsLeft() }} left</span></article>
    <article class="metric-card metric-green"><span class="metric-label">Paid revenue</span><strong>{{ \App\Support\Money::tzs($revenue) }}</strong><span class="metric-caption">Before {{ $feeBps / 100 }}% platform fee</span></article>
    <article class="metric-card metric-gold"><span class="metric-label">Price per seat</span><strong>{{ \App\Support\Money::tzs($tour->listing->price_minor) }}</strong><span class="metric-caption">Hold time {{ $tour->hold_minutes }} min</span></article>
    <article class="metric-card metric-green"><span class="metric-label">Rating</span><strong>{{ $tour->reviews->count() ? $avg.' ★' : '—' }}</strong><span class="metric-caption">{{ $tour->reviews->count() }} review(s)</span></article>
</div>
<div class="by-split" style="margin-top:16px">
    <div class="by-stack">
        <section class="panel data-panel"><div class="panel-heading"><div><span class="eyebrow">BOOKINGS · TUR-02</span><h2>Attendees</h2></div></div>
            @if ($bookings->isEmpty())<div class="empty-state"><span class="empty-mark">0</span><h3>No bookings yet</h3><p>{{ $ls === 'active' ? 'Share your tour so people can book.' : 'Bookings open once the tour is live.' }}</p></div>
            @else
            <form id="attendanceForm" method="post" action="{{ route('trainer.tours.attendance', $tour->listing) }}">@csrf</form>
            <div class="table-wrap"><table class="data-table"><thead><tr><th>Attendee</th><th>Seats</th><th>Amount</th><th>Status</th><th>Present</th><th></th></tr></thead><tbody>
                @foreach ($bookings as $b)<tr><td><b>{{ $b->attendee?->name }}</b><br><small>{{ $b->attendee?->phone }}</small></td><td>{{ $b->seats }}</td><td>{{ \App\Support\Money::tzs($b->total_minor) }}</td>
                <td><span class="by-chip st-{{ in_array($b->status, ['paid', 'completed'], true) ? 'released' : ($b->status === 'reserved' ? 'pending' : 'refunded') }}">{{ ucfirst($b->status) }}</span>
                    @if ($b->status === 'reserved')<br><small>Pay by {{ $b->expires_at?->format('H:i') }} ({{ $b->expires_at?->diffForHumans() }})</small>@endif
                    @if ($b->certificate_no)<br><small>🎓 {{ $b->certificate_no }}</small>@endif</td>
                <td>@if ($b->status === 'paid' && $open)<input type="checkbox" form="attendanceForm" name="attended[]" value="{{ $b->id }}" @checked($b->attended) aria-label="Present" style="width:auto;min-height:0">@elseif ($b->status === 'completed'){{ $b->attended ? 'Yes' : 'No' }}@endif</td>
                <td><div class="by-row">
                    @if ($b->status === 'reserved')<form method="post" action="{{ route('trainer.bookings.action', $b->uuid) }}">@csrf<input type="hidden" name="action" value="release"><button class="button button-tiny button-outline">Release seat</button></form>
                        @if ($simulate)<form method="post" action="{{ route('trainer.tours.simulate', $tour->listing) }}">@csrf<input type="hidden" name="action" value="pay"><input type="hidden" name="booking" value="{{ $b->uuid }}"><button class="button button-tiny button-outline">Demo: attendee pays</button></form>@endif
                    @elseif ($b->status === 'paid' && $open)<form method="post" action="{{ route('trainer.bookings.action', $b->uuid) }}" onsubmit="return confirm('Refund this seat to the attendee?')">@csrf<input type="hidden" name="action" value="refund"><button class="button button-tiny button-danger-quiet">Refund</button></form>
                    @elseif ($b->status === 'completed' && $simulate)<form method="post" action="{{ route('trainer.tours.simulate', $tour->listing) }}">@csrf<input type="hidden" name="action" value="review"><input type="hidden" name="booking" value="{{ $b->uuid }}"><button class="button button-tiny button-outline">Demo: attendee rates</button></form>@endif</div></td></tr>@endforeach
            </tbody></table></div>
            @if ($open && $bookings->where('status', 'paid')->isNotEmpty())<div style="padding:12px 16px"><button form="attendanceForm" class="button button-outline button-small">Save attendance</button></div>@endif
            @endif</section>
        @if ($open && in_array($ls, ['active', 'closed'], true))
        <section class="panel"><span class="eyebrow">FINISH THE TOUR · TUR-03</span>
            <p class="compact-copy" style="margin:8px 0">Completing the tour issues a certificate to every attendee marked present and releases the paid seats to your balance (minus the platform fee). Unpaid reservations are cancelled.@if ($tour->starts_at->isFuture() && ! $simulate) You can do this once the tour has started.@endif</p>
            <div class="by-row"><form method="post" action="{{ route('trainer.tours.complete', $tour->listing) }}" onsubmit="return confirm('Complete the tour, issue certificates and release payment?')">@csrf<button class="button button-primary">Complete tour &amp; issue certificates</button></form>
                <form method="post" action="{{ route('trainer.tours.cancel', $tour->listing) }}" onsubmit="return confirm('Cancel the tour and refund every paid seat?')">@csrf<button class="button button-danger-quiet">Cancel tour &amp; refund</button></form></div></section>
        @endif
        <section class="panel"><span class="eyebrow">DETAILS</span>
            <p style="white-space:pre-line;margin:8px 0">{{ $tour->description }}</p>
            <dl class="by-kv"><dt>Meeting point</dt><dd>{{ $tour->meeting_point }}</dd></dl>
            <h3 style="margin:14px 0 6px">Itinerary</h3><ol style="margin:0;padding-left:18px">@foreach ($tour->itinerary ?? [] as $i)<li><b>{{ $i['title'] }}</b>@if (! empty($i['details']))<br><small>{{ $i['details'] }}</small>@endif</li>@endforeach</ol>
            <h3 style="margin:14px 0 6px">Learning goals</h3><ul style="margin:0;padding-left:18px">@foreach ($tour->learning_goals ?? [] as $g)<li>{{ $g }}</li>@endforeach</ul></section>
        @if ($tour->reviews->isNotEmpty())<section class="panel data-panel"><div class="panel-heading"><div><span class="eyebrow">TUR-04</span><h2>Attendee ratings</h2></div></div>
            @foreach ($tour->reviews as $r)<div style="padding:12px 16px;border-bottom:1px solid var(--color-border)"><span class="by-stars">{{ str_repeat('★', $r->stars) }}{{ str_repeat('☆', 5 - $r->stars) }}</span> <small>{{ $r->attendee?->name }}</small><p style="margin:4px 0 0">{{ $r->comment }}</p></div>@endforeach</section>@endif
    </div>
    <aside class="by-stack">
        <section class="panel"><span class="eyebrow">MESSAGE ALL ATTENDEES</span>
            <form method="post" action="{{ route('trainer.tours.message', $tour->listing) }}" class="by-form" style="margin-top:8px">@csrf<textarea name="body" required maxlength="2000" placeholder="e.g. Please arrive 15 minutes early and bring boots."></textarea><button class="button button-primary button-small">Send to group</button></form>
            @if ($conversation)<p class="compact-copy" style="margin-top:8px"><a class="text-link" href="{{ route('trainer.chat.show', $conversation) }}">Open group chat →</a></p>@endif</section>
        @if ($simulate && $open)<section class="by-demo"><b>Demo mode</b> — acts as the admin and the attendee app until they are connected.
            <div class="by-row" style="margin-top:8px">
                @if ($ls === 'pending_review')<form method="post" action="{{ route('trainer.tours.simulate', $tour->listing) }}">@csrf<input type="hidden" name="action" value="approve"><button class="button button-tiny button-outline">Approve listing</button></form>@endif
                @if ($ls === 'active')<form method="post" action="{{ route('trainer.tours.simulate', $tour->listing) }}">@csrf<input type="hidden" name="action" value="book"><input type="hidden" name="seats" value="2"><button class="button button-tiny button-outline">Someone reserves 2 seats</button></form>@endif</div></section>@endif
    </aside>
</div>
@endsection
