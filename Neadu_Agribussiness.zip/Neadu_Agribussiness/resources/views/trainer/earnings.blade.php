@extends('trainer.layout')
@section('title', 'Earnings')
@section('trainer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('trainer.dashboard') }}">← Overview</a><span class="eyebrow">S-45 · PAYOUTS</span><h1>Tour earnings</h1><p>Your balance, what is waiting in escrow and your payouts.</p></div></div>
@unless ($verified)<div class="by-note" style="margin-bottom:14px">Payouts are available once your identity is verified.</div>@endunless
<div class="metric-grid">
    <article class="metric-card metric-green"><span class="metric-label">Available balance</span><strong>{{ \App\Support\Money::tzs($balance) }}</strong><span class="metric-caption">Ready to withdraw</span></article>
    <article class="metric-card metric-gold"><span class="metric-label">In escrow (after fee)</span><strong>{{ \App\Support\Money::tzs($pending) }}</strong><span class="metric-caption">Released when a tour completes</span></article>
    <article class="metric-card metric-blue"><span class="metric-label">Total earned</span><strong>{{ \App\Support\Money::tzs($earned) }}</strong><span class="metric-caption">All tours</span></article>
</div>
<div class="by-split" style="margin-top:16px">
    <div class="by-stack">
        <section class="panel data-panel"><div class="panel-heading"><div><span class="eyebrow">LEDGER</span><h2>Recent movements</h2></div></div>
            @if ($entries->isEmpty())<div class="empty-state"><h3>No earnings yet</h3><p>Completed tours appear here.</p></div>
            @else<div class="table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Description</th><th>In</th><th>Out</th></tr></thead><tbody>
                @foreach ($entries as $e)<tr><td>{{ $e->created_at?->format('d M Y H:i') }}</td><td>{{ $e->memo }}</td><td>{{ $e->credit_minor ? \App\Support\Money::tzs($e->credit_minor) : '' }}</td><td>{{ $e->debit_minor ? \App\Support\Money::tzs($e->debit_minor) : '' }}</td></tr>@endforeach
            </tbody></table></div>@endif</section>
        <section class="panel data-panel"><div class="panel-heading"><div><span class="eyebrow">PAYOUTS</span><h2>Withdrawals</h2></div></div>
            @if ($payouts->isEmpty())<div class="empty-state"><h3>No payouts yet</h3></div>
            @else<div class="table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Amount</th><th>To</th><th>Status</th></tr></thead><tbody>
                @foreach ($payouts as $p)<tr><td>{{ $p->created_at?->format('d M Y') }}</td><td>{{ \App\Support\Money::tzs($p->amount_minor) }}</td><td>{{ strtoupper($p->provider) }} {{ $p->destination }}</td><td><span class="by-chip st-{{ $p->state === 'paid' ? 'released' : 'pending' }}">{{ ucfirst($p->state) }}</span></td></tr>@endforeach
            </tbody></table></div>@endif</section>
    </div>
    <aside class="panel"><span class="eyebrow">WITHDRAW</span>
        <form method="post" action="{{ route('trainer.earnings.payout') }}" class="by-form" style="margin-top:8px">@csrf
            <label>Amount (TZS)<input type="number" name="amount" min="1000" step="any" max="{{ intdiv($balance, 100) }}" value="{{ old('amount') }}" required></label>
            <label>To<select name="provider"><option value="mpesa">M-Pesa</option><option value="tigopesa">Mixx by Yas (Tigo Pesa)</option><option value="airtelmoney">Airtel Money</option><option value="halopesa">HaloPesa</option><option value="bank">Bank account</option></select></label>
            <label>Phone or account number<input name="destination" required maxlength="40" value="{{ old('destination', $phone) }}"></label>
            <button class="button button-primary button-full" @disabled($balance < 100000 || ! $verified)>Withdraw</button>
            <p class="compact-copy">Minimum 1,000 TZS. The platform fee is already deducted from each tour.</p></form></aside>
</div>
@endsection
