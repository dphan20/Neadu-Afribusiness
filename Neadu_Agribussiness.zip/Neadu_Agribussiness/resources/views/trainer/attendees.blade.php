@extends('producer.layout')
@section('title', 'Attendees')
@section('heading', 'Attendees')
@section('lead', $listing->title)
@section('body')
<div class="table-wrap"><table class="data-table"><thead><tr><th>Name</th><th>Phone</th><th>Seats</th><th>Status</th></tr></thead><tbody>@forelse($bookings as $b)<tr><td>{{ $b->user?->name }}</td><td>{{ $b->user?->phone }}</td><td>{{ $b->seats }}</td><td>{{ ucfirst($b->status) }}</td></tr>@empty<tr><td colspan="4">No paid bookings yet.</td></tr>@endforelse</tbody></table></div>
<form class="p-card pf" method="post" action="{{ route('trainer.tours.message',$listing) }}">@csrf<label for="body">Message to all attendees</label><textarea id="body" name="body" required></textarea><div class="p-actions"><button class="button button-primary">Send to everyone</button></div></form>
@endsection
