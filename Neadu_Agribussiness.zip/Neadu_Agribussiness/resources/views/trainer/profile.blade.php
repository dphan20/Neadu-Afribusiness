@extends('trainer.layout')
@section('title', 'Organiser profile')
@section('trainer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('trainer.dashboard') }}">← Overview</a><span class="eyebrow">TUR-04</span><h1>Organiser profile</h1><p>What attendees see. Ratings from your tours build it.</p></div></div>
<div class="by-split">
    <div class="by-stack">
        <section class="panel"><div class="by-row" style="gap:14px"><span class="avatar" style="width:56px;height:56px;font-size:24px">{{ strtoupper(substr($me->name, 0, 1)) }}</span>
            <span><b style="font-size:18px">{{ $data['organisation'] ?? $me->name }}</b><br><span class="by-chip">{{ $me->isIdentityVerified() ? '✓ Verified organiser' : 'Not verified' }}</span></span></div>
            @if (! empty($data['bio']))<p style="margin:12px 0 0">{{ $data['bio'] }}</p>@endif
            <dl class="by-kv" style="margin-top:12px"><dt>Rating</dt><dd>@if ($stats['reviews'])<span class="by-stars">{{ str_repeat('★', (int) round($stats['avg'])) }}{{ str_repeat('☆', 5 - (int) round($stats['avg'])) }}</span> {{ $stats['avg'] }} ({{ $stats['reviews'] }})@else No ratings yet @endif</dd><dt>Tours completed</dt><dd>{{ $stats['tours'] }}</dd><dt>Attendees trained</dt><dd>{{ $stats['attendees'] }}</dd></dl></section>
        <section class="panel data-panel"><div class="panel-heading"><div><span class="eyebrow">REVIEWS</span><h2>What attendees say</h2></div></div>
            @forelse ($reviews as $r)<div style="padding:12px 16px;border-bottom:1px solid var(--color-border)"><span class="by-stars">{{ str_repeat('★', $r->stars) }}{{ str_repeat('☆', 5 - $r->stars) }}</span> <small>{{ $r->attendee?->name }} · {{ $r->tour?->listing?->title }}</small><p style="margin:4px 0 0">{{ $r->comment }}</p></div>
            @empty<div class="empty-state"><h3>No reviews yet</h3><p>Attendees can rate you after a completed tour.</p></div>@endforelse</section>
    </div>
    <aside class="panel"><span class="eyebrow">EDIT PROFILE</span>
        <form method="post" action="{{ route('trainer.profile.update') }}" class="by-form" style="margin-top:8px">@csrf
            <label>Organisation / farm name<input name="organisation" maxlength="120" value="{{ old('organisation', $data['organisation'] ?? '') }}"></label>
            <label>About<textarea name="bio" maxlength="800">{{ old('bio', $data['bio'] ?? '') }}</textarea></label>
            <label>Website<input type="url" name="website" maxlength="160" value="{{ old('website', $data['website'] ?? '') }}"></label>
            <button class="button button-primary button-full">Save profile</button></form></aside>
</div>
@endsection
