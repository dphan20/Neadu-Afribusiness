@extends('trainer.layout')
@section('title', 'My agri-tours')
@section('trainer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('trainer.dashboard') }}">← Overview</a><span class="eyebrow">S-29 · TOURS</span><h1>My agri-tours</h1><p>Create tours, manage attendees and issue certificates.</p></div>
    <a class="button button-primary" href="{{ route('trainer.tours.create') }}">New tour</a></div>
@if (session('status'))<div class="flash" role="status" style="margin-bottom:14px">{{ session('status') }}</div>@endif
@unless ($verified)<div class="flash" style="margin-bottom:14px">Drafts are always allowed. Submitting a tour for review needs a verified identity.</div>@endunless
<div class="by-row" style="margin-bottom:14px">
    @foreach (['all' => 'All', 'draft' => 'Drafts', 'review' => 'In review', 'live' => 'Live', 'past' => 'Past'] as $k => $label)
        <a class="button button-small {{ $tab === $k ? 'button-primary' : 'button-outline' }}" href="{{ route('trainer.tours', ['tab' => $k]) }}">{{ $label }}</a>
    @endforeach
</div>
@forelse ($tours as $t)
<section class="panel" style="margin-bottom:12px">
    <a class="text-link" href="{{ route('trainer.tours.show', $t->listing) }}"><b>{{ $t->listing->title }}</b></a>
    <span class="p-tag">{{ $t->state !== 'scheduled' ? ucfirst($t->state) : ucfirst(str_replace('_', ' ', $t->listing->status)) }}</span>
    <p class="compact-copy">{{ $t->starts_at?->format('d M Y H:i') }} · {{ $t->route }} · {{ $t->seatsTaken() }}/{{ $t->seats }} seats · {{ \App\Support\Money::tzs($t->listing->price_minor) }} per seat</p>
</section>
@empty
<div class="empty-state"><span class="empty-mark">0</span><h3>No tours here</h3><p>Create your first agri-tour.</p></div>
@endforelse
@endsection
