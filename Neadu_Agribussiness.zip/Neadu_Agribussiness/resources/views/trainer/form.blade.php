@extends('producer.layout')
@php($t = $listing?->tour)
@section('title', $listing ? 'Edit tour' : 'New tour')
@section('heading', $listing ? 'Edit tour' : 'Create an agri-tour')
@section('lead', 'Tell attendees where you go, what they learn and what it costs.')
@section('body')
<form class="p-card pf" method="post" enctype="multipart/form-data" action="{{ $listing ? route('trainer.tours.update',$listing) : route('trainer.tours.store') }}">@csrf @if($listing)@method('PUT')@endif
<label for="title">Title</label><input id="title" name="title" value="{{ old('title',$listing?->title) }}" required>
<label for="route">Route</label><input id="route" name="route" value="{{ old('route',$t?->route) }}" required>
<div class="row"><div><label for="region_id">Region</label><select id="region_id" name="region_id">@foreach($regions as $r)<option value="{{ $r->id }}" @selected(old('region_id',$listing?->region_id)==$r->id)>{{ $r->name }}</option>@endforeach</select></div>
<div><label for="district_id">District</label><select id="district_id" name="district_id" >@foreach($districts as $d)<option value="{{ $d->id }}" data-region="{{ $d->region_id }}" @selected(old('district_id',$listing?->district_id)==$d->id)>{{ $d->name }}</option>@endforeach</select></div></div>
<div class="row"><div><label for="starts_at">Starts</label><input id="starts_at" name="starts_at" type="datetime-local" value="{{ old('starts_at',$t?->starts_at?->format('Y-m-d\TH:i')) }}" required></div>
<div><label for="ends_at">Ends</label><input id="ends_at" name="ends_at" type="datetime-local" value="{{ old('ends_at',$t?->ends_at?->format('Y-m-d\TH:i')) }}"></div>
<div><label for="seats">Seats</label><input id="seats" name="seats" type="number" value="{{ old('seats',$t?->seats) }}" required></div>
<div><label for="price">Price per seat (TSh)</label><input id="price" name="price" value="{{ old('price',$listing ? number_format($listing->price_minor/100,2,'.','') : '') }}" required></div></div>
<label for="itinerary">Itinerary (one stop per line)</label><textarea id="itinerary" name="itinerary" required>{{ old('itinerary',implode("\n",$t?->itinerary['stops'] ?? [])) }}</textarea>
<label for="goals">Learning goals (one per line)</label><textarea id="goals" name="goals" required>{{ old('goals',implode("\n",$t?->itinerary['goals'] ?? [])) }}</textarea>
<label for="photos">Photos</label><input id="photos" name="photos[]" type="file" accept="image/*" capture="environment" multiple>
<div class="p-actions"><button class="button button-primary" name="submit" value="1">Submit for review</button><button class="button button-outline" name="submit" value="0">Save draft</button></div></form>
<script>const rg=document.getElementById('region_id'),ds=document.getElementById('district_id');function f(){[...ds.options].forEach(o=>o.hidden=o.dataset.region!==rg.value);if(ds.selectedOptions[0]?.hidden)ds.value=[...ds.options].find(o=>!o.hidden)?.value}rg.addEventListener('change',f);f();</script>
@endsection
