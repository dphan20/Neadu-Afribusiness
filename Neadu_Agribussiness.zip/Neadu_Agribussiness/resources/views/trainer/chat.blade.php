@extends('trainer.layout')
@section('title', 'Group chat')
@section('trainer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('trainer.chat') }}">← Group messages</a><span class="eyebrow">GROUP CHAT</span><h1>{{ $tour?->listing->title ?? 'Tour' }}</h1><p>{{ $conversation->participants->pluck('name')->implode(', ') }}</p></div>
    @if ($tour)<a class="button button-outline button-small" href="{{ route('trainer.tours.show', $tour->listing) }}">Open tour</a>@endif</div>
<section class="panel">
    @include('partials.chat-toolbar', ['area' => 'me', 'conversation' => $conversation])
    <div style="display:grid;gap:8px;min-height:240px;max-height:55vh;overflow:auto">
        @php($thread = $conversation->messagesFor(auth()->user()))
        @forelse ($thread as $m)@include('partials.chat-bubble', ['m' => $m, 'bubble' => 'by-msg', 'area' => 'me'])@empty<p class="compact-copy">No messages yet.</p>@endforelse
        <span id="latest"></span></div>
    <form method="post" action="{{ route('trainer.chat.send', $conversation) }}" class="by-form" style="margin-top:14px">@csrf<textarea name="body" required maxlength="2000" placeholder="Write to the group…"></textarea><button class="button button-primary button-small" style="width:max-content">Send</button></form>
</section>
@endsection
