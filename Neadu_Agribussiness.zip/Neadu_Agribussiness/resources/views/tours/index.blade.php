@extends('producer.layout')
@section('title', 'Agri-tours')
@section('heading', 'Agri-tours')
@section('lead', 'Learn on the farm. Book seats and get a certificate.')
@section('head-action')<a class="button button-outline" href="{{ route('tours.mine') }}">My bookings</a>@endsection
@section('body')
@forelse($tours as $t)<a class="p-card" style="display:block" href="{{ route('tours.show',$t) }}"><b>{{ $t->title }}</b><p class="p-muted">{{ $t->tour->starts_at->format('d-m-Y H:i') }} · {{ $t->tour->route }} · {{ $t->region?->name }} · TSh {{ number_format(intdiv($t->price_minor,100)) }} per seat · by {{ $t->owner?->name }}</p></a>@empty<div class="p-card">No upcoming tours.</div>@endforelse
@endsection
