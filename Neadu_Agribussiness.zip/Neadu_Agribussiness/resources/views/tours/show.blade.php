@extends('producer.layout')
@section('title', $listing->title)
@section('heading', $listing->title)
@section('lead', $listing->tour->route.' · '.$listing->tour->starts_at->format('d-m-Y H:i'))
@section('body')
<div class="p-card"><p>Organiser: <b>{{ $listing->owner?->name }}</b> {{ $rating ? '★ '.$rating : '' }} · {{ $free }} seats left · TSh {{ number_format(intdiv($listing->price_minor,100)) }} per seat</p>
<h3>Itinerary</h3><ol>@foreach($listing->tour->itinerary ?? [] as $s)<li><b>{{ is_array($s) ? ($s['title'] ?? '') : $s }}</b>@if(is_array($s) && ! empty($s['details'])) — {{ $s['details'] }}@endif</li>@endforeach</ol><h3>What you will learn</h3><ul>@foreach($listing->tour->learning_goals ?? [] as $g)<li>{{ $g }}</li>@endforeach</ul>@if($listing->tour->meeting_point)<p class="p-muted">Meeting point: {{ $listing->tour->meeting_point }}</p>@endif</div>
@if($free > 0 && $listing->user_id !== auth()->id())<form class="p-card pf" method="post" action="{{ route('tours.book',$listing) }}">@csrf<label for="seats">Seats</label><input id="seats" name="seats" type="number" min="1" max="{{ min(20,$free) }}" value="1"><div class="p-actions"><button class="button button-primary">Hold my seats</button></div></form>@endif
@endsection
