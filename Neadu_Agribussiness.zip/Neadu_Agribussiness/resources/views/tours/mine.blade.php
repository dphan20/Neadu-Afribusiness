@extends('producer.layout')
@section('title', 'My tour bookings')
@section('heading', 'My tour bookings')
@section('lead', 'Unpaid seats are released when the hold timer runs out.')
@section('body')
@forelse($bookings as $b)<div class="p-card"><b>{{ $b->tour?->listing?->title }}</b> <span class="p-tag">{{ ucfirst($b->status) }}</span><p class="p-muted">{{ $b->seats }} seats · TSh {{ number_format(intdiv($b->total_minor,100)) }} · {{ $b->tour?->starts_at?->format('d-m-Y H:i') }}@if($b->status==='reserved' && $b->expires_at) · pay before {{ $b->expires_at->format('H:i') }}@endif</p>
@if($b->status==='reserved' && $b->expires_at?->isFuture())<form class="pf" method="post" action="{{ route('tours.pay',$b) }}">@csrf<div class="row"><div><label>Pay with</label><select name="provider"><option value="mpesa">M-Pesa</option><option value="tigopesa">Mixx by Yas</option><option value="airtelmoney">Airtel Money</option><option value="halopesa">HaloPesa</option><option value="bank">Bank</option></select></div><div><label>Phone</label><input name="phone" value="{{ auth()->user()->phone }}"></div></div><div class="p-actions"><button class="button button-primary">Pay</button></div></form>@endif
@if($b->status==='completed')@if($b->certificate_no)<div class="p-actions"><a class="button button-outline button-small" href="{{ route('tours.certificate',$b) }}" target="_blank">Certificate {{ $b->certificate_no }}</a></div>@endif
<form class="pf" method="post" action="{{ route('tours.rate',$b) }}">@csrf<label>Rate the organiser</label><select name="stars">@foreach([5,4,3,2,1] as $s)<option>{{ $s }}</option>@endforeach</select><div class="p-actions"><button class="button button-outline button-small">Rate</button></div></form>@endif</div>@empty<div class="p-card">No bookings yet.</div>@endforelse
@endsection
