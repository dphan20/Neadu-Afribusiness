@extends('layouts.admin')
@section('title', 'Document review')
@section('content')
<main class="workspace-shell admin-shell">
    <aside class="workspace-sidebar admin-sidebar">
        <div class="workspace-person"><span class="avatar avatar-admin">A</span><span><b>NeAS Console</b><small>Administration</small></span></div>
        @include('admin.partials.navigation', ['active' => 'review-documents'])
    </aside>
    <section class="workspace-main">
        <div class="workspace-heading"><div><a class="back-link" href="{{ route('admin.dashboard') }}">← Admin dashboard</a><span class="eyebrow">LND-03 · BR-08</span><h1>Document review</h1><p>Land title documents decide whether a land listing becomes Verified.</p></div></div>
        @if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
        @if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
        @forelse($docs as $d)
        <section class="panel data-panel" style="margin-bottom:14px;padding:16px">
            <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><b>{{ str_replace('_',' ',ucfirst($d->kind)) }}</b> · {{ $d->user?->name }} ({{ $d->user?->phone ?? $d->user?->email }})<br>
            @if($d->subject_type==='land')Land: {{ $titles[$d->subject_id] ?? '#'.$d->subject_id }}<br>@endif<a target="_blank" href="{{ route('admin.review.file',$d) }}">Open document</a> · {{ $d->created_at->format('d-m-Y') }}</div>
            <span class="status-chip {{ $d->status==='approved' ? 'status-success' : 'status-neutral' }}">{{ ucfirst($d->status) }}</span></div>
            @if($d->status==='pending')
            <form method="post" action="{{ route('admin.review.documents.decide',$d) }}" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;align-items:center">@csrf
                <button class="button button-primary button-small" name="decision" value="approve">Approve</button>
                <input name="reason" placeholder="Reason (required to reject)" style="flex:1;min-width:200px">
                <button class="button button-danger-quiet button-small" name="decision" value="reject">Reject</button></form>
            @elseif($d->reason)<p style="color:var(--color-error)">{{ $d->reason }}</p>@endif
        </section>
        @empty<section class="panel data-panel"><div class="empty-state"><h3>No documents yet</h3></div></section>@endforelse
    </section>
</main>
@endsection
