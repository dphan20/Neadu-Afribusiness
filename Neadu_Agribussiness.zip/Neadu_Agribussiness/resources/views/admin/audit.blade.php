@extends('admin.layout')
@section('title', 'Audit log')
@section('admin_active', 'activity')
@section('eyebrow', 'ADM-07')
@section('heading', 'Audit log')
@section('lead', 'Every administrative action: who, when, and the values before and after. Entries cannot be edited or deleted.')
@section('admin_body')
<form method="get" class="panel" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px">
    <input name="action" value="{{ request('action') }}" placeholder="Filter by action, e.g. dispute" aria-label="Action">
    <input name="actor" value="{{ request('actor') }}" placeholder="Admin user id" inputmode="numeric" aria-label="Actor id" style="max-width:150px">
    <button class="button button-outline button-small" type="submit">Filter</button>
</form>
<section class="panel data-panel"><div class="table-wrap"><table class="data-table">
    <thead><tr><th>Time</th><th>Admin</th><th>Action</th><th>Target</th><th>Before</th><th>After</th></tr></thead>
    <tbody>
    @forelse ($logs as $log)
        <tr>
            <td>{{ $log->created_at?->format('d-m-Y H:i:s') }}</td>
            <td>{{ $log->actor?->name ?? 'System' }}</td>
            <td><code>{{ $log->action }}</code></td>
            <td>{{ class_basename($log->target_type) }} #{{ $log->target_id }}</td>
            <td><small>{{ $log->before ? json_encode($log->before, JSON_UNESCAPED_UNICODE) : '—' }}</small></td>
            <td><small>{{ $log->after ? json_encode($log->after, JSON_UNESCAPED_UNICODE) : '—' }}</small></td>
        </tr>
    @empty
        <tr><td colspan="6">No entries match.</td></tr>
    @endforelse
    </tbody>
</table></div></section>
<div style="margin-top:12px">{{ $logs->links() }}</div>
@endsection
