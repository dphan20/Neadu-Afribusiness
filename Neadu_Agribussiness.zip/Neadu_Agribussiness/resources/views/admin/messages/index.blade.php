@extends('admin.layout')
@section('title', __('chat.messages'))
@section('admin_active', 'messages')
@section('heading', __('chat.messages'))
@section('lead', __('chat.new_lead'))
@section('admin_body')
<p><a class="button button-primary button-small" href="{{ route('admin.messages.new') }}">✉ {{ __('chat.new_message') }}</a></p>
@forelse ($conversations as $c)
    @php($other = $c->participants->where('id', '!=', auth()->id())->pluck('name')->implode(', '))
    <a class="p-card" style="display:block" href="{{ route('admin.messages.show', $c) }}"><b>{{ $other ?: __('chat.conversation') }}</b>@if (($unread[$c->id] ?? 0) > 0) <span class="p-tag">{{ $unread[$c->id] }}</span>@endif
        <p class="p-muted">{{ $c->lastMessage?->trashed() ? __('chat.deleted') : \Illuminate\Support\Str::limit($c->lastMessage?->body ?? '', 80) }}</p></a>
@empty
    <div class="p-card">{{ __('chat.no_chats') }}</div>
@endforelse
@endsection
