@extends('admin.layout')
@section('title', __('chat.messages'))
@section('admin_active', 'messages')
@section('heading', $conversation->participants->where('id', '!=', auth()->id())->pluck('name')->implode(', ') ?: __('chat.conversation'))
@section('lead', '')
@section('admin_body')
<a class="back-link" href="{{ route('admin.messages') }}">{{ __('chat.back') }}</a>
@include('partials.chat-toolbar', ['area' => 'admin', 'conversation' => $conversation])
<div class="p-card">
    @foreach ($conversation->messagesFor(auth()->user()) as $m)@include('partials.chat-bubble', ['m' => $m, 'bubble' => 'p-msg', 'area' => 'admin'])@endforeach
    <span id="latest"></span>
</div>
<form class="p-card pf" method="post" action="{{ route('admin.messages.send', $conversation) }}">@csrf
    <label for="body">{{ __('chat.write_placeholder') }}</label>
    <textarea id="body" name="body" required maxlength="2000"></textarea>
    <button class="button button-primary">{{ __('chat.send') }}</button>
</form>
@endsection
