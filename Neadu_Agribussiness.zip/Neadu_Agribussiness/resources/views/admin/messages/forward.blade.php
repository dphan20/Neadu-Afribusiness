@extends('admin.layout')
@section('title', __('chat.forward_title'))
@section('admin_active', 'messages')
@section('heading', __('chat.forward_title'))
@section('lead', '')
@section('admin_body')
@include('partials.chat-forward-body', ['area' => 'admin'])
@endsection
