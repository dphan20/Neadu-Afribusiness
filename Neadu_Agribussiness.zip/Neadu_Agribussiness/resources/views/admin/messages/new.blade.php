@extends('admin.layout')
@section('title', __('chat.new_message'))
@section('admin_active', 'messages')
@section('heading', __('chat.new_message'))
@section('lead', __('chat.new_lead'))
@section('admin_body')
@include('partials.chat-compose-body', ['area' => 'admin'])
@endsection
