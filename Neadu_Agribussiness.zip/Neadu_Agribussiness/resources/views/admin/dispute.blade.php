@extends('admin.layout')
@section('title', 'Dispute')
@section('admin_active', 'disputes')
@section('eyebrow', 'S-50 · ADM-03')
@section('heading', 'Dispute: '.($o->listing?->title ?? 'order'))
@section('lead', $o->buyer?->name.' bought from '.$o->seller?->name.' · TSh '.number_format(intdiv($o->total(),100)).' in escrow')
@section('admin_body')
<div class="workspace-columns">
<section class="panel panel-main"><span class="eyebrow">CASE</span>
<p><b>Opened by:</b> {{ $d->opener?->name }} on {{ $d->created_at->format('d-m-Y') }}<br><b>Reason:</b> {{ $d->reason }}</p>
@foreach($evidence['details'] as $t)<p><b>Details:</b> {{ $t }}</p>@endforeach
<p><b>Evidence</b></p>
@forelse($evidence['files'] as $i => $f)<a class="button button-outline button-small" target="_blank" href="{{ route('admin.disputes.file',[$d,$i]) }}">{{ $f['name'] }}</a> @empty<p class="p-muted">No files attached.</p>@endforelse
@if($o->delivery)<p style="margin-top:12px"><b>Delivery:</b> {{ ucfirst(str_replace('_',' ',$o->delivery->status)) }} · {{ $o->delivery->points->count() }} GPS points @if($o->delivery->delivered_at) · delivered {{ $o->delivery->delivered_at->format('d-m-Y H:i') }}@endif</p>@endif
<p class="p-muted">Evidence window {{ $d->evidence_until->isPast() ? 'closed' : 'open until '.$d->evidence_until->format('d-m-Y') }} · decide by {{ $d->decide_by->format('d-m-Y') }}</p></section>
<aside class="panel">
@if($d->decision)<span class="eyebrow">DECIDED</span><h2>{{ ucfirst($d->decision) }}</h2><p>{{ $d->admin_note }}</p>
@else
<span class="eyebrow">DECISION</span>
<p class="p-muted">Release: seller gets TSh {{ number_format(intdiv($splits['release']['seller'],100)) }} and NeAS TSh {{ number_format(intdiv($splits['release']['fee'],100)) }}. Refund: buyer gets TSh {{ number_format(intdiv($splits['refund']['refund'],100)) }} back. Refunds above TSh {{ number_format($limitTzs) }} need a second admin.</p>
<form method="post" action="{{ route('admin.disputes.decide',$d) }}" class="by-form" style="display:grid;gap:8px">@csrf
<label>Decision<select name="decision" id="dec"><option value="release">Release to seller</option><option value="partial">Partial: split</option><option value="refund">Refund buyer</option></select></label>
<label id="share" style="display:none">Seller share of the goods (TSh, less than TSh {{ number_format(intdiv((int) $o->subtotal_minor,100)) }})<input name="seller_share" value="{{ old('seller_share') }}"></label>
<label>Reason for the decision (shown in the log)<textarea name="note" required minlength="5">{{ old('note') }}</textarea></label>
<button class="button button-primary">Record decision</button></form>
<script>const dec=document.getElementById('dec'),sh=document.getElementById('share');dec.addEventListener('change',()=>sh.style.display=dec.value==='partial'?'':'none');</script>
@endif</aside></div>
@endsection
