@php
$u = auth()->user();
$links = [
    ['dashboard', 'admin.dashboard', 'Dashboard', 'reports'],
    ['users', 'admin.users', 'All users', 'users'],
    ['review-documents', 'admin.review.documents', 'Document verification', 'verification'],
    ['vehicles', 'admin.vehicles', 'Vehicle verification', 'verification'],
    ['review-listings', 'admin.review.listings', 'Listing moderation', 'listings'],
    ['disputes', 'admin.disputes', 'Disputes', 'disputes'],
    ['finance', 'admin.finance', 'Finance & payouts', 'finance'],
    ['reconcile', 'admin.reconcile', 'Reconciliation', 'finance'],
    ['reference', 'admin.reference', 'Reference data', 'reference'],
    ['reports', 'admin.section', 'Reports', 'reports'],
    ['activity', 'admin.audit', 'Audit log', 'reference'],
    ['admins', 'admin.admins', 'Admin access', 'reference'],
];
@endphp
<nav class="workspace-nav" aria-label="Admin navigation">
    @foreach ($links as $i => [$key, $route, $label, $area])
        @if (\App\Support\AdminScope::can($u, $area))
            @php
                [$name, $param] = array_pad(explode(':', $route), 2, null);
            @endphp
            <a class="{{ $active === $key ? 'active' : '' }}" href="{{ $param ? route($name, $param) : route($name) }}"><span class="nav-mark">{{ str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) }}</span>{{ $label }}</a>
        @endif
    @endforeach
</nav>
