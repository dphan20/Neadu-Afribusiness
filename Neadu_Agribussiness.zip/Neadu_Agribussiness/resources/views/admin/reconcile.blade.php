@extends('admin.layout')
@section('title', 'Reconciliation')
@section('admin_active', 'reconcile')
@section('eyebrow', 'ADM-04')
@section('heading', 'Reconcile a statement')
@section('lead', 'Upload a mobile-money or bank statement as CSV: reference (phone or account), amount in TSh, optional date. A row matches a payment when both reference and amount are equal.')
@section('admin_body')
<form class="panel" method="post" enctype="multipart/form-data" action="{{ route('admin.reconcile.run') }}" style="padding:16px;margin-bottom:14px">@csrf
<input type="file" name="statement" accept=".csv,.txt" required> <button class="button button-primary button-small">Compare</button></form>
@if($result)
@php
$t = fn ($m) => number_format(intdiv((int) $m, 100));
@endphp
<div class="metric-grid admin-metrics"><article class="metric-card metric-green"><span class="metric-label">Matched</span><strong>{{ count($result['matched']) }}</strong></article>
<article class="metric-card metric-red"><span class="metric-label">On statement, not in NeAS</span><strong>{{ count($result['statement_only']) }}</strong></article>
<article class="metric-card metric-gold"><span class="metric-label">In NeAS, not on statement</span><strong>{{ count($result['neas_only']) }}</strong></article></div>
<section class="panel data-panel"><h3 style="padding:12px 12px 0">On the statement only</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Reference</th><th>TSh</th><th>Date</th></tr></thead><tbody>@forelse($result['statement_only'] as $r)<tr><td>{{ $r['reference'] }}</td><td>{{ $t($r['amount_minor']) }}</td><td>{{ $r['date'] }}</td></tr>@empty<tr><td colspan="3">None.</td></tr>@endforelse</tbody></table></div></section>
<section class="panel data-panel" style="margin-top:14px"><h3 style="padding:12px 12px 0">In NeAS only (last 90 days)</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>Payment</th><th>Reference</th><th>TSh</th><th>State</th><th>Date</th></tr></thead><tbody>@forelse($result['neas_only'] as $r)<tr><td>{{ substr($r['payment'],0,8) }}</td><td>{{ $r['reference'] }}</td><td>{{ $t($r['amount_minor']) }}</td><td>{{ $r['state'] }}</td><td>{{ $r['date'] }}</td></tr>@empty<tr><td colspan="5">None.</td></tr>@endforelse</tbody></table></div></section>
@endif
@endsection
