@extends('layouts.admin')
@section('title', 'Listing approval')
@section('content')
<main class="workspace-shell admin-shell">
    <aside class="workspace-sidebar admin-sidebar">
        <div class="workspace-person"><span class="avatar avatar-admin">A</span><span><b>NeAS Console</b><small>Administration</small></span></div>
        @include('admin.partials.navigation', ['active' => 'review-listings'])
    </aside>
    <section class="workspace-main">
        <div class="workspace-heading"><div><a class="back-link" href="{{ route('admin.dashboard') }}">← Admin dashboard</a><span class="eyebrow">BR-07</span><h1>Listing approval</h1><p>Storage facilities, tours and land waiting for review. Land is approved through its title document.</p></div></div>
        @if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
        @if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
        @forelse($items as $l)
        <section class="panel data-panel" style="margin-bottom:14px;padding:16px">
            <b>{{ $l->title }}</b> · {{ ucfirst($l->type->value) }} · {{ $l->owner?->name }} · {{ $l->region?->name }}
            @if($l->type->value==='land')<p class="p-muted">Title document: {{ ($landDocs[$l->id] ?? collect())->first()?->status ?? 'none' }}. <a href="{{ route('admin.review.documents') }}">Review documents</a></p>@endif
            <form method="post" action="{{ route('admin.review.listings.decide',$l) }}" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;align-items:center">@csrf
                @if($l->type->value!=='land')<button class="button button-primary button-small" name="decision" value="approve">Approve</button>@endif
                <input name="reason" placeholder="Reason (required to reject)" style="flex:1;min-width:200px">
                <button class="button button-danger-quiet button-small" name="decision" value="reject">Reject</button></form>
        </section>
        @empty<section class="panel data-panel"><div class="empty-state"><h3>Nothing waiting</h3></div></section>@endforelse
        <h2 style="margin:22px 0 10px">Active listings: remove prohibited items</h2>
        @foreach($active as $l)
        <section class="panel data-panel" style="margin-bottom:8px;padding:12px"><form method="post" action="{{ route('admin.review.listings.remove',$l) }}" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">@csrf
            <span style="flex:1;min-width:220px"><b>{{ $l->title }}</b> · {{ ucfirst($l->type->value) }} · {{ $l->owner?->name }}</span>
            <input name="reason" placeholder="Reason (required)" required minlength="5" style="min-width:200px"><button class="button button-danger-quiet button-small">Remove</button></form></section>
        @endforeach
    </section>
</main>
@endsection
