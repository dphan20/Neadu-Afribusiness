<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Console sign-in · NeAS</title>
    @include('layouts.partials.assets')
</head>
<body>
<main class="auth-shell">
    <section class="auth-intro">
        <span class="eyebrow">NeAS CONSOLE</span>
        <h1>Platform operations.</h1>
        <p>For NeAS staff only. Verification, disputes, finance and reference data. Every action is recorded against your name.</p>
        <div class="auth-points"><span>✓ Separate from the marketplace sign-in</span><span>✓ Access limited to your scope</span><span>✓ Auto sign-out after {{ config('neas.admin.idle_minutes', 30) }} min idle</span></div>
    </section>
    <section class="auth-card">
        <div class="auth-card-heading"><span class="brand-mark">N</span><div><h2>Console sign-in</h2><p>Administrators only</p></div></div>
        @if (session('status'))<div class="flash flash-success" role="status">{{ session('status') }}</div>@endif
        <form method="post" action="{{ route('admin.login.store') }}" class="form-stack">
            @csrf
            <label for="login">Email or phone number</label>
            <input id="login" name="login" type="text" value="{{ old('login') }}" autocomplete="username" required autofocus>
            @error('login')<span class="field-error">{{ $message }}</span>@enderror
            <label for="pin">Password</label>
            <input id="pin" name="pin" type="password" autocomplete="current-password" required>
            @error('pin')<span class="field-error">{{ $message }}</span>@enderror
            <button class="button button-primary button-full" type="submit">Sign in to console <span aria-hidden="true">→</span></button>
        </form>
    </section>
</main>
</body>
</html>
