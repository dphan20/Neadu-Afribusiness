@extends('admin.layout')
@section('title', 'Disputes')
@section('admin_active', 'disputes')
@section('eyebrow', 'S-50 · ADM-03 · BR-05')
@section('heading', 'Dispute queue')
@section('lead', 'Escrow stays frozen until an admin decides. Evidence closes after 3 days; decide within 5 working days.')
@section('admin_body')
<section class="panel data-panel"><div class="panel-heading"><div><span class="eyebrow">OPEN</span><h2>{{ $open->count() }} waiting</h2></div></div>
@if($open->isEmpty())<div class="empty-state"><h3>Queue is clear</h3></div>@else
<div class="table-wrap"><table class="data-table"><thead><tr><th>Order</th><th>Buyer → Seller</th><th>Opened by</th><th>Reason</th><th>Decide by</th><th></th></tr></thead><tbody>
@foreach($open as $d)<tr><td>{{ $d->order->listing?->title }}<br><small>TSh {{ number_format(intdiv($d->order->total(),100)) }}</small></td><td>{{ $d->order->buyer?->name }} → {{ $d->order->seller?->name }}</td><td>{{ $d->opener?->name }}</td><td>{{ \Illuminate\Support\Str::limit($d->reason, 60) }}</td>
<td style="{{ $d->decide_by->isPast() ? 'color:var(--color-error);font-weight:700' : '' }}">{{ $d->decide_by->format('d-m-Y') }}</td><td><a class="button button-primary button-small" href="{{ route('admin.disputes.show',$d) }}">Review</a></td></tr>@endforeach</tbody></table></div>@endif</section>
<section class="panel data-panel" style="margin-top:14px"><div class="panel-heading"><div><span class="eyebrow">DECIDED</span><h2>Recent decisions</h2></div></div>
<div class="table-wrap"><table class="data-table"><thead><tr><th>Order</th><th>Decision</th><th>Decided</th><th>Note</th></tr></thead><tbody>
@forelse($decided as $d)<tr><td>{{ $d->order->listing?->title }}</td><td>{{ ucfirst($d->decision) }}</td><td>{{ $d->decided_at?->format('d-m-Y') }}</td><td>{{ \Illuminate\Support\Str::limit((string) $d->admin_note, 70) }}</td></tr>@empty<tr><td colspan="4">None yet.</td></tr>@endforelse</tbody></table></div></section>
@endsection
