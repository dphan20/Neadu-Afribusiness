@extends('layouts.admin')

@section('title', 'Admin dashboard')

@section('content')
<main class="workspace-shell admin-shell">
    <aside class="workspace-sidebar admin-sidebar">
        <div class="workspace-person"><span class="avatar avatar-admin">A</span><span><b>NeAS Console</b><small>Administration</small></span></div>
        @include('admin.partials.navigation', ['active' => 'dashboard'])
    </aside>
    <section class="workspace-main">
        <div class="workspace-heading">
            <div><span class="eyebrow">PLATFORM OPERATIONS</span><h1>Admin dashboard</h1><p>Monitor marketplace health, manage access and resolve operational queues.</p></div>
            <a class="button button-primary button-small" href="{{ route('admin.users') }}">Manage users <span aria-hidden="true">→</span></a>
        </div>
        <div class="metric-grid admin-metrics">
            @foreach ($metrics as $metric)
                <article class="metric-card metric-{{ $metric['tone'] }}"><span class="metric-label">{{ $metric['label'] }}</span><strong>{{ number_format($metric['value']) }}</strong><span class="metric-caption">Live database count</span></article>
            @endforeach
        </div>
        <div class="workspace-columns">
            <section class="panel panel-main">
                <div class="panel-heading"><div><span class="eyebrow">ADMINISTRATION</span><h2>Operations center</h2></div></div>
                <div class="admin-link-grid">
                    @foreach ([
                        ['admin.users', 'users', 'All users', 'Search accounts, suspend with a recorded reason'],
                        ['admin.review.documents', 'verification', 'Document verification', 'Approve or reject IDs, licences and land titles'],
                        ['admin.review.listings', 'listings', 'Listing moderation', 'Approve submissions, remove prohibited items'],
                        ['admin.disputes', 'disputes', 'Disputes', 'Evidence, then release, partial or refund'],
                        ['admin.finance', 'finance', 'Finance & payouts', 'Escrow, fees, payouts, two-person refunds'],
                        ['admin.reconcile', 'finance', 'Reconciliation', 'Match a mobile-money statement with payments'],
                        ['admin.reference', 'reference', 'Reference data', 'Crops, units, regions, markets, fee rules, flags'],
                        ['admin.section:activity', 'reference', 'Activity log', 'Who did what and when'],
                    ] as [$target, $area, $label, $description])
                        @if (\App\Support\AdminScope::can(auth()->user(), $area))
                        @php
                            [$rn, $rp] = array_pad(explode(':', $target), 2, null);
                        @endphp
                        <a class="admin-link-card" href="{{ $rp ? route($rn, $rp) : route($rn) }}">
                            <span><b>{{ $label }}</b><small>{{ $description }}</small></span><span class="action-arrow" aria-hidden="true">→</span>
                        </a>
                        @endif
                    @endforeach
                </div>
            </section>
            <aside class="panel">
                <div class="panel-heading"><div><span class="eyebrow">LATEST ACCOUNTS</span><h2>New users</h2></div><a class="text-link" href="{{ route('admin.users') }}">All users →</a></div>
                @forelse ($recentUsers as $user)
                    <div class="compact-row"><span class="avatar avatar-small">{{ strtoupper(substr($user->name, 0, 1)) }}</span><span class="compact-copy"><b>{{ $user->name }}</b><small>{{ $user->phone ?? $user->email }}</small></span><span class="status-chip {{ $user->status === 'active' ? 'status-good' : 'status-warn' }}">{{ ucfirst($user->status) }}</span></div>
                @empty
                    <p class="muted-copy">No accounts have registered yet.</p>
                @endforelse
            </aside>
        </div>
        <section class="panel audit-panel">
            <div class="panel-heading"><div><span class="eyebrow">ACCOUNTABILITY</span><h2>Recent recorded activity</h2></div>@if (\App\Support\AdminScope::can(auth()->user(), 'reference'))<a class="text-link" href="{{ route('admin.audit') }}">Open audit log →</a>@endif</div>
            @forelse ($recentAudit as $entry)
                <div class="activity-row"><span class="activity-dot"></span><span><b>{{ str_replace('.', ' · ', $entry->action) }}</b><small>{{ $entry->created_at?->format('d-m-Y H:i') ?? '—' }} · {{ class_basename($entry->target_type) }} #{{ $entry->target_id }}</small></span></div>
            @empty
                <div class="empty-state compact-empty"><p>No administrative activity has been recorded yet.</p></div>
            @endforelse
        </section>
    </section>
</main>
@endsection
