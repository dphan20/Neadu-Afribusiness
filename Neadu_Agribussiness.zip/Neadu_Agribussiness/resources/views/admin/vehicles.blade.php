@extends('layouts.admin')

@section('title', 'Vehicle verification')

@section('content')
<main class="workspace-shell admin-shell">
    <aside class="workspace-sidebar admin-sidebar">
        <div class="workspace-person"><span class="avatar avatar-admin">A</span><span><b>NeAS Console</b><small>Administration</small></span></div>
        @include('admin.partials.navigation', ['active' => 'vehicles'])
    </aside>
    <section class="workspace-main">
        <div class="workspace-heading">
            <div><a class="back-link" href="{{ route('admin.dashboard') }}">← Admin dashboard</a><span class="eyebrow">LOGISTICS</span><h1>Vehicle verification</h1><p>Check plate, licence and photo before a transporter can accept jobs.</p></div>
        </div>
        @forelse ($vehicles as $v)
            <section class="panel data-panel" style="margin-bottom:14px;padding:16px">
                <div style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-start;justify-content:space-between">
                    <div style="display:flex;gap:14px;align-items:flex-start">
                        @if ($v->photo_path)<a target="_blank" href="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($v->photo_path) }}"><img src="{{ \Illuminate\Support\Facades\Storage::disk('public')->url($v->photo_path) }}" alt="Vehicle photo" style="width:120px;height:90px;object-fit:cover;border-radius:10px;border:1px solid var(--color-border)"></a>@endif
                        <div>
                            <b>{{ $v->typeLabel() }} · {{ str_starts_with($v->plate, 'BIC-') ? 'no plate' : $v->plate }}</b><br>
                            Capacity {{ number_format((float) $v->capacity_kg) }} kg<br>
                            Licence: {{ $v->licence_document ?? '—' }}<br>
                            Owner: {{ $v->owner?->name }} · {{ $v->owner?->phone ?? $v->owner?->email }} · identity {{ $v->owner?->isIdentityVerified() ? 'verified' : 'not verified' }}
                        </div>
                    </div>
                    <span class="status-chip {{ $v->verification_status === 'verified' ? 'status-success' : 'status-neutral' }}">{{ ucfirst($v->verification_status) }}</span>
                </div>
                @if ($v->verification_status !== 'verified')
                    <form method="post" action="{{ route('admin.vehicles.decide', $v) }}" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;align-items:center">
                        @csrf
                        <button class="button button-primary button-small" name="decision" value="approve" type="submit">Approve</button>
                        <input name="reason" placeholder="Reason (required to reject)" style="flex:1;min-width:200px">
                        <button class="button button-danger-quiet button-small" name="decision" value="reject" type="submit">Reject</button>
                    </form>
                @endif
                @if ($v->verification_status === 'rejected' && $v->reject_reason)<p style="color:var(--color-error)">Rejected: {{ $v->reject_reason }}</p>@endif
            </section>
        @empty
            <section class="panel data-panel"><div class="empty-state"><span class="empty-mark">0</span><h3>No vehicles yet</h3><p>Registered vehicles appear here for verification.</p></div></section>
        @endforelse
    </section>
</main>
@endsection
