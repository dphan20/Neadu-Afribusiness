@extends('admin.layout')
@section('title', 'Finance')
@section('admin_active', 'finance')
@section('eyebrow', 'S-50 · ADM-04 · NFR-S4')
@section('heading', 'Finance')
@section('lead', 'Escrow, fees, payout requests and two-person refunds. All amounts in TSh.')
@section('admin_body')
@php
$t = fn (int $m) => number_format(intdiv($m, 100));
@endphp
<div class="metric-grid admin-metrics">
<article class="metric-card metric-blue"><span class="metric-label">Held in escrow</span><strong>{{ $t($escrow) }}</strong></article>
<article class="metric-card metric-green"><span class="metric-label">Platform fees earned</span><strong>{{ $t($fees) }}</strong></article>
<article class="metric-card metric-gold"><span class="metric-label">Payouts waiting</span><strong>{{ $t($pendingPayouts) }}</strong></article>
<article class="metric-card metric-green"><span class="metric-label">Paid out so far</span><strong>{{ $t($paidOut) }}</strong></article>
<article class="metric-card metric-red"><span class="metric-label">Platform float (transport, consultations)</span><strong>{{ $float < 0 ? '-' : '' }}{{ $t(abs($float)) }}</strong></article></div>
<p><a class="button button-outline button-small" href="{{ route('admin.reconcile') }}">Reconcile a statement</a></p>
<section class="panel data-panel"><div class="panel-heading"><div><span class="eyebrow">TWO-PERSON REFUNDS</span><h2>Refund approvals</h2></div></div>
@forelse($refunds as $r)<div style="padding:12px;border-top:1px solid var(--color-border)"><b>{{ $r->dispute?->order?->listing?->title }}</b> · {{ ucfirst($r->decision) }} · TSh {{ $t((int) $r->amount_minor) }} · asked by {{ $r->requester?->name }} · <span class="status-chip status-neutral">{{ ucfirst($r->status) }}</span>
@if($r->status==='pending')@if($r->requested_by !== auth()->id())<form method="post" action="{{ route('admin.finance.refunds',$r) }}" style="display:inline">@csrf<button class="button button-primary button-small" name="decision" value="approve">Approve and refund</button> <button class="button button-danger-quiet button-small" name="decision" value="reject">Reject</button></form>@else<small>Waiting for a different admin.</small>@endif @endif</div>
@empty<p class="muted-copy" style="padding:12px">No refund requests.</p>@endforelse</section>
<section class="panel data-panel" style="margin-top:14px"><div class="panel-heading"><div><span class="eyebrow">S-45</span><h2>Payout requests</h2></div></div>
@forelse($payouts as $p)<div style="padding:12px;border-top:1px solid var(--color-border)"><b>{{ $p->user?->name }}</b> · TSh {{ $t((int) $p->amount_minor) }} · {{ strtoupper($p->method) }} → {{ $p->destination }} · <span class="status-chip status-neutral">{{ ucfirst($p->status) }}</span> {{ $p->reason }}
@if($p->status==='requested')<form method="post" action="{{ route('admin.finance.payouts',$p) }}" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;align-items:center">@csrf<button class="button button-primary button-small" name="decision" value="paid">Mark paid</button><input name="reason" placeholder="Reason (to reject)" style="min-width:200px"><button class="button button-danger-quiet button-small" name="decision" value="reject">Reject</button></form>@endif</div>
@empty<p class="muted-copy" style="padding:12px">No payout requests.</p>@endforelse</section>
@endsection
