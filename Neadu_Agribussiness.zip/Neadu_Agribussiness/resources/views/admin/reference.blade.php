@extends('admin.layout')
@section('title', 'Reference data')
@section('admin_active', 'reference')
@section('eyebrow', 'S-52 · ADM-05')
@section('heading', 'Reference data')
@section('lead', 'Changes apply at once and are written to the activity log with before and after values.')
@section('admin_body')
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">@foreach($entities as $k=>$e)<a class="button {{ $k===$entity ? 'button-primary' : 'button-outline' }} button-small" href="{{ route('admin.reference',$k) }}">{{ $e['label'] }}</a>@endforeach</div>
<section class="panel data-panel" style="padding:14px;margin-bottom:14px"><h3>Add to {{ strtolower($def['label']) }}</h3>
<form method="post" action="{{ route('admin.reference.store',$entity) }}" style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">@csrf
@foreach($def['fields'] as $name=>$f)<label style="display:grid;gap:3px;font-size:12px">{{ $f['label'] }}
@if($f['type']==='select')<select name="{{ $name }}">@foreach($options[$f['options']] as $id=>$label)<option value="{{ $id }}">{{ $label }}</option>@endforeach</select>@else<input name="{{ $name }}" type="{{ $f['type'] }}" value="{{ old($name) }}"@if(str_contains((string) (is_array($f['rules']) ? implode('|',$f['rules']) : $f['rules']),'required')) required @endif>@endif</label>@endforeach
<button class="button button-primary button-small">Add</button></form></section>
<section class="panel data-panel"><div class="table-wrap"><table class="data-table"><thead><tr>@foreach($def['fields'] as $f)<th>{{ $f['label'] }}</th>@endforeach<th></th></tr></thead><tbody>
@foreach($rows as $r)<tr>@foreach($def['fields'] as $name=>$f)<td>@if($f['type']==='select')<select form="f{{ $r->id }}" name="{{ $name }}">@foreach($options[$f['options']] as $id=>$label)<option value="{{ $id }}" @selected($r->$name==$id)>{{ $label }}</option>@endforeach</select>@else<input form="f{{ $r->id }}" name="{{ $name }}" type="{{ $f['type'] }}" value="{{ $r->$name }}" style="min-width:90px">@endif</td>@endforeach
<td style="white-space:nowrap">@if($entity==='fee_rules')<label style="font-size:12px"><input form="f{{ $r->id }}" type="checkbox" name="active" value="1" @checked($r->active)> active</label> @endif<button form="f{{ $r->id }}" class="button button-outline button-small">Save</button>
<form method="post" action="{{ route('admin.reference.destroy',[$entity,$r->id]) }}" style="display:inline" onsubmit="return confirm('Remove this entry?')">@csrf @method('DELETE')<button class="button button-danger-quiet button-small">Remove</button></form></td></tr>@endforeach</tbody></table></div>
@foreach($rows as $r)<form id="f{{ $r->id }}" method="post" action="{{ route('admin.reference.update',[$entity,$r->id]) }}">@csrf @method('PUT')</form>@endforeach</section>
<section class="panel data-panel" style="margin-top:14px;padding:14px"><h3>Feature flags (R2 / R3)</h3><div style="display:flex;gap:8px;flex-wrap:wrap">@foreach($flags as $fl)<form method="post" action="{{ route('admin.flags.toggle',$fl) }}">@csrf<button class="button {{ $fl->enabled ? 'button-primary' : 'button-outline' }} button-small">{{ $fl->key }} · {{ $fl->release }} · {{ $fl->enabled ? 'ON' : 'off' }}</button></form>@endforeach</div></section>
@endsection
