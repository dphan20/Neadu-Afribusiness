@extends('admin.layout')
@section('title', 'Admin access')
@section('admin_active', 'admins')
@section('eyebrow', 'ADM-08')
@section('heading', 'Admin access')
@section('lead', 'Least privilege: give each admin only the area they work in. Admins with no scope set are super admins.')
@section('admin_body')
<section class="panel data-panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>Admin</th><th>Contact</th><th>Scope</th></tr></thead><tbody>
@foreach($admins as $a)<tr><td>{{ $a->name }}</td><td>{{ $a->phone ?? $a->email }}</td><td><form method="post" action="{{ route('admin.admins.update',$a) }}" style="display:flex;gap:8px">@csrf @method('PUT')
<select name="scope">@foreach($scopes as $k=>$v)<option value="{{ $k }}" @selected($a->scope===$k)>{{ $v }}</option>@endforeach</select><button class="button button-outline button-small">Save</button></form></td></tr>@endforeach</tbody></table></div></section>
@endsection
