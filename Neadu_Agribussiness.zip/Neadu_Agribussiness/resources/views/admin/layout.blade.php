@extends('layouts.admin')

@section('content')
<main class="workspace-shell admin-shell">
    <aside class="workspace-sidebar admin-sidebar">
        <div class="workspace-person"><span class="avatar avatar-admin">A</span><span><b>NeAS Console</b><small>{{ \App\Support\AdminScope::SCOPES[\App\Support\AdminScope::of(auth()->user())] ?? 'Administration' }}</small></span></div>
        @include('admin.partials.navigation', ['active' => trim($__env->yieldContent('admin_active'))])
    </aside>
    <section class="workspace-main">
        <div class="workspace-heading">
            <div><a class="back-link" href="{{ route('admin.dashboard') }}">← Admin dashboard</a><span class="eyebrow">@yield('eyebrow', 'PLATFORM OPERATIONS')</span><h1>@yield('heading')</h1><p>@yield('lead')</p></div>
        </div>
        @if (session('status'))<div class="flash" role="status" style="margin-bottom:14px">{{ session('status') }}</div>@endif
        @if ($errors->any())<div class="flash flash-error" role="alert" style="margin-bottom:14px">{{ $errors->first() }}</div>@endif
        @yield('admin_body')
    </section>
</main>
@endsection
