@extends('layouts.admin')

@section('title', 'All users')

@section('content')
<main class="workspace-shell admin-shell">
    <aside class="workspace-sidebar admin-sidebar">
        <div class="workspace-person"><span class="avatar avatar-admin">A</span><span><b>NeAS Console</b><small>Administration</small></span></div>
        @include('admin.partials.navigation', ['active' => 'users'])
    </aside>
    <section class="workspace-main">
        <div class="workspace-heading">
            <div><a class="back-link" href="{{ route('admin.dashboard') }}">← Admin dashboard</a><span class="eyebrow">ACCESS MANAGEMENT</span><h1>All users</h1><p>Search accounts, inspect role assignments and manage access from one place.</p></div>
            <span class="status-chip status-neutral">{{ number_format($counts['all']) }} accounts</span>
        </div>
        <div class="user-summary-grid">
            <div class="summary-chip"><span>All accounts</span><b>{{ number_format($counts['all']) }}</b></div>
            <div class="summary-chip"><span>Active</span><b>{{ number_format($counts['active']) }}</b></div>
            <div class="summary-chip"><span>Suspended</span><b>{{ number_format($counts['suspended']) }}</b></div>
        </div>
        <section class="panel user-panel">
            <form method="get" action="{{ route('admin.users') }}" class="filter-bar">
                <label class="filter-search"><span class="sr-only">Search name, email or phone</span><input type="search" name="q" value="{{ $filters['q'] ?? '' }}" placeholder="Search name, email or phone"></label>
                <label><span class="sr-only">Filter by role</span><select name="role"><option value="">All roles</option>@foreach ($roleOptions as $role)<option value="{{ $role->value }}" @selected(($filters['role'] ?? '') === $role->value)>{{ $role->label() }}</option>@endforeach</select></label>
                <label><span class="sr-only">Filter by status</span><select name="status"><option value="">All account statuses</option><option value="active" @selected(($filters['status'] ?? '') === 'active')>Active</option><option value="suspended" @selected(($filters['status'] ?? '') === 'suspended')>Suspended</option></select></label>
                <button class="button button-primary button-small" type="submit">Apply filters</button>
                @if (count($filters))
                    <a class="button button-quiet button-small" href="{{ route('admin.users') }}">Clear</a>
                @endif
            </form>
            <div class="table-wrap">
                <table class="data-table user-table">
                    <thead><tr><th scope="col">User</th><th scope="col">Phone</th><th scope="col">Assigned roles</th><th scope="col">Identity</th><th scope="col">Status</th><th scope="col">Manage roles</th><th scope="col">Access</th></tr></thead>
                    <tbody>
                    @forelse ($users as $user)
                        <tr>
                            <td><span class="user-name-cell"><span class="avatar avatar-small">{{ strtoupper(substr($user->name, 0, 1)) }}</span><span><b>{{ $user->name }}</b><small>Joined {{ $user->created_at?->format('d-m-Y') }}</small></span></span></td>
                            <td>{{ $user->phone ?? $user->email }}</td>
                            <td><div class="role-badges">
                                @forelse ($user->roleAssignments as $assignment)
                                    @php($assignedRole = \App\Enums\UserRole::tryFrom($assignment->role))
                                    @if ($assignedRole)
                                        <span class="role-badge">{{ $assignedRole->label() }}
                                            @if ($user->roleAssignments->count() > 1 && ! ($user->is(auth()->user()) && $assignment->role === \App\Enums\UserRole::Admin->value))
                                                <form method="post" action="{{ route('admin.users.roles.remove', [$user, $assignment]) }}" class="inline-form" onsubmit="return confirm('Remove this role from {{ addslashes($user->name) }}?')">
                                                    @csrf @method('DELETE')
                                                    <button class="badge-remove" type="submit" aria-label="Remove {{ $assignedRole->label() }} role">×</button>
                                                </form>
                                            @endif
                                        </span>
                                    @endif
                                @empty
                                    <span class="muted-copy">No role</span>
                                @endforelse
                            </div></td>
                            <td>{{ ucfirst($user->verification_level) }}</td>
                            <td><span class="status-chip {{ $user->status === 'active' ? 'status-good' : 'status-warn' }}"><span class="status-dot"></span>{{ ucfirst($user->status) }}</span></td>
                            <td><form method="post" action="{{ route('admin.users.roles.assign', $user) }}" class="role-assign-form">@csrf
                                <label class="sr-only" for="role-{{ $user->id }}">Assign role to {{ $user->name }}</label>
                                <select id="role-{{ $user->id }}" name="role" required><option value="">Choose role</option>@foreach ($roleOptions as $role)<option value="{{ $role->value }}">{{ $role->label() }}</option>@endforeach</select>
                                <button class="button button-outline button-tiny" type="submit">Add</button>
                            </form></td>
                            <td><form method="post" action="{{ route('admin.users.status', $user) }}">@csrf @method('PATCH')
                                <input type="hidden" name="status" value="{{ $user->status === 'active' ? 'suspended' : 'active' }}">
                                @if ($user->status === 'active')<input name="reason" placeholder="Reason (required)" required maxlength="200" style="min-width:140px;margin-bottom:4px">@elseif ($user->suspension_reason)<small>{{ $user->suspension_reason }}</small>@endif
                                <button class="button {{ $user->status === 'active' ? 'button-danger-quiet' : 'button-outline' }} button-tiny" type="submit" @disabled($user->is(auth()->user()))>{{ $user->status === 'active' ? 'Suspend' : 'Reactivate' }}</button>
                            </form></td>
                        </tr>
                    @empty
                        <tr><td colspan="7"><div class="empty-state compact-empty"><h3>No users found</h3><p>Try a different search or remove one of the filters.</p></div></td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
            <div class="pagination-wrap">{{ $users->links() }}</div>
        </section>
        <p class="compliance-note">Role and account changes are recorded in the append-only admin activity log.</p>
    </section>
</main>
@endsection
