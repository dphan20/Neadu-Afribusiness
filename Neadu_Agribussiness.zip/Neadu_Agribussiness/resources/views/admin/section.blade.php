@extends('layouts.admin')

@section('title', $title)

@section('content')
<main class="workspace-shell admin-shell">
    <aside class="workspace-sidebar admin-sidebar">
        <div class="workspace-person"><span class="avatar avatar-admin">A</span><span><b>NeAS Console</b><small>Administration</small></span></div>
        @include('admin.partials.navigation', ['active' => $section])
    </aside>
    <section class="workspace-main">
        <div class="workspace-heading">
            <div><a class="back-link" href="{{ route('admin.dashboard') }}">← Admin dashboard</a><span class="eyebrow">PLATFORM OPERATIONS</span><h1>{{ $title }}</h1><p>{{ $description }}</p></div>
        </div>
        <section class="panel data-panel">
            <div class="panel-heading"><div><span class="eyebrow">CURRENT RECORDS</span><h2>{{ $rows->count() }} {{ $rows->count() === 1 ? 'record' : 'records' }}</h2></div></div>
            @if ($rows->isEmpty())
                <div class="empty-state"><span class="empty-mark">0</span><h3>Queue is clear</h3><p>There are no records in this view right now.</p></div>
            @else
                <div class="table-wrap"><table class="data-table">
                    <thead><tr>@foreach ($columns as $column)<th scope="col">{{ $column }}</th>@endforeach</tr></thead>
                    <tbody>@foreach ($rows as $row)<tr>@foreach ($row as $cell)<td>{{ $cell }}</td>@endforeach</tr>@endforeach</tbody>
                </table></div>
            @endif
        </section>
    </section>
</main>
@endsection
