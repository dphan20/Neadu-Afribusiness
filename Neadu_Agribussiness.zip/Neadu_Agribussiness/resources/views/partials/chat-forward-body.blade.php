@php($isAdminArea = ($area ?? 'me') === 'admin')
<div class="p-card">
    <small class="p-muted">{{ __('chat.forward_lead') }}</small>
    <p style="margin-top:6px"><b>↪</b> {{ $message->body ? \Illuminate\Support\Str::limit($message->body, 140) : ($message->kind === 'voice' ? __('chat.voice') : __('chat.photo')) }}</p>
</div>
@if ($errors->any())<div class="p-card" role="alert" style="border-color:var(--color-error)">{{ $errors->first() }}</div>@endif
<form class="p-card pf" method="get" action="{{ route($isAdminArea ? 'admin.messages.forward' : 'me.chat.forward', $message) }}">
    <label for="q">{{ __('chat.forward_people') }}</label>
    <input id="q" name="q" value="{{ $q }}" maxlength="60" placeholder="{{ __('chat.search') }}" autocomplete="off">
    <select name="role" aria-label="{{ __('chat.to') }}">
        <option value="">{{ __('chat.any_role') }}</option>
        @foreach (\App\Enums\UserRole::cases() as $r)<option value="{{ $r->value }}" @selected($role === $r->value)>{{ $r === \App\Enums\UserRole::Admin ? 'NeAS support' : $r->label() }}</option>@endforeach
    </select>
    <button class="button button-outline button-small">{{ __('chat.search_go') }}</button>
</form>
<form method="post" action="{{ route($isAdminArea ? 'admin.messages.forward.store' : 'me.chat.forward.store', $message) }}">@csrf
    @if ($people->isNotEmpty())
        <h3>{{ __('chat.forward_people') }}</h3>
        @foreach ($people as $p)
            <label class="p-card" style="display:flex;gap:10px;align-items:center"><input type="checkbox" name="users[]" value="{{ $p->uuid }}" style="width:auto;min-height:0"><span><b>{{ $p->name }}</b> <span class="p-muted">{{ $messaging->roleLabels($p) }}</span></span></label>
        @endforeach
    @endif
    <h3>{{ __('chat.forward_recent') }}</h3>
    @forelse ($recent as $c)
        @php($names = \Illuminate\Support\Str::limit($c->participants->where('id', '!=', auth()->id())->pluck('name')->implode(', '), 70))
        <label class="p-card" style="display:flex;gap:10px;align-items:center"><input type="checkbox" name="conversations[]" value="{{ $c->uuid }}" style="width:auto;min-height:0"><span><b>{{ $names ?: __('chat.conversation') }}</b><br><span class="p-muted">{{ $c->order?->listing?->title ?? $c->listing?->title }}</span></span></label>
    @empty
        <div class="p-card p-muted">{{ __('chat.no_chats') }}</div>
    @endforelse
    <button class="button button-primary" style="margin-top:8px">↪ {{ __('chat.forward_send') }}</button>
</form>
