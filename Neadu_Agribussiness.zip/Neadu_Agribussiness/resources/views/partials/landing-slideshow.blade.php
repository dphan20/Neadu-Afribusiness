@push('head')<link rel="stylesheet" href="{{ asset('css/landing-gallery.css') }}">@endpush
@php($slides = [
    ['maize-field', 'A farmer walking through a green maize field at golden hour', 'Grow', 736, 489],
    ['tractors', 'Tractors working a large green field', 'Mechanise', 735, 549],
    ['spraying-maize', 'A farmer spraying maize at sunset', 'Protect', 735, 490],
    ['ploughing', 'Oxen ploughing a field', 'Cultivate', 735, 549],
    ['fishing', 'Fishermen pulling in their nets', 'Fish', 736, 489],
    ['market-produce', 'Fresh vegetables and fruit loaded for market', 'Sell', 736, 986],
])
<div class="ng-slideshow" role="img" aria-label="Farming across Tanzania: crops, livestock, fish and markets">
    @foreach ($slides as $i => [$file, $alt, $label, $w, $h])
        <figure class="ng-slide" style="--i: {{ $i }}">
            <img src="{{ asset('images/gallery/'.$file.'.jpg') }}" alt="{{ $alt }}" width="{{ $w }}" height="{{ $h }}" @if ($i === 0) fetchpriority="high" @else loading="lazy" @endif decoding="async">
            <figcaption>{{ $label }}</figcaption>
        </figure>
    @endforeach
</div>
