@php($isAdminArea = ($area ?? 'me') === 'admin')
<form class="p-card pf" method="get" action="{{ route($isAdminArea ? 'admin.messages.new' : 'me.chat.new') }}">
    <label for="q">{{ __('chat.search') }}</label>
    <input id="q" name="q" value="{{ $q }}" maxlength="60" autocomplete="off">
    <label for="role">{{ __('chat.to') }}</label>
    <select id="role" name="role">
        <option value="">{{ __('chat.any_role') }}</option>
        @foreach (\App\Enums\UserRole::cases() as $r)<option value="{{ $r->value }}" @selected($role === $r->value)>{{ $r === \App\Enums\UserRole::Admin ? 'NeAS support' : $r->label() }}</option>@endforeach
    </select>
    <button class="button button-primary">{{ __('chat.search_go') }}</button>
</form>
@if ($errors->any())<div class="p-card" role="alert" style="border-color:var(--color-error)">{{ $errors->first() }}</div>@endif
@forelse ($people as $p)
    <div class="p-card">
        <b>{{ $p->name }}</b> <span class="p-muted">{{ $messaging->roleLabels($p) }}</span>
        <details>
            <summary style="cursor:pointer">✉ {{ __('chat.write') }}</summary>
            <form method="post" class="pf" action="{{ route($isAdminArea ? 'admin.messages.start' : 'me.chat.start') }}">@csrf
                <input type="hidden" name="user" value="{{ $p->uuid }}">
                <textarea name="body" required maxlength="2000" placeholder="{{ __('chat.write_placeholder') }}"></textarea>
                <button class="button button-primary button-small">{{ __('chat.send') }}</button>
            </form>
        </details>
    </div>
@empty
    <div class="p-card p-muted">{{ mb_strlen(trim($q)) >= 2 || $role !== '' ? __('chat.no_people') : __('chat.type_to_search') }}</div>
@endforelse
