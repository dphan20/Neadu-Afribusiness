@push('head')<link rel="stylesheet" href="{{ asset('css/landing-gallery.css') }}">@endpush
@php($shots = [
    ['market-produce', 'ng-a', 'Fresh vegetables and fruit loaded for market', 'From farm gate to market', 736, 986],
    ['ploughing', 'ng-b', 'Oxen ploughing a field', 'Livestock power the land', 735, 549],
    ['spraying-maize', 'ng-c', 'A farmer spraying maize at sunset', 'Protecting the crop', 735, 490],
    ['maize-field', 'ng-d', 'A farmer walking through tall green maize', 'Growing food for Tanzania', 736, 489],
    ['tractors', 'ng-e', 'Tractors working a large green field', 'Machinery at scale', 735, 549],
    ['fishing', 'ng-f', 'Fishermen pulling in their nets', 'Fisheries too', 736, 489],
])
<section class="ng-section" aria-labelledby="ng-title">
    <div class="ng-head"><span class="eyebrow">LIFE ON THE LAND AND WATER</span><h2 id="ng-title">Crops, livestock and fish.<br>One connected network.</h2></div>
    <div class="ng-grid">
        @foreach ($shots as $i => [$file, $cell, $alt, $caption, $w, $h])
            <figure class="ng-item {{ $cell }}" style="--d: {{ $i * 90 }}ms">
                <img src="{{ asset('images/gallery/'.$file.'.jpg') }}" alt="{{ $alt }}" width="{{ $w }}" height="{{ $h }}" loading="lazy" decoding="async">
                <figcaption>{{ $caption }}</figcaption>
            </figure>
        @endforeach
    </div>
</section>
<script>
(function () {
    var items = document.querySelectorAll('.ng-item');
    if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }
    document.documentElement.classList.add('ng-js');
    var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('ng-in'); io.unobserve(e.target); } });
    }, { threshold: 0.15 });
    items.forEach(function (el) { io.observe(el); });
})();
</script>
