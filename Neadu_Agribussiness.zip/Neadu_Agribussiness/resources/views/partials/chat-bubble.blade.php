@php
    /** One chat message with forward / delete actions. Needs $m (Message), $bubble (css class: p-msg or by-msg) and optionally $area ('me' | 'admin'). */
    $area = $area ?? 'me';
    $isAdminArea = $area === 'admin';
    $viewer = auth()->user();
    $mine = $viewer !== null && $m->sender_id === $viewer->id;
    $fileUrl = $m->file_path ? route($isAdminArea ? 'admin.messages.file' : 'me.chat.file', $m) : null;
@endphp
@once
<style>
    .chat-actions { display: flex; flex-wrap: wrap; gap: 4px 12px; align-items: center; margin-top: 4px; font-size: 12px; }
    .chat-actions summary { cursor: pointer; list-style: none; color: var(--color-text-muted); }
    .chat-actions details form { display: inline; }
    .chat-actions button { background: none; border: 0; padding: 2px 4px; font: inherit; font-size: 12px; cursor: pointer; color: var(--color-error); }
    .chat-actions a { color: var(--color-text-muted); text-decoration: none; }
    .chat-fwd { font-size: 11px; color: var(--color-text-muted); font-style: italic; }
</style>
@endonce
<div class="{{ $bubble }} {{ $mine ? 'me' : '' }}" id="m-{{ $m->uuid }}">
    @if ($m->trashed())
        <em class="p-muted">🚫 {{ __('chat.deleted') }}</em>
    @else
        @if ($m->forwarded_from_id)<div class="chat-fwd">↪ {{ __('chat.forwarded') }}</div>@endif
        @if ($m->kind === 'voice' && $fileUrl)<audio controls src="{{ $fileUrl }}"></audio>
        @elseif ($m->file_path && $fileUrl)<a href="{{ $fileUrl }}" target="_blank" rel="noopener"><img src="{{ $fileUrl }}" alt="" style="max-width:220px;border-radius:10px"></a>@endif
        @if ($m->kind === 'call')<div>📞 {{ $m->body }}</div>@elseif ($m->body)<div style="white-space:pre-line">{{ $m->body }}</div>@endif
        <small class="p-muted">{{ $m->sender?->name }} · {{ $m->created_at?->format('d M H:i') }}</small>
        <div class="chat-actions">
            <a href="{{ route($isAdminArea ? 'admin.messages.forward' : 'me.chat.forward', $m) }}">↪ {{ __('chat.forward') }}</a>
            <details>
                <summary>🗑 {{ __('chat.delete') }}</summary>
                <form method="post" action="{{ route($isAdminArea ? 'admin.messages.message.destroy' : 'me.chat.message.destroy', $m) }}">@csrf @method('DELETE')<input type="hidden" name="scope" value="me"><button>{{ __('chat.delete_for_me') }}</button></form>
                @if ($mine)<form method="post" action="{{ route($isAdminArea ? 'admin.messages.message.destroy' : 'me.chat.message.destroy', $m) }}">@csrf @method('DELETE')<input type="hidden" name="scope" value="everyone"><button>{{ __('chat.delete_for_everyone') }}</button></form>@endif
            </details>
        </div>
    @endif
</div>
