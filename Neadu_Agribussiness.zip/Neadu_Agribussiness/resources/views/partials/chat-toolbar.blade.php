@php($isAdminArea = ($area ?? 'me') === 'admin')
<div class="by-row" style="gap:12px;align-items:flex-start;margin-bottom:10px">
    <a class="button button-outline button-small" href="{{ route($isAdminArea ? 'admin.messages.new' : 'me.chat.new') }}">✉ {{ __('chat.new_message') }}</a>
    <details>
        <summary class="button button-outline button-small" style="cursor:pointer">🗑 {{ __('chat.delete_chat') }}</summary>
        <form method="post" action="{{ route($isAdminArea ? 'admin.messages.clear' : 'me.chat.clear', $conversation) }}" style="margin-top:6px">@csrf @method('DELETE')
            <small class="p-muted">{{ __('chat.delete_chat_note') }}</small><br>
            <button class="button button-small" style="color:var(--color-error)">{{ __('chat.delete_chat_confirm') }}</button>
        </form>
    </details>
</div>
