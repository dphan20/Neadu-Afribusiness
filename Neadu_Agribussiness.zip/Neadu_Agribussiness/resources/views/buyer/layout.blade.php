@extends('layouts.app')

@section('content')
@php($navItems = [
    ['buyer.dashboard', 'Overview'], ['buyer.market', 'Find produce'], ['buyer.orders', 'My orders'], ['buyer.favourites', 'Favourites'],
    ['buyer.wanted', 'Wanted to buy'], ['buyer.alerts', 'Price alerts'], ['buyer.contracts', 'Contracts (R3)'], ['buyer.chat', 'Messages'],
])
<main class="workspace-shell">
    <aside class="workspace-sidebar">
        <div class="workspace-person">
            <span class="avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</span>
            <span><b>{{ auth()->user()->name }}</b><small>Buyer</small></span>
        </div>
        <nav class="workspace-nav" aria-label="Buyer navigation">
            @foreach ($navItems as $i => [$route, $label])
                <a class="{{ request()->routeIs($route.'*') && ($route !== 'buyer.dashboard' || request()->routeIs('buyer.dashboard')) ? 'active' : '' }}" href="{{ route($route) }}"><span class="nav-mark">{{ str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) }}</span>{{ $label }}</a>
            @endforeach
            <a href="{{ route('workspace.section', 'wallet') }}"><span class="nav-mark">09</span>Wallet</a>
            <a href="{{ route('workspace.section', 'profile') }}"><span class="nav-mark">10</span>My profile</a>
        </nav>
    </aside>
    <section class="workspace-main">
        @if (session('error'))<div class="flash flash-error" role="alert" style="margin:0 0 14px">{{ session('error') }}</div>@endif
        @yield('buyer')
    </section>
</main>
@endsection
