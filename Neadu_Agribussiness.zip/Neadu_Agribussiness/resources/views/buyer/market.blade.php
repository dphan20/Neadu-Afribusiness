@extends('buyer.layout')
@section('title', 'Find produce')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.dashboard') }}">← Overview</a><span class="eyebrow">S-08 · MKT-03</span><h1>Find produce</h1><p>Search by product, place, price, quantity, quality and distance.</p></div></div>
<section class="panel data-panel">
    <form method="get" class="filter-bar" id="searchForm">
        <label class="filter-search"><span class="sr-only">Search</span><input name="q" value="{{ $f['q'] ?? '' }}" placeholder="Search title, e.g. maize"></label>
        <label><span class="sr-only">Product</span><select name="crop"><option value="">All products</option>@foreach ($crops as $c)<option value="{{ $c->id }}" @selected(($f['crop'] ?? '') == $c->id)>{{ $c->name_en }} / {{ $c->name_sw }}</option>@endforeach</select></label>
        <label><span class="sr-only">Region</span><select name="region"><option value="">All regions</option>@foreach ($regions as $r)<option value="{{ $r->id }}" @selected(($f['region'] ?? '') == $r->id)>{{ $r->name }}</option>@endforeach</select></label>
        <label><span class="sr-only">District</span><select name="district"><option value="">All districts</option>@foreach ($districts as $d)<option value="{{ $d->id }}" @selected(($f['district'] ?? '') == $d->id)>{{ $d->name }}</option>@endforeach</select></label>
        <label><input type="number" step="any" min="0" name="min_price" value="{{ $f['min_price'] ?? '' }}" placeholder="Min price TZS"></label>
        <label><input type="number" step="any" min="0" name="max_price" value="{{ $f['max_price'] ?? '' }}" placeholder="Max price TZS"></label>
        <label><input type="number" step="any" min="0" name="min_qty" value="{{ $f['min_qty'] ?? '' }}" placeholder="Min quantity"></label>
        <label><select name="grade"><option value="">Any quality</option>@foreach (['A', 'B', 'C'] as $g)<option value="{{ $g }}" @selected(($f['grade'] ?? '') === $g)>Grade {{ $g }}</option>@endforeach</select></label>
        <label><input type="number" step="any" name="max_km" value="{{ $f['max_km'] ?? '' }}" placeholder="Within km"></label>
        <input type="hidden" name="lat" id="lat" value="{{ $f['lat'] ?? '' }}"><input type="hidden" name="lng" id="lng" value="{{ $f['lng'] ?? '' }}">
        <button type="button" class="button button-outline button-small" id="geo">Use my location</button>
        <label><select name="sort">@foreach (['newest' => 'Newest', 'price_asc' => 'Price: low to high', 'price_desc' => 'Price: high to low', 'distance' => 'Nearest'] as $k => $v)<option value="{{ $k }}" @selected(($f['sort'] ?? 'newest') === $k)>{{ $v }}</option>@endforeach</select></label>
        <button class="button button-primary button-small">Search</button>
        <a class="button button-quiet button-small" href="{{ route('buyer.market') }}">Clear</a>
    </form>
    <div style="padding:16px">
        <p class="compact-copy">{{ $listings->count() }} {{ $listings->count() === 1 ? 'listing' : 'listings' }} found{{ ! empty($f['lat']) ? ' · distance from your location' : '' }}</p>
        @if ($listings->isEmpty())
            <div class="empty-state"><span class="empty-mark">0</span><h3>No produce matches</h3><p>Try fewer filters, or post a wanted-to-buy request.</p><a class="button button-gold button-small" href="{{ route('buyer.wanted') }}">Post wanted request</a></div>
        @else
        <div class="by-grid">
            @foreach ($listings as $l)
                <article class="by-card">
                    <div class="by-thumb">@if (! empty($l->photos[0]))<img src="{{ \Illuminate\Support\Str::startsWith($l->photos[0], 'http') ? $l->photos[0] : asset('storage/'.$l->photos[0]) }}" alt="">@else{{ mb_substr($l->produce?->crop?->name_en ?? $l->title, 0, 1) }}@endif</div>
                    <h3>{{ $l->title }}</h3>
                    <div class="by-price">{{ \App\Support\Money::tzs($l->price_minor, $l->currency) }} <small style="font-size:12px;color:var(--color-text-muted)">/ {{ $l->produce?->unit?->code ?? 'unit' }}</small></div>
                    <p>{{ rtrim(rtrim((string) $l->produce?->quantity, '0'), '.') }} {{ $l->produce?->unit?->code }} available @if ($l->produce?->grade)· Grade {{ $l->produce->grade }}@endif</p>
                    <p>{{ $l->district?->name }}{{ $l->district && $l->region ? ', ' : '' }}{{ $l->region?->name }} @if ($l->distance_km !== null)· {{ $l->distance_km }} km @endif</p>
                    <div class="by-row"><span class="by-chip">{{ $l->owner?->name }}</span>@if ($l->verified)<span class="by-chip">✓ Verified</span>@endif</div>
                    <div class="by-row">
                        <a class="button button-primary button-small" href="{{ route('buyer.listing', $l) }}">View &amp; order</a>
                        <form method="post" action="{{ route('buyer.favourite', $l) }}">@csrf<button class="button button-outline button-small" aria-label="Favourite">{{ in_array($l->id, $favourites, true) ? '★ Saved' : '☆ Save' }}</button></form>
                    </div>
                </article>
            @endforeach
        </div>
        @endif
    </div>
</section>
<script>
document.getElementById('geo')?.addEventListener('click', () => {
    if (!navigator.geolocation) { alert('Location is not available on this device.'); return; }
    navigator.geolocation.getCurrentPosition(p => {
        document.getElementById('lat').value = p.coords.latitude.toFixed(6);
        document.getElementById('lng').value = p.coords.longitude.toFixed(6);
        document.getElementById('searchForm').submit();
    }, () => alert('Could not read your location. Allow location access and try again.'));
});
</script>
@endsection
