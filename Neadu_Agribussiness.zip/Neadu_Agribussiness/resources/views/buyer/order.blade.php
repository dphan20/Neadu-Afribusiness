@extends('buyer.layout')
@section('title', 'Order '.strtoupper(substr($order->uuid, 0, 8)))
@section('buyer')
@php($s = $order->status->value)
@php($accepted = $order->accepted_at !== null)
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.orders') }}">← My orders</a><span class="eyebrow">ORDER {{ strtoupper(substr($order->uuid, 0, 8)) }}</span><h1>{{ $order->listing?->title }}</h1>
    <p><span class="by-chip st-{{ $s }}">{{ $order->status->label() }}</span> &nbsp;Seller: {{ $order->seller?->name }}</p></div>
    <form method="post" action="{{ route('buyer.chat.start') }}">@csrf<input type="hidden" name="order" value="{{ $order->uuid }}"><button class="button button-outline">Chat about this order</button></form></div>
<div class="by-split">
    <div class="by-stack">
        <section class="panel">
            <span class="eyebrow">PROGRESS</span>
            <ol class="by-steps" style="margin-top:12px">
                <li class="done"><i>✓</i>Order sent</li>
                <li class="{{ $accepted || ! in_array($s, ['pending', 'refunded'], true) ? 'done' : '' }}"><i>{{ $accepted || ! in_array($s, ['pending', 'refunded'], true) ? '✓' : '' }}</i>Producer accepted @if (! $accepted && $s === 'pending')<small>(by {{ $order->accept_by?->format('d M H:i') }})</small>@endif</li>
                <li class="{{ in_array($s, ['held', 'in_transit', 'delivered', 'released', 'disputed'], true) ? 'done' : '' }}"><i>✓</i>Paid into escrow</li>
                <li class="{{ in_array($s, ['in_transit', 'delivered', 'released'], true) ? 'done' : '' }}"><i>✓</i>Dispatched</li>
                <li class="{{ in_array($s, ['delivered', 'released'], true) ? 'done' : '' }}"><i>✓</i>Delivered @if ($s === 'delivered' && $order->auto_release_at)<small>(auto-confirms {{ $order->auto_release_at->format('d M H:i') }})</small>@endif</li>
                <li class="{{ $s === 'released' ? 'done' : '' }}"><i>✓</i>Receipt confirmed · payment released</li>
            </ol>
            @if ($s === 'refunded')<p class="by-note" style="margin-top:12px">This order was closed{{ $order->rejected_reason ? ': '.$order->rejected_reason : '' }}.</p>@endif
        </section>
        <section class="panel">
            <span class="eyebrow">DETAILS</span>
            <dl class="by-kv" style="margin-top:10px">
                <dt>Quantity</dt><dd>{{ rtrim(rtrim((string) $order->quantity, '0'), '.') }} {{ $order->listing?->produce?->unit?->code }}</dd>
                <dt>Unit price</dt><dd>{{ \App\Support\Money::tzs($order->unit_price_minor) }}</dd>
                <dt>Goods</dt><dd>{{ \App\Support\Money::tzs($order->subtotal_minor) }}</dd>
                <dt>Escrow fee</dt><dd>{{ \App\Support\Money::tzs($order->fee_minor) }}</dd>
                <dt>Total</dt><dd>{{ \App\Support\Money::tzs($order->total()) }}</dd>
                <dt>Collection</dt><dd>{{ $order->delivery_option === 'delivery' ? 'Delivery' : 'Pickup' }}</dd>
                @if ($order->buyer_note)<dt>Your note</dt><dd>{{ $order->buyer_note }}</dd>@endif
            </dl>
        </section>
        @if ($order->delivery)
            <section class="panel"><span class="eyebrow">DELIVERY</span><p style="margin:8px 0">Transporter: <b>{{ $order->delivery->transporter?->name ?? 'Not assigned' }}</b> · {{ ucfirst(str_replace('_', ' ', $order->delivery->status)) }} · {{ \App\Support\Money::tzs($order->delivery->price_minor) }}</p><a class="button button-outline button-small" href="{{ route('buyer.orders.track', $order) }}">Track delivery</a></section>
        @endif
        @if ($s === 'released')
            <section class="panel"><span class="eyebrow">S-16 · RATE THE PRODUCER</span>
                @if ($myRating)<p>You rated {{ $order->seller?->name }}: {{ str_repeat('★', $myRating->stars) }}{{ str_repeat('☆', 5 - $myRating->stars) }} {{ $myRating->comment }}</p>
                @else<form method="post" action="{{ route('buyer.orders.rate', $order) }}" class="by-form" style="margin-top:8px">@csrf
                    <div class="by-star">@for ($i = 5; $i >= 1; $i--)<input type="radio" name="stars" id="st{{ $i }}" value="{{ $i }}" required><label for="st{{ $i }}" title="{{ $i }} stars">★</label>@endfor</div>
                    <label>Comment (optional)<textarea name="comment" maxlength="600"></textarea></label><button class="button button-primary button-small">Submit rating</button></form>@endif
            </section>
        @endif
    </div>
    <aside class="by-stack">
        <section class="panel"><span class="eyebrow">NEXT STEP</span>
            @if ($s === 'pending' && $order->counter_unit_price_minor)
                <p>The producer countered at <b>{{ \App\Support\Money::tzs($order->counter_unit_price_minor) }}</b> per unit (was {{ \App\Support\Money::tzs($order->unit_price_minor) }}).</p>
                <div class="by-row"><form method="post" action="{{ route('buyer.orders.counter', $order) }}">@csrf<input type="hidden" name="action" value="accept"><button class="button button-primary">Accept counter</button></form>
                <form method="post" action="{{ route('buyer.orders.counter', $order) }}">@csrf<input type="hidden" name="action" value="decline"><button class="button button-danger-quiet">Decline &amp; cancel</button></form></div>
            @elseif ($s === 'pending' && $accepted)
                <p>The producer accepted. Pay <b>{{ \App\Support\Money::tzs($order->total()) }}</b> into escrow to start the order.</p>
                <a class="button button-primary button-full" href="{{ route('buyer.orders.pay', $order) }}">Pay into escrow</a>
                <a class="button button-outline button-full" style="margin-top:8px" href="{{ route('buyer.orders.delivery', $order) }}">Request delivery</a>
            @elseif ($s === 'pending')
                <p>Waiting for the producer to accept, reject or counter. If they do not respond in time the order lapses.</p>
                <form method="post" action="{{ route('buyer.orders.counter', $order) }}">@csrf<input type="hidden" name="action" value="decline"><button class="button button-danger-quiet button-small">Cancel order</button></form>
            @elseif (in_array($s, ['held', 'in_transit', 'delivered'], true))
                <p>Your {{ \App\Support\Money::tzs($order->total()) }} is safe in escrow. Confirm only when you have received the goods as described.</p>
                <form method="post" action="{{ route('buyer.orders.confirm', $order) }}" onsubmit="return confirm('Confirm receipt and release payment to the producer?')">@csrf<button class="button button-primary button-full">Confirm receipt &amp; release payment</button></form>
                @if (! $order->delivery && $s === 'held')<a class="button button-outline button-full" style="margin-top:8px" href="{{ route('buyer.orders.delivery', $order) }}">Request delivery</a>@endif
                <a class="button button-danger-quiet button-full" style="margin-top:8px" href="{{ route('buyer.orders.dispute', $order) }}">Open a dispute</a>
                @if ($s === 'delivered' && $order->auto_release_at)<p class="compact-copy" style="margin-top:8px">If you do nothing, payment is released automatically on {{ $order->auto_release_at->format('d M Y H:i') }}.</p>@endif
            @elseif ($s === 'disputed')
                <p>A dispute is open and the funds are frozen.</p><a class="button button-primary button-full" href="{{ route('buyer.orders.dispute', $order) }}">View dispute</a>
            @elseif ($s === 'released')<p>Completed. Payment was released to the producer.</p>
            @else<p>No further action.</p>@endif
        </section>
        @if ($simulate)
        <section class="by-demo"><b>Demo mode</b> — acts as the producer/transporter until their workspaces are connected (set NEAS_SIMULATE_GATEWAYS=false to remove).
            <div class="by-row" style="margin-top:8px">
                @foreach (['accept' => 'Producer accepts', 'counter' => 'Producer counters −5%', 'reject' => 'Producer rejects', 'ship' => 'Dispatch', 'deliver' => 'Mark delivered'] as $a => $label)
                    <form method="post" action="{{ route('buyer.orders.simulate', $order) }}">@csrf<input type="hidden" name="action" value="{{ $a }}"><button class="button button-tiny button-outline">{{ $label }}</button></form>
                @endforeach
            </div>
        </section>
        @endif
    </aside>
</div>
@endsection
