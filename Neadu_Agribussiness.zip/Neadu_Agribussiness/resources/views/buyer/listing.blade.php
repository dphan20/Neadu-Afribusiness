@extends('buyer.layout')
@section('title', $listing->title)
@section('buyer')
@php($p = $listing->produce)
@php($qty = (float) ($p?->quantity ?? 0))
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.market') }}">← Find produce</a><span class="eyebrow">S-09 · LISTING</span><h1>{{ $listing->title }}</h1><p>{{ $listing->district?->name }}{{ $listing->district && $listing->region ? ', ' : '' }}{{ $listing->region?->name }}</p></div>
    <form method="post" action="{{ route('buyer.favourite', $listing) }}">@csrf<button class="button button-outline">{{ $isFavourite ? '★ Saved to favourites' : '☆ Save to favourites' }}</button></form></div>
<div class="by-split">
    <div class="by-stack">
        <section class="panel">
            <div class="by-row" style="gap:10px;overflow:auto">
                @forelse ($listing->photos ?? [] as $ph)
                    <div class="by-thumb" style="width:220px;height:150px;flex:none"><img src="{{ \Illuminate\Support\Str::startsWith($ph, 'http') ? $ph : asset('storage/'.$ph) }}" alt="Produce photo"></div>
                @empty
                    <div class="by-thumb" style="width:100%;height:150px">{{ mb_substr($p?->crop?->name_en ?? $listing->title, 0, 1) }}<small style="font-size:12px;margin-left:8px">No photos uploaded</small></div>
                @endforelse
            </div>
            <dl class="by-kv" style="margin-top:16px">
                <dt>Product</dt><dd>{{ $p?->crop?->name_en }} / {{ $p?->crop?->name_sw }}</dd>
                <dt>Price</dt><dd>{{ \App\Support\Money::tzs($listing->price_minor, $listing->currency) }} per {{ $p?->unit?->code }}</dd>
                <dt>Available</dt><dd>{{ rtrim(rtrim((string) $p?->quantity, '0'), '.') }} {{ $p?->unit?->code }}</dd>
                <dt>Quality</dt><dd>{{ $p?->grade ? 'Grade '.$p->grade : 'Not graded' }}{{ $p?->quality_notes ? ' · '.$p->quality_notes : '' }}</dd>
                <dt>Harvested</dt><dd>{{ $p?->harvest_date?->format('d M Y') ?? '—' }}</dd>
                @if ($reference)<dt>Market price</dt><dd>{{ \App\Support\Money::tzs($reference->price_minor) }} <small>({{ $reference->source }}, {{ $reference->recorded_on }})</small></dd>@endif
            </dl>
        </section>
        <section class="panel">
            <span class="eyebrow">SELLER</span>
            <h2 style="margin:4px 0">{{ $listing->owner?->name }} @if ($listing->owner?->isIdentityVerified())<span class="by-chip">✓ ID verified</span>@endif @if ($listing->verified)<span class="by-chip">✓ Listing verified</span>@endif</h2>
            <p class="compact-copy">{{ $ratingCount ? '★ '.$ratingAvg.' from '.$ratingCount.' '.($ratingCount === 1 ? 'rating' : 'ratings') : 'No ratings yet' }}</p>
            <div class="by-row">
                <form method="post" action="{{ route('buyer.chat.start') }}">@csrf<input type="hidden" name="listing" value="{{ $listing->uuid }}"><button class="button button-outline button-small">Chat with seller</button></form>
                <a class="button button-outline button-small" href="{{ route('buyer.contracts.create', ['listing' => $listing->uuid]) }}">Offer a contract (R3)</a>
            </div>
        </section>
        <section class="panel">
            <span class="eyebrow">LOCATION</span>
            @if ($listing->lat && $listing->lng)
                @php($la = (float) $listing->lat)@php($ln = (float) $listing->lng)
                <iframe title="Listing location map" loading="lazy" style="width:100%;height:260px;border:0;border-radius:12px;margin-top:8px"
                    src="https://www.openstreetmap.org/export/embed.html?bbox={{ $ln - 0.05 }}%2C{{ $la - 0.05 }}%2C{{ $ln + 0.05 }}%2C{{ $la + 0.05 }}&amp;layer=mapnik&amp;marker={{ $la }}%2C{{ $ln }}"></iframe>
            @else
                <p class="compact-copy">The seller has not pinned an exact location. Area: {{ $listing->district?->name }} {{ $listing->region?->name }}.</p>
            @endif
        </section>
    </div>
    <aside class="panel" style="position:sticky;top:16px">
        <span class="eyebrow">S-11 · PLACE ORDER</span>
        @if ($listing->user_id === auth()->id())
            <p>This is your own listing.</p>
        @else
        <form method="post" action="{{ route('buyer.orders.store', $listing) }}" class="by-form" id="orderForm">
            @csrf
            <label>Quantity
                <select name="mode" id="mode"><option value="full">Full lot ({{ rtrim(rtrim((string) $p?->quantity, '0'), '.') }} {{ $p?->unit?->code }})</option><option value="part" @selected(old('mode') === 'part')>Part of the lot</option></select></label>
            <label id="qtyWrap" style="display:none">Quantity ({{ $p?->unit?->code }})<input type="number" step="any" min="0.001" max="{{ $qty }}" name="quantity" id="qty" value="{{ old('quantity') }}"></label>
            <label>Delivery<select name="delivery_option"><option value="pickup">I will collect (pickup)</option><option value="delivery">Deliver to me (choose transporter after)</option></select></label>
            <label>Note to producer (optional)<textarea name="note" maxlength="500">{{ old('note') }}</textarea></label>
            <dl class="by-kv" style="grid-template-columns:1fr auto">
                <dt>Goods</dt><dd id="sub">—</dd><dt>Escrow fee ({{ $feeBps / 100 }}%)</dt><dd id="fee">—</dd><dt><b>Total in escrow</b></dt><dd id="tot">—</dd>
            </dl>
            <button class="button button-primary button-full">Send order to producer</button>
            <p class="compact-copy">The producer has 24 hours to accept, reject or counter. You only pay after they accept; the money stays in escrow until you confirm receipt.</p>
        </form>
        @endif
    </aside>
</div>
<script>
(() => {
    const price = {{ (int) $listing->price_minor }}, full = {{ $qty }}, bps = {{ (int) $feeBps }};
    const mode = document.getElementById('mode'), qty = document.getElementById('qty'), wrap = document.getElementById('qtyWrap');
    const fmt = m => new Intl.NumberFormat('en-US').format(Math.floor(m / 100)) + ' TZS';
    function calc() {
        wrap.style.display = mode.value === 'part' ? 'grid' : 'none';
        const q = mode.value === 'full' ? full : parseFloat(qty.value || 0);
        const sub = Math.round(q * price), fee = Math.floor(sub * bps / 10000);
        document.getElementById('sub').textContent = fmt(sub); document.getElementById('fee').textContent = fmt(fee); document.getElementById('tot').textContent = fmt(sub + fee);
    }
    mode?.addEventListener('change', calc); qty?.addEventListener('input', calc); calc();
})();
</script>
@endsection
