@extends('buyer.layout')
@section('title', 'New contract offer')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.contracts') }}">← Contracts</a><span class="eyebrow">S-38 · CTR-01</span><h1>Contract offer</h1><p>{{ $listing ? $listing->title.' · '.$listing->owner?->name : 'Start from a listing in the marketplace.' }}</p></div></div>
@if (! $listing)
    <section class="panel"><div class="empty-state"><h3>Pick a listing first</h3><p>Open a listing and choose “Offer a contract”.</p><a class="button button-primary button-small" href="{{ route('buyer.market') }}">Find produce</a></div></section>
@else
<section class="panel" style="max-width:760px">
    <form method="post" action="{{ route('buyer.contracts.store') }}" class="by-form">@csrf<input type="hidden" name="listing" value="{{ $listing->uuid }}">
        <div class="two"><label>Quantity per delivery (kg)<input type="number" step="any" min="1" name="quantity_kg" value="{{ old('quantity_kg') }}" required></label><label>Number of deliveries<input type="number" min="1" max="60" name="deliveries" value="{{ old('deliveries', 4) }}" required></label></div>
        <label>Agreed price per unit (TZS) <small>— listing price {{ \App\Support\Money::tzs($listing->price_minor) }}</small><input type="number" step="any" min="1" name="unit_price" value="{{ old('unit_price', intdiv($listing->price_minor, 100)) }}" required></label>
        <div class="two"><label>Start date<input type="date" name="start_date" value="{{ old('start_date') }}" required></label><label>End date<input type="date" name="end_date" value="{{ old('end_date') }}" required></label></div>
        <label>Delivery terms<textarea name="delivery_terms" required maxlength="500" placeholder="e.g. Weekly pickup every Monday at the farm gate">{{ old('delivery_terms') }}</textarea></label>
        <label>Penalty / quality clause (optional)<textarea name="penalty" maxlength="500">{{ old('penalty') }}</textarea></label>
        <p class="by-note">Payment follows the normal escrow rules for each delivery. You will review the final terms and sign with a one-time code on the next screen.</p>
        <button class="button button-primary">Create offer</button>
    </form>
</section>
@endif
@endsection
