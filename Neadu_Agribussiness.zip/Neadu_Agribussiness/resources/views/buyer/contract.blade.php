@extends('buyer.layout')
@section('title', 'Contract')
@section('buyer')
@php($t = $contract->terms)
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.contracts') }}">← Contracts</a><span class="eyebrow">S-39 · CTR-02</span><h1>Review &amp; sign</h1><p>Contract {{ strtoupper(substr($contract->uuid, 0, 8)) }} · <span class="by-chip">{{ ucfirst(str_replace('_', ' ', $contract->status)) }}</span></p></div></div>
<div class="by-split">
    <section class="panel"><span class="eyebrow">TERMS</span>
        <dl class="by-kv" style="margin-top:10px">
            <dt>Buyer</dt><dd>{{ auth()->user()->name }}</dd><dt>Producer</dt><dd>{{ $contract->seller?->name }}</dd>
            <dt>Product</dt><dd>{{ $t['listing_title'] ?? '' }} {{ ! empty($t['crop']) ? '('.$t['crop'].')' : '' }}</dd>
            <dt>Quantity</dt><dd>{{ $t['quantity_kg_per_delivery'] ?? '' }} kg × {{ $t['deliveries'] ?? '' }} deliveries</dd>
            <dt>Agreed price</dt><dd>{{ \App\Support\Money::tzs($t['unit_price_minor'] ?? 0) }} per unit</dd>
            <dt>Period</dt><dd>{{ $t['start_date'] ?? '' }} → {{ $t['end_date'] ?? '' }}</dd>
            <dt>Payment</dt><dd>{{ $t['payment'] ?? '' }}</dd><dt>Delivery</dt><dd>{{ $t['delivery_terms'] ?? '' }}</dd>
            @if (! empty($t['penalty']))<dt>Penalty</dt><dd>{{ $t['penalty'] }}</dd>@endif
            @if ($contract->pdf_hash)<dt>Document hash</dt><dd style="word-break:break-all;font-size:12px">{{ $contract->pdf_hash }}</dd>@endif
        </dl>
    </section>
    <aside class="panel"><span class="eyebrow">E-SIGNATURE</span>
        @if ($signed)
            <p style="margin:10px 0"><b>✓ You signed</b> on {{ \Illuminate\Support\Carbon::parse($contract->signatures['buyer']['signed_at'])->format('d M Y H:i') }}.</p><p class="compact-copy">Waiting for the producer to counter-sign. The contract becomes active once both parties have signed.</p>
        @else
            @if (session('demo_otp'))<div class="by-demo" style="margin:10px 0">Demo mode — your code is <b>{{ session('demo_otp') }}</b></div>@endif
            <form method="post" action="{{ route('buyer.contracts.otp', $contract) }}" style="margin:10px 0">@csrf<button class="button button-outline button-full">Send me a code</button></form>
            <form method="post" action="{{ route('buyer.contracts.sign', $contract) }}" class="by-form">@csrf
                <label>6-digit code<input name="otp" inputmode="numeric" maxlength="6" autocomplete="one-time-code" required></label>
                <label style="display:flex;gap:8px;align-items:flex-start;font-weight:500"><input type="checkbox" name="agree" value="1" required style="width:auto;min-height:0;margin-top:3px"> I have read these terms and agree to be legally bound.</label>
                <button class="button button-primary button-full">Sign contract</button></form>
        @endif
    </aside>
</div>
@endsection
