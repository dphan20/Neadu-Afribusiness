@extends('buyer.layout')
@section('title', 'My orders')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.dashboard') }}">← Overview</a><span class="eyebrow">S-11 · S-14</span><h1>My orders</h1><p>Track every order, escrow payment and delivery.</p></div></div>
<section class="panel data-panel">
    <form method="get" class="filter-bar"><label><span class="sr-only">Status</span><select name="status" onchange="this.form.submit()"><option value="">All statuses</option>@foreach (\App\Enums\EscrowState::cases() as $s)<option value="{{ $s->value }}" @selected($filter === $s->value)>{{ $s->label() }}</option>@endforeach</select></label></form>
    @if ($orders->isEmpty())<div class="empty-state"><span class="empty-mark">0</span><h3>No orders</h3><p>Find produce and place an order.</p><a class="button button-primary button-small" href="{{ route('buyer.market') }}">Find produce</a></div>
    @else<div class="table-wrap"><table class="data-table"><thead><tr><th>Order</th><th>Listing</th><th>Seller</th><th>Quantity</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody>
        @foreach ($orders as $o)<tr><td>{{ strtoupper(substr($o->uuid, 0, 8)) }}</td><td>{{ $o->listing?->title }}</td><td>{{ $o->seller?->name }}</td><td>{{ rtrim(rtrim((string) $o->quantity, '0'), '.') }}</td><td>{{ \App\Support\Money::tzs($o->total()) }}</td>
        <td><span class="by-chip st-{{ $o->status->value }}">{{ $o->status->label() }}</span>@if ($o->counter_unit_price_minor && $o->status->value === 'pending')<br><small>Counter-offer</small>@endif</td>
        <td><a class="button button-tiny button-outline" href="{{ route('buyer.orders.show', $o) }}">Open</a></td></tr>@endforeach
    </tbody></table></div>@endif
</section>
@endsection
