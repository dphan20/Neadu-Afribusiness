@extends('buyer.layout')
@section('title', 'Price alerts')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.dashboard') }}">← Overview</a><span class="eyebrow">PRC-03</span><h1>Price alerts</h1><p>Get told when a market price moves above or below your target.</p></div></div>
<div class="by-split">
    <div class="by-stack">
        <section class="panel data-panel">
            <div class="panel-heading"><div><span class="eyebrow">YOUR ALERTS</span><h2>{{ $alerts->count() }} active</h2></div></div>
            @if ($alerts->isEmpty())<div class="empty-state"><span class="empty-mark">0</span><h3>No alerts</h3><p>Create one with the form.</p></div>
            @else<div class="table-wrap"><table class="data-table"><thead><tr><th>Product</th><th>Market</th><th>Condition</th><th>Latest price</th><th>Channels</th><th></th></tr></thead><tbody>
                @foreach ($alerts as $a)<tr><td>{{ $a->crop?->name_en }}</td><td>{{ $a->market?->name ?? 'Any market' }}</td><td>{{ ucfirst($a->condition) }} {{ \App\Support\Money::tzs($a->threshold_minor) }}</td><td>{{ isset($latest[$a->id]) ? \App\Support\Money::tzs($latest[$a->id]->price_minor) : '—' }}</td><td>{{ implode(', ', $a->channels ?? []) }}</td>
                <td><form method="post" action="{{ route('buyer.alerts.delete', $a->uuid) }}">@csrf @method('DELETE')<button class="button button-tiny button-danger-quiet">Remove</button></form></td></tr>@endforeach
            </tbody></table></div>@endif
        </section>
        <section class="panel data-panel">
            <div class="panel-heading"><div><span class="eyebrow">REFERENCE</span><h2>Recent market prices</h2></div></div>
            @if ($prices->isEmpty())<div class="empty-state"><h3>No price records yet</h3><p>Prices appear once markets report them.</p></div>
            @else<div class="table-wrap"><table class="data-table"><thead><tr><th>Produce</th><th>Market</th><th>Price</th><th>Date</th><th>Source</th></tr></thead><tbody>
                @foreach ($prices as $pr)<tr><td>{{ $pr->crop?->name_en }}</td><td>{{ $pr->market?->name }}</td><td>{{ \App\Support\Money::tzs($pr->price_minor) }}</td><td>{{ $pr->recorded_on }}</td><td>{{ $pr->source }}</td></tr>@endforeach
            </tbody></table></div>@endif
        </section>
    </div>
    <aside class="panel"><span class="eyebrow">NEW ALERT</span>
        <form method="post" action="{{ route('buyer.alerts.store') }}" class="by-form">@csrf
            <label>Product<select name="crop_id" required>@foreach ($crops as $c)<option value="{{ $c->id }}">{{ $c->name_en }} / {{ $c->name_sw }}</option>@endforeach</select></label>
            <label>Market<select name="market_id"><option value="">Any market</option>@foreach ($markets as $m)<option value="{{ $m->id }}">{{ $m->name }}</option>@endforeach</select></label>
            <div class="two"><label>When price is<select name="condition"><option value="below">Below</option><option value="above">Above</option></select></label><label>Target (TZS)<input type="number" step="any" min="1" name="threshold" required></label></div>
            <label>Notify me by</label>
            <div class="by-row"><label style="display:flex;gap:6px;align-items:center"><input type="checkbox" name="channels[]" value="in_app" checked style="width:auto;min-height:0"> In-app</label><label style="display:flex;gap:6px;align-items:center"><input type="checkbox" name="channels[]" value="sms" style="width:auto;min-height:0"> SMS</label></div>
            <button class="button button-primary">Create alert</button>
        </form>
    </aside>
</div>
@endsection
