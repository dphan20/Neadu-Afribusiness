@extends('buyer.layout')
@section('title', 'Request delivery')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.orders.show', $order) }}">← Order</a><span class="eyebrow">S-17 · LOG-02</span><h1>Request delivery</h1><p>Choose where to deliver and who carries it.</p></div></div>
<form method="post" action="{{ route('buyer.orders.delivery.store', $order) }}" class="by-split by-form">@csrf
    <section class="panel by-stack">
        <span class="eyebrow">DROP-OFF POINT</span>
        <div class="two"><label>Latitude<input name="drop_lat" id="dlat" type="number" step="any" value="{{ old('drop_lat', -6.7924) }}" required></label><label>Longitude<input name="drop_lng" id="dlng" type="number" step="any" value="{{ old('drop_lng', 39.2083) }}" required></label></div>
        <button type="button" class="button button-outline button-small" id="geo" style="width:max-content">Use my current location</button>
        <p class="compact-copy">Pickup point: {{ round($pickup[0], 4) }}, {{ round($pickup[1], 4) }} (producer’s location).</p>
        <span class="eyebrow" style="margin-top:10px">CHOOSE A TRANSPORTER</span>
        @forelse ($transporters as $t)
            @forelse ($t->vehicles as $v)
                <label class="role-option" style="display:flex;gap:10px;align-items:flex-start"><input type="radio" name="transporter_id" value="{{ $t->id }}" required style="width:auto;min-height:0" onclick="document.getElementById('veh').value='{{ $v->id }}'"><span><b>{{ $t->name }}</b><br><small>{{ $v->type }} · {{ $v->plate }} · up to {{ number_format((float) $v->capacity_kg) }} kg</small></span></label>
            @empty
                <label class="role-option" style="display:flex;gap:10px;align-items:flex-start"><input type="radio" name="transporter_id" value="{{ $t->id }}" required style="width:auto;min-height:0" onclick="document.getElementById('veh').value=''"><span><b>{{ $t->name }}</b><br><small>No vehicle registered yet</small></span></label>
            @endforelse
        @empty
            <div class="empty-state"><h3>No transporters available</h3><p>Try again later or arrange pickup instead.</p></div>
        @endforelse
        <input type="hidden" name="vehicle_id" id="veh">
    </section>
    <aside class="panel by-stack"><span class="eyebrow">HOW IT WORKS</span>
        <p class="compact-copy">The price is estimated from the distance and shown after you request. The transporter accepts, collects the goods and you can follow the trip live. A 4-digit handover code is shown to you once; give it to the driver only when the goods arrive.</p>
        <button class="button button-primary button-full" @disabled($transporters->isEmpty())>Request delivery</button></aside>
</form>
<script>document.getElementById('geo').addEventListener('click',()=>navigator.geolocation?.getCurrentPosition(p=>{document.getElementById('dlat').value=p.coords.latitude.toFixed(6);document.getElementById('dlng').value=p.coords.longitude.toFixed(6);},()=>alert('Could not read your location.')));</script>
@endsection
