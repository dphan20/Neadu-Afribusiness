@extends('buyer.layout')
@section('title', 'Chat')
@section('buyer')
@php($other = $conversation->participants->firstWhere('id', '!=', auth()->id()))
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.chat') }}">← Messages</a><span class="eyebrow">COM-01</span><h1>{{ $other?->name ?? 'Conversation' }}</h1>
    <p>{{ $conversation->order ? 'About order: '.$conversation->order->listing?->title : ($conversation->listing ? 'About listing: '.$conversation->listing->title : '') }}</p></div>
    @if ($conversation->order)<a class="button button-outline button-small" href="{{ route('buyer.orders.show', $conversation->order) }}">Open order</a>@endif</div>
<section class="panel">
    @include('partials.chat-toolbar', ['area' => 'me', 'conversation' => $conversation])
    <div style="display:grid;gap:8px;min-height:240px;max-height:55vh;overflow:auto">
        @php($thread = $conversation->messagesFor(auth()->user()))
        @forelse ($thread as $m)@include('partials.chat-bubble', ['m' => $m, 'bubble' => 'by-msg', 'area' => 'me'])
        @empty<p class="compact-copy">No messages yet. Say hello.</p>@endforelse
        <span id="latest"></span>
    </div>
    <form method="post" action="{{ route('buyer.chat.send', $conversation) }}" enctype="multipart/form-data" class="by-form" style="margin-top:14px">@csrf
        <textarea name="body" placeholder="Write a message…" maxlength="2000"></textarea>
        <div class="by-row"><input type="file" name="photo" accept="image/*" style="width:auto;min-height:0;border:0"><button class="button button-primary button-small">Send</button></div>
    </form>
</section>
@endsection
