@extends('buyer.layout')
@section('title', 'Dispute')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.orders.show', $order) }}">← Order</a><span class="eyebrow">S-15 · MKT-08</span><h1>{{ $dispute ? 'Your dispute' : 'Open a dispute' }}</h1><p>{{ $order->listing?->title }} · {{ \App\Support\Money::tzs($order->total()) }} frozen in escrow</p></div></div>
@if ($dispute)
<div class="by-split">
    <section class="panel"><dl class="by-kv">
        <dt>Reason</dt><dd>{{ ucfirst(str_replace('_', ' ', $dispute->reason)) }}</dd>
        <dt>Your account</dt><dd>{{ $dispute->evidence['details'] ?? '' }}</dd>
        <dt>Evidence deadline</dt><dd>{{ $dispute->evidence_until?->format('d M Y H:i') }}</dd>
        <dt>Decision due</dt><dd>{{ $dispute->decide_by?->format('d M Y') }}</dd>
        <dt>Decision</dt><dd>{{ $dispute->decision ? ucfirst($dispute->decision) : 'Under review by NeAS' }}</dd>
    </dl>
    @if (! empty($dispute->evidence['photos']))<div class="by-row" style="margin-top:14px">@foreach ($dispute->evidence['photos'] as $ph)<a href="{{ route('buyer.orders.dispute.photo', [$order, $loop->index]) }}" target="_blank" rel="noopener"><img src="{{ route('buyer.orders.dispute.photo', [$order, $loop->index]) }}" alt="Evidence photo" style="width:110px;height:90px;object-fit:cover;border-radius:10px"></a>@endforeach</div>@endif</section>
    <aside class="by-stack">
        <section class="panel"><span class="eyebrow">EVIDENCE</span><p class="compact-copy">Use the order chat to share more photos and messages with the producer and NeAS reviewer.</p>
            <form method="post" action="{{ route('buyer.chat.start') }}">@csrf<input type="hidden" name="order" value="{{ $order->uuid }}"><button class="button button-primary button-full">Open dispute chat</button></form></section>
        @if ($order->delivery)<section class="panel"><span class="eyebrow">TRACKING</span><p class="compact-copy">{{ $order->delivery->points->count() }} tracking points recorded.</p><a class="button button-outline button-full" href="{{ route('buyer.orders.track', $order) }}">View tracking history</a></section>@endif
    </aside>
</div>
@else
<section class="panel" style="max-width:720px">
    <form method="post" action="{{ route('buyer.orders.dispute.store', $order) }}" enctype="multipart/form-data" class="by-form">@csrf
        <label>What went wrong?<select name="reason" required>@foreach (['not_delivered' => 'Goods not delivered', 'wrong_quantity' => 'Wrong quantity', 'poor_quality' => 'Poor quality', 'not_as_described' => 'Not as described', 'other' => 'Other'] as $k => $v)<option value="{{ $k }}" @selected(old('reason') === $k)>{{ $v }}</option>@endforeach</select></label>
        <label>Describe the problem<textarea name="details" required minlength="10" maxlength="1500">{{ old('details') }}</textarea></label>
        <label>Photos (up to 6)<input type="file" name="photos[]" accept="image/*" multiple></label>
        <p class="by-note">Opening a dispute freezes the payment. You have 3 days to add evidence and NeAS decides within 5 working days. Only dispute genuine problems.</p>
        <button class="button button-danger-quiet">Open dispute</button>
    </form>
</section>
@endif
@endsection
