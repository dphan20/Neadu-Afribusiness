@extends('buyer.layout')
@section('title', 'Pay into escrow')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.orders.show', $order) }}">← Order</a><span class="eyebrow">S-12 · MKT-05</span><h1>Pay into escrow</h1><p>Your money is held safely and only released when you confirm receipt.</p></div></div>
<div class="by-split">
    <section class="panel">
        <form method="post" action="{{ route('buyer.orders.pay.store', $order) }}" class="by-form" x-data>
            @csrf
            <label>Payment method
                <select name="provider" id="provider">
                    <optgroup label="Mobile money"><option value="mpesa">M-Pesa</option><option value="tigopesa">Mixx by Yas (Tigo Pesa)</option><option value="airtelmoney">Airtel Money</option><option value="halopesa">HaloPesa</option></optgroup>
                    <optgroup label="Bank"><option value="bank">Bank transfer</option></optgroup>
                </select></label>
            <label id="phoneWrap">Mobile money number<input name="phone" inputmode="tel" placeholder="2557XXXXXXXX" value="{{ old('phone', auth()->user()->phone) }}"></label>
            <label id="bankWrap" style="display:none">Bank account number<input name="bank_account" value="{{ old('bank_account') }}"></label>
            <button class="button button-primary button-full">Pay {{ \App\Support\Money::tzs($order->total()) }}</button>
            <p class="compact-copy">You will get a prompt on your phone to approve the payment. Duplicate taps will not charge you twice.</p>
        </form>
    </section>
    <aside class="panel"><span class="eyebrow">SUMMARY</span><h2 style="margin:6px 0">{{ $order->listing?->title }}</h2>
        <dl class="by-kv" style="grid-template-columns:1fr auto"><dt>Goods</dt><dd>{{ \App\Support\Money::tzs($order->subtotal_minor) }}</dd><dt>Escrow fee</dt><dd>{{ \App\Support\Money::tzs($order->fee_minor) }}</dd><dt><b>Total</b></dt><dd>{{ \App\Support\Money::tzs($order->total()) }}</dd></dl>
        <p class="by-note" style="margin-top:12px">Seller: {{ $order->seller?->name }}. If something goes wrong you can open a dispute before releasing payment.</p></aside>
</div>
<script>
const prov = document.getElementById('provider');
function sw(){const b = prov.value === 'bank'; document.getElementById('bankWrap').style.display = b ? 'grid' : 'none'; document.getElementById('phoneWrap').style.display = b ? 'none' : 'grid';}
prov.addEventListener('change', sw); sw();
</script>
@endsection
