@extends('buyer.layout')
@section('title', 'Wanted to buy')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.dashboard') }}">← Overview</a><span class="eyebrow">MKT-11 · R2</span><h1>Wanted to buy</h1><p>Tell producers what you need and the price you can pay.</p></div></div>
<div class="by-split">
    <section class="panel data-panel">
        <div class="panel-heading"><div><span class="eyebrow">YOUR REQUESTS</span><h2>{{ $requests->count() }} {{ $requests->count() === 1 ? 'request' : 'requests' }}</h2></div></div>
        @if ($requests->isEmpty())<div class="empty-state"><span class="empty-mark">0</span><h3>No requests</h3><p>Post your first request using the form.</p></div>
        @else<div class="table-wrap"><table class="data-table"><thead><tr><th>Product</th><th>Quantity</th><th>Max price</th><th>Region</th><th>Needed by</th><th>Status</th><th></th></tr></thead><tbody>
            @foreach ($requests as $r)<tr><td>{{ $r->crop?->name_en }}</td><td>{{ rtrim(rtrim((string) $r->quantity, '0'), '.') }}</td><td>{{ $r->max_price_minor ? \App\Support\Money::tzs($r->max_price_minor) : 'Open' }}</td><td>{{ $r->region?->name ?? 'Any' }}</td><td>{{ $r->needed_by?->format('d M Y') ?? '—' }}</td><td><span class="by-chip">{{ ucfirst($r->status) }}</span></td>
            <td>@if ($r->status === 'open')<form method="post" action="{{ route('buyer.wanted.close', $r->uuid) }}">@csrf @method('PATCH')<button class="button button-tiny button-outline">Close</button></form>@endif</td></tr>@endforeach
        </tbody></table></div>@endif
    </section>
    <aside class="panel"><span class="eyebrow">NEW REQUEST</span>
        <form method="post" action="{{ route('buyer.wanted.store') }}" class="by-form">@csrf
            <label>Product<select name="crop_id" required>@foreach ($crops as $c)<option value="{{ $c->id }}" @selected(old('crop_id') == $c->id)>{{ $c->name_en }} / {{ $c->name_sw }}</option>@endforeach</select></label>
            <div class="two"><label>Quantity (kg)<input type="number" step="any" min="0.001" name="quantity" value="{{ old('quantity') }}" required></label><label>Max price per unit (TZS)<input type="number" step="any" min="0" name="max_price" value="{{ old('max_price') }}"></label></div>
            <div class="two"><label>Region<select name="region_id"><option value="">Any</option>@foreach ($regions as $r)<option value="{{ $r->id }}">{{ $r->name }}</option>@endforeach</select></label><label>Needed by<input type="date" name="needed_by" value="{{ old('needed_by') }}"></label></div>
            <label>Note<textarea name="note" maxlength="500">{{ old('note') }}</textarea></label>
            <button class="button button-primary">Post request</button>
        </form>
    </aside>
</div>
@endsection
