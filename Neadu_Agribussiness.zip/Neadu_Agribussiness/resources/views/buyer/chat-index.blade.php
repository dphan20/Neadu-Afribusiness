@extends('buyer.layout')
@section('title', 'Messages')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.dashboard') }}">← Overview</a><span class="eyebrow">COM-01</span><h1>Messages</h1><p>Conversations about listings, orders and disputes.</p></div></div>
<p><a class="button button-primary button-small" href="{{ route('me.chat.new') }}">✉ {{ __('chat.new_message') }}</a></p>
<section class="panel">
    @forelse ($conversations as $c)@php($other = $c->participants->firstWhere('id', '!=', auth()->id()))@php($last = $c->messages->last())
        <a href="{{ route('buyer.chat.show', $c) }}" style="display:flex;justify-content:space-between;gap:10px;padding:12px 0;border-bottom:1px solid var(--color-border)">
            <span><b>{{ $other?->name ?? 'Conversation' }}</b><br><small>{{ $c->order ? 'Order · '.$c->order->listing?->title : ($c->listing ? 'Listing · '.$c->listing->title : '') }}</small></span>
            <span style="text-align:right"><small>{{ $last ? \Illuminate\Support\Str::limit($last->body ?? '📷 Photo', 40) : 'No messages yet' }}</small><br><small>{{ $c->updated_at?->diffForHumans() }}</small></span></a>
    @empty
        <div class="empty-state"><span class="empty-mark">✉</span><h3>No conversations</h3><p>Open a listing or order and choose “Chat”.</p></div>
    @endforelse
</section>
@endsection
