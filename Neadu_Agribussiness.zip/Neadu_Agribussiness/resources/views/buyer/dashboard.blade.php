@extends('buyer.layout')
@section('title', 'Buyer workspace')
@section('buyer')
<div class="workspace-heading">
    <div><span class="eyebrow">Mnunuzi</span><h1>Habari, {{ explode(' ', auth()->user()->name)[0] }}</h1><p>Find produce at a fair price and pay safely through escrow.</p></div>
    <a class="button button-primary" href="{{ route('buyer.market') }}">Find produce</a>
</div>
<div class="metric-grid">
    @foreach ($metrics as $m)
        <article class="metric-card metric-{{ $m['tone'] }}"><span class="metric-label">{{ $m['label'] }}</span><strong>{{ $m['value'] }}</strong><span class="metric-caption">Buyer workspace</span></article>
    @endforeach
</div>
<div class="workspace-columns">
    <section class="panel panel-main">
        <div class="panel-heading"><div><span class="eyebrow">RECENT ORDERS</span><h2>Latest activity</h2></div><a class="text-link" href="{{ route('buyer.orders') }}">All orders →</a></div>
        @forelse ($recent as $o)
            <a class="compact-row" href="{{ route('buyer.orders.show', $o) }}" style="display:flex;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid var(--color-border)">
                <span><b>{{ $o->listing?->title }}</b><br><small>{{ $o->seller?->name }} · {{ rtrim(rtrim((string) $o->quantity, '0'), '.') }} units</small></span>
                <span><span class="by-chip st-{{ $o->status->value }}">{{ $o->status->label() }}</span><br><small>{{ \App\Support\Money::tzs($o->total()) }}</small></span>
            </a>
        @empty
            <div class="empty-state"><span class="empty-mark">0</span><h3>No orders yet</h3><p>Search the marketplace and place your first order.</p></div>
        @endforelse
    </section>
    <aside class="panel guidance-panel">
        <span class="guidance-icon">N</span><span class="eyebrow">QUICK LINKS</span><h2>Shortcuts</h2>
        <p><a class="text-link" href="{{ route('buyer.wanted') }}">Post a wanted-to-buy request →</a></p>
        <p><a class="text-link" href="{{ route('buyer.alerts') }}">Set a price alert →</a></p>
        <p><a class="text-link" href="{{ route('buyer.contracts') }}">Contract offers (R3) →</a></p>
        <p><a class="text-link" href="{{ route('buyer.chat') }}">Messages →</a></p>
    </aside>
</div>
@endsection
