@extends('buyer.layout')
@section('title', 'Contracts')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.dashboard') }}">← Overview</a><span class="eyebrow">R3 · CTR-01</span><h1>Contract offers</h1><p>Agree recurring supply terms with a producer and sign with a one-time code.</p></div><a class="button button-primary" href="{{ route('buyer.contracts.create') }}">New offer</a></div>
<section class="panel data-panel">
    @if ($contracts->isEmpty())<div class="empty-state"><span class="empty-mark">0</span><h3>No contract offers</h3><p>Open a listing and choose “Offer a contract”.</p></div>
    @else<div class="table-wrap"><table class="data-table"><thead><tr><th>Listing</th><th>Producer</th><th>Per delivery</th><th>Period</th><th>Status</th><th></th></tr></thead><tbody>
        @foreach ($contracts as $c)<tr><td>{{ $c->terms['listing_title'] ?? '—' }}</td><td>{{ $c->seller?->name }}</td><td>{{ $c->terms['quantity_kg_per_delivery'] ?? '' }} kg × {{ $c->terms['deliveries'] ?? '' }}</td><td>{{ $c->terms['start_date'] ?? '' }} → {{ $c->terms['end_date'] ?? '' }}</td><td><span class="by-chip">{{ ucfirst(str_replace('_', ' ', $c->status)) }}</span></td><td><a class="button button-tiny button-outline" href="{{ route('buyer.contracts.show', $c) }}">Open</a></td></tr>@endforeach
    </tbody></table></div>@endif
</section>
@endsection
