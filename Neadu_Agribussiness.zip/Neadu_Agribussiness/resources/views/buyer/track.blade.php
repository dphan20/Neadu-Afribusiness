@extends('buyer.layout')
@section('title', 'Track delivery')
@section('buyer')
@php($pts = $delivery->points)
@push('head')
@include('layouts.partials.entry', ['entry' => 'resources/js/tracking.js'])
<style>
    .live-map { height: 380px; border-radius: 12px; overflow: hidden; z-index: 0; }
    .live-steps { list-style: none; display: grid; grid-template-columns: repeat(6, 1fr); gap: 4px; margin: 0 0 12px; padding: 0; }
    .live-steps li { text-align: center; font-size: 11px; font-weight: 700; padding: 8px 2px; border-radius: 8px; border: 1px solid var(--color-border); color: var(--color-text-muted); background: var(--color-background); }
    .live-steps li.done { background: var(--color-primary-soft); color: var(--color-primary-dark); }
    .live-steps li.now { background: var(--color-primary); color: #fff; border-color: var(--color-primary); }
    .live-offline { margin: 0 0 10px; padding: 8px 12px; border-radius: 10px; font-size: 13px; font-weight: 600; background: var(--color-accent-soft); color: var(--color-warning); }
    .live-vehicle { display: block; width: 22px; height: 22px; border-radius: 50%; background: var(--color-accent); border: 3px solid #fff; box-shadow: 0 2px 8px rgb(0 0 0 / 35%); }
    .live-vehicle-wrap { background: none; border: 0; }
    @media (max-width: 640px) { .live-map { height: 300px; } .live-steps li { font-size: 9.5px; } }
</style>
@endpush
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.orders.show', $order) }}">← Order</a><span class="eyebrow">S-18 · LOG-04</span><h1>Track delivery</h1><p>{{ $order->listing?->title }} · <span id="track-status">{{ __('tracking.steps.'.$delivery->status) }}</span></p></div></div>
@if (session('delivery_code'))<div class="by-note" style="margin-bottom:14px"><b>Handover code: {{ session('delivery_code') }}</b> — shown only once. Give it to the driver only when the goods have arrived (BR-09).</div>@endif
<div class="by-split">
    <section class="panel">
        <ol class="live-steps" id="track-steps" aria-label="{{ __('tracking.steps_label') }}">
            @php($flow = \App\Models\Delivery::FLOW)
            @php($idx = array_search($delivery->status, $flow, true))
            @php($idx = $idx === false ? -1 : $idx)
            @foreach ($flow as $i => $stepKey)
                <li data-step="{{ $stepKey }}" class="{{ $i < $idx ? 'done' : ($i === $idx ? 'now' : '') }}" @if ($i === $idx) aria-current="step" @endif>{{ __('tracking.steps.'.$stepKey) }}</li>
            @endforeach
        </ol>
        <div class="live-offline" id="live-offline" role="status" aria-live="polite" hidden></div>
        <div id="live-map" class="live-map" role="region" aria-label="{{ __('tracking.map_label') }}"
             data-config="{{ json_encode([
                'uuid' => $delivery->uuid,
                'pickup' => [(float) $delivery->pickup_lat, (float) $delivery->pickup_lng],
                'drop' => [(float) $delivery->drop_lat, (float) $delivery->drop_lng],
                'points' => $pts->map(fn ($p) => [(float) $p->lat, (float) $p->lng])->values()->all(),
                'realtime' => config('neas.realtime'),
                'text' => [
                    'pickup' => __('tracking.pickup'), 'drop' => __('tracking.drop'), 'vehicle' => __('tracking.vehicle'),
                    'offline' => __('tracking.offline'), 'unavailable' => __('tracking.unavailable'),
                    'lastUpdate' => __('tracking.last_update', ['time' => ':time']), 'steps' => __('tracking.steps'),
                ],
             ], JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT) }}"></div>
        <p class="compact-copy" style="margin-top:8px" id="live-last">{{ $pts->isEmpty() ? __('tracking.no_points') : __('tracking.last_update', ['time' => \Illuminate\Support\Carbon::parse($pts->last()->recorded_at)->diffForHumans()]).' · '.$pts->count() }}</p>
    </section>
    <aside class="by-stack">
        <section class="panel"><span class="eyebrow">TRIP</span>
            <dl class="by-kv" style="margin-top:8px"><dt>Transporter</dt><dd>{{ $delivery->transporter?->name ?? 'Pending' }}</dd><dt>Vehicle</dt><dd>{{ $delivery->vehicle ? $delivery->vehicle->type.' · '.$delivery->vehicle->plate : '—' }}</dd><dt>Price</dt><dd>{{ \App\Support\Money::tzs($delivery->price_minor) }}</dd><dt>Status</dt><dd>{{ ucfirst(str_replace('_', ' ', $delivery->status)) }}</dd></dl>
            <form method="post" action="{{ route('buyer.chat.start') }}" style="margin-top:12px">@csrf<input type="hidden" name="order" value="{{ $order->uuid }}"><button class="button button-outline button-small">Message</button></form></section>
        @if ($simulate)<section class="by-demo"><b>Demo mode</b><form method="post" action="{{ route('buyer.orders.simulate', $order) }}" style="margin-top:8px">@csrf<input type="hidden" name="action" value="track"><button class="button button-tiny button-outline">Add GPS point</button></form></section>@endif
    </aside>
</div>
@endsection
