@extends('buyer.layout')
@section('title', 'Favourites')
@section('buyer')
<div class="workspace-heading"><div><a class="back-link" href="{{ route('buyer.dashboard') }}">← Overview</a><span class="eyebrow">MKT-11</span><h1>Favourites</h1><p>Listings you saved to come back to.</p></div></div>
@if ($items->isEmpty())
    <section class="panel"><div class="empty-state"><span class="empty-mark">☆</span><h3>No favourites yet</h3><p>Tap “Save” on any listing to keep it here.</p><a class="button button-primary button-small" href="{{ route('buyer.market') }}">Find produce</a></div></section>
@else
<div class="by-grid">
    @foreach ($items as $fav)@php($l = $fav->listing)
        <article class="by-card"><h3>{{ $l->title }}</h3><div class="by-price">{{ \App\Support\Money::tzs($l->price_minor, $l->currency) }}</div>
            <p>{{ $l->owner?->name }} · {{ $l->region?->name }} · {{ $l->status === 'active' ? 'Available' : 'Not available' }}</p>
            <div class="by-row"><a class="button button-primary button-small" href="{{ route('buyer.listing', $l) }}">View</a>
            <form method="post" action="{{ route('buyer.favourite', $l) }}">@csrf<button class="button button-danger-quiet button-small">Remove</button></form></div></article>
    @endforeach
</div>
@endif
@endsection
