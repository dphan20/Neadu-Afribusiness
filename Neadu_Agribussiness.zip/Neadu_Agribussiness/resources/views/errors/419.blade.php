@extends('errors.layout')

@section('code', '419')
@section('title_en', 'Page expired')
@section('msg_en', 'Your session ran out before the form was sent. Go back, reload the page and try again. Nothing was changed.')
@section('title_sw', 'Muda wa ukurasa umekwisha')
@section('msg_sw', 'Kikao chako kiliisha kabla ya fomu kutumwa. Rudi nyuma, pakia upya ukurasa kisha ujaribu tena. Hakuna kilichobadilishwa.')
@section('actions')<a class="btn" href="{{ url()->previous() }}">Try again · Jaribu tena</a>@endsection
