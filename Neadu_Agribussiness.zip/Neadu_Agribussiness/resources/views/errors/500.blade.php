@extends('errors.layout')

@section('code', '500')
@section('title_en', 'Something went wrong')
@section('msg_en', 'Our system hit an unexpected problem. It is not your fault. Please try again in a few minutes.')
@section('title_sw', 'Kuna hitilafu')
@section('msg_sw', 'Mfumo wetu umekumbwa na tatizo lisilotarajiwa. Si kosa lako. Tafadhali jaribu tena baada ya dakika chache.')

