@extends('errors.layout')

@section('code', '404')
@section('title_en', 'Page not found')
@section('msg_en', 'We could not find the page you asked for. The link may be old, or the address may have a typing mistake.')
@section('title_sw', 'Ukurasa haupatikani')
@section('msg_sw', 'Hatukuweza kupata ukurasa uliouomba. Kiungo kinaweza kuwa cha zamani au anwani ina kosa la kuandika.')
@section('actions')<a class="btn" href="{{ url('/dashboard') }}">My workspace · Eneo langu</a>@endsection
