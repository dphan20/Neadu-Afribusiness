@extends('errors.layout')

@section('code', '403')
@section('title_en', 'Access denied')
@section('msg_en', 'You do not have permission to open this page. If you think this is a mistake, sign in with the right account.')
@section('title_sw', 'Huruhusiwi kuingia')
@section('msg_sw', 'Huna ruhusa ya kufungua ukurasa huu. Ikiwa unaona ni kosa, ingia kwa akaunti sahihi.')
@section('actions')<a class="btn" href="{{ url('/login') }}">Sign in · Ingia</a>@endsection
