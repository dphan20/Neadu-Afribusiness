@extends('errors.layout')

@section('code', '503')
@section('title_en', 'Back soon')
@section('msg_en', 'NeAS is being updated or is briefly unavailable. Please try again shortly.')
@section('title_sw', 'Tunarudi hivi karibuni')
@section('msg_sw', 'NeAS inasasishwa au haipatikani kwa muda mfupi. Tafadhali jaribu tena baadaye kidogo.')

