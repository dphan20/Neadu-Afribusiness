<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <meta name="color-scheme" content="light dark">
    <meta name="theme-color" content="#1B6B3A">
    <title>@yield('code') · @yield('title_en') · NeAS</title>
    @include('layouts.partials.icons')
    {{-- Self-contained on purpose: error pages must still render when the database, session or build files are down. --}}
    <style>
        :root { --bg: #F7F8F4; --card: #FFFFFF; --text: #1C2A1F; --muted: #4F5F53; --primary: #1B6B3A; --border: #E4E9E1; --on-primary: #FFFFFF; }
        @media (prefers-color-scheme: dark) { :root { --bg: #0F1A13; --card: #16231B; --text: #EAF1EB; --muted: #B3C2B7; --primary: #66BB6A; --border: #2A3B30; --on-primary: #0F1A13; } }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; background: var(--bg); color: var(--text); font: 16px/1.6 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
        main { width: 100%; max-width: 560px; padding: clamp(24px, 5vw, 44px); border: 1px solid var(--border); border-radius: 20px; background: var(--card); text-align: center; }
        .mark { display: inline-grid; place-items: center; width: 48px; height: 48px; border-radius: 14px; background: #1B6B3A; color: #fff; font-weight: 800; font-size: 22px; }
        .code { margin: 18px 0 0; color: var(--primary); font-size: clamp(56px, 14vw, 88px); font-weight: 800; line-height: 1; letter-spacing: -.02em; }
        h1 { margin: 10px 0 8px; font-size: clamp(22px, 4vw, 28px); line-height: 1.25; }
        p { margin: 0 0 6px; color: var(--muted); }
        .sw { margin-top: 18px; padding-top: 18px; border-top: 1px solid var(--border); }
        .sw h2 { margin: 0 0 6px; font-size: 19px; }
        .actions { display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; margin-top: 26px; }
        .btn { display: inline-block; padding: 12px 22px; border: 2px solid var(--primary); border-radius: 12px; font-weight: 700; text-decoration: none; color: var(--primary); }
        .btn-primary { background: var(--primary); color: var(--on-primary); }
        .btn:focus-visible { outline: 3px solid #F2A900; outline-offset: 3px; }
    </style>
</head>
<body>
    <main role="main">
        <span class="mark" aria-hidden="true">N</span>
        <p class="code" aria-hidden="true">@yield('code')</p>
        <h1>@yield('title_en')</h1>
        <p>@yield('msg_en')</p>
        <div class="sw" lang="sw">
            <h2>@yield('title_sw')</h2>
            <p>@yield('msg_sw')</p>
        </div>
        <div class="actions">
            @yield('actions')
            <a class="btn btn-primary" href="{{ url('/') }}">Home · Mwanzo</a>
        </div>
    </main>
</body>
</html>
