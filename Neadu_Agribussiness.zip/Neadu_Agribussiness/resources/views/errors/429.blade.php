@extends('errors.layout')

@section('code', '429')
@section('title_en', 'Too many requests')
@section('msg_en', 'You are going a little too fast. Please wait a minute and try again.')
@section('title_sw', 'Maombi mengi mno')
@section('msg_sw', 'Unaenda kwa kasi kidogo. Tafadhali subiri dakika moja kisha ujaribu tena.')
@section('actions')<a class="btn" href="{{ url()->current() }}">Try again · Jaribu tena</a>@endsection
