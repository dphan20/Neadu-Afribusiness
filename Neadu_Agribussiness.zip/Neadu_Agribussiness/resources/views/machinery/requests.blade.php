@extends('producer.layout')
@section('title', 'My quote requests')
@section('heading', 'My quote requests')
@section('lead', 'Prices, financing and rental answers from sellers.')
@section('head-action')<a class="button button-primary" href="{{ route('machinery.index') }}">Find machinery</a>@endsection
@section('body')
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
@forelse($quotes as $r)
<div class="p-card"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><b>{{ $r->listing?->title }} × {{ $r->quantity }}</b><span class="p-tag">{{ ucfirst($r->status) }}</span></div>
<p class="p-muted">{{ $r->reference() }} · {{ ucfirst($r->kind) }}@if($r->months) for {{ $r->months }} months @endif · to {{ $r->listing?->owner?->name }} · {{ $r->created_at?->format('d-m-Y') }}</p>
@if($r->status==='quoted')<p>Quoted <b>TSh {{ number_format($r->quoted_minor/100) }}</b>, valid until {{ $r->valid_until?->format('d-m-Y') }}@if($r->reply)<br>{{ $r->reply }}@endif</p>@endif
@if($r->status==='declined')<p class="p-muted">Declined: {{ $r->decline_reason }}</p>@endif
<div class="p-actions">
@if($r->listing && ! $r->listing->trashed() && $r->listing->status==='active')<a class="button button-outline button-small" href="{{ route('machinery.show',$r->listing) }}">View machine</a>@endif
@if($r->status==='quoted')<a class="button button-outline button-small" href="{{ route('machinery.quotes.document',$r) }}" target="_blank" rel="noopener">Quotation (PDF)</a>@endif
@if($r->listing && ! $r->listing->trashed())<form method="post" action="{{ route('me.chat.listing',$r->listing) }}">@csrf<button class="button button-outline button-small">Message seller</button></form>@endif
@if(in_array($r->status,['open','quoted'],true))<form method="post" action="{{ route('machinery.requests.withdraw',$r) }}">@csrf<button class="button button-danger-quiet button-small">Withdraw</button></form>@endif</div></div>
@empty<div class="p-card"><b>No requests yet.</b><p class="p-muted">Open a machine and choose Ask the seller.</p></div>@endforelse
{{ $quotes->onEachSide(1)->links() }}
@endsection
