@extends('producer.layout')
@section('title', $listing->title)
@section('heading', $listing->title)
@section('lead', 'TSh '.number_format($listing->price_minor/100).' · '.($listing->region?->name ?? ''))
@section('head-action')<a class="button button-outline" href="{{ route('machinery.sheet',$listing) }}" target="_blank" rel="noopener">Spec sheet (PDF)</a>@endsection
@section('body')
@php($T = \App\Http\Controllers\Trader\TraderController::class)
@if(session('status'))<div class="flash" role="status">{{ session('status') }}</div>@endif
@if($errors->any())<div class="flash flash-error" role="alert">{{ $errors->first() }}</div>@endif
@if($listing->status!=='active')<div class="flash">Only you can see this: the listing is {{ str_replace('_',' ',$listing->status) }}.</div>@endif
@if($listing->photos)<div style="display:flex;gap:10px;flex-wrap:wrap">@foreach($listing->photos as $p)<img src="{{ asset('storage/'.$p) }}" alt="{{ $listing->title }}" style="height:170px;border-radius:12px;object-fit:cover" loading="lazy">@endforeach</div>@endif
<div class="p-card"><p><b>{{ $T::CATEGORIES[$machine->category] ?? 'Equipment' }}</b> · {{ $T::CONDITIONS[$machine->machine_condition] ?? '' }}@if($machine->brand) · {{ $machine->brand }} {{ $machine->model }}@endif @if($machine->year) · {{ $machine->year }}@endif · {{ $machine->stock }} in stock @if($machine->warranty) · Warranty: {{ $machine->warranty }}@endif</p>
@if($machine->description)<p style="white-space:pre-wrap">{{ $machine->description }}</p>@endif
@if($machine->specs)<table class="p-table" style="width:100%"><tbody>@foreach($machine->specs as $s)<tr><th style="text-align:left;width:40%">{{ $s['k'] }}</th><td>{{ $s['v'] }}</td></tr>@endforeach</tbody></table>@endif
@if($machine->brochure_path)<p><a href="{{ asset('storage/'.$machine->brochure_path) }}" target="_blank" rel="noopener">Download the brochure (PDF)</a></p>@endif
@if(in_array('rental',$machine->offers ?? [],true) && $machine->rental_rate_minor)<p>Rental from TSh {{ number_format($machine->rental_rate_minor/100) }} per day.</p>@endif</div>
<div class="p-card"><b>Sold by {{ $seller->business['name'] ?? $listing->owner?->name }}</b>
@if($seller)<p class="p-muted">{{ $seller->business['about'] ?? '' }}<br>@if(!empty($seller->business['services']))Services: {{ implode(', ', array_map(fn($s)=>$T::SERVICES[$s] ?? $s, $seller->business['services'])) }}<br>@endif @if(!empty($seller->business['address'])){{ $seller->business['address'] }}<br>@endif @if(!empty($seller->business['phone']))Phone: {{ $seller->business['phone'] }}@endif @if(!empty($seller->business['hours'])) · {{ $seller->business['hours'] }}@endif</p>@endif
@unless($isOwner)<form method="post" action="{{ route('me.chat.listing',$listing) }}">@csrf<button class="button button-outline button-small">Message the seller</button></form>@endunless</div>
@unless($isOwner)
@if($listing->status==='active')
<form class="p-card pf" method="post" action="{{ route('machinery.request',$listing) }}">@csrf
<b>Ask the seller</b>
<div class="row"><div><label for="kind">What do you need?</label><select id="kind" name="kind">@foreach(['quote'=>['Price quotation','sale'],'financing'=>['Financing / pay in instalments','financing'],'rental'=>['Rental','rental']] as $k=>[$label,$need])@continue(! in_array($need, $machine->offers ?? ['sale'], true) || ($k==='financing' && ! $financing) || ($k==='rental' && ! $rental))<option value="{{ $k }}" @selected(old('kind')===$k)>{{ $label }}</option>@endforeach</select></div>
<div><label for="quantity">Quantity</label><input id="quantity" name="quantity" type="number" min="1" max="100" value="{{ old('quantity',1) }}" required></div>
<div><label for="months">Months (financing or rental)</label><input id="months" name="months" type="number" min="1" max="60" value="{{ old('months') }}"></div></div>
<label for="message">Message (optional)</label><textarea id="message" name="message" maxlength="500" placeholder="Where it will be used, when you need it.">{{ old('message') }}</textarea>
<div class="p-actions"><button class="button button-primary">Send request</button></div></form>
@endif
@if($mine->isNotEmpty())<div class="p-card"><b>Your requests for this machine</b>@foreach($mine as $q)<p class="p-muted">{{ ucfirst($q->kind) }} · {{ $q->created_at?->format('d-m-Y') }} · {{ ucfirst($q->status) }}@if($q->status==='quoted') · TSh {{ number_format($q->quoted_minor/100) }}@endif</p>@endforeach<a href="{{ route('machinery.requests') }}">See all my requests</a></div>@endif
@endunless
@endsection
