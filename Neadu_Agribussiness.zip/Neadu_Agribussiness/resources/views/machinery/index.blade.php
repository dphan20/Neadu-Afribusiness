@extends('producer.layout')
@section('title', 'Machinery market')
@section('heading', 'Machinery and technology')
@section('lead', 'Find tractors, pumps, dryers, sensors and software from traders across Tanzania. Ask for a price, financing or rental.')
@section('head-action')<a class="button button-outline" href="{{ route('machinery.requests') }}">My quote requests</a>@endsection
@section('body')
@php($T = \App\Http\Controllers\Trader\TraderController::class)
<form class="p-card" method="get" action="{{ route('machinery.index') }}" style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">
<div><label for="q">Search</label><input id="q" name="q" value="{{ $q }}" placeholder="Name, brand or model"></div>
<div><label for="category">Type</label><select id="category" name="category"><option value="">All</option>@foreach($T::CATEGORIES as $k=>$v)<option value="{{ $k }}" @selected($category===$k)>{{ $v }}</option>@endforeach</select></div>
<div><label for="condition">Condition</label><select id="condition" name="condition"><option value="">Any</option>@foreach($T::CONDITIONS as $k=>$v)<option value="{{ $k }}" @selected($condition===$k)>{{ $v }}</option>@endforeach</select></div>
<div><label for="offer">Offer</label><select id="offer" name="offer"><option value="">Any</option>@foreach($T::OFFERS as $k=>$v)<option value="{{ $k }}" @selected($offer===$k)>{{ $v }}</option>@endforeach</select></div>
<div><label for="region">Region</label><select id="region" name="region"><option value="0">All</option>@foreach($regions as $r)<option value="{{ $r->id }}" @selected($region===$r->id)>{{ $r->name }}</option>@endforeach</select></div>
<button class="button button-outline">Search</button></form>
@forelse($machines as $m)
@php($mc = $m->machine)
<a class="p-card" href="{{ route('machinery.show',$m) }}" style="display:flex;gap:14px;text-decoration:none;color:inherit">
@if($m->photos)<img src="{{ asset('storage/'.$m->photos[0]) }}" alt="" style="width:120px;height:90px;object-fit:cover;border-radius:10px" loading="lazy">@endif
<span><b>{{ $m->title }}</b><br><span class="p-muted">{{ $T::CATEGORIES[$mc?->category] ?? 'Equipment' }} · {{ $T::CONDITIONS[$mc?->machine_condition] ?? '' }} · {{ $m->region?->name }}</span><br>TSh {{ number_format($m->price_minor/100) }} · {{ $m->owner?->name }}</span></a>
@empty<div class="p-card"><b>Nothing matches.</b><p class="p-muted">Try fewer filters. New machinery is added by traders every day.</p></div>@endforelse
{{ $machines->onEachSide(1)->links() }}
@endsection
