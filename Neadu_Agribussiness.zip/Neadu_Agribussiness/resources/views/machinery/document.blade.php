<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Quotation {{ $quote->reference() }}</title>
<style>body{font-family:Arial,Helvetica,sans-serif;color:#17231b;max-width:780px;margin:24px auto;padding:0 18px}.bar{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #1f7a3d;padding-bottom:10px;margin-bottom:16px}table{border-collapse:collapse;width:100%;margin:14px 0}th,td{border:1px solid #dde;padding:9px;text-align:left;font-size:14px}th{background:#f2f7f3}.right{text-align:right}.muted{color:#566;font-size:13px}button{padding:8px 14px;border:0;background:#1f7a3d;color:#fff;border-radius:8px;cursor:pointer}@media print{button{display:none}body{margin:0}}</style></head><body>
<div class="bar"><b>NeAS · Nendu Agribusiness System</b><button type="button" onclick="window.print()">Print or save as PDF</button></div>
<h1 style="margin:0">Quotation {{ $quote->reference() }}</h1>
<p class="muted">Issued {{ $quote->replied_at?->format('d-m-Y') }} · Valid until <b>{{ $quote->valid_until?->format('d-m-Y') }}</b></p>
<table><tr><th>Seller</th><th>Buyer</th></tr><tr>
<td><b>{{ $seller->business['name'] ?? $quote->listing->owner?->name }}</b>@if(!empty($seller->business['phone']))<br>{{ $seller->business['phone'] }}@endif @if(!empty($seller->business['email']))<br>{{ $seller->business['email'] }}@endif @if(!empty($seller->business['address']))<br>{{ $seller->business['address'] }}@endif</td>
<td><b>{{ $quote->user?->name }}</b><br>{{ $quote->user?->phone }}</td></tr></table>
<table><tr><th>Item</th><th>Request</th><th class="right">Quantity</th><th class="right">Total (TSh)</th></tr>
<tr><td>{{ $quote->listing->title }}@if($quote->listing->machine?->brand)<br><span class="muted">{{ $quote->listing->machine->brand }} {{ $quote->listing->machine->model }}</span>@endif</td><td>{{ ucfirst($quote->kind) }}@if($quote->months), {{ $quote->months }} months @endif</td><td class="right">{{ $quote->quantity }}</td><td class="right"><b>{{ number_format($quote->quoted_minor/100) }}</b></td></tr></table>
@if($quote->reply)<p><b>Notes from the seller</b><br>{{ $quote->reply }}</p>@endif
<p class="muted">This quotation is an offer from the seller and is not a payment or an order. To buy, agree the details with the seller. Prices in Tanzanian shillings.</p>
</body></html>
