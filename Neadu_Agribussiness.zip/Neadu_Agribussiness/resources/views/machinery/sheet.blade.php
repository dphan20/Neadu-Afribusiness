<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{{ $listing->title }} - specification sheet</title>
<style>body{font-family:Arial,Helvetica,sans-serif;color:#17231b;max-width:820px;margin:24px auto;padding:0 18px}h1{margin:0 0 4px}.muted{color:#566;font-size:14px}table{border-collapse:collapse;width:100%;margin:12px 0}th,td{border-bottom:1px solid #dde;padding:8px;text-align:left;font-size:14px}th{width:38%}.photos img{height:150px;margin:0 8px 8px 0;border-radius:8px;object-fit:cover}.bar{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #1f7a3d;padding-bottom:10px;margin-bottom:14px}button{padding:8px 14px;border:0;background:#1f7a3d;color:#fff;border-radius:8px;cursor:pointer}@media print{button{display:none}body{margin:0}}</style></head><body>
@php($T = \App\Http\Controllers\Trader\TraderController::class)
<div class="bar"><b>NeAS · Nendu Agribusiness System</b><button type="button" onclick="window.print()">Print or save as PDF</button></div>
<h1>{{ $listing->title }}</h1>
<p class="muted">{{ $T::CATEGORIES[$machine->category] ?? 'Equipment' }} · {{ $T::CONDITIONS[$machine->machine_condition] ?? '' }} · {{ $listing->region?->name }}@if($listing->district), {{ $listing->district->name }}@endif</p>
<p><b>Price: TSh {{ number_format($listing->price_minor/100) }}</b> · {{ $machine->stock }} in stock @if(in_array('rental',$machine->offers ?? [],true) && $machine->rental_rate_minor) · Rental TSh {{ number_format($machine->rental_rate_minor/100) }} per day @endif</p>
@if($listing->photos)<div class="photos">@foreach(array_slice($listing->photos,0,3) as $p)<img src="{{ asset('storage/'.$p) }}" alt="">@endforeach</div>@endif
<table><tbody>
@if($machine->brand)<tr><th>Brand and model</th><td>{{ $machine->brand }} {{ $machine->model }}</td></tr>@endif
@if($machine->year)<tr><th>Year</th><td>{{ $machine->year }}</td></tr>@endif
@if($machine->warranty)<tr><th>Warranty</th><td>{{ $machine->warranty }}</td></tr>@endif
@foreach($machine->specs ?? [] as $s)<tr><th>{{ $s['k'] }}</th><td>{{ $s['v'] }}</td></tr>@endforeach
</tbody></table>
@if($machine->description)<p style="white-space:pre-wrap">{{ $machine->description }}</p>@endif
<p class="muted"><b>{{ $seller->business['name'] ?? $listing->owner?->name }}</b>@if(!empty($seller->business['phone'])) · {{ $seller->business['phone'] }}@endif @if(!empty($seller->business['email'])) · {{ $seller->business['email'] }}@endif @if(!empty($seller->business['address'])) · {{ $seller->business['address'] }}@endif<br>Generated {{ now()->format('d-m-Y') }}. Price and availability can change; confirm with the seller.</p>
</body></html>
