@extends('layouts.app')

@section('title', 'Create an account')

@section('content')
<main class="auth-shell auth-shell-register">
    <section class="auth-intro">
        <span class="eyebrow">JOIN THE NETWORK</span>
        <h1>One account.<br>Room to grow.</h1>
        <p>Choose the roles that fit your work. NeAS will create a separate workspace for each role you choose.</p>
        <div class="auth-points"><span>✓ Sign up with email or phone</span><span>✓ Choose more than one role</span><span>✓ Switch workspaces any time</span></div>
    </section>
    <section class="auth-card">
        <div class="auth-card-heading"><span class="brand-mark">N</span><div><h2>Create account</h2><p>Start with your details and work roles</p></div></div>
        <form method="post" action="{{ route('register.store') }}" class="form-stack">
            @csrf
            <label for="name">Full name</label>
            <input id="name" name="name" value="{{ old('name') }}" autocomplete="name" required>
            @error('name')<span class="field-error">{{ $message }}</span>@enderror

            <label for="email">Email address <span class="label-hint">email or phone, at least one</span></label>
            <input id="email" name="email" type="email" value="{{ old('email') }}" placeholder="you@example.com" autocomplete="email">
            @error('email')<span class="field-error">{{ $message }}</span>@enderror

            <label for="phone">Mobile phone number <span class="label-hint">optional if you gave an email</span></label>
            <input id="phone" name="phone" type="tel" value="{{ old('phone') }}" placeholder="0712 345 678 or +255 712 345 678" autocomplete="tel">
            @error('phone')<span class="field-error">{{ $message }}</span>@enderror

            <label for="pin">Password <span class="label-hint">at least 8 characters</span></label>
            <input id="pin" name="pin" type="password" autocomplete="new-password" minlength="8" maxlength="64" required>
            @error('pin')<span class="field-error">{{ $message }}</span>@enderror

            <label for="pin_confirmation">Confirm password</label>
            <input id="pin_confirmation" name="pin_confirmation" type="password" autocomplete="new-password" minlength="8" maxlength="64" required>

            <label for="role-dd-button">Your roles <span class="label-hint">select all that apply</span></label>
            <details class="role-dd" id="role-dd">
                <summary id="role-dd-button"><span data-role-summary class="is-empty">Select your roles</span></summary>
                <div class="role-dd-panel">
                    @foreach ($roles as $role)
                        @continue($role === \App\Enums\UserRole::Admin)
                        <label class="role-dd-option">
                            <input type="checkbox" name="roles[]" value="{{ $role->value }}" @checked(in_array($role->value, old('roles', []), true))>
                            <span><b>{{ $role->label() }}</b><small>{{ $role->swahiliLabel() }}</small></span>
                        </label>
                    @endforeach
                </div>
            </details>
            @error('roles')<span class="field-error">{{ $message }}</span>@enderror
            @error('roles.*')<span class="field-error">{{ $message }}</span>@enderror

            <button class="button button-primary button-full" type="submit">Create my account <span aria-hidden="true">→</span></button>
        </form>
        <p class="auth-footnote">Already registered? <a href="{{ route('login') }}">Sign in</a></p>
    </section>
</main>
<script>
    (function () {
        var dd = document.getElementById('role-dd');
        if (!dd) { return; }
        var label = dd.querySelector('[data-role-summary]');
        var boxes = dd.querySelectorAll('input[type="checkbox"]');

        function refresh() {
            var names = [];
            boxes.forEach(function (box) {
                if (box.checked) { names.push(box.parentElement.querySelector('b').textContent.trim()); }
            });
            label.textContent = names.length ? names.join(', ') : 'Select your roles';
            label.classList.toggle('is-empty', names.length === 0);
        }

        boxes.forEach(function (box) { box.addEventListener('change', refresh); });
        document.addEventListener('click', function (event) { if (!dd.contains(event.target)) { dd.removeAttribute('open'); } });
        document.addEventListener('keydown', function (event) { if (event.key === 'Escape') { dd.removeAttribute('open'); } });
        dd.closest('form').addEventListener('submit', function (event) {
            var any = false;
            boxes.forEach(function (box) { if (box.checked) { any = true; } });
            if (!any) { event.preventDefault(); dd.setAttribute('open', ''); label.textContent = 'Please select at least one role'; }
        });
        refresh();
    })();
</script>
@endsection
