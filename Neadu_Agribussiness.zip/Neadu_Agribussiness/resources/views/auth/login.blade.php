@extends('layouts.app')

@section('title', 'Sign in')

@section('content')
<main class="auth-shell">
    <section class="auth-intro">
        <span class="eyebrow">WELCOME BACK</span>
        <h1>Your work,<br>moving forward.</h1>
        <p>Sign in with the email or phone number linked to your NeAS account. Your available workspaces appear after sign-in.</p>
        <div class="auth-points"><span>✓ Role-based workspace</span><span>✓ Secure session</span><span>✓ One account, multiple roles</span></div>
    </section>
    <section class="auth-card">
        <div class="auth-card-heading"><span class="brand-mark">N</span><div><h2>Sign in</h2><p>Access your NeAS workspace</p></div></div>
        <form method="post" action="{{ route('login.store') }}" class="form-stack">
            @csrf
            <label for="login">Email or phone number</label>
            <input id="login" name="login" type="text" value="{{ old('login') }}" placeholder="you@example.com or 0712 345 678" autocomplete="username" required>
            @error('login')<span class="field-error">{{ $message }}</span>@enderror
            <label for="pin">Password</label>
            <input id="pin" name="pin" type="password" autocomplete="current-password" placeholder="Enter your password" required>
            @error('pin')<span class="field-error">{{ $message }}</span>@enderror
            <button class="button button-primary button-full" type="submit">Sign in securely <span aria-hidden="true">→</span></button>
        </form>
        <p class="auth-footnote">New to NeAS? <a href="{{ route('register') }}">Create your account</a></p>
    </section>
</main>
@endsection
