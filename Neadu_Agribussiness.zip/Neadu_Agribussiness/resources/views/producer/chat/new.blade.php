@extends('producer.layout')
@section('title', __('chat.new_message'))
@section('heading', __('chat.new_message'))
@section('lead', __('chat.new_lead'))
@section('body')
@include('partials.chat-compose-body', ['area' => 'me'])
@endsection
