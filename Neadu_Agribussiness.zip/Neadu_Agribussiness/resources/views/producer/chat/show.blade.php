@extends('producer.layout')
@section('title', 'Chat')
@section('heading', $conversation->participants->where('id','!=',auth()->id())->pluck('name')->implode(', '))
@section('lead', $conversation->order?->listing?->title ?? 'Expert advice')
@section('body')
@include('partials.chat-toolbar', ['area' => 'me', 'conversation' => $conversation])
<div class="p-card">
@foreach($messages as $m)@include('partials.chat-bubble', ['m' => $m, 'bubble' => 'p-msg', 'area' => 'me'])@endforeach
<span id="latest"></span>
</div>
<form class="p-card pf" method="post" enctype="multipart/form-data" action="{{ route('me.chat.send',$conversation) }}">@csrf
<label for="body">Message</label><input id="body" name="body" maxlength="2000">
<input id="voice" name="voice" type="file" accept="audio/*" hidden>
<div class="p-actions"><button class="button button-primary">Send</button><button type="button" id="rec" class="button button-outline">🎤 Record voice note</button><input name="photo" type="file" accept="image/*" capture="environment"></div></form>
<script>
const rec=document.getElementById('rec'),vf=document.getElementById('voice');let mr,chunks=[];
rec.addEventListener('click',async()=>{
 if(mr&&mr.state==='recording'){mr.stop();return}
 try{const s=await navigator.mediaDevices.getUserMedia({audio:true});mr=new MediaRecorder(s);chunks=[];
  mr.ondataavailable=e=>chunks.push(e.data);
  mr.onstop=()=>{s.getTracks().forEach(t=>t.stop());const f=new File(chunks,'voice.webm',{type:'audio/webm'});const dt=new DataTransfer();dt.items.add(f);vf.files=dt.files;rec.textContent='✓ Voice note ready, press Send'};
  mr.start();rec.textContent='■ Stop recording'}catch(e){rec.textContent='Microphone not available'}
});
</script>
@endsection
