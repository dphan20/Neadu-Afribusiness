@extends('producer.layout')
@section('title', __('chat.forward_title'))
@section('heading', __('chat.forward_title'))
@section('lead', '')
@section('body')
@include('partials.chat-forward-body', ['area' => 'me'])
@endsection
