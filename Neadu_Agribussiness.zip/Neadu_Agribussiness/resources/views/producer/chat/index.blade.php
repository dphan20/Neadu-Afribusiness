@extends('producer.layout')
@section('title', 'Messages')
@section('heading', 'Messages')
@section('lead', 'Chats with buyers and experts.')
@section('body')
<p><a class="button button-primary button-small" href="{{ route('me.chat.new') }}">✉ {{ __('chat.new_message') }}</a></p>
@forelse($conversations as $c)@php($other = $c->participants->where('id','!=',auth()->id())->pluck('name')->implode(', '))
<a class="p-card" style="display:block" href="{{ route('me.chat.show',$c) }}"><b>{{ $other ?: 'Conversation' }}</b><p class="p-muted">{{ $c->order?->listing?->title ?? 'Expert advice' }}</p></a>
@empty<div class="p-card">No conversations yet.</div>@endforelse
@endsection
