@extends('producer.layout')
@section('title', 'Book delivery')
@section('heading', 'Book delivery')
@section('lead', 'We suggest a price from the distance and weight. You can change it.')
@section('body')
@php($pre = \App\Support\RoleNav::activeRole()->value === 'B' ? 'buyer' : 'producer')
<form class="p-card pf" method="post" action="{{ route($pre.'.delivery.store',$order) }}">@csrf
<p class="p-muted">Load: {{ $kg ? $kg.' kg' : 'not measured in kg' }} · Pickup: {{ $order->listing?->lat ? $order->listing->lat.', '.$order->listing->lng : 'enter below' }}</p>
<div class="row">
 <div><label for="drop_lat">Drop-off latitude *</label><input id="drop_lat" name="drop_lat" value="{{ old('drop_lat') }}" required></div>
 <div><label for="drop_lng">Drop-off longitude *</label><input id="drop_lng" name="drop_lng" value="{{ old('drop_lng') }}" required></div>
</div>
@unless($order->listing?->lat)<div class="row"><div><label for="pickup_lat">Pickup latitude *</label><input id="pickup_lat" name="pickup_lat" value="{{ old('pickup_lat') }}"></div><div><label for="pickup_lng">Pickup longitude *</label><input id="pickup_lng" name="pickup_lng" value="{{ old('pickup_lng') }}"></div></div>@endunless
<p id="quote" class="p-tag" hidden></p>
<label for="price">Your price (TSh) — leave empty to use the suggestion</label><input id="price" name="price" inputmode="decimal">
<label for="transporter_id">Transporter</label>
<select id="transporter_id" name="transporter_id"><option value="">Any available transporter (open job)</option>
@foreach ($transporters as $t)<option value="{{ $t['user']->id }}">{{ $t['user']->name }} — {{ $t['vehicle']->type }}, {{ number_format($t['vehicle']->capacity_kg) }} kg{{ $t['rating'] ? ' · ★ '.$t['rating'] : '' }}</option>@endforeach</select>
<div class="p-actions"><button class="button button-primary">Book delivery</button></div>
</form>
<script>
const q=document.getElementById('quote');let t;
function ask(){const p=new URLSearchParams({drop_lat:drop_lat.value,drop_lng:drop_lng.value});
 if(window.pickup_lat&&pickup_lat.value){p.set('pickup_lat',pickup_lat.value);p.set('pickup_lng',pickup_lng.value)}
 fetch('{{ route($pre.'.delivery.quote',$order) }}?'+p,{headers:{Accept:'application/json'}}).then(r=>r.ok?r.json():null).then(j=>{if(j){q.hidden=false;q.textContent='Suggested: '+j.price+' for '+j.distance_km+' km'}})}
['drop_lat','drop_lng'].forEach(i=>document.getElementById(i).addEventListener('input',()=>{clearTimeout(t);t=setTimeout(ask,500)}));
</script>
@endsection
