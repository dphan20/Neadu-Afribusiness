@extends('producer.layout')
@section('title', 'Delivery')
@section('heading', 'Delivery tracking')
@section('lead', $delivery->order->listing?->title)
@section('body')
<div class="p-card"><p>Status: <span class="p-tag" id="st">{{ ucfirst(str_replace('_',' ',$delivery->status)) }}</span> · Transporter: {{ $delivery->transporter?->name ?? 'open job, waiting for a transporter' }} · Price: TSh {{ number_format(intdiv($delivery->price_minor,100)) }} · {{ $delivery->distance_km }} km</p>
<iframe id="map" title="Live map" width="100%" height="360" style="border:0;border-radius:12px"></iframe>
<p class="p-muted" id="last">Waiting for the first location update…</p>
<a class="button button-quiet" href="{{ route(\App\Support\RoleNav::activeRole()->value === 'B' ? 'buyer.orders.show' : 'producer.orders.show',$delivery->order) }}">Back to order</a></div>
<script>
const map=document.getElementById('map');
function show(lat,lng){const d=.05;map.src='https://www.openstreetmap.org/export/embed.html?bbox='+[lng-d,lat-d,lng+d,lat+d].join(',')+'&layer=mapnik&marker='+lat+','+lng}
function poll(){fetch('{{ route('me.delivery.track',$delivery) }}',{headers:{Accept:'application/json'}}).then(r=>r.json()).then(j=>{
 document.getElementById('st').textContent=j.status.replace('_',' ');
 const p=j.latest||{lat:j.pickup[0],lng:j.pickup[1]};show(p.lat,p.lng);
 if(j.latest)document.getElementById('last').textContent='Last update '+new Date(j.points[j.points.length-1].at).toLocaleTimeString()}).catch(()=>{})}
poll();setInterval(poll,15000);
</script>
@endsection
