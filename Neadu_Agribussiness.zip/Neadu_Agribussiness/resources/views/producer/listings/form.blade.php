@extends('producer.layout')
@php($p = $listing?->produce)
@php($v = fn ($k, $d = null) => old($k, $d))
@section('title', $listing ? 'Edit listing' : 'New listing')
@section('heading', $listing ? 'Edit listing' : 'Create a listing')
@section('lead', 'Required fields are marked *. Extra details help you sell faster.')
@section('body')
<form class="p-card pf" method="post" enctype="multipart/form-data" action="{{ $listing ? route('producer.listings.update', $listing) : route('producer.listings.store') }}">
@csrf @if ($listing) @method('PUT') @endif
<div class="row">
 <div><label for="category">Category *</label><select id="category" name="category">@foreach ($categories as $c)<option value="{{ $c->value }}" @selected($v('category', $p?->category?->value ?? ($defaults['category'] ?? 'crop')) === $c->value)>{{ $c->label() }} ({{ $c->swahiliLabel() }})</option>@endforeach</select></div>
 <div><label for="crop_id">Product *</label><select id="crop_id" name="crop_id">@foreach ($crops as $c)<option value="{{ $c['id'] }}" data-cat="{{ $c['category'] }}" @selected($v('crop_id', $p?->crop_id) == $c['id'])>{{ $c['name'] }}</option>@endforeach</select></div>
</div>
<label for="title">Title (optional)</label><input id="title" name="title" value="{{ $v('title', $listing?->title) }}">
<div class="row">
 <div><label for="region_id">Region *</label><select id="region_id" name="region_id">@foreach ($regions as $r)<option value="{{ $r->id }}" @selected($v('region_id', $listing?->region_id ?? ($defaults['region_id'] ?? null)) == $r->id)>{{ $r->name }}</option>@endforeach</select></div>
 <div><label for="district_id">District *</label><select id="district_id" name="district_id">@foreach ($districts as $d)<option value="{{ $d->id }}" data-region="{{ $d->region_id }}" @selected($v('district_id', $listing?->district_id ?? ($defaults['district_id'] ?? null)) == $d->id)>{{ $d->name }}</option>@endforeach</select></div>
</div>
<div class="row">
 <div><label for="quantity">Quantity *</label><input id="quantity" name="quantity" type="number" step="0.001" min="0" value="{{ $v('quantity', $p ? \App\Support\Quantity::pretty($p->quantity) : '') }}"></div>
 <div><label for="unit_id">Unit *</label><select id="unit_id" name="unit_id">@foreach ($units as $u)<option value="{{ $u->id }}" @selected($v('unit_id', $p?->unit_id) == $u->id)>{{ $u->name_en }}</option>@endforeach</select></div>
 <div><label for="price">Price per unit (TSh) *</label><input id="price" name="price" inputmode="decimal" value="{{ $v('price', $listing ? number_format($listing->price_minor/100, 2, '.', '') : '') }}"></div>
 <div><label for="quality">Quality *</label><select id="quality" name="quality">@foreach (['premium','standard','economy'] as $q)<option value="{{ $q }}" @selected($v('quality', $p?->quality ?? 'standard') === $q)>{{ ucfirst($q) }}</option>@endforeach</select></div>
</div>
<label for="photos">Photos * (at least one, up to 6)</label>
{{-- capture opens the phone camera directly --}}
<input id="photos" name="photos[]" type="file" accept="image/*" capture="environment" multiple>
@if ($listing && $listing->photos)<div class="p-actions">@foreach ($listing->photos as $ph)<label class="check"><img src="{{ asset('storage/'.$ph) }}" alt="" width="64" height="64" style="object-fit:cover;border-radius:8px"><input type="checkbox" name="remove_photos[]" value="{{ $ph }}"> remove</label>@endforeach</div>@endif
<details><summary><b>More details (optional)</b></summary>
<div class="row">
 <div><label for="harvest_date">Harvest date</label><input id="harvest_date" name="harvest_date" type="date" max="{{ now()->toDateString() }}" value="{{ $v('harvest_date', $p?->harvest_date?->toDateString()) }}"></div>
 <div><label for="grade">Grade</label><select id="grade" name="grade"><option value="">—</option>@foreach (['A','B','C'] as $g)<option @selected($v('grade', $p?->grade) === $g)>{{ $g }}</option>@endforeach</select></div>
 <div><label for="packaging">Packaging</label><input id="packaging" name="packaging" value="{{ $v('packaging', $p?->packaging) }}"></div>
 <div><label for="min_order">Minimum order</label><input id="min_order" name="min_order" type="number" step="0.001" value="{{ $v('min_order', $p?->min_order ? \App\Support\Quantity::pretty($p->min_order) : '') }}"></div>
</div>
<label for="video">Video (mp4/webm, up to 30 MB)</label><input id="video" name="video" type="file" accept="video/*">
<label for="quality_notes">Quality notes</label><textarea id="quality_notes" name="quality_notes">{{ $v('quality_notes', $p?->quality_notes) }}</textarea>
<div class="row"><div><label for="lat">Pickup latitude</label><input id="lat" name="lat" value="{{ $v('lat', $listing?->lat) }}"></div><div><label for="lng">Pickup longitude</label><input id="lng" name="lng" value="{{ $v('lng', $listing?->lng) }}"></div></div>
</details>
<div class="p-actions">
 <button class="button button-primary" name="submit" value="1">{{ $listing ? 'Save and submit for review' : 'Submit for review' }}</button>
 <button class="button button-outline" name="submit" value="0">Save {{ $listing ? 'changes' : 'as draft' }}</button>
</div>
</form>
<script>
const cat=document.getElementById('category'),crop=document.getElementById('crop_id'),reg=document.getElementById('region_id'),dis=document.getElementById('district_id');
function fc(){[...crop.options].forEach(o=>o.hidden=o.dataset.cat!==cat.value);if(crop.selectedOptions[0]?.hidden)crop.value=[...crop.options].find(o=>!o.hidden)?.value}
function fd(){[...dis.options].forEach(o=>o.hidden=o.dataset.region!==reg.value);if(dis.selectedOptions[0]?.hidden)dis.value=[...dis.options].find(o=>!o.hidden)?.value}
cat.addEventListener('change',fc);reg.addEventListener('change',fd);fc();fd();
</script>
@endsection
