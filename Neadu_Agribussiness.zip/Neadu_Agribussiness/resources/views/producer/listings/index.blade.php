@extends('producer.layout')
@section('title', 'My listings')
@section('heading', 'My listings')
@section('lead', 'Edit, pause or close what you sell.')
@section('head-action')<a class="button button-primary" href="{{ route('producer.listings.create') }}">New listing</a>@endsection
@section('body')
@forelse ($listings as $l)
<div class="p-card">
 <b>{{ $l->title }}</b> <span class="p-tag">{{ ucfirst(str_replace('_',' ',$l->status)) }}</span>
 <p class="p-muted">{{ $l->produce?->category?->label() }} · {{ \App\Support\Quantity::pretty($l->produce?->remaining() ?? 0) }} {{ $l->produce?->unit?->code }} left of {{ \App\Support\Quantity::pretty($l->produce?->quantity ?? 0) }} · TSh {{ number_format(intdiv($l->price_minor,100)) }} per {{ $l->produce?->unit?->code }}</p>
 @if ($l->status === 'sold_out')<p class="p-muted">Sold out: hidden from the marketplace. Edit the quantity to restock.</p>@endif
 <div class="p-actions">
  <a class="button button-outline button-small" href="{{ route('producer.listings.edit', $l) }}">Edit</a>
  @if (in_array($l->status, ['draft','rejected']))<form method="post" action="{{ route('producer.listings.submit', $l) }}">@csrf<button class="button button-primary button-small">Submit for review</button></form>@endif
  @if ($l->status === 'active')<form method="post" action="{{ route('producer.listings.pause', $l) }}">@csrf<button class="button button-quiet button-small">Pause</button></form>@endif
  @if ($l->status === 'paused')<form method="post" action="{{ route('producer.listings.resume', $l) }}">@csrf<button class="button button-primary button-small">Resume</button></form>@endif
  @if ($l->status !== 'closed')<form method="post" action="{{ route('producer.listings.close', $l) }}" onsubmit="return confirm('Close this listing?')">@csrf<button class="button button-danger-quiet button-small">Close</button></form>@endif
 </div>
</div>
@empty<div class="p-card">No listings yet. <a href="{{ route('producer.listings.create') }}">Create your first listing</a>.</div>@endforelse
@endsection
