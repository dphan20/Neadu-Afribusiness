@extends('producer.layout')
@section('title', 'Producer profile')
@section('heading', 'Profile & verification')
@section('lead', 'Tell buyers who you are and where you produce.')
@section('body')
<form class="p-card pf" method="post" action="{{ route('producer.profile.update') }}">@csrf @method('PUT')
<label>I am a</label>
@foreach ($types as $t)<label class="check"><input type="radio" name="producer_type" value="{{ $t->value }}" @checked(old('producer_type', $business['producer_type'] ?? 'farmer') === $t->value)> {{ $t->label() }} ({{ $t->swahiliLabel() }})</label>@endforeach
<div class="row"><div><label for="region">Region</label><select id="region" name="region_id">@foreach ($regions as $r)<option value="{{ $r->id }}" @selected(old('region_id', $profile?->region_id) == $r->id)>{{ $r->name }}</option>@endforeach</select></div>
<div><label for="district">District</label><select id="district" name="district_id">@foreach ($districts as $d)<option value="{{ $d->id }}" data-region="{{ $d->region_id }}" @selected(old('district_id', $profile?->district_id) == $d->id)>{{ $d->name }}</option>@endforeach</select></div></div>
<label for="farm">Farm / business name</label><input id="farm" name="farm_name" value="{{ old('farm_name', $business['farm_name'] ?? '') }}">
<label>What do you produce?</label>
@foreach ($crops as $c)<label class="check"><input type="checkbox" name="crop_ids[]" value="{{ $c->id }}" @checked(in_array($c->id, old('crop_ids', $business['crop_ids'] ?? []))) > {{ $c->name_en }}</label>@endforeach
<div class="p-actions"><button class="button button-primary">Save profile</button></div>
<p class="p-muted">Phone: {{ auth()->user()->phone_verified_at ? '✓ verified' : 'not verified' }} · Identity: {{ auth()->user()->isIdentityVerified() ? '✓ verified' : 'not verified' }}</p>
</form>
<script>
const r=document.getElementById('region'),d=document.getElementById('district');
function f(){[...d.options].forEach(o=>{o.hidden=o.dataset.region!==r.value});if(d.selectedOptions[0]?.hidden){d.value=[...d.options].find(o=>!o.hidden)?.value}}
r.addEventListener('change',f);f();
</script>
@endsection
