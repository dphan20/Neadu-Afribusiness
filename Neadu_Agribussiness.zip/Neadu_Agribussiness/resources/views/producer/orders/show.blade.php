@extends('producer.layout')
@section('title', 'Order')
@section('heading', $order->listing?->title ?? 'Order')
@section('lead', 'Order '.substr($order->uuid, 0, 8).' · '.$order->status->label())
@section('body')
<div class="p-card"><div class="p-grid">
 <div><span class="p-muted">Buyer</span><br><b>{{ $order->buyer?->name }}</b></div>
 <div><span class="p-muted">Quantity</span><br><b>{{ \App\Support\Quantity::pretty($order->quantity) }} {{ $order->listing?->produce?->unit?->code }}</b></div>
 <div><span class="p-muted">Unit price</span><br><b>TSh {{ number_format(intdiv($order->unit_price_minor,100)) }}</b></div>
 <div><span class="p-muted">Subtotal</span><br><b>TSh {{ number_format(intdiv($order->subtotal_minor,100)) }}</b></div>
 <div><span class="p-muted">Platform fee ({{ $fee['bps']/100 }}%)</span><br><b>TSh {{ number_format(intdiv($fee['fee'],100)) }}</b></div>
 <div><span class="p-muted">You receive</span><br><b>TSh {{ number_format(intdiv($order->subtotal_minor - $fee['fee'],100)) }}</b></div>
</div>
@if ($order->counter_status === 'offered')<p>Counter-offer sent: TSh {{ number_format(intdiv($order->counter_unit_price_minor,100)) }} per unit (waiting for buyer).</p>@endif
@if ($order->reject_reason)<p class="p-muted">Closed: {{ $order->reject_reason }}</p>@endif
</div>

@if ($order->awaitingAnswer())
<div class="p-card pf"><h3>Your answer @if($order->accept_by) <span class="p-muted">(due {{ $order->accept_by->format('d M H:i') }})</span>@endif</h3>
 <div class="p-actions"><form method="post" action="{{ route('producer.orders.accept',$order) }}">@csrf<button class="button button-primary">Accept order</button></form></div>
 <form method="post" action="{{ route('producer.orders.reject',$order) }}">@csrf<label for="reason">Reject: reason</label><input id="reason" name="reason" required><div class="p-actions"><button class="button button-danger-quiet">Reject</button></div></form>
 @if ($order->status === \App\Enums\EscrowState::Pending)
 <form method="post" action="{{ route('producer.orders.counter',$order) }}"><label for="price">Counter-offer: new price per unit (TSh)</label><input id="price" name="price" inputmode="decimal" required>@csrf<div class="p-actions"><button class="button button-outline">Send counter-offer</button></div></form>@endif
</div>
@endif

<div class="p-actions">
@if ($order->accepted_at && $order->status === \App\Enums\EscrowState::Held)
 <form method="post" action="{{ route('producer.orders.ship',$order) }}">@csrf<button class="button button-outline">Mark as shipped</button></form>
 @unless($activeDelivery)<a class="button button-primary" href="{{ route('producer.delivery.create',$order) }}">Book delivery</a>@endunless
@endif
@if ($activeDelivery)<a class="button button-outline" href="{{ route('me.delivery.show',$activeDelivery) }}">Track delivery</a>@endif
<form method="post" action="{{ route('me.chat.order',$order) }}">@csrf<button class="button button-outline">Chat with buyer</button></form>
<a class="button button-outline" href="{{ route('producer.orders.receipt',$order) }}">Payout receipt</a>
</div>

@if (in_array($order->status, [\App\Enums\EscrowState::Held, \App\Enums\EscrowState::InTransit, \App\Enums\EscrowState::Delivered]) && ! $order->dispute)
<form class="p-card pf" method="post" enctype="multipart/form-data" action="{{ route('producer.orders.dispute',$order) }}"><h3>Open a dispute</h3>
@csrf<label for="dr">What went wrong?</label><textarea id="dr" name="reason" required minlength="10"></textarea>
<label for="ev">Evidence (photos or PDF, up to 5)</label><input id="ev" type="file" name="evidence[]" multiple accept="image/*,application/pdf" required>
<div class="p-actions"><button class="button button-danger-quiet">Open dispute</button></div></form>
@endif
@if ($order->dispute)
<div class="p-card"><h3>Dispute</h3><p>{{ $order->dispute->reason }}</p><p class="p-muted">Evidence until {{ $order->dispute->evidence_until->format('d M') }} · decision by {{ $order->dispute->decide_by->format('d M') }} @if($order->dispute->decision)· Decision: {{ $order->dispute->decision }}@endif</p>
@foreach ($order->dispute->evidence ?? [] as $i => $e)<a href="{{ route('producer.disputes.file',[$order->dispute,$i]) }}" target="_blank">{{ $e['name'] }}</a> @endforeach
@if (! $order->dispute->decision && $order->dispute->evidence_until->isFuture())
<form class="pf" method="post" enctype="multipart/form-data" action="{{ route('producer.disputes.evidence',$order->dispute) }}">@csrf<input type="file" name="evidence[]" multiple required accept="image/*,application/pdf"><div class="p-actions"><button class="button button-outline button-small">Add evidence</button></div></form>@endif
</div>@endif

@if ($order->status === \App\Enums\EscrowState::Released && ! $rated)
<form class="p-card pf" method="post" action="{{ route('producer.orders.rating',$order) }}"><h3>Rate this buyer</h3>@csrf
<label for="stars">Stars</label><select id="stars" name="stars">@foreach([5,4,3,2,1] as $s)<option>{{ $s }}</option>@endforeach</select>
<label for="cm">Comment (optional)</label><input id="cm" name="comment" maxlength="500"><div class="p-actions"><button class="button button-primary">Save rating</button></div></form>
@endif
@endsection
