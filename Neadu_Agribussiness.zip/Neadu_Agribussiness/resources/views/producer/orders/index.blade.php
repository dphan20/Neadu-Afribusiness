@extends('producer.layout')
@section('title', 'Orders')
@section('heading', 'Orders')
@section('lead', 'Answer new orders within 24 hours: accept, reject or counter.')
@section('body')
<div class="p-actions">@foreach (['all'=>'All','awaiting'=>'Awaiting my answer','open'=>'In progress','done'=>'Completed'] as $k=>$label)<a class="button {{ $filter===$k ? 'button-primary' : 'button-outline' }} button-small" href="{{ route('producer.orders.index',['filter'=>$k]) }}">{{ $label }}</a>@endforeach</div>
@forelse ($orders as $o)
<a class="p-card" style="display:block;margin-top:12px" href="{{ route('producer.orders.show',$o) }}">
 <b>{{ $o->listing?->title ?? 'Order' }}</b> <span class="p-tag">{{ $o->status->label() }}</span>
 <p class="p-muted">{{ $o->buyer?->name }} · {{ \App\Support\Quantity::pretty($o->quantity) }} · TSh {{ number_format(intdiv($o->subtotal_minor,100)) }}
 @if ($o->awaitingAnswer() && $o->accept_by) · answer {{ $o->accept_by->isPast() ? 'overdue' : 'within '.$o->accept_by->diffForHumans(null, true) }}@endif</p>
</a>
@empty<div class="p-card" style="margin-top:12px">No orders here.</div>@endforelse
@endsection
