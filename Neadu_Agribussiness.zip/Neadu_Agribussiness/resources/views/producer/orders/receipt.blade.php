@extends('producer.layout')
@section('title', 'Receipt')
@section('heading', $r['released'] ? 'Payout receipt' : 'Payout estimate')
@section('lead', $r['released'] ? 'Receipt '.$r['receipt_no'] : 'Final receipt is issued when escrow is released.')
@section('body')
<div class="p-card"><div class="table-wrap"><table class="data-table"><tbody>
<tr><td>Item</td><td>{{ $r['item'] }}</td></tr>
<tr><td>Quantity</td><td>{{ \App\Support\Quantity::pretty($r['quantity']) }} {{ $r['unit'] }}</td></tr>
<tr><td>Unit price</td><td>{{ $r['unit_price']->format() }}</td></tr>
<tr><td>Subtotal</td><td>{{ $r['subtotal']->format() }}</td></tr>
<tr><td>Platform fee ({{ $r['fee_bps']/100 }}%)</td><td>− {{ $r['fee']->format() }}</td></tr>
<tr><td><b>Paid to you</b></td><td><b>{{ $r['payout']->format() }}</b></td></tr>
<tr><td>Buyer</td><td>{{ $r['order']->buyer?->name }}</td></tr>
@if ($r['released'])<tr><td>Released</td><td>{{ $r['order']->released_at?->format('d M Y H:i') }}</td></tr>@endif
</tbody></table></div>
<div class="p-actions"><button class="button button-outline" onclick="window.print()">Print</button><a class="button button-quiet" href="{{ route('producer.orders.show',$r['order']) }}">Back to order</a></div></div>
@endsection
