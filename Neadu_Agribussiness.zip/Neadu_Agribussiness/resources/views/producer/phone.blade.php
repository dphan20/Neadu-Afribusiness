@extends('producer.layout')
@section('title', 'Verify phone')
@section('heading', 'Verify your phone')
@section('lead', 'We send a 6-digit code by SMS.')
@section('body')
<div class="p-card pf">
@if ($verified)<p>✓ Your phone number is verified.</p><a class="button button-primary" href="{{ route('producer.identity') }}">Next: verify identity</a>
@else
<form method="post" action="{{ route('producer.phone.send') }}">@csrf<button class="button button-outline">Send me a code</button></form>
<form method="post" action="{{ route('producer.phone.verify') }}">@csrf
<label for="code">Code</label><input id="code" name="code" inputmode="numeric" maxlength="6" required>
<div class="p-actions"><button class="button button-primary">Verify</button></div></form>
@endif
</div>
@endsection
