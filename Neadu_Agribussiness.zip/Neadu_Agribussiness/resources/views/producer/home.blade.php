@extends('producer.layout')
@section('title', 'Producer overview')
@section('heading', 'Habari, '.explode(' ', auth()->user()->name)[0])
@section('lead', 'Sell, ship, store and get advice from one place.')
@section('body')
<div class="p-grid">
@foreach ($stats as $s)<a class="p-card" href="{{ $s['href'] }}"><span class="p-muted">{{ $s['label'] }}</span><h2>{{ $s['value'] }}</h2></a>@endforeach
</div>
<div class="p-card"><h2>Get ready to sell</h2>
@foreach ($checklist as $c)<p>{{ $c['done'] ? '✓' : '○' }} <a href="{{ $c['href'] }}">{{ $c['label'] }}</a></p>@endforeach
</div>
<div class="p-actions"><a class="button button-primary" href="{{ route('producer.listings.create') }}">Create a listing</a><a class="button button-outline" href="{{ route('producer.orders.index', ['filter'=>'awaiting']) }}">Answer orders</a><a class="button button-outline" href="{{ route('producer.diagnosis.create') }}">Diagnose a photo</a></div>
@endsection
