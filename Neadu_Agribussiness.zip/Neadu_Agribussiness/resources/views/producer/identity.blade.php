@extends('producer.layout')
@section('title', 'Verify identity')
@section('heading', 'Verify your identity (NIDA)')
@section('lead', 'Required before you list produce, accept orders, ship or receive payouts.')
@section('body')
<div class="p-card pf">
@if ($user->isIdentityVerified())<p>✓ Verified. NIDA: {{ $masked }}</p><a class="button button-primary" href="{{ route('producer.profile') }}">Continue</a>
@else
<form method="post" action="{{ route('producer.identity.verify') }}">@csrf
<label for="nida">NIDA number (20 digits)</label><input id="nida" name="nida_number" inputmode="numeric" maxlength="20" value="{{ old('nida_number') }}" required>
<div class="p-actions"><button class="button button-primary">Verify</button></div></form>
<p class="p-muted">Your number is stored encrypted and only the last 4 digits are ever shown.</p>
@endif
</div>
@endsection
