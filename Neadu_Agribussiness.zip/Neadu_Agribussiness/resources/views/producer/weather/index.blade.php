@extends('producer.layout')
@section('title', __('weather.title'))
@section('heading', __('weather.title').' · '.$region?->name)
@section('lead', __('weather.lead'))
@section('body')
@php($cur = $forecast['current'])
<style>
    .wx-head { background: var(--color-water); color: #fff; border-radius: 16px; padding: 18px 20px; margin-bottom: 14px; display: flex; flex-wrap: wrap; gap: 14px 28px; align-items: center; }
    .wx-temp { font: 800 44px/1 var(--font-heading); }
    .wx-head small { opacity: .9; }
    .wx-banner { padding: 9px 14px; border-radius: 12px; font-size: 13px; font-weight: 600; margin-bottom: 12px; background: var(--color-accent-soft); color: var(--color-warning); }
    .wx-foot { margin-top: 14px; padding: 10px 14px; border-radius: 12px; background: var(--color-water-soft); font-weight: 700; font-size: 14px; }
</style>
<form class="p-card pf" method="get" id="wx-form">
    <label for="r">{{ __('weather.district') }}</label>
    <select id="r" name="region_id" onchange="this.form.submit()">@foreach($regions as $r)<option value="{{ $r->id }}" @selected($region?->id===$r->id)>{{ $r->name }}</option>@endforeach</select>
    <button class="button button-outline button-small" type="submit">{{ __('weather.reload') }}</button>
</form>
<div class="wx-banner" id="wx-offline" role="status" aria-live="polite" hidden>{{ __('weather.offline') }}</div>
@if($forecast['stale'] && $days !== [])<div class="wx-banner" role="status">{{ __('weather.stale') }}</div>@endif

@if($days === [])
    <div class="p-card"><b>{{ __('weather.empty_title') }}</b><p class="p-muted">{{ __('weather.empty_body') }}</p></div>
@else
    @if($cur)
        @php($now = \App\Enums\WeatherCondition::from($cur['condition']))
        <section class="wx-head" aria-label="{{ __('weather.now') }}">
            <div><small>{{ __('weather.now') }}</small><div class="wx-temp">{{ round($cur['temperature']) }}°C</div></div>
            <div><span style="font-size:34px" aria-hidden="true">{{ $now->icon() }}</span><div><b>{{ $now->label() }}</b></div></div>
            <div><small>{{ __('weather.wind') }}</small><div><b>{{ round($cur['wind_kmh']) }} km/h</b></div></div>
            <div><small>{{ __('weather.rain') }}</small><div><b>{{ round($cur['rain_mm'], 1) }} mm</b></div></div>
        </section>
    @endif
    @foreach($alerts as $a)<div class="p-card" style="border-color:var(--color-error)">⚠ <b>{{ \Illuminate\Support\Carbon::parse($a['date'])->format('D d M') }}</b>: {{ $a['message'] }}</div>@endforeach
    <div class="p-grid">@foreach($days as $d)@php($c = \App\Enums\WeatherCondition::from($d['condition']))<div class="p-card"><b>{{ \Illuminate\Support\Carbon::parse($d['date'])->format('D d M') }}</b><p><span aria-hidden="true">{{ $c->icon() }}</span> {{ $c->label() }}</p><p>{{ round($d['tmin']) }}° – {{ round($d['tmax']) }}°C</p><p class="p-muted">{{ __('weather.rain') }} {{ round($d['rain_mm']) }} mm · {{ __('weather.wind') }} {{ round($d['wind_kmh']) }} km/h</p></div>@endforeach</div>
    @if($hint)<div class="p-card"><b>{{ __('weather.hint_title') }}</b><p>{{ __('weather.hint.'.$hint['level'], ['mm' => $hint['mm']]) }}</p></div>@endif
@endif

<h3>{{ __('weather.windows_title') }}</h3>
@foreach($windows as $w)<div class="p-card"><b>{{ $w['crop']->name_sw }} ({{ $w['crop']->name_en }})</b> <span class="p-tag">{{ $w['window']['label'] }}</span>@if($w['window']['next'])<p class="p-muted">{{ $w['window']['next'] }}</p>@endif</div>@endforeach
<p class="p-muted">{{ __('weather.indicative') }}</p>

<p class="wx-foot" id="wx-source">{{ __('weather.source_line', ['source' => $forecast['source'], 'time' => $updatedAt ?? '—']) }}</p>
<script>
(function () {
    var box = document.getElementById('wx-offline');
    function sync() { box.hidden = navigator.onLine; }
    window.addEventListener('online', sync); window.addEventListener('offline', sync); sync();
})();
</script>
@endsection
