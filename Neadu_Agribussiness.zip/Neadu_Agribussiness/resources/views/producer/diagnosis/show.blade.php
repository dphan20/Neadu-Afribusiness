@extends('producer.layout')
@section('title', 'Diagnosis result')
@section('heading', $case->result)
@section('lead', $case->subject.' · confidence '.$case->confidence.'%')
@section('body')
<div class="p-card"><img src="{{ route('producer.diagnosis.photo',$case) }}" alt="Photo" style="max-width:280px;border-radius:12px">
<h3>Matibabu (treatment)</h3><p>{{ $case->treatment }}</p><h3>Kinga (prevention)</h3><p>{{ $case->prevention }}</p>
@if($case->confidence < 60)<p class="p-tag">Confidence is low. We recommend asking an expert.</p>@endif
<div class="p-actions">
<form method="post" action="{{ route('producer.diagnosis.chat',$case) }}">@csrf<button class="button button-primary">Chat with an expert</button></form>
@if(! $case->escalated_at)<form method="post" action="{{ route('producer.diagnosis.escalate',$case) }}">@csrf<button class="button button-outline">Escalate to expert</button></form>@else<span class="p-tag">Sent to {{ $case->expert?->name }}</span>@endif
</div>
@if($case->expert_reply)<h3>Expert reply</h3><p>{{ $case->expert_reply }}</p>@if($case->expert_correction)<p class="p-muted">The expert corrected the AI: {{ $case->expert_correction }}</p>@endif
@if(! $case->expert_rating)<form class="pf" method="post" action="{{ route('producer.diagnosis.rate',$case) }}">@csrf<label for="st">Rate this expert</label><select id="st" name="stars">@foreach([5,4,3,2,1] as $s)<option>{{ $s }}</option>@endforeach</select><div class="p-actions"><button class="button button-outline button-small">Rate</button></div></form>@else<p class="p-tag">You rated {{ $case->expert_rating }}/5</p>@endif @endif</div>
@endsection
