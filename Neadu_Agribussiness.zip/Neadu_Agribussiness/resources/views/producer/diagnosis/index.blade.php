@extends('producer.layout')
@section('title', 'Diagnosis')
@section('heading', 'Crop & animal diagnosis')
@section('lead', 'Take a photo and get advice in Kiswahili.')
@section('head-action')<a class="button button-primary" href="{{ route('producer.diagnosis.create') }}">New diagnosis</a>@endsection
@section('body')
@forelse($cases as $c)<a class="p-card" style="display:block" href="{{ route('producer.diagnosis.show',$c) }}"><b>{{ $c->subject }}</b> <span class="p-tag">{{ $c->confidence }}%</span><p class="p-muted">{{ $c->result }} · {{ $c->created_at->format('d M') }}{{ $c->escalated_at ? ' · sent to expert' : '' }}</p></a>
@empty<div class="p-card">No diagnoses yet.</div>@endforelse
@endsection
