@extends('producer.layout')
@section('title', 'New diagnosis')
@section('heading', 'New diagnosis')
@section('lead', 'Take a clear, close photo of the affected plant, animal or fish.')
@section('body')
<form class="p-card pf" method="post" enctype="multipart/form-data" action="{{ route('producer.diagnosis.store') }}">@csrf
<div class="row"><div><label for="kind">Type</label><select id="kind" name="kind"><option value="crop">Crop (Mazao)</option><option value="livestock">Livestock (Mifugo)</option><option value="fish">Fish (Samaki)</option></select></div>
<div><label for="subject">What is it? (e.g. maize, goat)</label><input id="subject" name="subject" value="{{ old('subject') }}" required></div></div>
<label>Photo</label>@include('me.partials.photo-picker')
<div class="p-actions"><button class="button button-primary">Diagnose</button></div></form>
@endsection
