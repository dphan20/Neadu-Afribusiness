@extends('producer.layout')
@section('title', 'Price alerts')
@section('heading', 'Price alerts')
@section('lead', 'Get told by SMS, WhatsApp or in the app when a price crosses your target.')
@section('body')
<form class="p-card pf" method="post" action="{{ route('me.alerts.store') }}">@csrf
<div class="row"><div><label for="crop_id">Product</label><select id="crop_id" name="crop_id">@foreach($crops as $c)<option value="{{ $c->id }}">{{ $c->name_en }} ({{ $c->name_sw }})</option>@endforeach</select></div>
<div><label for="market_id">Market</label><select id="market_id" name="market_id"><option value="">Any market</option>@foreach($markets as $m)<option value="{{ $m->id }}">{{ $m->name }}</option>@endforeach</select></div>
<div><label for="condition">When price goes</label><select id="condition" name="condition"><option value="above">Above</option><option value="below">Below</option></select></div>
<div><label for="threshold">Price (TSh)</label><input id="threshold" name="threshold" inputmode="decimal" required></div></div>
<label>Tell me by</label><label class="check"><input type="checkbox" name="channels[]" value="in_app" checked> In app</label><label class="check"><input type="checkbox" name="channels[]" value="sms"> SMS</label><label class="check"><input type="checkbox" name="channels[]" value="whatsapp"> WhatsApp</label>
<div class="p-actions"><button class="button button-primary">Save alert</button></div></form>
@foreach($alerts as $a)<div class="p-card"><b>{{ $a->crop->name_en }}</b> {{ $a->condition }} TSh {{ number_format(intdiv($a->threshold_minor,100)) }} {{ $a->market ? '· '.$a->market->name : '' }} <span class="p-tag">{{ $a->active ? 'On' : 'Off' }}</span> <span class="p-muted">{{ implode(', ',$a->channels) }}</span>
<div class="p-actions"><form method="post" action="{{ route('me.alerts.toggle',$a) }}">@csrf<button class="button button-quiet button-small">{{ $a->active ? 'Turn off' : 'Turn on' }}</button></form><form method="post" action="{{ route('me.alerts.destroy',$a) }}">@csrf @method('DELETE')<button class="button button-danger-quiet button-small">Delete</button></form></div></div>@endforeach
<h3>Latest market prices</h3>
@foreach($latest as $r)<p class="p-muted">{{ $r->crop->name_en }} · {{ $r->market->name }} · TSh {{ number_format(intdiv($r->price_minor,100)) }} · {{ $r->recorded_on }}</p>@endforeach
@endsection
