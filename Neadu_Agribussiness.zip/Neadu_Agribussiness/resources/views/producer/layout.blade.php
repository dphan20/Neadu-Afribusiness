@extends('layouts.app')

@section('content')
@php
$activeRole = \App\Support\RoleNav::activeRole();
$nav = \App\Support\RoleNav::for($activeRole);
@endphp
<main class="workspace-shell">
    <aside class="workspace-sidebar">
        <div class="workspace-person">
            <span class="avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</span>
            <span><b>{{ auth()->user()->name }}</b><small>{{ $activeRole->label() }}</small></span>
        </div>
        <nav class="workspace-nav" aria-label="Producer navigation">
            @foreach ($nav as $i => [$route, $label])
                <a class="{{ request()->routeIs($route.'*') ? 'active' : '' }}" href="{{ route($route) }}"><span class="nav-mark">{{ str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) }}</span>{{ $label }}</a>
            @endforeach
        </nav>
    </aside>
    <section class="workspace-main">
        <div class="workspace-heading"><div><span class="eyebrow">{{ $activeRole->swahiliLabel() }} · {{ strtoupper($activeRole->label()) }}</span><h1>@yield('heading')</h1><p>@yield('lead')</p></div>@yield('head-action')</div>
        @yield('body')
    </section>
</main>
@endsection
