@extends('producer.layout')
@section('title', 'Voice assistant')
@section('heading', 'Voice assistant (Kiswahili)')
@section('lead', 'Tap the microphone and speak. Ask about prices, warehouses, weather, orders and your deliveries.')
@section('body')
<div class="vo-card" id="vo">
    <div class="vo-log" id="log" aria-live="polite">
        <div class="vo-msg bot">Habari! Gusa kipaza sauti kisha sema, kwa mfano “bei ya mahindi”. Money actions need you to say “ndiyo”.</div>
    </div>
    <div class="vo-chips">
        @foreach (['bei ya mahindi', 'ghala', 'hali ya hewa', 'oda zangu', 'mzigo wangu'] as $s)<button type="button" data-say="{{ $s }}">{{ $s }}</button>@endforeach
    </div>
    <p class="vo-status" id="vo-status" role="status" aria-live="polite"></p>
    <div class="ai-clip" id="vo-clip" hidden><audio controls preload="metadata" id="vo-audio"></audio><div class="ai-clip-btns"><button type="button" class="ai-send" id="vo-send">Send voice</button><button type="button" class="ai-lang ai-clip-x" id="vo-discard">Discard</button></div></div>
    <div class="vo-bar">
        <button class="vo-mic" id="mic" type="button" aria-pressed="false" aria-label="Speak">
            <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>
        </button>
        <input id="t" type="text" autocomplete="off" placeholder="Or type here, e.g. bei ya mahindi" aria-label="Type a command">
        <button class="ai-lang" type="button" data-voice-lang>SW</button>
        <button class="ai-send" id="go" type="button">Send</button>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var log = document.getElementById('log'), status = document.getElementById('vo-status'), mic = document.getElementById('mic'), input = document.getElementById('t');
    var token = document.querySelector('meta[name=csrf-token]').content;
    function add(who, text) { var d = document.createElement('div'); d.className = 'vo-msg ' + who; d.textContent = text; log.appendChild(d); log.scrollTop = log.scrollHeight; }
    function speak(text) {
        if (!('speechSynthesis' in window) || !text) { return; }
        try {
            speechSynthesis.cancel();
            var u = new SpeechSynthesisUtterance(text), voices = speechSynthesis.getVoices();
            var v = voices.filter(function (x) { return /^sw/i.test(x.lang); })[0] || voices.filter(function (x) { return /^en/i.test(x.lang); })[0];
            u.lang = v ? v.lang : 'sw-TZ'; if (v) { u.voice = v; } speechSynthesis.speak(u);
        } catch (e) { /* speaking is optional */ }
    }
    function send(text) {
        text = (text || '').trim(); if (!text) { return; }
        add('me', text); status.textContent = 'Inafikiri…';
        fetch(@json(route('producer.voice.command')), { method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': token, 'X-Requested-With': 'XMLHttpRequest' }, body: JSON.stringify({ text: text }) })
            .then(function (r) { if (!r.ok) { throw new Error(r.status); } return r.json(); })
            .then(function (j) { status.textContent = ''; add('bot', j.reply || 'Hitilafu imetokea.'); speak(j.reply); })
            .catch(function () { status.textContent = ''; add('bot', 'Hitilafu imetokea. Jaribu tena. (Something went wrong, please try again.)'); });
    }
    var clipBox = document.getElementById('vo-clip'), audio = document.getElementById('vo-audio');
    var voice = NeasVoice.create({
        transcribeUrl: @json(route('me.ask.transcribe')), lang: NeasVoice.getLang,
        onRecorded: function (c) { audio.src = c.url; clipBox.hidden = false; status.textContent = 'Recorded ' + c.seconds + 's. Play it back, then tap Send voice.'; },
        onFinal: function (t) { clipBox.hidden = true; status.textContent = ''; send(t); },
        onError: function (m) { status.textContent = m; },
        onState: function (s) {
            mic.classList.toggle('is-listening', s === 'listening'); mic.disabled = s === 'processing' || s === 'recorded';
            mic.setAttribute('aria-pressed', s === 'listening' ? 'true' : 'false');
            if (s === 'idle') { clipBox.hidden = true; }
            if (s === 'listening') { status.textContent = NeasVoice.getLang() === 'en-US' ? 'Recording… speak now, then tap the microphone to stop.' : 'Inarekodi… sema sasa, kisha bonyeza kipaza sauti kusimamisha.'; }
            document.getElementById('vo-send').disabled = document.getElementById('vo-discard').disabled = s === 'processing';
            if (s === 'processing') { status.textContent = 'Converting your voice to text…'; }
        }
    });
    document.getElementById('vo-send').addEventListener('click', function () { voice.send(); });
    document.getElementById('vo-discard').addEventListener('click', function () { voice.discard(); status.textContent = ''; });
    mic.addEventListener('click', function () { try { speechSynthesis.cancel(); } catch (e) {} voice.toggle(); });
    document.getElementById('go').addEventListener('click', function () { send(input.value); input.value = ''; });
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); send(input.value); input.value = ''; } });
    document.querySelectorAll('[data-say]').forEach(function (b) { b.addEventListener('click', function () { send(b.getAttribute('data-say')); }); });
});
</script>
@endsection
