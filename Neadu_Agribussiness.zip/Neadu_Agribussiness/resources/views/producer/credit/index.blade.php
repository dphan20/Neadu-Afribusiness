@extends('producer.layout')
@section('title', 'Credit score')
@section('heading', 'Your credit score')
@section('lead', 'Built from how you trade on NeAS. Only you decide who sees it.')
@section('body')
<div class="p-card"><h2 style="font-size:44px">{{ $score }}</h2><div class="p-bar"><span style="width:{{ ($score-$min)/($max-$min)*100 }}%"></span></div><p class="p-muted">Range {{ $min }} – {{ $max }}</p></div>
@foreach($factors as $f)<div class="p-card"><b>{{ $f['label'] }}</b> <span class="p-tag">{{ $f['points'] >= 0 ? '+' : '' }}{{ $f['points'] }}{{ $f['max'] ? ' / '.$f['max'] : '' }}</span><p class="p-muted">{{ $f['detail'] }}</p>@if($f['tip'])<p>💡 {{ $f['tip'] }}</p>@endif</div>@endforeach
<form class="p-card pf" method="post" action="{{ route('producer.credit.consent') }}">@csrf<h3>Share with lenders</h3>
<p>{{ $consent ? 'Lenders you apply to can see your score.' : 'Your score is private. No lender can see it.' }}</p>
<input type="hidden" name="consent" value="{{ $consent ? 0 : 1 }}"><div class="p-actions"><button class="button {{ $consent ? 'button-danger-quiet' : 'button-primary' }}">{{ $consent ? 'Stop sharing' : 'I agree to share my score with lenders' }}</button></div></form>
@endsection
