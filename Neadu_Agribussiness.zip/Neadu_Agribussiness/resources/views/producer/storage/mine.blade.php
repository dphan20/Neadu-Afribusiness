@extends('producer.layout')
@section('title', 'Storage bookings')
@section('heading', 'My storage bookings')
@section('lead', 'Requests you sent to warehouses.')
@section('body')
@forelse($bookings as $b)
<div class="p-card"><b>{{ $b->facilityListing?->title }}</b> <span class="p-tag">{{ ucfirst($b->status) }}</span>
<p class="p-muted">{{ \App\Support\Quantity::pretty($b->quantity_kg) }} kg · {{ $b->starts_on }} → {{ $b->ends_on }} · TSh {{ number_format(intdiv($b->price_minor,100)) }} · {{ ucfirst($b->payment_method) }} ({{ $b->payment_state }}) @if($b->receipt_no)· Receipt <a href="{{ route('me.storage.receipt',$b) }}">{{ $b->receipt_no }}</a>@endif @if($b->decline_reason)· Declined: {{ $b->decline_reason }}@endif</p>
@if($b->status==='requested')<form method="post" action="{{ route('producer.storage.cancel',$b) }}">@csrf<button class="button button-danger-quiet button-small">Cancel request</button></form>@endif</div>
@empty<div class="p-card">No bookings yet. <a href="{{ route('producer.storage.index') }}">Find storage</a>.</div>@endforelse
@endsection
