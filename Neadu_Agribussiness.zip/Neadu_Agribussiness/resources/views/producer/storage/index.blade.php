@extends('producer.layout')
@section('title', 'Find storage')
@section('heading', 'Find storage')
@section('lead', 'Search warehouses by place and capacity.')
@section('head-action')<a class="button button-outline" href="{{ route('producer.storage.mine') }}">My bookings</a>@endsection
@section('body')
<form class="p-card pf" method="get"><div class="row">
<div><label>Region</label><select name="region_id"><option value="">Any</option>@foreach($regions as $r)<option value="{{ $r->id }}" @selected(($filters['region_id']??null)==$r->id)>{{ $r->name }}</option>@endforeach</select></div>
<div><label>District</label><select name="district_id"><option value="">Any</option>@foreach($districts as $d)<option value="{{ $d->id }}" @selected(($filters['district_id']??null)==$d->id)>{{ $d->name }}</option>@endforeach</select></div>
<div><label>Minimum space (kg)</label><input name="min_kg" type="number" value="{{ $filters['min_kg']??'' }}"></div>
<div><label>Name</label><input name="q" value="{{ $filters['q']??'' }}"></div></div>
<div class="p-actions"><button class="button button-primary">Search</button></div></form>
@forelse($facilities as $f)
<a class="p-card" style="display:block" href="{{ route('producer.storage.show',$f) }}"><b>{{ $f->title }}</b> <span class="p-tag">{{ $f->storage?->facility_type }}</span>
<p class="p-muted">{{ number_format((float)($f->storage?->capacity_kg??0)) }} kg capacity · TSh {{ number_format($f->price_minor/100, 2) }} per kg per day · {{ $f->owner?->name }}</p></a>
@empty<div class="p-card">No warehouses match.</div>@endforelse
{{ $facilities->links() }}
@endsection
