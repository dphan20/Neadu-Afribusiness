@extends('producer.layout')
@section('title', $listing->title)
@section('heading', $listing->title)
@section('lead', $listing->storage?->facility_type.' · '.number_format((float)($listing->storage?->capacity_kg??0)).' kg · TSh '.number_format($listing->price_minor/100, 2).' per kg per day')
@section('body')
<form class="p-card pf" method="post" action="{{ route('producer.storage.store',$listing) }}">@csrf
<div class="row"><div><label for="q">Quantity (kg) *</label><input id="q" name="quantity_kg" type="number" step="0.001" value="{{ old('quantity_kg') }}" required></div>
<div><label for="s">From *</label><input id="s" name="starts_on" type="date" min="{{ now()->toDateString() }}" value="{{ old('starts_on') }}" required></div>
<div><label for="e">To *</label><input id="e" name="ends_on" type="date" value="{{ old('ends_on') }}" required></div></div>
<label>Payment</label><label class="check"><input type="radio" name="payment_method" value="escrow" checked> Pay now into escrow</label><label class="check"><input type="radio" name="payment_method" value="invoice"> Invoice me</label>
<p class="p-tag" id="est" hidden></p>
<div class="p-actions"><button class="button button-primary">Request storage</button></div></form>
<script>
const rate={{ (int)$listing->price_minor }}/100,q=document.getElementById('q'),s=document.getElementById('s'),e=document.getElementById('e'),est=document.getElementById('est');
function c(){if(!q.value||!s.value||!e.value)return;const d=Math.round((new Date(e.value)-new Date(s.value))/864e5)+1;if(d<1)return;est.hidden=false;est.textContent='Estimate: TSh '+Math.round(rate*q.value*d).toLocaleString()+' for '+d+' days'}
[q,s,e].forEach(x=>x.addEventListener('input',c));
</script>
@endsection
