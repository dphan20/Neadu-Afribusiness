@extends('producer.layout')
@section('title', 'Coming soon')
@section('heading', 'Not switched on yet')
@section('lead', 'This feature is part of a later release.')
@section('body')
<div class="p-card"><p>The <b>{{ str_replace('_', ' ', $feature) }}</b> feature is switched off. An administrator can turn it on with <code>php artisan neas:flag {{ $feature }} on</code>.</p><a class="button button-primary" href="{{ route('producer.home') }}">Back to overview</a></div>
@endsection
