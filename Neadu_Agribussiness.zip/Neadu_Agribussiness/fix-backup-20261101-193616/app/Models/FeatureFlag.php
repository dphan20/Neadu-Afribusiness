<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FeatureFlag extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['enabled' => 'boolean'];
    }

    /** NFR-M3: R2/R3 features are dark until their flag is switched on. */
    public static function isEnabled(string $key): bool
    {
        $row = static::query()->where('key', $key)->first();

        // An explicit row always wins. With no row, features are on while developing/testing and dark in production.
        return $row !== null ? (bool) $row->enabled : app()->environment('local', 'testing');
    }
}
