<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BuyerChatController;
use App\Http\Controllers\ChatMessageController;
use App\Http\Controllers\BuyerContractController;
use App\Http\Controllers\BuyerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SeoController;
use App\Http\Controllers\Expert\ExpertController;
use App\Http\Controllers\Producer as P;
use App\Http\Controllers\Shared\AssistantController;
use App\Http\Controllers\Shared\MeController;
use App\Http\Controllers\Shared\TourController;
use App\Http\Controllers\Trainer\TrainerController;
use Illuminate\Support\Facades\Route;

Route::view('/', 'welcome')->name('home');
Route::get('/robots.txt', [SeoController::class, 'robots'])->name('seo.robots');
Route::get('/sitemap.xml', [SeoController::class, 'sitemap'])->name('seo.sitemap');
Route::get('/login', [AuthController::class, 'loginForm'])->middleware('guest')->name('login');
Route::post('/login', [AuthController::class, 'login'])->middleware(['guest', 'throttle:login'])->name('login.store');
Route::get('/register', [AuthController::class, 'registerForm'])->middleware('guest')->name('register');
Route::post('/register', [AuthController::class, 'register'])->middleware(['guest', 'throttle:4,1'])->name('register.store');
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');
Route::post('/role/switch', [AuthController::class, 'switchRole'])->middleware(['auth', 'active'])->name('role.switch');

Route::middleware(['auth', 'active'])->group(function (): void {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/workspace/{section}', [DashboardController::class, 'section'])->name('workspace.section');
});

/* ------------------------------------------------------------------------------------------------------------------
 | Pages every signed-in role shares: notifications, chat, wallet, profile, settings, help, alerts, weather, delivery.
 * ---------------------------------------------------------------------------------------------------------------- */
Route::prefix('me')->name('me.')->middleware(['auth', 'active'])->group(function (): void {
    Route::get('/notifications', [MeController::class, 'notifications'])->name('notifications');                  // S-43

    Route::get('/chat/new', [P\ChatController::class, 'compose'])->name('chat.new');                              // write to anyone
    Route::post('/chat/new', [P\ChatController::class, 'start'])->middleware('throttle:20,1')->name('chat.start');
    Route::get('/chat', [P\ChatController::class, 'index'])->name('chat.index');                                  // S-42 / COM-01
    Route::get('/chat/{conversation}', [P\ChatController::class, 'show'])->name('chat.show');
    Route::post('/chat/{conversation}', [P\ChatController::class, 'send'])->middleware('throttle:60,1')->name('chat.send');
    Route::get('/chat/files/{message}', [P\ChatController::class, 'file'])->name('chat.file');
    Route::post('/chat/order/{order}', [P\ChatController::class, 'forOrder'])->name('chat.order');
    Route::post('/chat/listing/{listing}', [P\ChatController::class, 'forListing'])->name('chat.listing');
    // COM-01: forward / delete (any role, any chat)
    Route::get('/chat/message/{message}/forward', [ChatMessageController::class, 'forwardForm'])->name('chat.forward');
    Route::post('/chat/message/{message}/forward', [ChatMessageController::class, 'forward'])->middleware('throttle:20,1')->name('chat.forward.store');
    Route::delete('/chat/message/{message}', [ChatMessageController::class, 'destroy'])->middleware('throttle:60,1')->name('chat.message.destroy');
    Route::delete('/chat/{conversation}', [ChatMessageController::class, 'clear'])->name('chat.clear');

    Route::get('/alerts', [P\PriceAlertController::class, 'index'])->name('alerts.index');                        // PRC-03
    Route::post('/alerts', [P\PriceAlertController::class, 'store'])->name('alerts.store');
    Route::post('/alerts/{alert}/toggle', [P\PriceAlertController::class, 'toggle'])->name('alerts.toggle');
    Route::delete('/alerts/{alert}', [P\PriceAlertController::class, 'destroy'])->name('alerts.destroy');

    Route::get('/ask', [AssistantController::class, 'index'])->name('ask');                                       // Ask AI (photo + question)
    Route::post('/ask', [AssistantController::class, 'send'])->middleware('throttle:12,1')->name('ask.send');
    Route::post('/ask/stream', [AssistantController::class, 'stream'])->middleware('throttle:20,1')->name('ask.stream');   // live answer, can be stopped
    Route::delete('/ask', [AssistantController::class, 'clear'])->middleware('throttle:10,1')->name('ask.clear');          // delete all answers
    Route::delete('/ask/{query}', [AssistantController::class, 'destroy'])->middleware('throttle:60,1')->name('ask.destroy'); // delete one
    Route::get('/ask/{query}/photo', [AssistantController::class, 'photo'])->name('ask.photo');

    Route::get('/weather', [P\WeatherController::class, 'index'])->name('weather');                               // WTH-01..03

    Route::get('/deliveries/{delivery}', [P\DeliveryController::class, 'show'])->name('delivery.show');           // S-18
    Route::get('/deliveries/{delivery}/track', [P\DeliveryController::class, 'track'])->name('delivery.track');

    Route::get('/profile', [MeController::class, 'profile'])->name('profile');                                    // S-44
    Route::post('/profile/documents', [MeController::class, 'uploadDocument'])->middleware('throttle:10,1')->name('documents.store');
    Route::get('/documents/{document}', [MeController::class, 'document'])->name('documents');
    Route::get('/wallet', [MeController::class, 'wallet'])->name('wallet');                                       // S-45
    Route::post('/wallet/payout', [MeController::class, 'payout'])->middleware('throttle:10,1')->name('payout');
    Route::get('/settings', [MeController::class, 'settings'])->name('settings');                                 // S-46
    Route::put('/settings', [MeController::class, 'updateSettings'])->name('settings.update');
    Route::post('/settings/password', [MeController::class, 'changePin'])->middleware('throttle:5,1')->name('pin');
    Route::get('/settings/export', [MeController::class, 'export'])->name('export');
    Route::delete('/settings/account', [MeController::class, 'destroy'])->middleware('throttle:3,1')->name('delete');
    Route::get('/identity', [MeController::class, 'identity'])->name('identity');                                // ACC-03
    Route::post('/identity', [MeController::class, 'verifyIdentity'])->middleware('throttle:5,1')->name('identity.verify');
    Route::get('/storage-receipts/{booking}', [MeController::class, 'storageReceipt'])->middleware('feature:storage_receipt')->name('storage.receipt');
    Route::get('/help', [MeController::class, 'help'])->name('help');                                             // S-47
});

/* Agri-tours (S-28): anyone signed in can browse and book; trainers manage theirs under /trainer. */
Route::prefix('tours')->name('tours.')->middleware(['auth', 'active', 'feature:tours'])->group(function (): void {
    Route::get('/', [TourController::class, 'index'])->name('index');
    Route::get('/mine', [TourController::class, 'mine'])->name('mine');
    Route::get('/{listing}', [TourController::class, 'show'])->name('show');
    Route::post('/{listing}/book', [TourController::class, 'book'])->middleware('throttle:10,1')->name('book');
    Route::post('/bookings/{booking}/pay', [TourController::class, 'pay'])->middleware('throttle:10,1')->name('pay');
    Route::post('/bookings/{booking}/rate', [TourController::class, 'rate'])->name('rate');
    Route::get('/bookings/{booking}/certificate', [TourController::class, 'certificate'])->name('certificate');
});

/* Advice written by experts (readable by every signed-in role). */
Route::get('/advice', [ExpertController::class, 'feed'])->middleware(['auth', 'active'])->name('advice.feed');

/* ------------------------------------------------------------------------------------------------------------------
 | Role 1 - Producer (P) and Trader (R, who may also sell produce)
 * ---------------------------------------------------------------------------------------------------------------- */
Route::prefix('producer')->name('producer.')->middleware(['auth', 'active', 'role:P,R'])->group(function (): void {
    Route::get('/', [P\HomeController::class, 'index'])->name('home');

    // ACC-01..04
    Route::get('/phone', [P\OnboardingController::class, 'phone'])->name('phone');
    Route::post('/phone/send', [P\OnboardingController::class, 'sendOtp'])->middleware('throttle:5,1')->name('phone.send');
    Route::post('/phone/verify', [P\OnboardingController::class, 'verifyOtp'])->middleware('throttle:10,1')->name('phone.verify');
    Route::get('/identity', [P\OnboardingController::class, 'identity'])->name('identity');
    Route::post('/identity', [P\OnboardingController::class, 'verifyIdentity'])->middleware('throttle:5,1')->name('identity.verify');
    Route::get('/profile', [P\OnboardingController::class, 'profile'])->name('profile');
    Route::put('/profile', [P\OnboardingController::class, 'updateProfile'])->name('profile.update');

    // MKT-01/02/10 (listing needs a verified identity: BR-01)
    Route::get('/listings', [P\ListingController::class, 'index'])->name('listings.index');
    Route::middleware('identity')->group(function (): void {
        Route::get('/listings/create', [P\ListingController::class, 'create'])->name('listings.create');
        Route::post('/listings', [P\ListingController::class, 'store'])->name('listings.store');
        Route::get('/listings/{listing}/edit', [P\ListingController::class, 'edit'])->name('listings.edit');
        Route::put('/listings/{listing}', [P\ListingController::class, 'update'])->name('listings.update');
        Route::post('/listings/{listing}/submit', [P\ListingController::class, 'submit'])->name('listings.submit');
        Route::post('/listings/{listing}/resume', [P\ListingController::class, 'resume'])->name('listings.resume');
    });
    Route::post('/listings/{listing}/pause', [P\ListingController::class, 'pause'])->name('listings.pause');
    Route::post('/listings/{listing}/close', [P\ListingController::class, 'close'])->name('listings.close');

    // MKT-04/05/07/08/09
    Route::get('/orders', [P\OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/{order}', [P\OrderController::class, 'show'])->name('orders.show');
    Route::get('/orders/{order}/receipt', [P\OrderController::class, 'receipt'])->name('orders.receipt');
    Route::middleware('identity')->group(function (): void {
        Route::post('/orders/{order}/accept', [P\OrderController::class, 'accept'])->name('orders.accept');
        Route::post('/orders/{order}/reject', [P\OrderController::class, 'reject'])->name('orders.reject');
        Route::post('/orders/{order}/counter', [P\OrderController::class, 'counter'])->name('orders.counter');
        Route::post('/orders/{order}/ship', [P\OrderController::class, 'ship'])->name('orders.ship');
    });
    Route::post('/orders/{order}/dispute', [P\DisputeController::class, 'store'])->name('orders.dispute');
    Route::post('/disputes/{dispute}/evidence', [P\DisputeController::class, 'addEvidence'])->name('disputes.evidence');
    Route::get('/disputes/{dispute}/evidence/{index}', [P\DisputeController::class, 'file'])->whereNumber('index')->name('disputes.file');
    Route::post('/orders/{order}/rating', [P\RatingController::class, 'store'])->name('orders.rating');

    // LOG-02/04
    Route::get('/orders/{order}/delivery', [P\DeliveryController::class, 'create'])->name('delivery.create');
    Route::get('/orders/{order}/delivery/quote', [P\DeliveryController::class, 'quote'])->name('delivery.quote');
    Route::post('/orders/{order}/delivery', [P\DeliveryController::class, 'store'])->middleware('identity')->name('delivery.store');

    // STO-02/03
    Route::get('/storage', [P\StorageController::class, 'index'])->name('storage.index');
    Route::get('/storage/bookings', [P\StorageController::class, 'mine'])->name('storage.mine');
    Route::get('/storage/{listing}', [P\StorageController::class, 'show'])->name('storage.show');
    Route::post('/storage/{listing}/book', [P\StorageController::class, 'store'])->middleware('identity')->name('storage.store');
    Route::post('/storage/bookings/{booking}/cancel', [P\StorageController::class, 'cancel'])->name('storage.cancel');

    // DIA-01..04 (R2)
    Route::middleware('feature:diagnosis')->group(function (): void {
        Route::get('/diagnosis', [P\DiagnosisController::class, 'index'])->name('diagnosis.index');
        Route::get('/diagnosis/new', [P\DiagnosisController::class, 'create'])->name('diagnosis.create');
        Route::post('/diagnosis', [P\DiagnosisController::class, 'store'])->name('diagnosis.store');
        Route::get('/diagnosis/{case}', [P\DiagnosisController::class, 'show'])->name('diagnosis.show');
        Route::get('/diagnosis/{case}/photo', [P\DiagnosisController::class, 'photo'])->name('diagnosis.photo');
        Route::post('/diagnosis/{case}/chat', [P\DiagnosisController::class, 'chat'])->name('diagnosis.chat');
        Route::post('/diagnosis/{case}/escalate', [P\DiagnosisController::class, 'escalate'])->name('diagnosis.escalate');
        Route::post('/diagnosis/{case}/rate', [P\DiagnosisController::class, 'rate'])->name('diagnosis.rate');
    });

    // CRS-01..03 (R3), VOI-01..04 (R2)
    Route::middleware('feature:credit_score')->group(function (): void {
        Route::get('/credit', [P\CreditScoreController::class, 'index'])->name('credit');
        Route::post('/credit/consent', [P\CreditScoreController::class, 'consent'])->name('credit.consent');
    });
    Route::middleware('feature:voice')->group(function (): void {
        Route::get('/voice', [P\VoiceController::class, 'index'])->name('voice');
        Route::post('/voice/command', [P\VoiceController::class, 'command'])->middleware('throttle:30,1')->name('voice.command');
    });
});

/* ------------------------------------------------------------------------------------------------------------------
 | Role 2 - Buyer workspace (S-08 .. S-18, S-38/39, MKT-11, PRC-03, COM-01)
 * ---------------------------------------------------------------------------------------------------------------- */
Route::prefix('buyer')->name('buyer.')->middleware(['auth', 'active', 'role:B'])->group(function (): void {
    Route::get('/', [BuyerController::class, 'dashboard'])->name('dashboard');
    Route::get('/market', [BuyerController::class, 'market'])->name('market');                                   // S-08
    Route::get('/market/{listing}', [BuyerController::class, 'listing'])->name('listing');                       // S-09
    Route::post('/market/{listing}/favourite', [BuyerController::class, 'toggleFavourite'])->name('favourite');
    Route::post('/market/{listing}/order', [BuyerController::class, 'storeOrder'])->name('orders.store');        // S-11
    Route::get('/favourites', [BuyerController::class, 'favourites'])->name('favourites');
    Route::get('/wanted', [BuyerController::class, 'wanted'])->name('wanted');
    Route::post('/wanted', [BuyerController::class, 'storeWanted'])->name('wanted.store');
    Route::patch('/wanted/{uuid}/close', [BuyerController::class, 'closeWanted'])->name('wanted.close');
    Route::get('/alerts', [BuyerController::class, 'alerts'])->name('alerts');                                   // PRC-03
    Route::post('/alerts', [BuyerController::class, 'storeAlert'])->name('alerts.store');
    Route::delete('/alerts/{uuid}', [BuyerController::class, 'deleteAlert'])->name('alerts.delete');

    Route::get('/orders', [BuyerController::class, 'orders'])->name('orders');
    Route::get('/orders/{uuid}', [BuyerController::class, 'showOrder'])->name('orders.show');
    Route::post('/orders/{uuid}/counter', [BuyerController::class, 'respondCounter'])->name('orders.counter');
    Route::get('/orders/{uuid}/pay', [BuyerController::class, 'payForm'])->name('orders.pay');                   // S-12
    Route::post('/orders/{uuid}/pay', [BuyerController::class, 'pay'])->middleware('throttle:10,1')->name('orders.pay.store');
    Route::post('/orders/{uuid}/confirm', [BuyerController::class, 'confirm'])->middleware('throttle:20,1')->name('orders.confirm');          // S-14
    Route::get('/orders/{uuid}/dispute', [BuyerController::class, 'disputeForm'])->name('orders.dispute');       // S-15
    Route::post('/orders/{uuid}/dispute', [BuyerController::class, 'openDispute'])->middleware('throttle:10,1')->name('orders.dispute.store');
    Route::get('/orders/{uuid}/dispute/photo/{index}', [BuyerController::class, 'disputePhoto'])->whereNumber('index')->name('orders.dispute.photo');
    Route::post('/orders/{uuid}/rate', [BuyerController::class, 'rate'])->name('orders.rate');                   // S-16
    Route::get('/orders/{uuid}/delivery', [BuyerController::class, 'deliveryForm'])->name('orders.delivery');    // S-17
    Route::post('/orders/{uuid}/delivery', [BuyerController::class, 'requestDelivery'])->name('orders.delivery.store');
    Route::get('/orders/{uuid}/track', [BuyerController::class, 'track'])->name('orders.track');                 // S-18
    Route::post('/orders/{uuid}/simulate', [BuyerController::class, 'simulate'])->name('orders.simulate');       // demo only

    Route::get('/contracts', [BuyerContractController::class, 'index'])->name('contracts');                      // R3
    Route::get('/contracts/new', [BuyerContractController::class, 'create'])->name('contracts.create');          // S-38
    Route::post('/contracts', [BuyerContractController::class, 'store'])->name('contracts.store');
    Route::get('/contracts/{uuid}', [BuyerContractController::class, 'show'])->name('contracts.show');           // S-39
    Route::post('/contracts/{uuid}/otp', [BuyerContractController::class, 'sendOtp'])->middleware('throttle:5,1')->name('contracts.otp');
    Route::post('/contracts/{uuid}/sign', [BuyerContractController::class, 'sign'])->middleware('throttle:10,1')->name('contracts.sign');

    Route::get('/chat', [BuyerChatController::class, 'index'])->name('chat');                                    // COM-01
    Route::post('/chat/start', [BuyerChatController::class, 'start'])->name('chat.start');
    Route::get('/chat/{uuid}', [BuyerChatController::class, 'show'])->name('chat.show');
    Route::post('/chat/{uuid}', [BuyerChatController::class, 'send'])->name('chat.send');
});

/* ------------------------------------------------------------------------------------------------------------------
 | Role 3 - Expert (E): case queue, AI corrections, advice
 * ---------------------------------------------------------------------------------------------------------------- */
Route::prefix('expert')->name('expert.')->middleware(['auth', 'active', 'role:E'])->group(function (): void {
    Route::get('/', [ExpertController::class, 'queue'])->name('queue');                                           // S-37
    Route::get('/cases/{case}', [ExpertController::class, 'show'])->name('case');
    Route::get('/cases/{case}/photo', [ExpertController::class, 'photo'])->name('photo');
    Route::post('/cases/{case}/reply', [ExpertController::class, 'reply'])->middleware('throttle:30,1')->name('reply');
    Route::get('/advice', [ExpertController::class, 'advice'])->name('advice');
    Route::post('/advice', [ExpertController::class, 'advicePublish'])->middleware('throttle:10,1')->name('advice.publish');
    Route::delete('/advice/{post}', [ExpertController::class, 'adviceDelete'])->name('advice.delete');
});

/* ------------------------------------------------------------------------------------------------------------------
 | Role 4 - Trainer / entrepreneur (G): agri-tours (R2 feature flag "tours")
 * ---------------------------------------------------------------------------------------------------------------- */
Route::prefix('trainer')->name('trainer.')->middleware(['auth', 'active', 'role:G', 'feature:tours'])->group(function (): void {
    Route::get('/', [TrainerController::class, 'tours'])->name('tours');                                          // S-29
    Route::get('/tours/new', [TrainerController::class, 'form'])->name('tours.create');
    Route::post('/tours', [TrainerController::class, 'save'])->name('tours.store');
    Route::get('/tours/{listing}/edit', [TrainerController::class, 'form'])->name('tours.edit');
    Route::put('/tours/{listing}', [TrainerController::class, 'save'])->name('tours.update');
    Route::get('/tours/{listing}/attendees', [TrainerController::class, 'attendees'])->name('tours.attendees');
    Route::post('/tours/{listing}/message', [TrainerController::class, 'groupMessage'])->middleware('throttle:10,1')->name('tours.message');
    Route::post('/tours/{listing}/complete', [TrainerController::class, 'complete'])->name('tours.complete');
    Route::post('/tours/{listing}/close', [TrainerController::class, 'close'])->name('tours.close');
});

// Role files. The NeAS console has its own sign-in and guard (routes/admin.php).
require __DIR__.'/transporter.php';
require __DIR__.'/landwarehouse.php';
require __DIR__.'/admin.php';
