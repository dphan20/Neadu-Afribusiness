<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="color-scheme" content="light dark">
    <meta name="theme-color" content="#1B6B3A">
    @php
        $seoTitle = trim($__env->yieldContent('title', 'NeAS')).' · NeAS';
        $seoDesc = trim($__env->yieldContent('meta_description', 'NeAS connects Tanzanian farmers, buyers, transporters, warehouses and experts with secure escrow payments, verified participants and fast AI help in Kiswahili and English.'));
        $seoRobots = trim($__env->yieldContent('robots', request()->routeIs('home') ? 'index,follow,max-image-preview:large' : 'noindex,follow'));
        $seoUrl = request()->routeIs('home') ? route('home') : url()->current();
    @endphp
    <title>{{ $seoTitle }}</title>
    <meta name="description" content="{{ $seoDesc }}">
    <meta name="robots" content="{{ $seoRobots }}">
    <link rel="canonical" href="{{ $seoUrl }}">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="NeAS · Neadu Agribusiness System">
    <meta property="og:title" content="{{ $seoTitle }}">
    <meta property="og:description" content="{{ $seoDesc }}">
    <meta property="og:url" content="{{ $seoUrl }}">
    <meta property="og:locale" content="{{ app()->getLocale() === 'sw' ? 'sw_TZ' : 'en_TZ' }}">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="{{ $seoTitle }}">
    <meta name="twitter:description" content="{{ $seoDesc }}">
    @include('layouts.partials.assets')
    @include('layouts.partials.pwa')
    @stack('head')
</head>
<body>
    <a class="skip-link" href="#main-content">Skip to main content</a>
    <header class="site-header">
        <a class="brand" href="{{ route('home') }}" aria-label="NeAS home">
            <span class="brand-mark">N</span>
            <span>NeAS<small>Neadu Agribusiness System</small></span>
        </a>
        <div class="header-actions">
            @auth
                @if (auth()->user()->roleAssignments->where('role', '!=', 'A')->count() > 1)
                    <form method="post" action="{{ route('role.switch') }}" class="role-switch">
                        @csrf
                        <label class="sr-only" for="active-role">Switch workspace</label>
                        <select id="active-role" name="role" onchange="this.form.submit()">
                            @foreach (auth()->user()->roleAssignments->where('role', '!=', 'A') as $assignment)
                                @php($assignedRole = \App\Enums\UserRole::tryFrom($assignment->role))
                                @if ($assignedRole)
                                    <option value="{{ $assignedRole->value }}" @selected(session('active_role') === $assignedRole->value)>
                                        {{ $assignedRole->label() }}
                                    </option>
                                @endif
                            @endforeach
                        </select>
                    </form>
                @endif
                <a class="header-link" href="{{ route('dashboard') }}">Workspace</a>
                <a class="header-link" href="{{ route('me.ask') }}">@include('layouts.partials.icon-sparkles')<span class="label">Ask AI</span></a>
                <form method="post" action="{{ route('logout') }}">
                    @csrf
                    <button class="button button-quiet button-small" type="submit">Sign out</button>
                </form>
            @else
                <a class="header-link" href="{{ route('login') }}">Sign in</a>
                <a class="button button-primary button-small" href="{{ route('register') }}">Create account</a>
            @endauth
        </div>
    </header>

    @if (session('status'))
        <div class="flash flash-success" role="status">{{ session('status') }}</div>
    @endif
    @if ($errors->any())
        <div class="flash flash-error" role="alert">
            <strong>Please check the form:</strong>
            <ul>@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
        </div>
    @endif

    <div id="main-content" tabindex="-1">
        @yield('content')
    </div>

    <footer class="site-footer">
        <span>NeAS · Tanzania</span>
        <span>Protected marketplace · Secure escrow · Built for every role</span>
    </footer>
    @include('layouts.partials.photo-picker-js')
    @include('layouts.partials.ai-widget')
</body>
</html>
