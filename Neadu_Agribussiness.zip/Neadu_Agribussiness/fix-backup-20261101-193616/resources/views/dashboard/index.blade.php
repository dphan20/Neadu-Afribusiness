@extends('layouts.app')

@section('title', $role->label().' workspace')

@section('content')
<main class="workspace-shell">
    <aside class="workspace-sidebar">
        <div class="workspace-person">
            <span class="avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</span>
            <span><b>{{ auth()->user()->name }}</b><small>{{ $role->label() }}</small></span>
        </div>
        <nav class="workspace-nav" aria-label="Workspace navigation">
            <a class="active" href="{{ route('dashboard') }}"><span class="nav-mark">01</span>Overview</a>
            @foreach ($navigation as $key => $item)
                <a href="{{ route('workspace.section', $key) }}"><span class="nav-mark">{{ str_pad((string) $loop->iteration + 1, 2, '0', STR_PAD_LEFT) }}</span>{{ $item['label'] }}</a>
            @endforeach
        </nav>
        <div class="sidebar-note"><b>Need a hand?</b><p>Support is available for account and transaction questions.</p><a href="mailto:support@neas.example">Contact support</a></div>
    </aside>

    <section class="workspace-main">
        <div class="workspace-heading">
            <div><span class="eyebrow">{{ $role->swahiliLabel() }}</span><h1>Habari, {{ explode(' ', auth()->user()->name)[0] }}</h1><p>Your workspace at a glance. Choose a section to manage today's work.</p></div>
            <span class="status-chip {{ auth()->user()->isIdentityVerified() ? 'status-good' : 'status-warn' }}">
                <span class="status-dot"></span>{{ auth()->user()->isIdentityVerified() ? 'Identity verified' : 'Identity review required' }}
            </span>
        </div>

        <div class="metric-grid">
            @foreach ($metrics as $metric)
                <article class="metric-card metric-{{ $metric['tone'] }}">
                    <span class="metric-label">{{ $metric['label'] }}</span>
                    <strong>{{ $metric['value'] }}</strong>
                    <span class="metric-caption">{{ $role->label() }} workspace</span>
                </article>
            @endforeach
        </div>

        @php($tools = [
            'P' => ['producer.home', 'PRODUCER TOOLS', 'Sell, ship, store and get advice', 'Open producer workspace', 'Listings, orders, delivery, storage, diagnosis, alerts, weather'],
            'E' => ['expert.dashboard', 'EXPERT TOOLS', 'Answer cases and publish advice', 'Open expert workspace', 'Case queue, AI corrections, advice, consultation earnings'],
            'G' => ['trainer.tours', 'TRAINER TOOLS', 'Run agri-tours', 'Open trainer workspace', 'Create tours, manage attendees, certificates, payouts'],
            'L' => ['landowner.listings', 'LAND OWNER TOOLS', 'List land and answer enquiries', 'Open land workspace', 'Farmland and sites, title documents, enquiries, offers, lease drafts'],
            'W' => ['warehouse.facilities', 'WAREHOUSE TOOLS', 'Fill your storage', 'Open warehouse workspace', 'Facilities, booking requests, receipts, expiry alerts, payouts'],
            'T' => ['transporter.home', 'TRANSPORTER TOOLS', 'Find jobs and drive trips', 'Open transporter workspace', 'Vehicles, jobs, trip mode with GPS, delivery proof'],
        ])
        @if (isset($tools[$role->value]) && \Illuminate\Support\Facades\Route::has($tools[$role->value][0]))
            @php([$toolRoute, $toolEyebrow, $toolTitle, $toolCta, $toolText] = $tools[$role->value])
            <div class="panel" style="margin-bottom:14px"><div class="panel-heading"><div><span class="eyebrow">{{ $toolEyebrow }}</span><h2>{{ $toolTitle }}</h2></div></div>
                <div class="action-grid"><a class="action-card" href="{{ route($toolRoute) }}"><span><b>{{ $toolCta }}</b><small>{{ $toolText }}</small></span><span class="action-arrow">→</span></a></div></div>
        @endif

        <div class="panel" style="margin-bottom:14px"><div class="panel-heading"><div><span class="eyebrow">AI ASSISTANT</span><h2>Ask about anything you can photograph</h2></div></div>
            <div class="action-grid"><a class="action-card" href="{{ route('me.ask') }}"><span><b>Ask AI</b><small>Take a photo of a plant, animal, fish, produce, machine or land and ask your question</small></span><span class="action-arrow">→</span></a></div></div>

        <div class="workspace-columns">
            <section class="panel panel-main">
                <div class="panel-heading"><div><span class="eyebrow">YOUR WORKSPACE</span><h2>Get things moving</h2></div><span class="panel-count">{{ count($navigation) }} sections</span></div>
                <div class="action-grid">
                    @foreach ($navigation as $key => $item)
                        <a class="action-card" href="{{ route('workspace.section', $key) }}">
                            <span class="action-index">{{ str_pad((string) $loop->iteration, 2, '0', STR_PAD_LEFT) }}</span>
                            <span><b>{{ $item['label'] }}</b><small>Open {{ strtolower($item['label']) }} workspace</small></span>
                            <span class="action-arrow" aria-hidden="true">→</span>
                        </a>
                    @endforeach
                </div>
            </section>
            <aside class="panel guidance-panel">
                <span class="guidance-icon">N</span>
                <span class="eyebrow">ACCOUNT CHECKLIST</span>
                <h2>Keep your account ready</h2>
                <p>Complete identity verification before listing produce, accepting orders or receiving payouts.</p>
                <div class="check-row"><span class="{{ auth()->user()->phone_verified_at ? 'check-done' : 'check-pending' }}">{{ auth()->user()->phone_verified_at ? '✓' : '·' }}</span><span><b>Phone number</b><small>{{ auth()->user()->phone_verified_at ? 'Verified' : 'Verification required' }}</small></span></div>
                <div class="check-row"><span class="{{ auth()->user()->isIdentityVerified() ? 'check-done' : 'check-pending' }}">{{ auth()->user()->isIdentityVerified() ? '✓' : '·' }}</span><span><b>Identity</b><small>{{ auth()->user()->isIdentityVerified() ? 'Verified' : 'NIDA review required' }}</small></span></div>
                <a class="text-link" href="{{ route('workspace.section', 'profile') }}">Review my profile <span aria-hidden="true">→</span></a>
            </aside>
        </div>
    </section>
</main>
@endsection
