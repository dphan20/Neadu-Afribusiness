@extends('layouts.app')

@section('title', $title)

@section('content')
<main class="workspace-shell">
    <aside class="workspace-sidebar">
        <div class="workspace-person">
            <span class="avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</span>
            <span><b>{{ auth()->user()->name }}</b><small>{{ $role->label() }}</small></span>
        </div>
        <nav class="workspace-nav" aria-label="Workspace navigation">
            <a href="{{ route('dashboard') }}"><span class="nav-mark">01</span>Overview</a>
            @foreach ($navigation as $key => $item)
                <a class="{{ $section === $key ? 'active' : '' }}" href="{{ route('workspace.section', $key) }}"><span class="nav-mark">{{ str_pad((string) $loop->iteration + 1, 2, '0', STR_PAD_LEFT) }}</span>{{ $item['label'] }}</a>
            @endforeach
        </nav>
    </aside>

    <section class="workspace-main">
        <div class="workspace-heading">
            <div><a class="back-link" href="{{ route('dashboard') }}">← Overview</a><span class="eyebrow">{{ $role->label() }} workspace</span><h1>{{ $title }}</h1><p>{{ $description }}</p></div>
            @if ($section === 'listings' && in_array($role, [\App\Enums\UserRole::Producer, \App\Enums\UserRole::LandOwner, \App\Enums\UserRole::WarehouseOwner, \App\Enums\UserRole::Trader, \App\Enums\UserRole::Trainer], true))
                <span class="status-chip status-neutral">Listing management</span>
            @endif
        </div>
        <section class="panel data-panel">
            <div class="panel-heading"><div><span class="eyebrow">RECORDS</span><h2>{{ $rows->count() }} {{ $rows->count() === 1 ? 'record' : 'records' }}</h2></div></div>
            @if ($columns === [])
                <div class="empty-state"><span class="empty-mark">i</span><h3>Conversation access is private</h3><p>Your messaging service is not connected to this workspace yet. No conversation data is displayed until it is available.</p></div>
            @elseif ($rows->isEmpty())
                <div class="empty-state"><span class="empty-mark">0</span><h3>No records to show</h3><p>There are no records for this section and account yet.</p></div>
            @else
                <div class="table-wrap">
                    <table class="data-table">
                        <thead><tr>@foreach ($columns as $column)<th scope="col">{{ $column }}</th>@endforeach</tr></thead>
                        <tbody>
                            @foreach ($rows as $row)
                                <tr>@foreach ($row as $cell)<td>{{ $cell }}</td>@endforeach</tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </section>
    </section>
</main>
@endsection
