<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Artisan;

/** Local only: one demo admin per scope. Password for all: ConsoleDemo#2026 */
class AdminDemoSeeder extends Seeder
{
    public function run(): void
    {
        foreach ([['super', '255700000008'], ['support', '255700000018'], ['verification', '255700000028'], ['finance', '255700000038']] as [$scope, $phone]) {
            Artisan::call('admin:create', [
                'name' => ucfirst($scope).' admin', 'email' => "admin.{$scope}@neas.test", '--phone' => $phone,
                '--scope' => $scope, '--password' => 'ConsoleDemo#2026',
            ]);
        }
    }
}
