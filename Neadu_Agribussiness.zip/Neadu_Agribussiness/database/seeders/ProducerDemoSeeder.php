<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Enums\ListingType;
use App\Models\{Crop, District, FeatureFlag, Listing, Market, Order, PriceRecord, ProduceListing, Region, RoleProfile, StorageFacility, Unit, User, Vehicle};
use Illuminate\Database\Seeder;

/** Local demo data for the Producer role. Never runs in production. Turns the R2/R3 flags on so every screen can be tried. */
class ProducerDemoSeeder extends Seeder
{
    public function run(): void
    {
        FeatureFlag::query()->update(['enabled' => true]);

        $producer = User::where('phone', '255700000000')->firstOrFail();
        $buyer = User::where('phone', '255700000001')->firstOrFail();
        $warehouse = User::where('phone', '255700000006')->firstOrFail();
        $transporter = User::where('phone', '255700000004')->firstOrFail();
        $iringa = Region::where('name', 'Iringa')->firstOrFail();
        $district = District::where('region_id', $iringa->id)->firstOrFail();
        $maize = Crop::where('slug', 'maize')->firstOrFail();
        $kg = Unit::where('code', 'kg')->firstOrFail();

        RoleProfile::updateOrCreate(['user_id' => $producer->id, 'role' => 'P'], [
            'region_id' => $iringa->id, 'district_id' => $district->id,
            'business' => ['producer_type' => 'farmer', 'crop_ids' => [$maize->id], 'farm_name' => 'Demo Farm'],
        ]);

        $listing = Listing::firstOrCreate(['user_id' => $producer->id, 'title' => 'Maize - Iringa'], [
            'type' => ListingType::Produce, 'region_id' => $iringa->id, 'district_id' => $district->id, 'lat' => -7.77, 'lng' => 35.69,
            'price_minor' => 1_200_00, 'status' => 'active', 'photos' => [],
        ]);
        ProduceListing::firstOrCreate(['listing_id' => $listing->id], [
            'category' => 'crop', 'crop_id' => $maize->id, 'unit_id' => $kg->id, 'quantity' => 5000, 'quality' => 'standard', 'grade' => 'A', 'min_order' => 50,
        ]);

        Order::firstOrCreate(['buyer_id' => $buyer->id, 'seller_id' => $producer->id, 'listing_id' => $listing->id], [
            'quantity' => 200, 'unit_price_minor' => 1_200_00, 'subtotal_minor' => 240_000_00, 'status' => 'pending', 'accept_by' => now()->addHours(24),
        ]);

        $store = Listing::firstOrCreate(['user_id' => $warehouse->id, 'title' => 'Iringa Cold Store'], [
            'type' => ListingType::Storage, 'region_id' => $iringa->id, 'district_id' => $district->id,
            'price_minor' => 5_00, 'status' => 'active', 'photos' => [],
        ]);
        StorageFacility::firstOrCreate(['listing_id' => $store->id], ['facility_type' => 'Dry warehouse', 'capacity_kg' => 50000]);

        Vehicle::firstOrCreate(['plate' => 'T123DEMO'], ['user_id' => $transporter->id, 'type' => 'Truck', 'capacity_kg' => 3000]);

        $market = Market::where('region_id', $iringa->id)->firstOrFail();
        PriceRecord::firstOrCreate(['crop_id' => $maize->id, 'market_id' => $market->id, 'recorded_on' => now()->toDateString()], [
            'region_id' => $iringa->id, 'price_minor' => 1_250_00, 'unit_id' => $kg->id, 'source' => 'Demo',
        ]);
    }
}
