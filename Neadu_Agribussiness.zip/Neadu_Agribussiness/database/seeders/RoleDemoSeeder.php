<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Enums\ListingType;
use App\Models\{AdvicePost, Conversation, Crop, DiagnosisCase, District, Listing, Message, Region, RoleProfile, Tour, TourBooking, Unit, User};
use App\Services\LedgerService;
use Illuminate\Database\Seeder;

/**
 * Local demo data for the Expert and Trainer workspaces. Needs DemoUsersSeeder + ProducerDemoSeeder first.
 * Demo accounts (password 1234 in the seed): expert 255700000002, trainer 255700000003, transporter 255700000004.
 */
class RoleDemoSeeder extends Seeder
{
    public function run(LedgerService $ledger): void
    {
        $producer = User::where('phone', '255700000000')->firstOrFail();
        $buyer = User::where('phone', '255700000001')->firstOrFail();
        $expert = User::where('phone', '255700000002')->firstOrFail();
        $trainer = User::where('phone', '255700000003')->firstOrFail();
        $iringa = Region::where('name', 'Iringa')->firstOrFail();
        $district = District::where('region_id', $iringa->id)->firstOrFail();
        $maize = Crop::where('slug', 'maize')->firstOrFail();
        $kg = Unit::where('code', 'kg')->firstOrFail();

        RoleProfile::updateOrCreate(['user_id' => $expert->id, 'role' => 'E'], ['region_id' => $iringa->id, 'district_id' => $district->id, 'business' => ['speciality' => 'crop', 'registration' => 'DEMO-AGR-001']]);

        // ---- Expert: one open case (escalated, with a chat) and one answered case, plus published advice.
        foreach ([['Maize leaves yellowing', 'Nitrogen deficiency', 71, false], ['Tomato leaf curl', 'Tomato yellow leaf curl virus', 64, true]] as [$subject, $result, $confidence, $answered]) {
            $case = DiagnosisCase::firstOrCreate(['user_id' => $producer->id, 'subject' => $subject], [
                'photo_path' => 'diagnosis/demo.jpg', 'subject_kind' => 'crop', 'result' => $result, 'confidence' => $confidence,
                'treatment' => 'Weka mbolea ya kukuzia na fuatilia majani kwa wiki mbili.', 'prevention' => 'Zungusha mazao kila msimu.',
            ]);
            if ($case->escalated_at === null) {
                $c = Conversation::create();
                $c->participants()->syncWithoutDetaching([$producer->id, $expert->id]);
                Message::create(['conversation_id' => $c->id, 'sender_id' => $producer->id, 'kind' => 'text', 'body' => "Tafadhali nisaidie: {$subject}."]);
                $case->forceFill(['expert_id' => $expert->id, 'escalated_at' => now(), 'conversation_id' => $c->id])->save();
            }
            if ($answered && $case->expert_reply === null) {
                $case->forceFill(['expert_reply' => 'Hii ni virusi vya kujikunja majani. Ondoa mimea iliyoathirika na dhibiti wadudu weupe.', 'ai_correct' => true, 'replied_at' => now(), 'fee_minor' => 2_000_00, 'expert_rating' => 5])->save();
                $ledger->post([['account' => 'platform:float', 'debit' => 2_000_00], ['account' => 'expert:'.$expert->id, 'credit' => 2_000_00]], null, null, 'Demo consultation '.$case->uuid);
            }
        }
        AdvicePost::firstOrCreate(['expert_id' => $expert->id, 'title' => 'Maize: top-dress after the first weeding'], [
            'category' => 'crop', 'published_at' => now(), 'body' => "Apply urea or CAN about three to four weeks after planting, once the first weeding is done and the soil is moist.\nKeep the fertiliser a hand-width from the stem and cover it lightly with soil.",
        ]);

        // ---- Trainer: one tour that starts in three weeks, with a paid booking from the buyer.
        $tourListing = Listing::firstOrCreate(['user_id' => $trainer->id, 'title' => 'Iringa maize and dairy study tour'], [
            'type' => ListingType::Tour, 'region_id' => $iringa->id, 'district_id' => $district->id, 'price_minor' => 85_000_00, 'status' => 'active', 'photos' => [],
        ]);
        Tour::firstOrCreate(['listing_id' => $tourListing->id], [
            'route' => 'Iringa town - Kalenga - Mufindi', 'starts_at' => now()->addWeeks(3), 'ends_at' => now()->addWeeks(3)->addDays(2), 'seats' => 20,
            'itinerary' => ['stops' => ['Day 1: Iringa seed farm and storage facility', 'Day 2: Mufindi dairy cooperative', 'Day 3: Market visit and Q&A'], 'goals' => ['Improve post-harvest handling', 'Meet buyers and cooperatives']],
        ]);
        if (! TourBooking::where('listing_id', $tourListing->id)->where('user_id', $buyer->id)->exists()) {
            $amount = 85_000_00 * 2;
            TourBooking::create(['listing_id' => $tourListing->id, 'user_id' => $buyer->id, 'seats' => 2, 'amount_minor' => $amount, 'status' => 'paid']);
            $ledger->post([['account' => 'external:payment', 'debit' => $amount], ['account' => 'escrow', 'credit' => $amount]], null, null, 'Demo tour booking');
        }
    }
}
