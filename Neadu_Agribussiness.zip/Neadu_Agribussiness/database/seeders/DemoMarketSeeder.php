<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Crop;
use App\Models\District;
use App\Models\Listing;
use App\Models\Market;
use App\Models\PriceRecord;
use App\Models\ProduceListing;
use App\Models\Region;
use App\Models\Unit;
use App\Models\User;
use App\Models\Vehicle;
use Illuminate\Database\Seeder;

/** Demo-only marketplace content so the buyer screens are not empty. Never run in production. */
class DemoMarketSeeder extends Seeder
{
    public function run(): void
    {
        $producer = User::query()->whereHas('roleAssignments', fn ($q) => $q->where('role', 'P'))->first();
        $transporter = User::query()->whereHas('roleAssignments', fn ($q) => $q->where('role', 'T'))->first();
        if ($producer === null) {
            return;
        }
        $kg = Unit::query()->where('code', 'kg')->first();
        $gunia = Unit::query()->where('code', 'gunia')->first();
        if ($kg === null) {
            return;
        }

        $rows = [
            ['Fresh white maize, Iringa', 'maize', 'Iringa', 'Iringa Rural', -7.7700, 35.6900, 110_000, 5000, $kg, 'A'],
            ['Kilombero rice, polished', 'rice', 'Morogoro', 'Kilombero', -8.0900, 36.6800, 260_000, 2000, $kg, 'A'],
            ['Dry beans (njahi)', 'beans', 'Arusha', 'Meru', -3.3800, 36.8500, 320_000, 800, $kg, 'B'],
            ['Ripe tomatoes, crates', 'tomatoes', 'Mbeya', 'Rungwe', -9.2500, 33.6400, 9_000_000, 120, $gunia ?? $kg, 'B'],
        ];
        foreach ($rows as [$title, $slug, $regionName, $districtName, $lat, $lng, $price, $qty, $unit, $grade]) {
            $crop = Crop::query()->where('slug', $slug)->first();
            $region = Region::query()->where('name', $regionName)->first();
            if ($crop === null || $region === null) {
                continue;
            }
            $district = District::firstOrCreate(['region_id' => $region->id, 'name' => $districtName]);
            $listing = Listing::query()->firstOrNew(['user_id' => $producer->id, 'title' => $title]);
            if ($listing->exists) {
                continue;
            }
            $listing->forceFill([
                'type' => 'produce', 'region_id' => $region->id, 'district_id' => $district->id, 'lat' => $lat, 'lng' => $lng,
                'price_minor' => $price, 'status' => 'active', 'verified' => true, 'verified_at' => now(),
            ])->save();
            ProduceListing::create([
                'listing_id' => $listing->id, 'crop_id' => $crop->id, 'unit_id' => $unit->id, 'quantity' => $qty, 'grade' => $grade,
                'harvest_date' => now()->subDays(10), 'quality_notes' => 'Clean, dry, sorted by hand.',
            ]);
            $market = Market::query()->where('region_id', $region->id)->first();
            if ($market !== null) {
                PriceRecord::firstOrCreate(
                    ['crop_id' => $crop->id, 'market_id' => $market->id, 'region_id' => $region->id, 'recorded_on' => now()->toDateString()],
                    ['price_minor' => (int) ($price * 0.95), 'unit_id' => $unit->id, 'source' => 'Demo market survey']
                );
            }
        }

        if ($transporter !== null) {
            Vehicle::firstOrCreate(['plate' => 'T123 DEM'], ['user_id' => $transporter->id, 'type' => 'Canter 3-tonne truck', 'capacity_kg' => 3000]);
        }
    }
}
