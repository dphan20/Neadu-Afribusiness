<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Enums\UserRole;
use App\Models\DiagnosisCase;
use App\Models\User;
use Illuminate\Database\Seeder;

/** Demo-only escalated AI cases so the expert queue is not empty. Never run in production. */
class DemoExpertSeeder extends Seeder
{
    public function run(): void
    {
        $producer = User::query()->whereHas('roleAssignments', fn ($q) => $q->where('role', UserRole::Producer->value))->first();
        if ($producer === null) {
            return;
        }
        $rows = [
            ['Maize leaves with ragged holes', 'crop', 'Fall armyworm', 58],
            ['Tomato leaves curling and yellow', 'crop', 'Tomato yellow leaf curl virus', 49],
            ['Cow with swollen udder, reduced milk', 'livestock', 'Mastitis', 62],
            ['Chickens with watery droppings', 'livestock', 'Newcastle disease', 44],
            ['Tilapia gasping at the pond surface', 'fisheries', 'Low dissolved oxygen', 53],
            ['Rice leaves with brown diamond spots', 'crop', 'Rice blast', 66],
        ];
        foreach ($rows as [$subject, $domain, $result, $confidence]) {
            DiagnosisCase::query()->firstOrCreate(
                ['user_id' => $producer->id, 'subject' => $subject],
                ['photo_path' => 'demo/case.jpg', 'domain' => $domain, 'result' => $result, 'ai_result' => $result, 'confidence' => $confidence, 'status' => 'escalated']
            );
        }
    }
}
