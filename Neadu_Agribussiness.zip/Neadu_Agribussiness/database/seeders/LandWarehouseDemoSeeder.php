<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Enums\ListingType;
use App\Models\{District, LandEnquiry, LandPlot, Listing, Region, StorageBooking, StorageFacility, User};
use App\Services\LedgerService;
use Illuminate\Database\Seeder;

/** Local demo data for the Land owner (…05) and Warehouse owner (…06). Needs DemoUsersSeeder + ProducerDemoSeeder first. */
class LandWarehouseDemoSeeder extends Seeder
{
    public function run(LedgerService $ledger): void
    {
        $producer = User::where('phone', '255700000000')->firstOrFail();
        $buyer = User::where('phone', '255700000001')->firstOrFail();
        $landlord = User::where('phone', '255700000005')->firstOrFail();
        $warehouse = User::where('phone', '255700000006')->firstOrFail();
        $iringa = Region::where('name', 'Iringa')->firstOrFail();
        $district = District::where('region_id', $iringa->id)->firstOrFail();

        $land = Listing::firstOrCreate(['user_id' => $landlord->id, 'title' => '12 acres farmland near Iringa'], [
            'type' => ListingType::Land, 'region_id' => $iringa->id, 'district_id' => $district->id, 'lat' => -7.78, 'lng' => 35.70,
            'price_minor' => 600_000_00, 'status' => 'active', 'photos' => [],
        ]);
        $land->forceFill(['verified' => true, 'verified_at' => now()])->save();
        LandPlot::firstOrCreate(['listing_id' => $land->id], ['size_acres' => 12, 'tenure' => 'lease', 'rent_period' => 'year', 'site_type' => 'farmland', 'soil' => 'Loam', 'water' => 'Borehole', 'road_access' => true]);
        if (! LandEnquiry::where('listing_id', $land->id)->exists()) {
            LandEnquiry::create(['listing_id' => $land->id, 'user_id' => $buyer->id, 'kind' => 'offer', 'offer_minor' => 550_000_00, 'message' => 'I would lease it for three years.']);
            LandEnquiry::create(['listing_id' => $land->id, 'user_id' => $producer->id, 'kind' => 'visit', 'visit_on' => now()->addDays(10)->toDateString(), 'message' => 'Can I see the plot?']);
        }

        $store = Listing::where('user_id', $warehouse->id)->where('title', 'Iringa Cold Store')->first();
        if ($store !== null) {
            StorageFacility::updateOrCreate(['listing_id' => $store->id], ['facility_type' => 'grain_storage', 'capacity_kg' => 50000, 'conditions' => ['dry', 'fumigation'], 'security' => 'Guarded, CCTV']);
            if (! StorageBooking::where('facility_listing_id', $store->id)->where('user_id', $producer->id)->exists()) {
                $price = 5_00 * 2_000 * 30; // 5.00 TSh per kg per day x 2,000 kg x 30 days
                StorageBooking::create([
                    'facility_listing_id' => $store->id, 'user_id' => $producer->id, 'quantity_kg' => 2000, 'starts_on' => now()->addDays(2)->toDateString(),
                    'ends_on' => now()->addDays(31)->toDateString(), 'price_minor' => $price, 'status' => 'requested', 'payment_method' => 'escrow', 'payment_state' => 'held',
                ]);
                $ledger->post([['account' => 'external:payment', 'debit' => $price], ['account' => 'escrow', 'credit' => $price]], null, null, 'Demo storage booking');
            }
        }
    }
}
