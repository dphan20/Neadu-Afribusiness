<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Enums\UserRole;
use App\Models\User;
use App\Models\UserRoleAssignment;
use Illuminate\Database\Seeder;

/** One demo user per role in SRS 2.2, including Trainer (G). Demo PIN: 1234. Never run in production. */
class DemoUsersSeeder extends Seeder
{
    public function run(): void
    {
        foreach (UserRole::cases() as $i => $role) {
            $u = User::firstOrCreate(['phone' => '25570000000'.$i], ['name' => 'Demo '.$role->name, 'username' => strtolower($role->name)]);
            $u->forceFill(['pin_hash' => '1234', 'verification_level' => 'full', 'phone_verified_at' => now(), 'verified_at' => now(), 'nida_number' => '1990010100000'.$i])->save();
            UserRoleAssignment::firstOrCreate(['user_id' => $u->id, 'role' => $role->value]);
        }
    }
}
