<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(ReferenceDataSeeder::class);
        // Demo accounts and sample data are opt-in only: NEAS_SEED_DEMO=true (never in production).
        if (! app()->isProduction() && filter_var(env('NEAS_SEED_DEMO', false), FILTER_VALIDATE_BOOL)) {
            $this->call(DemoUsersSeeder::class);
            $this->call(ProducerDemoSeeder::class);   // turns every feature flag on locally
            $this->call(AdminDemoSeeder::class);      // console admins (separate sign-in at /admin/login)
            $this->call(DemoMarketSeeder::class);
            $this->call(RoleDemoSeeder::class);       // expert and trainer demo data
            $this->call(TransporterDemoSeeder::class);
            $this->call(LandWarehouseDemoSeeder::class);
        }
    }
}
