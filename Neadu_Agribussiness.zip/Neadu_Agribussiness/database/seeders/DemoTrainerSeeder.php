<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Enums\ListingType;
use App\Enums\UserRole;
use App\Models\Listing;
use App\Models\Region;
use App\Models\Tour;
use App\Models\User;
use Illuminate\Database\Seeder;

/** Demo-only agri-tours so the trainer screens are not empty. Never run in production. */
class DemoTrainerSeeder extends Seeder
{
    public function run(): void
    {
        $trainer = User::query()->whereHas('roleAssignments', fn ($q) => $q->where('role', UserRole::Trainer->value))->first();
        if ($trainer === null) {
            return;
        }
        $rows = [
            ['Avocado orchards study tour, Njombe', 'Njombe', 'Iringa → Mufindi → Njombe', 'active', 3, 12_000_000, 20],
            ['Dairy farming one-day visit, Arusha', 'Arusha', 'Arusha → Usa River → Tengeru', 'draft', 12, 4_500_000, 30],
        ];
        foreach ($rows as [$title, $region, $route, $status, $days, $price, $seats]) {
            $listing = Listing::query()->firstOrNew(['user_id' => $trainer->id, 'title' => $title, 'type' => ListingType::Tour->value]);
            if ($listing->exists) {
                continue;
            }
            $listing->forceFill(['region_id' => Region::query()->where('name', $region)->value('id'), 'price_minor' => $price, 'status' => $status, 'photos' => []])->save();
            Tour::create([
                'listing_id' => $listing->id, 'route' => $route, 'starts_at' => now()->addDays($days)->setTime(7, 30), 'ends_at' => now()->addDays($days + 1)->setTime(17, 0), 'seats' => $seats,
                'description' => 'Visit working farms, meet the farmers and learn practical methods you can apply on your own land.',
                'meeting_point' => 'Main bus stand, 7:00 am', 'hold_minutes' => 30,
                'itinerary' => [['title' => 'Departure and introductions', 'details' => 'Meet at the bus stand and travel together.'], ['title' => 'Farm visit and demonstration', 'details' => 'Hands-on session with the farm owner.'], ['title' => 'Market linkages and wrap-up', 'details' => 'Discuss pricing, buyers and next steps.']],
                'learning_goals' => ['Orchard layout and spacing', 'Pest and disease basics', 'Finding reliable buyers'],
            ]);
        }
    }
}
