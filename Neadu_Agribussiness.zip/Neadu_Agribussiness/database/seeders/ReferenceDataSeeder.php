<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\{Category, Crop, District, FeatureFlag, FeeRule, Market, Region, Unit};
use Illuminate\Database\Seeder;

class ReferenceDataSeeder extends Seeder
{
    public function run(): void
    {
        foreach (['Dar es Salaam', 'Iringa', 'Arusha', 'Mbeya', 'Morogoro', 'Dodoma', 'Mwanza'] as $r) {
            $region = Region::firstOrCreate(['name' => $r]);
            Market::firstOrCreate(['region_id' => $region->id, 'name' => $r.' Central Market']);
        }
        $districts = ['Dar es Salaam' => ['Ilala', 'Kinondoni', 'Temeke'], 'Iringa' => ['Iringa Rural', 'Kilolo', 'Mufindi'], 'Arusha' => ['Arusha City', 'Meru', 'Karatu'],
            'Mbeya' => ['Mbeya Rural', 'Rungwe', 'Mbarali'], 'Morogoro' => ['Morogoro Rural', 'Kilosa', 'Mvomero'], 'Dodoma' => ['Dodoma City', 'Chamwino', 'Kongwa'], 'Mwanza' => ['Ilemela', 'Nyamagana', 'Magu']];
        foreach ($districts as $r => $names) {
            $region = Region::where('name', $r)->first();
            foreach ($names as $n) {
                District::firstOrCreate(['region_id' => $region->id, 'name' => $n]);
            }
        }
        $cat = Category::firstOrCreate(['slug' => 'cereals'], ['name_sw' => 'Nafaka', 'name_en' => 'Cereals']);
        $leg = Category::firstOrCreate(['slug' => 'legumes'], ['name_sw' => 'Jamii ya kunde', 'name_en' => 'Legumes']);
        $veg = Category::firstOrCreate(['slug' => 'vegetables'], ['name_sw' => 'Mboga', 'name_en' => 'Vegetables']);
        foreach ([['maize', 'Mahindi', 'Maize', $cat], ['rice', 'Mchele', 'Rice', $cat], ['beans', 'Maharage', 'Beans', $leg], ['tomatoes', 'Nyanya', 'Tomatoes', $veg]] as [$s, $sw, $en, $c]) {
            Crop::firstOrCreate(['slug' => $s], ['category_id' => $c->id, 'name_sw' => $sw, 'name_en' => $en]);
        }
        $lv = Category::firstOrCreate(['slug' => 'livestock'], ['name_sw' => 'Mifugo', 'name_en' => 'Livestock']);
        $fs = Category::firstOrCreate(['slug' => 'fish'], ['name_sw' => 'Samaki', 'name_en' => 'Fish']);
        foreach ([['cattle', 'Ng\'ombe', 'Cattle', $lv], ['goats', 'Mbuzi', 'Goats', $lv], ['chicken', 'Kuku', 'Chicken', $lv], ['tilapia', 'Sato', 'Tilapia', $fs], ['sardines', 'Dagaa', 'Sardines (dagaa)', $fs]] as [$s, $sw, $en, $c]) {
            Crop::firstOrCreate(['slug' => $s], ['category_id' => $c->id, 'name_sw' => $sw, 'name_en' => $en]);
        }
        // kg_factor_milli: 1 kg = 1000. Gunia and crate sizes are assumptions to confirm with the business owner.
        foreach ([['kg', 'Kilo', 'Kilogram', 1_000], ['tonne', 'Tani', 'Tonne', 1_000_000], ['gunia', 'Gunia', 'Bag (gunia, 100 kg)', 100_000],
            ['crate', 'Kreti', 'Crate (25 kg)', 25_000], ['litre', 'Lita', 'Litre', null], ['head', 'Kichwa', 'Head of livestock', null]] as [$c, $sw, $en, $f]) {
            Unit::firstOrCreate(['code' => $c], ['name_sw' => $sw, 'name_en' => $en, 'kg_factor_milli' => $f]);
        }
        // OPEN-Q2: 2.5% default until the business owner sets fee levels.
        FeeRule::firstOrCreate(['key' => 'platform_fee'], ['bps' => 250, 'note' => 'OPEN-Q2: default, set by business owner']);
        foreach (['diagnosis' => 'R2', 'voice' => 'R2', 'tours' => 'R2', 'machinery' => 'R2', 'contracts' => 'R3', 'credit_score' => 'R3', 'ussd' => 'R2', 'backhaul' => 'R3', 'storage_receipt' => 'R2', 'storage_alerts' => 'R2', 'financing' => 'R3', 'rental' => 'R3'] as $k => $rel) {
            FeatureFlag::firstOrCreate(['key' => $k], ['release' => $rel, 'enabled' => false]);
        }
    }
}
