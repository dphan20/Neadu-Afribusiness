<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Enums\ListingType;
use App\Models\{Crop, Delivery, District, FeatureFlag, Listing, Order, ProduceListing, Region, Unit, User, Vehicle};
use App\Services\LedgerService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

/** Local demo data for the Transporter role: a verified vehicle and three jobs. Never runs in production. */
class TransporterDemoSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(ReferenceDataSeeder::class);
        $this->call(DemoUsersSeeder::class);
        FeatureFlag::query()->where('key', 'backhaul')->update(['enabled' => true]);

        $driver = User::where('phone', '255700000004')->firstOrFail();
        $producer = User::where('phone', '255700000000')->firstOrFail();
        $buyer = User::where('phone', '255700000001')->firstOrFail();
        $admin = User::where('phone', '255700000008')->firstOrFail();

        $vehicle = Vehicle::firstOrCreate(['plate' => 'T123DEMO'], ['user_id' => $driver->id, 'type' => 'pickup', 'capacity_kg' => 1500, 'licence_document' => 'DL-DEMO-001']);
        $vehicle->forceFill(['verification_status' => 'verified', 'verified_at' => now(), 'verified_by' => $admin->id])->save();

        if (Delivery::query()->whereIn('status', ['requested', 'assigned'])->exists()) {
            $this->command?->info('Transport jobs already exist, none added.');

            return;
        }

        $iringa = Region::where('name', 'Iringa')->firstOrFail();
        $listing = Listing::firstOrCreate(['user_id' => $producer->id, 'title' => 'Maize - Iringa (transport demo)'], [
            'type' => ListingType::Produce, 'region_id' => $iringa->id, 'district_id' => District::where('region_id', $iringa->id)->firstOrFail()->id,
            'lat' => -7.77, 'lng' => 35.69, 'price_minor' => 1_200_00, 'status' => 'active', 'photos' => [],
        ]);
        ProduceListing::firstOrCreate(['listing_id' => $listing->id], [
            'category' => 'crop', 'crop_id' => Crop::where('slug', 'maize')->firstOrFail()->id, 'unit_id' => Unit::where('code', 'kg')->firstOrFail()->id,
            'quantity' => 5000, 'quality' => 'standard', 'grade' => 'A', 'min_order' => 50,
        ]);

        $jobs = [
            // [pickup lat, lng, drop lat, lng, km, price TSh, code, quantity kg, direct to demo driver]
            [-7.77, 35.69, -6.17, 35.74, 215.0, 45_000, '4821', 400, false],   // open job: Iringa -> Dodoma
            [-7.77, 35.69, -6.82, 37.66, 260.0, 38_000, '7305', 300, true],    // request addressed to the demo driver
            [-6.20, 35.75, -6.79, 39.28, 450.0, 60_000, '1590', 500, false],   // starts near Dodoma: shows up as back-haul
        ];
        foreach ($jobs as [$pLat, $pLng, $dLat, $dLng, $km, $tsh, $code, $qty, $direct]) {
            $subtotal = $qty * 1_200_00;
            $order = new Order();
            $order->forceFill([
                'buyer_id' => $buyer->id, 'seller_id' => $producer->id, 'listing_id' => $listing->id, 'quantity' => $qty,
                'unit_price_minor' => 1_200_00, 'subtotal_minor' => $subtotal, 'status' => 'held',
                'accept_by' => now()->addDay(), 'accepted_at' => now(), 'delivery_option' => 'transporter',
            ])->save();
            app(LedgerService::class)->post([
                ['account' => 'external:payment', 'debit' => $subtotal], ['account' => 'escrow', 'credit' => $subtotal],
            ], $order->id, null, 'Demo payment');

            Delivery::create([
                'order_id' => $order->id, 'transporter_id' => $direct ? $driver->id : null, 'booked_by' => $producer->id,
                'pickup_lat' => $pLat, 'pickup_lng' => $pLng, 'drop_lat' => $dLat, 'drop_lng' => $dLng, 'distance_km' => $km,
                'price_minor' => $tsh * 100, 'suggested_price_minor' => $tsh * 100, 'status' => 'requested', 'delivery_code_hash' => Hash::make($code),
            ]);
            $this->command?->info("Job {$km} km, TSh ".number_format($tsh)." - handover code {$code}".($direct ? ' (request for demo driver)' : ''));
        }
    }
}
