<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/** Land owner (L) and warehouse owner (W) workspaces. */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('land_enquiries')) {
            Schema::create('land_enquiries', function (Blueprint $t) { // LND-04
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('listing_id')->constrained(); $t->foreignId('user_id')->constrained();
                $t->string('kind', 8)->default('message'); // message | visit | offer
                $t->text('message')->nullable(); $t->date('visit_on')->nullable(); $t->unsignedBigInteger('offer_minor')->nullable();
                $t->string('status', 12)->default('open'); // open | accepted | declined
                $t->text('reply')->nullable(); $t->timestamp('replied_at')->nullable(); $t->timestamps();
            });
        }

        $this->add('land_plots', 'site_type', fn (Blueprint $t) => $t->string('site_type', 16)->default('farmland')); // farmland | factory | service_centre (LND-02)
        $this->add('land_plots', 'rent_period', fn (Blueprint $t) => $t->string('rent_period', 8)->nullable());          // month | year, for leases
        $this->add('listings', 'moderation_note', fn (Blueprint $t) => $t->string('moderation_note')->nullable());
        $this->add('storage_bookings', 'decided_at', fn (Blueprint $t) => $t->timestamp('decided_at')->nullable());
        $this->add('storage_bookings', 'decline_reason', fn (Blueprint $t) => $t->string('decline_reason')->nullable());
        $this->add('storage_bookings', 'grade', fn (Blueprint $t) => $t->string('grade', 16)->nullable());               // STO-04
        $this->add('storage_bookings', 'produce_note', fn (Blueprint $t) => $t->string('produce_note')->nullable());
        $this->add('storage_bookings', 'received_at', fn (Blueprint $t) => $t->timestamp('received_at')->nullable());
        $this->add('storage_bookings', 'expiry_alert_at', fn (Blueprint $t) => $t->timestamp('expiry_alert_at')->nullable()); // STO-05
        $this->add('storage_bookings', 'settled_at', fn (Blueprint $t) => $t->timestamp('settled_at')->nullable());

        foreach (['storage_receipt' => 'R2', 'storage_alerts' => 'R2'] as $key => $release) {
            DB::table('feature_flags')->insertOrIgnore(['key' => $key, 'enabled' => false, 'release' => $release, 'created_at' => now(), 'updated_at' => now()]);
        }
    }

    public function down(): void
    {
        DB::table('feature_flags')->whereIn('key', ['storage_receipt', 'storage_alerts'])->delete();
        Schema::table('storage_bookings', fn (Blueprint $t) => $t->dropColumn(['decided_at', 'decline_reason', 'grade', 'produce_note', 'received_at', 'expiry_alert_at', 'settled_at']));
        Schema::table('listings', fn (Blueprint $t) => $t->dropColumn('moderation_note'));
        Schema::table('land_plots', fn (Blueprint $t) => $t->dropColumn(['site_type', 'rent_period']));
        Schema::dropIfExists('land_enquiries');
    }

    private function add(string $table, string $column, \Closure $define): void
    {
        if (! Schema::hasColumn($table, $column)) {
            Schema::table($table, fn (Blueprint $t) => $define($t));
        }
    }
};
