<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** LOG-05 / XDV-09: who sent a GPS point, how accurate it was, and when the server confirmed it. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tracking_points', function (Blueprint $t): void {
            if (! Schema::hasColumn('tracking_points', 'driver_id')) {
                $t->foreignId('driver_id')->nullable()->constrained('users')->nullOnDelete();
            }
            if (! Schema::hasColumn('tracking_points', 'accuracy_meters')) {
                $t->decimal('accuracy_meters', 8, 2)->nullable();
            }
            if (! Schema::hasColumn('tracking_points', 'speed_kmh')) {
                $t->decimal('speed_kmh', 6, 2)->nullable();
            }
            if (! Schema::hasColumn('tracking_points', 'synced_at')) {
                $t->dateTime('synced_at')->nullable(); // null until the server has stored the point
            }
            $t->index(['delivery_id', 'recorded_at'], 'tracking_points_delivery_recorded_idx');
        });
    }

    public function down(): void
    {
        Schema::table('tracking_points', function (Blueprint $t): void {
            $t->dropIndex('tracking_points_delivery_recorded_idx');
            $t->dropConstrainedForeignId('driver_id');
            $t->dropColumn(['accuracy_meters', 'speed_kmh', 'synced_at']);
        });
    }
};
