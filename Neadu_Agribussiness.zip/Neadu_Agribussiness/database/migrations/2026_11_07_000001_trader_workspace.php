<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/** Trader / technology provider (R): fuller machine details, quote validity, and the machinery market switched on. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('machines', function (Blueprint $t): void {
            foreach ([
                'category' => fn () => $t->string('category', 32)->nullable()->index(),
                'brand' => fn () => $t->string('brand', 80)->nullable(),
                'model' => fn () => $t->string('model', 80)->nullable(),
                'year' => fn () => $t->unsignedSmallInteger('year')->nullable(),
                'stock' => fn () => $t->unsignedInteger('stock')->default(1),
                'offers' => fn () => $t->json('offers')->nullable(),               // sale | financing | rental
                'rental_rate_minor' => fn () => $t->unsignedBigInteger('rental_rate_minor')->nullable(), // per day
                'description' => fn () => $t->text('description')->nullable(),
                'brochure_path' => fn () => $t->string('brochure_path')->nullable(),
            ] as $col => $add) {
                if (! Schema::hasColumn('machines', $col)) {
                    $add();
                }
            }
        });

        Schema::table('machine_quotes', function (Blueprint $t): void {
            if (! Schema::hasColumn('machine_quotes', 'valid_until')) {
                $t->date('valid_until')->nullable();
            }
            if (! Schema::hasColumn('machine_quotes', 'decline_reason')) {
                $t->string('decline_reason', 200)->nullable();
            }
        });

        // The machinery market is part of the Trader's job; admins can still switch it off in the feature flags.
        DB::table('feature_flags')->updateOrInsert(['key' => 'machinery'], ['enabled' => true, 'release' => 'R2', 'updated_at' => now(), 'created_at' => now()]);
    }

    public function down(): void
    {
        Schema::table('machine_quotes', fn (Blueprint $t) => $t->dropColumn(['valid_until', 'decline_reason']));
        Schema::table('machines', fn (Blueprint $t) => $t->dropColumn(['category', 'brand', 'model', 'year', 'stock', 'offers', 'rental_rate_minor', 'description', 'brochure_path']));
    }
};
