<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Role 4 (Trainer / entrepreneur): agri-tour details, bookings with seat-hold timer, reviews, group chat. Safe to re-run. */
return new class extends Migration
{
    public function up(): void
    {
        $add = [
            'description' => fn (Blueprint $t) => $t->text('description')->nullable(),
            'learning_goals' => fn (Blueprint $t) => $t->json('learning_goals')->nullable(),
            'meeting_point' => fn (Blueprint $t) => $t->string('meeting_point')->nullable(),
            'hold_minutes' => fn (Blueprint $t) => $t->unsignedSmallInteger('hold_minutes')->default(30), // TUR-02: unpaid seats release after this
            'state' => fn (Blueprint $t) => $t->string('state', 10)->default('scheduled'),                  // scheduled | completed | cancelled
            'completed_at' => fn (Blueprint $t) => $t->timestamp('completed_at')->nullable(),
        ];
        foreach ($add as $col => $def) {
            if (! Schema::hasColumn('tours', $col)) {
                Schema::table('tours', fn (Blueprint $t) => $def($t));
            }
        }
        if (! Schema::hasColumn('conversations', 'tour_id')) {
            Schema::table('conversations', fn (Blueprint $t) => $t->unsignedBigInteger('tour_id')->nullable()->index());
        }
        if (! Schema::hasTable('tour_bookings')) {
            Schema::create('tour_bookings', function (Blueprint $t) {
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('tour_id')->constrained()->cascadeOnDelete(); $t->foreignId('user_id')->constrained();
                $t->unsignedSmallInteger('seats'); $t->unsignedBigInteger('total_minor'); $t->char('currency', 3)->default('TZS');
                $t->string('status', 10)->default('reserved')->index(); // reserved | paid | completed | expired | cancelled | refunded
                $t->timestamp('expires_at')->nullable(); $t->timestamp('paid_at')->nullable(); $t->boolean('attended')->default(true);
                $t->string('certificate_no')->nullable()->unique(); $t->timestamp('certificate_issued_at')->nullable();
                $t->timestamps(); $t->softDeletes();
            });
        }
        if (! Schema::hasTable('tour_reviews')) {
            Schema::create('tour_reviews', function (Blueprint $t) { // TUR-04
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('tour_id')->constrained()->cascadeOnDelete(); $t->foreignId('tour_booking_id')->constrained()->cascadeOnDelete();
                $t->foreignId('attendee_id')->constrained('users'); $t->foreignId('organiser_id')->constrained('users');
                $t->unsignedTinyInteger('stars'); $t->text('comment')->nullable(); $t->timestamps(); $t->unique('tour_booking_id');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('tour_reviews');
        Schema::dropIfExists('tour_bookings');
    }
};
