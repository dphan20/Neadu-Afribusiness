<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique();
            $t->string('name'); $t->string('username')->nullable()->unique(); $t->string('phone', 20)->unique();
            $t->text('nida_number')->nullable();            // encrypted cast (DAT-01)
            $t->string('nida_hash', 64)->nullable()->unique(); // HMAC for uniqueness checks without decrypting
            $t->string('pin_hash')->nullable(); $t->text('description')->nullable();
            $t->string('language', 2)->default('sw');
            $t->string('status', 16)->default('active');
            $t->string('verification_level', 16)->default('phone'); // phone | nida | full (BR-01)
            $t->timestamp('phone_verified_at')->nullable(); $t->timestamp('verified_at')->nullable();
            $t->unsignedTinyInteger('failed_pin_attempts')->default(0); $t->timestamp('locked_until')->nullable(); // NFR-S3
            $t->boolean('credit_share_consent')->default(false); // BR-10
            $t->rememberToken(); $t->timestamps(); $t->softDeletes();
        });
        Schema::create('user_roles', function (Blueprint $t) { // SRS 2.2: P B E T L W R A
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->string('role', 1);
            $t->timestamps(); $t->unique(['user_id', 'role']);
        });
        Schema::create('role_profiles', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->string('role', 1);
            $t->foreignId('region_id')->nullable()->constrained(); $t->foreignId('district_id')->nullable()->constrained();
            $t->json('business')->nullable(); $t->text('documents')->nullable(); // encrypted cast
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('otp_codes', function (Blueprint $t) {
            $t->id(); $t->string('phone', 20)->index(); $t->string('code_hash'); $t->unsignedTinyInteger('attempts')->default(0);
            $t->dateTime('expires_at'); $t->timestamp('consumed_at')->nullable(); $t->timestamps();
        });
        Schema::create('user_devices', function (Blueprint $t) { // NFR-S3 session/device list
            $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->string('name'); $t->string('ip', 45)->nullable();
            $t->timestamp('last_seen_at')->nullable(); $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['user_devices', 'otp_codes', 'role_profiles', 'user_roles', 'users'] as $n) {
            Schema::dropIfExists($n);
        }
    }
};
