<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('favourites')) {
            Schema::create('favourites', function (Blueprint $t) {
                $t->id(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->foreignId('listing_id')->constrained()->cascadeOnDelete();
                $t->timestamps(); $t->unique(['user_id', 'listing_id']);
            });
        }
        if (! Schema::hasTable('wanted_requests')) {
            Schema::create('wanted_requests', function (Blueprint $t) {
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->foreignId('crop_id')->constrained();
                $t->foreignId('region_id')->nullable()->constrained(); $t->decimal('quantity', 14, 3); $t->unsignedBigInteger('max_price_minor')->nullable();
                $t->date('needed_by')->nullable(); $t->text('note')->nullable(); $t->string('status', 12)->default('open');
                $t->timestamps(); $t->softDeletes();
            });
        }
        $columns = [
            'buyer_note' => fn (Blueprint $t) => $t->text('buyer_note')->nullable(),
            'counter_unit_price_minor' => fn (Blueprint $t) => $t->unsignedBigInteger('counter_unit_price_minor')->nullable(),
            'counter_quantity' => fn (Blueprint $t) => $t->decimal('counter_quantity', 14, 3)->nullable(),
            'rejected_reason' => fn (Blueprint $t) => $t->string('rejected_reason')->nullable(),
        ];
        foreach ($columns as $name => $add) {
            if (! Schema::hasColumn('orders', $name)) {
                Schema::table('orders', fn (Blueprint $t) => $add($t));
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('wanted_requests');
        Schema::dropIfExists('favourites');
    }
};
