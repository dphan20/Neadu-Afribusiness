<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('conversations', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('listing_id')->nullable()->constrained(); $t->foreignId('order_id')->nullable()->constrained();
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('conversation_user', function (Blueprint $t) {
            $t->foreignId('conversation_id')->constrained()->cascadeOnDelete(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->primary(['conversation_id', 'user_id']);
        });
        Schema::create('messages', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('conversation_id')->constrained()->cascadeOnDelete(); $t->foreignId('sender_id')->constrained('users');
            $t->string('kind', 8)->default('text'); // text | photo | voice | call
            $t->text('body')->nullable(); $t->string('file_path')->nullable(); $t->timestamps(); $t->softDeletes();
        });
        Schema::create('notifications_log', function (Blueprint $t) { // SRS "Notification": user, type, channel, content, read, sent time
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->string('type', 32);
            $t->string('channel', 8)->default('in_app'); $t->json('content'); $t->timestamp('read_at')->nullable(); $t->timestamp('sent_at')->nullable();
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('price_records', function (Blueprint $t) {
            $t->id(); $t->foreignId('crop_id')->constrained(); $t->foreignId('market_id')->constrained(); $t->foreignId('region_id')->constrained();
            $t->unsignedBigInteger('price_minor'); $t->foreignId('unit_id')->constrained(); $t->date('recorded_on')->index(); $t->string('source');
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('price_alerts', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained()->cascadeOnDelete(); $t->foreignId('crop_id')->constrained();
            $t->foreignId('market_id')->nullable()->constrained(); $t->string('condition', 8); $t->unsignedBigInteger('threshold_minor'); // above | below
            $t->json('channels'); $t->timestamps(); $t->softDeletes();
        });
        Schema::create('diagnosis_cases', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained(); $t->string('photo_path'); $t->string('subject'); // crop or animal
            $t->string('result')->nullable(); $t->unsignedTinyInteger('confidence')->nullable(); $t->text('expert_reply')->nullable();
            $t->foreignId('expert_id')->nullable()->constrained('users'); $t->timestamps(); $t->softDeletes();
        });
        Schema::create('credit_score_snapshots', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained(); $t->unsignedSmallInteger('score'); $t->json('factors');
            $t->boolean('lender_consent')->default(false); $t->date('snapshot_on'); $t->timestamps(); $t->softDeletes();
        });
        Schema::create('audit_logs', function (Blueprint $t) { // ADM-07
            $t->id(); $t->foreignId('actor_id')->nullable()->constrained('users'); $t->string('action'); $t->string('target_type'); $t->unsignedBigInteger('target_id');
            $t->json('before')->nullable(); $t->json('after')->nullable(); $t->timestamp('created_at')->useCurrent(); $t->index(['target_type', 'target_id']);
        });
    }

    public function down(): void
    {
        foreach (['audit_logs', 'credit_score_snapshots', 'diagnosis_cases', 'price_alerts', 'price_records', 'notifications_log', 'messages', 'conversation_user', 'conversations'] as $n) {
            Schema::dropIfExists($n);
        }
    }
};
