<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vehicles', function (Blueprint $t) {
            if (! Schema::hasColumn('vehicles', 'photo_path')) {
                $t->string('photo_path')->nullable();
            }
            if (! Schema::hasColumn('vehicles', 'verification_status')) {
                $t->string('verification_status', 12)->default('pending')->index();   // pending | verified | rejected (LOG-01)
                $t->timestamp('verified_at')->nullable();
                $t->foreignId('verified_by')->nullable()->constrained('users');
                $t->string('reject_reason')->nullable();
            }
        });

        Schema::table('deliveries', function (Blueprint $t) {
            if (! Schema::hasColumn('deliveries', 'accepted_at')) {
                $t->timestamp('accepted_at')->nullable();
                $t->timestamp('delivered_at')->nullable();
                $t->json('timeline')->nullable();                       // [{status, at, lat, lng}] (LOG-04)
                $t->string('proof_type', 12)->nullable();               // code | photo | signature (LOG-06)
                $t->string('proof_path')->nullable();
                $t->string('recipient_name', 120)->nullable();
                $t->unsignedTinyInteger('code_attempts')->default(0);
                $t->string('escrow_state', 12)->default('none');       // none | held | released (LOG-08)
            }
        });

        // LOG-09 is an R3 feature: dark until the flag is switched on (it is always visible locally).
        DB::table('feature_flags')->insertOrIgnore([
            'key' => 'backhaul', 'enabled' => false, 'release' => 'R3', 'created_at' => now(), 'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        Schema::table('deliveries', function (Blueprint $t) {
            $t->dropColumn(['accepted_at', 'delivered_at', 'timeline', 'proof_type', 'proof_path', 'recipient_name', 'code_attempts', 'escrow_state']);
        });
        Schema::table('vehicles', function (Blueprint $t) {
            $t->dropConstrainedForeignId('verified_by');
            $t->dropColumn(['photo_path', 'verification_status', 'verified_at', 'reject_reason']);
        });
        DB::table('feature_flags')->where('key', 'backhaul')->delete();
    }
};
