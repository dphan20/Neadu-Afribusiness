<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Expert (E) and Trainer (G) workspaces, plus the shared wallet / document tables. (Transporter columns: 2026_10_30_000010.) */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('verification_documents')) {
            Schema::create('verification_documents', function (Blueprint $t) { // ADM-01, LOG-01, LND-03
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained();
                $t->string('subject_type', 16)->default('user'); // user | vehicle | land
                $t->unsignedBigInteger('subject_id')->nullable(); $t->string('kind', 32); $t->string('path');
                $t->string('status', 12)->default('pending'); // pending | approved | rejected
                $t->string('reason')->nullable(); $t->foreignId('reviewed_by')->nullable()->constrained('users'); $t->timestamp('reviewed_at')->nullable();
                $t->timestamps();
            });
        }
        if (! Schema::hasTable('tour_bookings')) {
            Schema::create('tour_bookings', function (Blueprint $t) { // TUR-02
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('listing_id')->constrained(); $t->foreignId('user_id')->constrained();
                $t->unsignedSmallInteger('seats'); $t->unsignedBigInteger('amount_minor');
                $t->string('status', 12)->default('held'); // held | paid | completed | cancelled
                $t->timestamp('expires_at')->nullable(); $t->timestamp('certificate_at')->nullable(); $t->timestamps();
            });
        }
        if (! Schema::hasTable('tour_ratings')) {
            Schema::create('tour_ratings', function (Blueprint $t) { // TUR-04
                $t->id(); $t->foreignId('tour_booking_id')->unique()->constrained()->cascadeOnDelete(); $t->foreignId('rater_id')->constrained('users');
                $t->foreignId('organiser_id')->constrained('users'); $t->unsignedTinyInteger('stars'); $t->text('comment')->nullable(); $t->timestamps();
            });
        }
        if (! Schema::hasTable('advice_posts')) {
            Schema::create('advice_posts', function (Blueprint $t) { // expert publishes advice
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('expert_id')->constrained('users'); $t->string('category', 12)->default('crop');
                $t->string('title'); $t->text('body'); $t->timestamp('published_at')->nullable(); $t->timestamps(); $t->softDeletes();
            });
        }
        if (! Schema::hasTable('payout_requests')) {
            Schema::create('payout_requests', function (Blueprint $t) { // S-45
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained(); $t->unsignedBigInteger('amount_minor');
                $t->string('method', 16); $t->text('destination'); // encrypted cast
                $t->string('status', 12)->default('requested'); // requested | paid | rejected
                $t->string('reason')->nullable(); $t->foreignId('decided_by')->nullable()->constrained('users'); $t->timestamp('decided_at')->nullable(); $t->timestamps();
            });
        }

        $this->addColumns('diagnosis_cases', [
            'ai_correct' => fn (Blueprint $t) => $t->boolean('ai_correct')->nullable(),               // DIA-05
            'expert_correction' => fn (Blueprint $t) => $t->text('expert_correction')->nullable(),
            'expert_rating' => fn (Blueprint $t) => $t->unsignedTinyInteger('expert_rating')->nullable(),
            'fee_minor' => fn (Blueprint $t) => $t->unsignedBigInteger('fee_minor')->default(0),
            'replied_at' => fn (Blueprint $t) => $t->timestamp('replied_at')->nullable(),
        ]);
    }

    public function down(): void
    {
        Schema::table('diagnosis_cases', fn (Blueprint $t) => $t->dropColumn(['ai_correct', 'expert_correction', 'expert_rating', 'fee_minor', 'replied_at']));
        foreach (['payout_requests', 'advice_posts', 'tour_ratings', 'tour_bookings', 'verification_documents'] as $n) {
            Schema::dropIfExists($n);
        }
    }

    /** @param array<string, \Closure(Blueprint): mixed> $columns */
    private function addColumns(string $table, array $columns): void
    {
        foreach ($columns as $name => $add) {
            if (! Schema::hasColumn($table, $name)) {
                Schema::table($table, fn (Blueprint $t) => $add($t));
            }
        }
    }
};
