<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Chat unread counts (MessagingService::unreadCounts) and Conversation::markReadBy read this column, but no earlier migration created it. */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('conversation_user', 'last_read_at')) {
            Schema::table('conversation_user', function (Blueprint $t): void {
                $t->dateTime('last_read_at')->nullable();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('conversation_user', 'last_read_at')) {
            Schema::table('conversation_user', fn (Blueprint $t) => $t->dropColumn('last_read_at'));
        }
    }
};
