<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Artisan;

/** Removes the sample machinery, quotes, price records and unused demo accounts so the system starts clean. */
return new class extends Migration
{
    public function up(): void
    {
        try {
            Artisan::call('neas:purge-demo', ['--force' => true, '--users' => true]);
        } catch (Throwable $e) {
            report($e); // never block a deployment because the clean-up could not run
        }
    }

    public function down(): void {}
};
