<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_queries', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->text('question'); $t->string('photo_path')->nullable(); $t->text('answer'); $t->string('model', 64);
            $t->timestamps(); $t->softDeletes();
            $t->index(['user_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_queries');
    }
};
