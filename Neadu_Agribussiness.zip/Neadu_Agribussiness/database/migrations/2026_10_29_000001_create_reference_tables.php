<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('regions', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->string('name')->unique(); $t->timestamps(); $t->softDeletes();
        });
        Schema::create('districts', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('region_id')->constrained(); $t->string('name');
            $t->timestamps(); $t->softDeletes(); $t->unique(['region_id', 'name']);
        });
        Schema::create('markets', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('region_id')->constrained(); $t->string('name');
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('categories', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->string('slug')->unique(); $t->string('name_sw'); $t->string('name_en');
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('crops', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('category_id')->constrained(); $t->string('slug')->unique();
            $t->string('name_sw'); $t->string('name_en'); $t->timestamps(); $t->softDeletes();
        });
        // SRS 7.7: kg, tonne, gunia, crate, litre, head. kg_factor_milli = kilograms x 1000 (no floats); null = not convertible.
        Schema::create('units', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->string('code', 16)->unique(); $t->string('name_sw'); $t->string('name_en');
            $t->unsignedBigInteger('kg_factor_milli')->nullable(); $t->timestamps(); $t->softDeletes();
        });
        // BR-03 / ADM-05: fee rules live in reference data. OPEN-Q2: levels set by the business owner.
        Schema::create('fee_rules', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->string('key')->index(); $t->unsignedInteger('bps');
            $t->unsignedBigInteger('min_minor')->default(0); $t->boolean('active')->default(true); $t->text('note')->nullable();
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('feature_flags', function (Blueprint $t) { // NFR-M3: R2/R3 gating
            $t->id(); $t->string('key')->unique(); $t->boolean('enabled')->default(false); $t->string('release', 2)->nullable(); $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['feature_flags', 'fee_rules', 'units', 'crops', 'categories', 'markets', 'districts', 'regions'] as $n) {
            Schema::dropIfExists($n);
        }
    }
};
