<?php

declare(strict_types=1);

use App\Models\FeatureFlag;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/** Role 3 (Expert): case queue, advice, consultations, AI corrections (R3), reviews, payouts. Safe to re-run. */
return new class extends Migration
{
    public function up(): void
    {
        $add = [
            'status' => fn (Blueprint $t) => $t->string('status', 12)->default('escalated')->index(), // escalated | in_review | answered | closed
            'domain' => fn (Blueprint $t) => $t->string('domain', 12)->default('crop'),                // crop | livestock | fisheries
            'ai_result' => fn (Blueprint $t) => $t->string('ai_result')->nullable(), // original AI output, kept when an expert corrects `result`
            'claimed_at' => fn (Blueprint $t) => $t->timestamp('claimed_at')->nullable(),
            'answered_at' => fn (Blueprint $t) => $t->timestamp('answered_at')->nullable(),
        ];
        foreach ($add as $col => $def) {
            if (! Schema::hasColumn('diagnosis_cases', $col)) {
                Schema::table('diagnosis_cases', fn (Blueprint $t) => $def($t));
            }
        }
        DB::table('diagnosis_cases')->whereNull('ai_result')->update(['ai_result' => DB::raw('result')]);
        DB::table('diagnosis_cases')->whereNotNull('expert_reply')->where('status', 'escalated')->update(['status' => 'answered']);

        foreach (['diagnosis_case_id', 'consultation_id'] as $col) {
            if (! Schema::hasColumn('conversations', $col)) {
                Schema::table('conversations', fn (Blueprint $t) => $t->unsignedBigInteger($col)->nullable()->index());
            }
        }

        if (! Schema::hasTable('advice_posts')) {
            Schema::create('advice_posts', function (Blueprint $t) {
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained()->cascadeOnDelete();
                $t->string('title'); $t->text('body'); $t->string('domain', 12)->default('crop'); $t->foreignId('crop_id')->nullable()->constrained();
                $t->foreignId('region_id')->nullable()->constrained(); $t->string('language', 2)->default('sw');
                $t->string('status', 10)->default('draft'); // draft | published
                $t->timestamp('published_at')->nullable(); $t->timestamps(); $t->softDeletes();
            });
        }
        if (! Schema::hasTable('consultations')) {
            Schema::create('consultations', function (Blueprint $t) {
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('expert_id')->constrained('users'); $t->foreignId('producer_id')->constrained('users');
                $t->foreignId('diagnosis_case_id')->nullable()->constrained(); $t->string('topic'); $t->string('mode', 6)->default('chat'); // chat | voice
                $t->string('status', 10)->default('requested'); // requested | accepted | completed | declined
                $t->string('payment_state', 10)->default('unpaid'); // unpaid | held | released
                $t->unsignedBigInteger('fee_minor'); $t->char('currency', 3)->default('TZS'); $t->timestamp('scheduled_at')->nullable();
                $t->timestamp('completed_at')->nullable(); $t->timestamps(); $t->softDeletes();
            });
        }
        if (! Schema::hasTable('ai_corrections')) {
            Schema::create('ai_corrections', function (Blueprint $t) { // DIA-05: expert verdicts that feed retraining
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('diagnosis_case_id')->constrained(); $t->foreignId('expert_id')->constrained('users');
                $t->string('ai_result')->nullable(); $t->unsignedTinyInteger('ai_confidence')->nullable(); $t->string('verdict', 10); // correct | partial | incorrect
                $t->string('corrected_result')->nullable(); $t->text('notes')->nullable(); $t->timestamp('exported_at')->nullable();
                $t->timestamps(); $t->unique(['diagnosis_case_id', 'expert_id']);
            });
        }
        if (! Schema::hasTable('expert_reviews')) {
            Schema::create('expert_reviews', function (Blueprint $t) {
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('expert_id')->constrained('users'); $t->foreignId('producer_id')->constrained('users');
                $t->foreignId('consultation_id')->nullable()->constrained(); $t->foreignId('diagnosis_case_id')->nullable()->constrained();
                $t->unsignedTinyInteger('stars'); $t->text('comment')->nullable(); $t->timestamps();
            });
        }
        if (! Schema::hasTable('payouts')) {
            Schema::create('payouts', function (Blueprint $t) {
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained(); $t->unsignedBigInteger('amount_minor'); $t->char('currency', 3)->default('TZS');
                $t->string('provider', 12); $t->string('destination'); $t->string('state', 10)->default('requested'); // requested | paid | failed
                $t->timestamps();
            });
        }
        FeatureFlag::firstOrCreate(['key' => 'ai_feedback'], ['release' => 'R3', 'enabled' => false]);
    }

    public function down(): void
    {
        foreach (['payouts', 'expert_reviews', 'ai_corrections', 'consultations', 'advice_posts'] as $n) {
            Schema::dropIfExists($n);
        }
    }
};
