<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('listings', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained();
            $t->string('type', 16)->index(); // produce | storage | land | machine | tour
            $t->string('title'); $t->foreignId('region_id')->nullable()->constrained(); $t->foreignId('district_id')->nullable()->constrained();
            $t->decimal('lat', 10, 7)->nullable(); $t->decimal('lng', 10, 7)->nullable();
            $t->unsignedBigInteger('price_minor'); $t->char('currency', 3)->default('TZS');
            $t->string('status', 16)->default('draft')->index(); // draft | pending_review | active | rejected | closed (BR-07)
            $t->json('photos')->nullable(); $t->boolean('verified')->default(false); // BR-08
            $t->timestamp('verified_at')->nullable(); $t->foreignId('verified_by')->nullable()->constrained('users');
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('produce_listings', function (Blueprint $t) {
            $t->id(); $t->foreignId('listing_id')->unique()->constrained()->cascadeOnDelete();
            $t->foreignId('crop_id')->constrained(); $t->foreignId('unit_id')->constrained();
            $t->decimal('quantity', 14, 3); $t->string('grade', 16)->nullable(); $t->date('harvest_date')->nullable(); $t->text('quality_notes')->nullable();
            $t->timestamps();
        });
        Schema::create('storage_facilities', function (Blueprint $t) {
            $t->id(); $t->foreignId('listing_id')->unique()->constrained()->cascadeOnDelete();
            $t->string('facility_type'); $t->decimal('capacity_kg', 14, 3); $t->json('conditions')->nullable(); $t->text('security')->nullable(); $t->timestamps();
        });
        Schema::create('land_plots', function (Blueprint $t) {
            $t->id(); $t->foreignId('listing_id')->unique()->constrained()->cascadeOnDelete();
            $t->decimal('size_acres', 12, 2); $t->string('tenure', 8); // lease | sale
            $t->string('soil')->nullable(); $t->string('water')->nullable(); $t->boolean('road_access')->default(false);
            $t->text('title_document')->nullable(); // encrypted cast (DAT-01)
            $t->timestamps();
        });
        Schema::create('machines', function (Blueprint $t) {
            $t->id(); $t->foreignId('listing_id')->unique()->constrained()->cascadeOnDelete();
            $t->string('sector'); $t->json('specs')->nullable(); $t->string('machine_condition', 16)->nullable(); $t->string('warranty')->nullable(); $t->timestamps();
        });
        Schema::create('tours', function (Blueprint $t) {
            $t->id(); $t->foreignId('listing_id')->unique()->constrained()->cascadeOnDelete();
            $t->string('route'); $t->dateTime('starts_at'); $t->timestamp('ends_at')->nullable();
            $t->unsignedSmallInteger('seats'); $t->json('itinerary')->nullable(); $t->timestamps();
        });
        Schema::create('storage_bookings', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('facility_listing_id')->constrained('listings'); $t->foreignId('user_id')->constrained();
            $t->decimal('quantity_kg', 14, 3); $t->date('starts_on'); $t->date('ends_on'); $t->unsignedBigInteger('price_minor');
            $t->string('status', 16)->default('requested'); $t->string('receipt_no')->nullable(); $t->timestamps(); $t->softDeletes();
        });
    }

    public function down(): void
    {
        foreach (['storage_bookings', 'tours', 'machines', 'land_plots', 'storage_facilities', 'produce_listings', 'listings'] as $n) {
            Schema::dropIfExists($n);
        }
    }
};
