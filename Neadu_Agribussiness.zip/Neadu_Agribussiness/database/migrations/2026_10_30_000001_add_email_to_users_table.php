<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->string('email', 190)->nullable()->unique()->after('username');
        });

        // Phone becomes optional (an account may be email-only). The unique index stays.
        Schema::table('users', function (Blueprint $t) {
            $t->string('phone', 20)->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->dropUnique(['email']);
            $t->dropColumn('email');
        });
    }
};
