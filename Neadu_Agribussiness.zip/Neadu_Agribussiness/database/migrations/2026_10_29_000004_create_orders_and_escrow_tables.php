<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique();
            $t->foreignId('buyer_id')->constrained('users'); $t->foreignId('seller_id')->constrained('users'); $t->foreignId('listing_id')->constrained();
            $t->decimal('quantity', 14, 3); $t->unsignedBigInteger('unit_price_minor'); $t->unsignedBigInteger('subtotal_minor');
            $t->unsignedBigInteger('fee_minor')->default(0); $t->char('currency', 3)->default('TZS');
            $t->string('status', 16)->default('pending')->index(); // App\Enums\EscrowState
            $t->string('delivery_option', 16)->default('pickup');
            $t->timestamp('accept_by')->nullable(); $t->timestamp('accepted_at')->nullable();   // 24h (11.2)
            $t->timestamp('delivered_at')->nullable(); $t->timestamp('auto_release_at')->nullable(); // 48h (11.2) OPEN-Q2
            $t->foreignId('contract_id')->nullable();
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('payments', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('order_id')->constrained();
            $t->unsignedBigInteger('amount_minor'); $t->unsignedBigInteger('fee_minor')->default(0); $t->char('currency', 3)->default('TZS');
            $t->string('provider', 32); $t->text('reference')->nullable(); // encrypted cast (DAT-01)
            $t->string('idempotency_key')->unique(); $t->string('state', 16)->default('initiated'); // initiated|held|released|refunded
            $t->timestamps(); $t->softDeletes();
        });
        // NFR-S4 / DAT-01: append-only double-entry ledger. No updated_at, no soft deletes; model blocks update/delete.
        Schema::create('ledger_entries', function (Blueprint $t) {
            $t->id(); $t->uuid('transaction_uuid')->index(); $t->foreignId('order_id')->nullable()->constrained();
            $t->foreignId('payment_id')->nullable()->constrained(); $t->string('account', 48)->index(); // e.g. escrow, seller:12, platform_fee
            $t->unsignedBigInteger('debit_minor')->default(0); $t->unsignedBigInteger('credit_minor')->default(0); $t->char('currency', 3)->default('TZS');
            $t->string('memo')->nullable(); $t->timestamp('created_at')->useCurrent();
        });
        Schema::create('webhook_events', function (Blueprint $t) { // 9.4 idempotent signed webhooks
            $t->id(); $t->string('provider', 32); $t->string('event_id'); $t->json('payload'); $t->timestamp('processed_at')->nullable();
            $t->timestamps(); $t->unique(['provider', 'event_id']);
        });
        Schema::create('refund_approvals', function (Blueprint $t) { // NFR-S4 two-person approval
            $t->id(); $t->foreignId('payment_id')->constrained(); $t->unsignedBigInteger('amount_minor');
            $t->foreignId('requested_by')->constrained('users'); $t->foreignId('approved_by')->nullable()->constrained('users');
            $t->timestamp('approved_at')->nullable(); $t->timestamps();
        });
        Schema::create('vehicles', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('user_id')->constrained(); $t->string('type'); $t->string('plate')->unique();
            $t->decimal('capacity_kg', 12, 2); $t->text('licence_document')->nullable(); $t->timestamps(); $t->softDeletes(); // encrypted
        });
        Schema::create('deliveries', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('order_id')->constrained();
            $t->foreignId('transporter_id')->nullable()->constrained('users'); $t->foreignId('vehicle_id')->nullable()->constrained();
            $t->decimal('pickup_lat', 10, 7); $t->decimal('pickup_lng', 10, 7); $t->decimal('drop_lat', 10, 7); $t->decimal('drop_lng', 10, 7);
            $t->unsignedBigInteger('price_minor')->default(0); $t->string('status', 16)->default('requested');
            $t->string('delivery_code_hash')->nullable(); // BR-09
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('tracking_points', function (Blueprint $t) {
            $t->id(); $t->foreignId('delivery_id')->constrained()->cascadeOnDelete(); $t->decimal('lat', 10, 7); $t->decimal('lng', 10, 7);
            $t->dateTime('recorded_at')->index();
        });
        Schema::create('contracts', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('buyer_id')->constrained('users'); $t->foreignId('seller_id')->constrained('users');
            $t->json('terms'); $t->string('status', 16)->default('draft'); $t->json('signatures')->nullable(); $t->string('pdf_hash', 64)->nullable();
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('disputes', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('order_id')->constrained(); $t->foreignId('opener_id')->constrained('users');
            $t->string('reason'); $t->json('evidence')->nullable(); $t->dateTime('evidence_until'); $t->dateTime('decide_by'); // BR-05: 3d / 5 working days
            $t->string('decision', 16)->nullable(); // release | partial | refund
            $t->unsignedBigInteger('partial_minor')->nullable(); $t->foreignId('decided_by')->nullable()->constrained('users'); $t->timestamp('decided_at')->nullable();
            $t->timestamps(); $t->softDeletes();
        });
        Schema::create('ratings', function (Blueprint $t) {
            $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('order_id')->constrained(); $t->foreignId('rater_id')->constrained('users');
            $t->foreignId('ratee_id')->constrained('users'); $t->unsignedTinyInteger('stars'); $t->text('comment')->nullable();
            $t->timestamps(); $t->softDeletes(); $t->unique(['order_id', 'rater_id']); // BR-06
        });
    }

    public function down(): void
    {
        foreach (['ratings', 'disputes', 'contracts', 'tracking_points', 'deliveries', 'vehicles', 'refund_approvals', 'webhook_events', 'ledger_entries', 'payments', 'orders'] as $n) {
            Schema::dropIfExists($n);
        }
    }
};
