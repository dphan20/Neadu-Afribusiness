<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** COM-01: forwarded messages, "delete for me" on single messages, and "delete chat" (clears history for one person). */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('messages', function (Blueprint $t): void {
            if (! Schema::hasColumn('messages', 'forwarded_from_id')) {
                $t->unsignedBigInteger('forwarded_from_id')->nullable()->index();
            }
        });

        Schema::table('conversation_user', function (Blueprint $t): void {
            if (! Schema::hasColumn('conversation_user', 'hidden_at')) {
                $t->dateTime('hidden_at')->nullable(); // everything up to this moment is cleared for this person
            }
        });

        if (! Schema::hasTable('message_hides')) {
            Schema::create('message_hides', function (Blueprint $t): void {
                $t->foreignId('message_id')->constrained()->cascadeOnDelete();
                $t->foreignId('user_id')->constrained()->cascadeOnDelete();
                $t->timestamp('created_at')->nullable();
                $t->primary(['message_id', 'user_id']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('message_hides');
        Schema::table('conversation_user', fn (Blueprint $t) => $t->dropColumn('hidden_at'));
        Schema::table('messages', function (Blueprint $t): void {
            $t->dropIndex(['forwarded_from_id']);
            $t->dropColumn('forwarded_from_id');
        });
    }
};
