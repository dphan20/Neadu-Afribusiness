<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Records when, and which version of, the Terms of Use and Privacy Policy a user accepted at sign-up. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $t): void {
            if (! Schema::hasColumn('users', 'terms_accepted_at')) {
                $t->timestamp('terms_accepted_at')->nullable();
            }
            if (! Schema::hasColumn('users', 'terms_version')) {
                $t->string('terms_version', 20)->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $t): void {
            $t->dropColumn(['terms_accepted_at', 'terms_version']);
        });
    }
};
