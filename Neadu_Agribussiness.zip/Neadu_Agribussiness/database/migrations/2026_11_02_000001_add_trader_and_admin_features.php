<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/** Trader (R) machinery quotes, and the admin console: dispute notes, two-person refunds, suspension reasons. */
return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('machine_quotes')) {
            Schema::create('machine_quotes', function (Blueprint $t) { // MCH-02/03/04
                $t->id(); $t->uuid('uuid')->unique(); $t->foreignId('listing_id')->constrained(); $t->foreignId('user_id')->constrained();
                $t->string('kind', 12)->default('quote'); // quote | financing | rental
                $t->unsignedSmallInteger('quantity')->default(1); $t->unsignedSmallInteger('months')->nullable(); $t->text('message')->nullable();
                $t->string('status', 12)->default('open'); // open | quoted | declined
                $t->unsignedBigInteger('quoted_minor')->nullable(); $t->text('reply')->nullable(); $t->timestamp('replied_at')->nullable(); $t->timestamps();
            });
        }

        $this->add('disputes', 'admin_note', fn (Blueprint $t) => $t->text('admin_note')->nullable());
        $this->add('users', 'suspension_reason', fn (Blueprint $t) => $t->string('suspension_reason')->nullable());
        $this->add('refund_approvals', 'dispute_id', fn (Blueprint $t) => $t->foreignId('dispute_id')->nullable()->constrained());
        $this->add('refund_approvals', 'decision', fn (Blueprint $t) => $t->string('decision', 8)->nullable());          // refund | partial
        $this->add('refund_approvals', 'partial_minor', fn (Blueprint $t) => $t->unsignedBigInteger('partial_minor')->nullable());
        $this->add('refund_approvals', 'note', fn (Blueprint $t) => $t->text('note')->nullable());
        $this->add('refund_approvals', 'status', fn (Blueprint $t) => $t->string('status', 10)->default('pending'));    // pending | executed | rejected
        $this->add('refund_approvals', 'executed_at', fn (Blueprint $t) => $t->timestamp('executed_at')->nullable());
        if (Schema::hasColumn('refund_approvals', 'payment_id')) {
            Schema::table('refund_approvals', fn (Blueprint $t) => $t->foreignId('payment_id')->nullable()->change());
        }

        foreach (['financing' => 'R3', 'rental' => 'R3'] as $key => $release) {
            DB::table('feature_flags')->insertOrIgnore(['key' => $key, 'enabled' => false, 'release' => $release, 'created_at' => now(), 'updated_at' => now()]);
        }
    }

    public function down(): void
    {
        DB::table('feature_flags')->whereIn('key', ['financing', 'rental'])->delete();
        Schema::table('refund_approvals', function (Blueprint $t) {
            $t->dropConstrainedForeignId('dispute_id');
            $t->dropColumn(['decision', 'partial_minor', 'note', 'status', 'executed_at']);
        });
        Schema::table('users', fn (Blueprint $t) => $t->dropColumn('suspension_reason'));
        Schema::table('disputes', fn (Blueprint $t) => $t->dropColumn('admin_note'));
        Schema::dropIfExists('machine_quotes');
    }

    private function add(string $table, string $column, \Closure $define): void
    {
        if (! Schema::hasColumn($table, $column)) {
            Schema::table($table, fn (Blueprint $t) => $define($t));
        }
    }
};
