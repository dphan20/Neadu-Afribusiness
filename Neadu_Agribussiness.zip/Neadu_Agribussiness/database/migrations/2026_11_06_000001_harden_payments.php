<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Phase 4: provider reference, settlement time and failure reason on payments, so callbacks and reconciliation can find and explain them. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $t): void {
            if (! Schema::hasColumn('payments', 'provider_ref')) {
                $t->string('provider_ref', 80)->nullable()->index();
            }
            if (! Schema::hasColumn('payments', 'settled_at')) {
                $t->timestamp('settled_at')->nullable();
            }
            if (! Schema::hasColumn('payments', 'failure_reason')) {
                $t->string('failure_reason', 200)->nullable();
            }
            $t->index(['order_id', 'state']);
        });
    }

    public function down(): void
    {
        Schema::table('payments', function (Blueprint $t): void {
            $t->dropIndex(['order_id', 'state']);
            $t->dropColumn(['provider_ref', 'settled_at', 'failure_reason']);
        });
    }
};
