<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/** Producer role (SRS P): extra columns on the existing marketplace, order, storage and diagnosis tables. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('produce_listings', function (Blueprint $t) {
            $t->string('category', 12)->default('crop')->after('listing_id');     // MKT-01: crop | livestock | fish
            $t->string('quality', 12)->default('standard')->after('grade');       // MKT-01: premium | standard | economy
            $t->decimal('quantity_sold', 14, 3)->default(0)->after('quantity');   // MKT-10: remaining = quantity - quantity_sold
            $t->decimal('min_order', 14, 3)->nullable();                          // MKT-02
            $t->string('packaging')->nullable();                                  // MKT-02
            $t->string('video_path')->nullable();                                 // MKT-02
        });

        Schema::table('orders', function (Blueprint $t) {
            $t->unsignedBigInteger('counter_unit_price_minor')->nullable();       // MKT-04 counter offer
            $t->string('counter_status', 12)->nullable();                         // offered | accepted | declined
            $t->timestamp('rejected_at')->nullable();
            $t->string('reject_reason')->nullable();
            $t->timestamp('released_at')->nullable();
            $t->unsignedBigInteger('payout_minor')->nullable();                   // MKT-05: subtotal - fee
            $t->string('receipt_no')->nullable()->unique();                       // MKT-07
        });

        Schema::table('deliveries', function (Blueprint $t) {
            $t->foreignId('booked_by')->nullable()->constrained('users');
            $t->decimal('distance_km', 8, 2)->nullable();
            $t->unsignedBigInteger('suggested_price_minor')->default(0);          // LOG-02
        });

        Schema::table('storage_bookings', function (Blueprint $t) {
            $t->string('payment_method', 8)->default('escrow');                   // STO-03: escrow | invoice
            $t->string('payment_state', 12)->default('unpaid');                   // unpaid | held | invoiced
        });

        Schema::table('diagnosis_cases', function (Blueprint $t) {
            $t->string('subject_kind', 12)->default('crop');                      // crop | livestock | fish
            $t->text('treatment')->nullable();                                    // DIA-02 (Kiswahili)
            $t->text('prevention')->nullable();
            $t->timestamp('escalated_at')->nullable();                            // DIA-04
            $t->foreignId('conversation_id')->nullable()->constrained();          // DIA-03
        });

        Schema::table('price_alerts', function (Blueprint $t) {
            $t->boolean('active')->default(true);
            $t->timestamp('last_triggered_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('price_alerts', fn (Blueprint $t) => $t->dropColumn(['active', 'last_triggered_at']));
        Schema::table('diagnosis_cases', function (Blueprint $t) {
            $t->dropConstrainedForeignId('conversation_id');
            $t->dropColumn(['subject_kind', 'treatment', 'prevention', 'escalated_at']);
        });
        Schema::table('storage_bookings', fn (Blueprint $t) => $t->dropColumn(['payment_method', 'payment_state']));
        Schema::table('deliveries', function (Blueprint $t) {
            $t->dropConstrainedForeignId('booked_by');
            $t->dropColumn(['distance_km', 'suggested_price_minor']);
        });
        Schema::table('orders', function (Blueprint $t) {
            $t->dropUnique(['receipt_no']);
            $t->dropColumn(['counter_unit_price_minor', 'counter_status', 'rejected_at', 'reject_reason', 'released_at', 'payout_minor', 'receipt_no']);
        });
        Schema::table('produce_listings', fn (Blueprint $t) => $t->dropColumn(['category', 'quality', 'quantity_sold', 'min_order', 'packaging', 'video_path']));
    }
};
