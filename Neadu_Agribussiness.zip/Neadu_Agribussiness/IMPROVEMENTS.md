# NeAS upgrade: AI fix, security hardening, faster and cleaner UI

## 1. Why "Ask AI" failed to answer, and what changed
| Cause in the old code | Fix |
|---|---|
| `GEMINI_MODEL=gemini-2.5-flash` is on Google's retirement schedule (earliest 16 Oct 2026). A retired model answers 404, which the old code showed as a vague "AI had a problem". | Default is now `gemini-3.5-flash`, with automatic fallback to `GEMINI_FALLBACK_MODELS` on 404 / 429 / 5xx. A 404 now says which model is gone. |
| Hidden "thinking" tokens shared a 2048-token cap, so the visible answer could come back empty or cut off. | Cap raised to 8192, thinking switched off on 2.5-flash, reasoning parts are never shown. |
| Every question was treated alone, so "and for one acre?" had no context. | The last 6 exchanges (12 h) are sent with each question. |
| Replies defaulted to Kiswahili even when the user wrote English. | The model replies in the language of the latest message. |
| The prompt said nothing about how NeAS works. | Prompt now carries the user's real menu and escrow/dispute rules, read from `config/neas.php`. |
| Safety blocks, truncation and empty replies all looked the same; default filters blocked normal farm talk. | Each case has its own message; filters set to block only high-probability harm. |
| A failed question left its photo on disk. | Photo is deleted when no answer was produced. |

## 2. Security
- Security headers on every response (CSP, nosniff, frame-ancestors, Referrer/Permissions-Policy, HSTS in production).
- Sign-in limited per account + IP (5/min) and per IP (30/min); unknown accounts now cost the same time as known ones.
- Password rule for new accounts: 8+ characters with letters and numbers; leaked passwords rejected in production.
- USSD/SMS callbacks now fail closed (503) in production when `NEAS_USSD_SECRET` is empty. Before, they were open.
- Production refuses to start with `NEAS_SIMULATE_GATEWAYS=true` (payments would "succeed" with no money), forces `APP_DEBUG` off, forces HTTPS links, and blocks `migrate:fresh`.
- `SESSION_ENCRYPT=true` in `.env.example`, plus a production checklist at the bottom of that file.

**Do this first: your zip contained `.env` with a real Gemini key and database password. Create a new Gemini key, change the DB password, and never share `.env`.**

## 3. UI and speed
- JavaScript 59 KB to 0.5 KB (axios removed; it was unused). Added double-submit protection so a second tap on Pay cannot run twice.
- About 25 KB of CSS that was repeated inside every role page is now one cached file.
- Fonts (Inter, Plus Jakarta Sans) are self-hosted through npm. No Google Fonts request.
- Gzip and one-year caching for built assets (`public/.htaccess`).
- Dark mode fixed: chips, borders and chat bubbles were light-on-light.
- Text that was 9 to 11px is now 12 to 15px. Skip link, visible focus ring, sticky header, SVG icon instead of an emoji, mobile header that fits.

## 4. Apply (PowerShell)
```powershell
cd C:\xampp\htdocs
Expand-Archive -Force $HOME\Downloads\neas-upgrade.zip $env:TEMP\neas-upgrade
Copy-Item -Recurse -Force $env:TEMP\neas-upgrade\neas-upgrade\* C:\xampp\htdocs\Neadu_Agribussiness\
cd C:\xampp\htdocs\Neadu_Agribussiness
Remove-Item resources\js\bootstrap.js, package-lock.json -ErrorAction SilentlyContinue
pnpm install
pnpm build
```
Open `.env` and set `GEMINI_MODEL=gemini-3.5-flash` and `SESSION_ENCRYPT=true`, then:
```powershell
php artisan optimize:clear
php artisan test
php artisan serve
```

## 5. Not done, and not verified
- I could not run `php artisan test` here (no Composer access). New tests are in `AssistantTest.php` and `SecurityTest.php`; I only syntax-checked them. The front-end build did compile.
- Two register tests in `RoleWorkspaceTest.php` used a 6-digit password that the existing 8-character rule already rejected; I updated them.
- Not changed: live mobile-money gateway, real NIDA check, Kiswahili translation of screens (menus are English), CSP nonces to remove `'unsafe-inline'`.
- I kept your Laravel + Blade app. The prompt's Inertia/React/Laravel 13 rewrite would discard working screens.
