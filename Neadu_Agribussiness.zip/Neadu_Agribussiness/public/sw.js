/*
 * NeAS service worker.
 *
 * SAFETY RULES (do not relax without a security review):
 *  1. Pages (HTML) are NEVER cached. Dashboards, orders, payments and chat always come from the network.
 *     If the network is down, a navigation shows the static offline page instead.
 *  2. Only same-origin GET requests for public static files (hashed build assets, images, icons, css, js, fonts) are cached.
 *  3. /api, anything with an Authorization header, non-GET requests and responses marked private/no-store are never cached.
 *
 * To ship a new version: change VERSION below. Old caches are deleted on activate and the page offers an "Update" button.
 */
const VERSION = 'neas-2026.11.3';
const STATIC_CACHE = VERSION + '-static';
const RUNTIME_CACHE = VERSION + '-runtime';
const BASE = (typeof self !== 'undefined' && self.location) ? new URL('./', self.location.href).pathname : '/'; const OFFLINE_URL = BASE + 'offline.html';
const MAX_RUNTIME_ENTRIES = 80;

const PRECACHE = [OFFLINE_URL, BASE + 'manifest.webmanifest', BASE + 'icons/icon-192.png', BASE + 'icons/icon-512.png', BASE + 'css/pwa.css', BASE + 'js/pwa.js'];
const STATIC_PREFIXES = ['/build/assets/', '/images/', '/icons/', '/css/', '/js/', '/fonts/'];
const NEVER_PREFIXES = ['/api', '/admin', '/me', '/pay', '/orders', '/buyer', '/producer', '/expert', '/trainer', '/transporter', '/landowner', '/warehouse', '/trader', '/storage', '/broadcasting', '/livewire', '/up', '/login', '/register', '/logout', '/dashboard', '/workspace'];

/** Pure routing decision, unit-tested in tests/pwa/sw.test.mjs. Returns 'immutable' | 'swr' | null. */
function strategyFor(request, origin) {
  const url = new URL(request.url);
  const path = url.pathname.startsWith(BASE) ? '/' + url.pathname.slice(BASE.length) : url.pathname; if (request.method !== 'GET') return null;
  if (url.origin !== origin) return null;
  if (request.headers && request.headers.get && (request.headers.get('Authorization') || request.headers.get('Range'))) return null;
  if (NEVER_PREFIXES.some((p) => path === p || path.startsWith(p + '/'))) return null;
  if (path.startsWith('/build/assets/')) return 'immutable'; // file names contain a content hash, so they never change
  if (STATIC_PREFIXES.some((p) => path.startsWith(p)) || path === '/manifest.webmanifest') return 'swr';
  return null;
}

/** A response may be stored only if it is a plain 200 that does not ask to be kept private. */
function isStorable(response) {
  if (!response || response.status !== 200 || response.type !== 'basic') return false;
  const cc = (response.headers.get('Cache-Control') || '').toLowerCase();
  if (cc.includes('no-store') || cc.includes('private')) return false;
  if (response.headers.get('Set-Cookie')) return false;
  return true;
}

if (typeof self !== 'undefined' && typeof self.addEventListener === 'function' && typeof caches !== 'undefined') {
  self.addEventListener('install', (event) => {
    // Does NOT skipWaiting: the new version waits until the person taps "Update", so a page is never swapped mid-form.
    // Each file is cached on its own: if one is missing the worker still installs (a failed install made the app not installable).
    event.waitUntil(caches.open(STATIC_CACHE).then((cache) => Promise.all(PRECACHE.map((u) => cache.add(new Request(u, { cache: 'reload' })).catch(() => null)))));
  });

  self.addEventListener('activate', (event) => {
    event.waitUntil((async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)));
      await self.clients.claim();
    })());
  });

  self.addEventListener('message', (event) => {
    if (event.data === 'SKIP_WAITING') self.skipWaiting();
    if (event.data === 'GET_VERSION' && event.source) event.source.postMessage({ type: 'VERSION', version: VERSION });
  });

  self.addEventListener('fetch', (event) => {
    const request = event.request;

    // Page navigations: network only. Offline page if the network is unreachable.
    if (request.mode === 'navigate') {
      event.respondWith(fetch(request).catch(async () => (await caches.match(OFFLINE_URL)) || new Response('Offline', { status: 503, headers: { 'Content-Type': 'text/plain' } })));
      return;
    }

    const strategy = strategyFor(request, self.location.origin);
    if (strategy === null) return; // not ours: the browser handles it normally (no caching by the worker)

    if (strategy === 'immutable') {
      event.respondWith(caches.match(request).then((hit) => hit || fetchAndStore(request, STATIC_CACHE)));
      return;
    }
    // stale-while-revalidate
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_CACHE);
      const hit = await cache.match(request);
      const network = fetchAndStore(request, RUNTIME_CACHE).catch(() => null);
      if (hit) { event.waitUntil(network); return hit; }
      return (await network) || new Response('', { status: 504 });
    })());
  });

  async function fetchAndStore(request, cacheName) {
    const response = await fetch(request);
    if (isStorable(response)) {
      const cache = await caches.open(cacheName);
      await cache.put(request, response.clone());
      if (cacheName === RUNTIME_CACHE) trim(cache);
    }
    return response;
  }

  async function trim(cache) {
    const keys = await cache.keys();
    if (keys.length > MAX_RUNTIME_ENTRIES) await Promise.all(keys.slice(0, keys.length - MAX_RUNTIME_ENTRIES).map((k) => cache.delete(k)));
  }
}

if (typeof module !== 'undefined') module.exports = { strategyFor, isStorable, VERSION, NEVER_PREFIXES };
