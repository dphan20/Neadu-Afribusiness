/*
 * NeAS PWA client: registers the service worker, shows the install prompt, offers updates, and reports the connection state.
 * No dependencies. Everything is wrapped so a failure here can never break the application.
 */
(function () {
  'use strict';
  var BASE = (function () { try { var c = document.currentScript; if (c && c.src) { return new URL('../', c.src).pathname; } } catch (e) {} return '/'; })(); var DISMISS_KEY = 'neas.pwa.dismissed';
  var DISMISS_DAYS = 14;
  var deferredPrompt = null;
  var reloading = false;

  function store(op, key, value) { try { return op === 'get' ? localStorage.getItem(key) : localStorage.setItem(key, value); } catch (e) { return null; } }
  function dismissedRecently() { var t = parseInt(store('get', DISMISS_KEY) || '0', 10); return t && (Date.now() - t) < DISMISS_DAYS * 864e5; }
  function isStandalone() { return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true; }
  function isLocal() { return /^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname); }
  function isIos() { return /iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream; }
  function el(tag, attrs, html) { var n = document.createElement(tag); Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); }); if (html) { n.innerHTML = html; } return n; }
  function remove(n) { if (n && n.parentNode) { n.parentNode.removeChild(n); } }

  /* ---------- connection banner + failed-request guard ---------- */
  var connBar = null, connTimer = null;
  function showConn(ok, text) {
    remove(connBar); clearTimeout(connTimer);
    connBar = el('div', { 'class': 'pwa-conn' + (ok ? ' ok' : ''), role: 'status', 'aria-live': 'polite' }); connBar.textContent = text;
    document.body.appendChild(connBar);
    if (ok) { connTimer = setTimeout(function () { remove(connBar); }, 2500); }
  }
  window.addEventListener('offline', function () { if (isLocal()) { return; } showConn(false, 'You are offline. Changes will not be saved until you reconnect.'); });
  window.addEventListener('online', function () { showConn(true, 'Back online.'); if (reg) { reg.update().catch(function () {}); } });
  if (!isLocal() && navigator.onLine === false) { document.addEventListener('DOMContentLoaded', function () { showConn(false, 'You are offline. Changes will not be saved until you reconnect.'); }); }

  // Never let a form (payment, order, message) be sent while offline: it would fail half-way. Nothing is queued on purpose.
  document.addEventListener('submit', function (e) {
    if (!isLocal() && navigator.onLine === false && e.target && e.target.method && e.target.method.toLowerCase() === 'post') {
      e.preventDefault();
      showConn(false, 'No connection. Nothing was sent. Please reconnect and try again.');
    }
  }, true);

  /* ---------- install prompt ---------- */
  // The browser fires beforeinstallprompt once, early. It is kept in window.__neasInstall (also by the inline head snippet) so a late click still works.
  deferredPrompt = window.__neasInstall || null;
  function installButtons() { return document.querySelectorAll('[data-pwa-install]'); }
  function setInstallButtons(visible) { Array.prototype.forEach.call(installButtons(), function (b) { b.hidden = !visible; }); }

  function banner(title, text, withInstall) {
    if (document.querySelector('.pwa-banner')) { return; }
    var b = el('div', { 'class': 'pwa-banner', role: 'dialog', 'aria-label': 'Install NeAS' });
    b.innerHTML = '<img src="' + BASE + 'icons/icon-192.png" alt="" width="40" height="40"><div class="pwa-text"><b></b><span></span></div><div class="pwa-actions"></div>';
    b.querySelector('b').textContent = title; b.querySelector('span').textContent = text;
    var actions = b.querySelector('.pwa-actions');
    if (withInstall) { var i = el('button', { type: 'button', 'class': 'pwa-btn' }); i.textContent = 'Install'; i.addEventListener('click', promptInstall); actions.appendChild(i); }
    var n = el('button', { type: 'button', 'class': 'pwa-btn quiet' }); n.textContent = withInstall ? 'Not now' : 'Got it';
    n.addEventListener('click', function () { store('set', DISMISS_KEY, String(Date.now())); remove(b); });
    actions.appendChild(n);
    document.body.appendChild(b);
  }

  // Step-by-step help shown only when the browser has no one-tap install (iPhone, Firefox, or an address that is not https).
  function howTo() {
    remove(document.querySelector('.pwa-banner'));
    var secure = location.protocol === 'https:' || isLocal();
    var ua = navigator.userAgent, text;
    if (!secure) { text = 'Installing needs a secure (https) address. Open the https version of this site, then tap Install again.'; }
    else if (isIos()) { text = 'Tap the Share button, scroll down and tap "Add to Home Screen", then tap Add.'; }
    else if (/firefox/i.test(ua) && /android/i.test(ua)) { text = 'Open the browser menu (three dots) and tap "Install".'; }
    else if (/firefox/i.test(ua)) { text = 'Firefox on a computer cannot install web apps. Open this site in Chrome or Edge to install it.'; }
    else if (/android/i.test(ua)) { text = 'Open the browser menu (three dots) and tap "Install app" or "Add to Home screen".'; }
    else { text = 'Click the install icon at the right of the address bar, or open the browser menu and choose "Install NeAS".'; }
    banner('Install NeAS', text, false);
  }

  function promptInstall() {
    var p = deferredPrompt || window.__neasInstall;
    if (!p) { howTo(); return; }
    deferredPrompt = null; window.__neasInstall = null;
    remove(document.querySelector('.pwa-banner'));
    try {
      p.prompt();
      Promise.resolve(p.userChoice).then(function (c) {
        if (c && c.outcome === 'accepted') { setInstallButtons(false); }
        else { store('set', DISMISS_KEY, String(Date.now())); }
      }).catch(function () {});
    } catch (e) { howTo(); }
  }

  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault(); deferredPrompt = e; window.__neasInstall = e;
    if (isStandalone()) { return; }
    setInstallButtons(true);
    if (!dismissedRecently()) { setTimeout(function () { if (deferredPrompt) { banner('Install NeAS', 'Open it like an app, faster, from your home screen.', true); } }, 8000); }
  });
  window.addEventListener('appinstalled', function () { deferredPrompt = null; window.__neasInstall = null; setInstallButtons(false); remove(document.querySelector('.pwa-banner')); showConn(true, 'NeAS is installed.'); });
  document.addEventListener('click', function (e) { var t = e.target && e.target.closest ? e.target.closest('[data-pwa-install]') : null; if (t) { e.preventDefault(); promptInstall(); } });
  function initInstallUi() {
    if (isStandalone()) { setInstallButtons(false); return; }
    setInstallButtons(true); // always offer it: without the browser prompt it shows how to install by hand
    if (deferredPrompt && !dismissedRecently()) { setTimeout(function () { if (deferredPrompt) { banner('Install NeAS', 'Open it like an app, faster, from your home screen.', true); } }, 8000); }
    if (isIos() && !dismissedRecently()) { setTimeout(function () { banner('Install NeAS', 'Tap Share, then "Add to Home Screen".', false); }, 8000); }
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', initInstallUi); } else { initInstallUi(); }

  /* ---------- service worker + updates ---------- */
  var reg = null;
  function showUpdate(worker) {
    if (document.querySelector('.pwa-toast')) { return; }
    var t = el('div', { 'class': 'pwa-toast', role: 'status' }, '<span>A new version of NeAS is ready.</span>');
    var b = el('button', { type: 'button', 'class': 'pwa-btn' }); b.textContent = 'Update';
    b.addEventListener('click', function () { b.disabled = true; b.textContent = 'Updating…'; worker.postMessage('SKIP_WAITING'); });
    t.appendChild(b); document.body.appendChild(t);
  }
  function track(r) {
    if (r.waiting && navigator.serviceWorker.controller) { showUpdate(r.waiting); }
    r.addEventListener('updatefound', function () {
      var w = r.installing; if (!w) { return; }
      w.addEventListener('statechange', function () { if (w.state === 'installed' && navigator.serviceWorker.controller) { showUpdate(w); } });
    });
  }

  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register(BASE + 'sw.js', { scope: BASE, updateViaCache: 'none' }).then(function (r) {
        reg = r; track(r);
        // Look for a new version when the app returns to the foreground and once an hour while it stays open.
        document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') { r.update().catch(function () {}); } });
        setInterval(function () { r.update().catch(function () {}); }, 3600000);
      }).catch(function () { /* the site works without it */ });
    });
    // Reload only when an UPDATE took over (the page already had a worker). On the very first install the worker just claims the page: no reload, so nothing typed is lost.
    var hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', function () { if (!hadController) { hadController = true; return; } if (reloading) { return; } reloading = true; location.reload(); });
  }
})();
