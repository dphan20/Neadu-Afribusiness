/* Ask AI: open/close the dialog, suggestion chips, Enter to send, auto-growing box. Streaming itself lives in photo-picker-js. */
(function () {
  'use strict';
  var dialog = document.getElementById('ai-dialog');

  document.addEventListener('click', function (e) {
    var open = e.target.closest && e.target.closest('[data-ai-open]');
    if (open) {
      e.preventDefault();
      if (dialog && typeof dialog.showModal === 'function') {
        if (!dialog.open) { dialog.showModal(); }
        var q = dialog.querySelector('[data-ai-input]'); if (q) { q.focus(); }
      } else {
        var link = document.querySelector('a[href$="/me/ask"]'); location.href = link ? link.href : '/me/ask';
      }
      return;
    }
    if (e.target.closest && e.target.closest('[data-ai-close]') && dialog) { dialog.close(); return; }
    if (dialog && e.target === dialog) { dialog.close(); return; }

    var chip = e.target.closest && e.target.closest('[data-ai-suggest]');
    if (chip) {
      var f = chip.closest('form') || dialog || document, box = f.querySelector('[data-ai-input]');
      if (box) { box.value = chip.getAttribute('data-ai-suggest'); box.dispatchEvent(new Event('input', { bubbles: true })); box.focus(); }
    }
  });

  function grow(t) { t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 180) + 'px'; }
  document.addEventListener('input', function (e) { if (e.target.matches && e.target.matches('[data-ai-input]')) { grow(e.target); } });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.target.matches && e.target.matches('[data-ai-input]')) {
      e.preventDefault(); var f = e.target.form; if (f && f.requestSubmit) { f.requestSubmit(); }
    }
  });
})();

/* Small, safe formatter for AI answers: **bold**, *italic*, lists, headings, paragraphs. Everything is escaped first. */
(function () {
  'use strict';
  function esc(t) { return t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function inline(t) { return esc(t).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/(^|[\s(])\*(?!\s)(.+?)\*(?=[\s).,;:!?]|$)/g, '$1<em>$2</em>').replace(/`([^`]+)`/g, '<code>$1</code>'); }
  function html(text) {
    var lines = String(text || '').replace(/\r/g, '').split('\n'), out = [], list = null, para = [];
    function endPara() { if (para.length) { out.push('<p>' + para.join('<br>') + '</p>'); para = []; } }
    function endList() { if (list) { out.push('</' + list + '>'); list = null; } }
    lines.forEach(function (raw) {
      var l = raw.trim(), m;
      if (!l) { endPara(); endList(); return; }
      if ((m = l.match(/^#{1,4}\s+(.*)$/))) { endPara(); endList(); out.push('<h4>' + inline(m[1]) + '</h4>'); return; }
      if ((m = l.match(/^(?:[-*•])\s+(.*)$/))) { endPara(); if (list !== 'ul') { endList(); out.push('<ul>'); list = 'ul'; } out.push('<li>' + inline(m[1]) + '</li>'); return; }
      if ((m = l.match(/^(\d+)[.)]\s+(.*)$/))) { endPara(); if (list !== 'ol') { endList(); out.push('<ol>'); list = 'ol'; } out.push('<li>' + inline(m[2]) + '</li>'); return; }
      endList(); para.push(inline(l));
    });
    endPara(); endList();
    return out.join('');
  }
  window.NeasMd = { html: html };
  function upgrade() { Array.prototype.forEach.call(document.querySelectorAll('[data-md]'), function (n) { n.innerHTML = html(n.textContent); n.removeAttribute('data-md'); }); }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', upgrade); } else { upgrade(); }
})();
