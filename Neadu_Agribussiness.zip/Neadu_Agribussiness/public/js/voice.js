/*
 * NeAS voice input: record -> listen back -> Send voice / Discard.
 * The clip is recorded with MediaRecorder (works in Chrome, Edge, Firefox, Safari, Android), converted to WAV and written down by the server (Gemini).
 * Nothing is sent until the person presses "Send voice".
 */
(function () {
  'use strict';
  var MAX_MS = 60000, MIN_MS = 700;

  function csrf() { var m = document.querySelector('meta[name="csrf-token"]'); return m ? m.content : ''; }
  function getLang() { try { return localStorage.getItem('neas.voice.lang') === 'en-US' ? 'en-US' : 'sw-TZ'; } catch (e) { return 'sw-TZ'; } }
  function setLang(v) { try { localStorage.setItem('neas.voice.lang', v); } catch (e) { /* private mode */ } }

  var MSG = {
    blocked: 'The microphone is blocked. Tap the lock icon next to the address, allow Microphone, then try again.',
    nomic: 'No microphone was found on this device.',
    secure: 'Voice needs a secure (https) address or localhost.',
    short: 'That was too short. Tap Record, speak, then tap Stop.',
    silent: 'The microphone is not picking up any sound. Check that the right microphone is selected and not muted, then record again.',
    unsupported: 'This browser cannot record voice. Please type your question.',
    empty: 'I could not make out any words. Record again, closer to the microphone.',
    server: 'Voice could not be converted to text. Check the internet connection or type your question.'
  };

  function encodeWav(samples, rate) {
    var buf = new ArrayBuffer(44 + samples.length * 2), v = new DataView(buf), i, o = 44;
    function str(off, s) { for (var k = 0; k < s.length; k++) { v.setUint8(off + k, s.charCodeAt(k)); } }
    str(0, 'RIFF'); v.setUint32(4, 36 + samples.length * 2, true); str(8, 'WAVE'); str(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, rate, true);
    v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); str(36, 'data'); v.setUint32(40, samples.length * 2, true);
    for (i = 0; i < samples.length; i++, o += 2) { var s = Math.max(-1, Math.min(1, samples[i])); v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true); }
    return new Blob([v], { type: 'audio/wav' });
  }

  // Any recording format -> 16 kHz mono WAV (always accepted by the transcription service). Falls back to the original clip.
  function toWav(blob) {
    var Ctx = window.AudioContext || window.webkitAudioContext, Off = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (!Ctx || !Off || !blob.arrayBuffer) { return Promise.resolve(blob); }
    return blob.arrayBuffer().then(function (data) {
      var ctx = new Ctx();
      return new Promise(function (res, rej) { ctx.decodeAudioData(data, res, rej); }).then(function (audio) {
        try { ctx.close(); } catch (e) { /* ignore */ }
        var rate = 16000, off = new Off(1, Math.max(1, Math.ceil(audio.duration * rate)), rate), src = off.createBufferSource();
        src.buffer = audio; src.connect(off.destination); src.start();
        return off.startRendering();
      });
    }).then(function (r) { return encodeWav(r.getChannelData(0), 16000); }).catch(function () { return blob; });
  }

  function micError(e) {
    var n = e && e.name;
    if (n === 'NotFoundError' || n === 'DevicesNotFoundError') { return MSG.nomic; }
    if (location.protocol !== 'https:' && !/^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname)) { return MSG.secure; }
    return MSG.blocked;
  }

  /**
   * states: idle -> listening (recording) -> recorded (clip ready) -> processing -> idle
   * opt: transcribeUrl, lang(), onState(s), onError(msg), onRecorded({url, seconds}), onFinal(text)
   */
  function create(opt) {
    var state = 'idle', stream = null, recorder = null, chunks = [], timer = null, startedAt = 0, peak = 0, meter = null, meterCtx = null, clip = null;
    function emit(s) { state = s; if (opt.onState) { opt.onState(s); } }
    function error(m) { if (opt.onError) { opt.onError(m); } }
    function release() {
      clearTimeout(timer); clearInterval(meter); meter = null;
      if (meterCtx) { try { meterCtx.close(); } catch (e) { /* ignore */ } meterCtx = null; }
      if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; }
    }
    function dropClip() { if (clip && clip.url) { URL.revokeObjectURL(clip.url); } clip = null; }

    function watchLevel(s) {
      var Ctx = window.AudioContext || window.webkitAudioContext; peak = 1; if (!Ctx) { return; }
      try {
        meterCtx = new Ctx(); var an = meterCtx.createAnalyser(); an.fftSize = 1024; meterCtx.createMediaStreamSource(s).connect(an);
        var data = new Float32Array(an.fftSize); peak = 0;
        meter = setInterval(function () { an.getFloatTimeDomainData(data); for (var i = 0; i < data.length; i++) { var a = Math.abs(data[i]); if (a > peak) { peak = a; } } }, 80);
      } catch (e) { peak = 1; }
    }

    function start() {
      if (state !== 'idle') { return; }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) { return error(location.protocol !== 'https:' && !/^(localhost|127\.0\.0\.1)$/.test(location.hostname) ? MSG.secure : MSG.unsupported); }
      dropClip();
      navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }).then(function (s) {
        stream = s; chunks = [];
        try { recorder = new MediaRecorder(s); } catch (e) { release(); return error(MSG.unsupported); }
        recorder.ondataavailable = function (ev) { if (ev.data && ev.data.size) { chunks.push(ev.data); } };
        recorder.onstop = function () {
          var ms = Date.now() - startedAt, level = peak, type = recorder.mimeType || 'audio/webm';
          release();
          if (ms < MIN_MS || !chunks.length) { emit('idle'); return error(MSG.short); }
          if (level < 0.008) { emit('idle'); return error(MSG.silent); }
          var blob = new Blob(chunks, { type: type });
          clip = { blob: blob, url: URL.createObjectURL(blob), seconds: Math.round(ms / 100) / 10 };
          emit('recorded'); if (opt.onRecorded) { opt.onRecorded(clip); }
        };
        watchLevel(s); startedAt = Date.now(); recorder.start(250); emit('listening');
        timer = setTimeout(stop, MAX_MS);
      }).catch(function (e) { release(); emit('idle'); error(micError(e)); });
    }

    function stop() { if (recorder && recorder.state === 'recording') { try { recorder.stop(); } catch (e) { release(); emit('idle'); } } }

    function send() {
      if (state !== 'recorded' || !clip) { return; }
      var blob = clip.blob; emit('processing');
      toWav(blob).then(function (wav) {
        var fd = new FormData(); fd.append('audio', wav, 'voice.wav'); fd.append('lang', opt.lang ? opt.lang() : 'sw-TZ');
        return fetch(opt.transcribeUrl, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } });
      }).then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (x) {
          if (!x.ok || !x.j.text) { emit('recorded'); return error(x.j.error || (x.ok ? MSG.empty : MSG.server)); }
          dropClip(); emit('idle'); if (opt.onFinal) { opt.onFinal(x.j.text); }
        }).catch(function () { emit('recorded'); error(MSG.server); });
    }

    function discard() { if (state === 'processing') { return; } stop(); release(); dropClip(); emit('idle'); }
    function toggle() { if (state === 'idle') { start(); } else if (state === 'listening') { stop(); } }
    return { start: start, stop: stop, send: send, discard: discard, toggle: toggle, state: function () { return state; } };
  }

  window.NeasVoice = { create: create, getLang: getLang, setLang: setLang, supported: !!(navigator.mediaDevices && window.MediaRecorder) };

  /* ---- declarative: <button data-voice="#textarea"> inside a form ---- */
  function bind(btn) {
    if (btn.__voice) { return btn.__voice; }
    var form = btn.closest('form') || document, status = form.querySelector('[data-ask-status]'), label = btn.querySelector('span'), bar = null;
    function target() { return document.querySelector(btn.getAttribute('data-voice')); }
    function say(t) { if (status) { status.textContent = t || ''; } }
    function removeBar() { if (bar) { bar.remove(); bar = null; } }
    var v = NeasVoice.create({
      transcribeUrl: btn.getAttribute('data-voice-url') || '/me/ask/transcribe', lang: getLang,
      onRecorded: function (clip) {
        removeBar(); bar = document.createElement('div'); bar.className = 'ai-clip';
        bar.innerHTML = '<audio controls preload="metadata"></audio><div class="ai-clip-btns"><button type="button" class="ai-send" data-clip-send>Send voice</button><button type="button" class="ai-lang ai-clip-x" data-clip-discard>Discard</button></div>';
        bar.querySelector('audio').src = clip.url;
        bar.querySelector('[data-clip-send]').addEventListener('click', function () { v.send(); });
        bar.querySelector('[data-clip-discard]').addEventListener('click', function () { v.discard(); });
        var anchor = btn.closest('.ai-actions') || btn.parentNode; anchor.parentNode.insertBefore(bar, anchor);
        say('Recorded ' + clip.seconds + 's. Play it back, then tap Send voice.');
      },
      onFinal: function (text) {
        removeBar(); var el = target(); if (!el) { return; }
        el.value = ((el.value || '').trim() + ' ' + text).trim(); el.dispatchEvent(new Event('input', { bubbles: true }));
        say(''); if (form.requestSubmit) { form.requestSubmit(); }
      },
      onError: function (m) { say(m); },
      onState: function (s) {
        btn.classList.toggle('is-listening', s === 'listening'); btn.setAttribute('aria-pressed', s === 'listening' ? 'true' : 'false');
        btn.disabled = s === 'processing' || s === 'recorded';
        if (label) { label.textContent = s === 'listening' ? 'Stop' : 'Record'; }
        if (s === 'idle') { removeBar(); }
        if (s === 'listening') { say(getLang() === 'en-US' ? 'Recording… speak now, then tap Stop.' : 'Inarekodi… sema sasa, kisha bonyeza Stop.'); }
        if (bar) { Array.prototype.forEach.call(bar.querySelectorAll('button'), function (b) { b.disabled = s === 'processing'; }); }
        if (s === 'processing') { say('Converting your voice to text…'); }
      }
    });
    btn.__voice = v;
    return v;
  }

  document.addEventListener('click', function (e) {
    var lang = e.target.closest && e.target.closest('[data-voice-lang]');
    if (lang) { setLang(getLang() === 'en-US' ? 'sw-TZ' : 'en-US'); syncLang(); return; }
    var b = e.target.closest && e.target.closest('[data-voice]');
    if (b) { e.preventDefault(); bind(b).toggle(); }
  });
  function syncLang() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-voice-lang]'), function (b) {
      b.textContent = getLang() === 'en-US' ? 'EN' : 'SW'; b.setAttribute('aria-label', 'Voice language: ' + (getLang() === 'en-US' ? 'English' : 'Kiswahili') + '. Tap to change.');
    });
  }
  document.addEventListener('DOMContentLoaded', syncLang);
  if (document.readyState !== 'loading') { syncLang(); }
})();
