<?php

namespace App\Providers;

use App\Contracts\DiagnosisEngine;
use App\Contracts\IdentityVerifier;
use App\Contracts\PaymentGateway;
use App\Contracts\SmsGateway;
use App\Contracts\WeatherProvider;
use App\Services\LogSmsGateway;
use App\Services\GeminiDiagnosisEngine;
use App\Services\MockDiagnosisEngine;
use App\Services\MockIdentityVerifier;
use App\Services\MockPaymentGateway;
use App\Services\MockWeatherProvider;
use App\Services\OpenMeteoWeatherProvider;
use App\Services\Weather\OpenMeteoAdapter;
use App\Services\Weather\WeatherServiceInterface;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;
use Illuminate\Validation\Rules\Password;
use RuntimeException;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // OPEN-Q3 / Q4 / Q7: external providers sit behind interfaces. Swap these bindings for real adapters.
        $this->app->bind(IdentityVerifier::class, MockIdentityVerifier::class);
        $this->app->bind(PaymentGateway::class, MockPaymentGateway::class);
        $this->app->bind(SmsGateway::class, LogSmsGateway::class);
        $this->app->bind(DiagnosisEngine::class, fn ($app) => filled(config('services.gemini.key'))
            ? $app->make(GeminiDiagnosisEngine::class)
            : $app->make(MockDiagnosisEngine::class)); // no key configured: deterministic stand-in (local only)
        $this->app->bind(WeatherProvider::class, fn ($app) => config('neas.weather.provider') === 'mock'
            ? $app->make(MockWeatherProvider::class)
            : $app->make(OpenMeteoWeatherProvider::class));
        $this->app->bind(WeatherServiceInterface::class, OpenMeteoAdapter::class); // S-32 page and the hourly alert job
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $this->guardProduction();

        // Sign-in is limited per account AND per address, so one attacker cannot hammer one account from many IPs,
        // and one shared mobile-network IP cannot lock out every farmer behind it.
        RateLimiter::for('login', static fn (Request $request): array => [
            Limit::perMinute(5)->by('login|'.mb_strtolower((string) ($request->input('login') ?? $request->input('phone'))).'|'.$request->ip()),
            Limit::perMinute(30)->by('login-ip|'.$request->ip()),
        ]);

        // One password rule for the whole app (NFR-S3): 8+ characters with letters and numbers; known-leaked passwords rejected in production.
        Password::defaults(static fn (): Password => app()->isProduction()
            ? Password::min(8)->letters()->numbers()->uncompromised()
            : Password::min(8)->letters()->numbers());
    }

    /** Refuse to run production in an unsafe configuration instead of silently taking real money in a demo mode. */
    private function guardProduction(): void
    {
        if (! $this->app->isProduction()) {
            return;
        }

        if ((bool) config('neas.simulate_gateways')) {
            throw new RuntimeException('NEAS_SIMULATE_GATEWAYS must be false in production: payments would be confirmed without any money moving.');
        }
        if (config('app.debug')) {
            config(['app.debug' => false]); // never show stack traces, queries or secrets to visitors
            Log::critical('APP_DEBUG was true in production and has been forced off. Fix .env.');
        }

        if (blank(config('neas.payments.webhook_secret'))) {
            Log::critical('NEAS_PAYMENT_WEBHOOK_SECRET is empty: payment callbacks are refused, so paid orders will not start escrow.');
        }
        config(['session.secure' => true, 'session.http_only' => true]); // cookies never travel over plain HTTP

        URL::forceScheme('https');
        DB::prohibitDestructiveCommands(); // migrate:fresh / db:wipe refuse to run against the live database
    }
}
