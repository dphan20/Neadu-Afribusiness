# Fix 3: Expert and Trainer workspaces wired together

**Status: written and statically checked, NOT yet run.** PHP lint passes, every `expert.*` / `trainer.*` route name used in code, views and tests exists, and every routed controller method exists. Run `php artisan test` to confirm; send the first failure if any.

## What was wrong
Two versions of each workspace were mixed. `routes/web.php` pointed at a simple version (`Expert\ExpertController`, `Trainer\TrainerController`) while the tests, most views and the chat controllers were built for the full version. The Expert dashboard redirected to a route that did not exist (500).

## What changed
- **Routes:** `/expert/*` and `/trainer/*` now map to `ExpertController`, `ExpertChatController`, `TrainerController`, `TrainerChatController` (dashboard, cases, advice, consultations, earnings, profile, chat; tours, bookings, certificates, earnings, profile, group chat). Added public `/certificates/{number}`. Old simple controllers and their views (`expert/queue`, `trainer/form`) removed.
- **Models:** `DiagnosisCase::producer()/corrections()`, `AdvicePost::crop()/region()` (+ `expert()` now uses `user_id`, soft deletes), `Tour::listing()/bookings()/reviews()/seatsTaken()/seatsLeft()`, `TourBooking::tour()/attendee()/listing()`, `User::tourBookings()`, casts for the new date/array columns.
- **Rewritten views:** `expert/case`, `expert/advice`, `expert/feed`, `trainer/tours`.
- **Producer to expert hand-off:** a new diagnosis is `open`; "Escalate" puts it in the expert queue (`escalated`); the first expert to claim it owns it. Direct expert chat assigns the case as `in_review`.
- **Attendee tours:** `TourService`, `Shared/TourController` and the `tours/*` views used an older booking schema (`listing_id`, `amount_minor`, `held`) that the migrations never create. They now use `tour_id`, `total_minor`, `reserved`, `TourReview`, and certificate numbers.
- **Feature flags:** with no row in `feature_flags`, features are on in local/testing and off in production. An explicit row always wins.

## Known limits
- `advice_posts` has two conflicting migrations; the Expert one (`user_id`, `domain`) runs first. A database that already has the older table (`expert_id`, `category`) needs `migrate:fresh`.
- Not yet reviewed: Producer, Buyer, Transporter, Land owner, Warehouse owner, Trader and Admin role workflows.
