# Shared helpers. Reads .env WITHOUT sourcing it (values may contain spaces, # or $).
APP_DIR="${APP_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
envget() { grep -E "^$1=" "$APP_DIR/.env" 2>/dev/null | tail -1 | cut -d= -f2- | sed -e 's/[[:space:]]#.*$//' -e 's/^"//' -e 's/"[[:space:]]*$//' -e "s/^'//" -e "s/'\$//"; }
alert() {  # alert "message"  -> posts to BACKUP_ALERT_WEBHOOK (Slack/Discord-compatible JSON) and logs
  local msg="$1" hook; hook="$(envget BACKUP_ALERT_WEBHOOK)"
  echo "$(date -Is) ALERT: $msg" >&2
  [ -n "$hook" ] && curl -fsS -m 10 -H 'Content-Type: application/json' -d "{\"text\":\"NeAS $(hostname): ${msg//\"/\'}\",\"content\":\"NeAS $(hostname): ${msg//\"/\'}\"}" "$hook" >/dev/null 2>&1 || true
}
