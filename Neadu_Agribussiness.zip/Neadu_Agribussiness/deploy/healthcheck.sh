#!/usr/bin/env bash
# Every 5 minutes: site up over HTTPS, queue not stuck, failed jobs not piling up, disk not full, certificate not expiring.
set -uo pipefail
. "$(dirname "$0")/lib.sh"
URL="$(envget APP_URL)"; STATE="${TMPDIR:-/tmp}/neas-health.state"; PROBLEMS=()

curl -fsS -m 15 -o /dev/null "$URL/up" || PROBLEMS+=("site not answering at $URL/up")
FAILED=$(cd "$APP_DIR" && php artisan queue:failed --format=json 2>/dev/null | python3 -c 'import sys,json;print(len(json.load(sys.stdin)))' 2>/dev/null || echo 0)
[ "${FAILED:-0}" -gt 10 ] && PROBLEMS+=("$FAILED failed queue jobs")
pgrep -f "queue:work" >/dev/null || PROBLEMS+=("no queue worker running")
pgrep -f "reverb:start" >/dev/null || PROBLEMS+=("reverb (live tracking) not running")
USED=$(df --output=pcent "$APP_DIR" | tail -1 | tr -dc '0-9'); [ "${USED:-0}" -ge 90 ] && PROBLEMS+=("disk ${USED}% full")
HOST=$(echo "$URL" | sed -E 's#https?://([^/:]+).*#\1#')
END=$(echo | openssl s_client -servername "$HOST" -connect "$HOST:443" 2>/dev/null | openssl x509 -noout -enddate 2>/dev/null | cut -d= -f2)
if [ -n "$END" ]; then DAYS=$(( ($(date -d "$END" +%s) - $(date +%s)) / 86400 )); [ "$DAYS" -lt 14 ] && PROBLEMS+=("TLS certificate expires in $DAYS days"); fi

NOW="${PROBLEMS[*]:-}"
if [ -n "$NOW" ]; then
  # alert on change only, so a long outage does not send 288 messages a day
  [ "$(cat "$STATE" 2>/dev/null)" = "$NOW" ] || { alert "PROBLEM: $NOW"; echo "$NOW" > "$STATE"; }
  exit 1
fi
[ -s "$STATE" ] && { alert "RECOVERED: all checks pass"; : > "$STATE"; }
exit 0
