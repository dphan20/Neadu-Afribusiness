# NeAS production runbook

What is already done in the code, and what only you can do on a server. Work top to bottom. `[code]` = in this repo, `[you]` = needs your server, domain or provider account.

## 0. Blockers before real money moves
1. **Payment gateway is still a mock** `[you + code]`. `PaymentGateway` is bound to `MockPaymentGateway`. Real mobile-money / bank payments need a provider contract (for example Selcom, Azampay, Flutterwave, or direct M-Pesa/Tigo/Airtel APIs) and an adapter class. `php artisan neas:preflight` fails until this is replaced.
2. **Demo data must not exist** `[you]`. Never seed demo data on production (deploy.sh loads only the reference data with db:seed --class=ReferenceDataSeeder --force). Preflight checks for the demo accounts (phones starting `2557000000`).
3. **Admin accounts** `[you]`: `php artisan admin:create "Your Name" you@domain --scope=super` (12+ character password).

## 1. Server `[you]`
- Ubuntu 24.04 LTS, 2 vCPU / 4 GB RAM minimum. PHP 8.3 or 8.4 with: `fpm cli mbstring xml curl zip gd intl bcmath redis pdo_mysql`. Composer 2, Node 22 + pnpm, nginx, Redis, MySQL 8 / MariaDB 10.11, supervisor, certbot, rclone.
- PHP: `expose_php=Off`, `display_errors=Off`, OPcache on (`opcache.validate_timestamps=0` if you always run `deploy.sh`).
- **Composer lock needs PHP 8.4** until it is re-resolved: on a PHP 8.3 box run `composer config platform.php 8.3.0 && composer update --with-all-dependencies` once on your laptop and commit `composer.lock`.

## 2. Domain, DNS, HTTPS `[you]`
- DNS `A` (and `AAAA`) record: `app.example.co.tz` to the server IP. TTL 300 while launching.
- `sudo certbot certonly --webroot -w /var/www/certbot -d app.example.co.tz`, then install `deploy/nginx.conf`. Certbot renews automatically; the health check warns 14 days before expiry.
- Test: `curl -I https://app.example.co.tz` returns 200 and `Strict-Transport-Security`. HTTPS is mandatory: service workers and the install prompt do not work without it.

## 3. Firewall and permissions `[you]`
```
sudo ufw default deny incoming && sudo ufw allow OpenSSH && sudo ufw allow 80,443/tcp && sudo ufw enable
# MySQL, Redis and Reverb (8080) listen on 127.0.0.1 only. Confirm: ss -tlnp
sudo apt install fail2ban unattended-upgrades
```
SSH keys only (`PasswordAuthentication no`). App files owned by the deploy user; only `storage/` and `bootstrap/cache/` writable by `www-data`:
```
sudo chown -R deploy:www-data /var/www/neas && sudo find /var/www/neas -type d -exec chmod 755 {} \;
sudo chmod -R ug+rwX /var/www/neas/storage /var/www/neas/bootstrap/cache && chmod 640 /var/www/neas/.env
```

## 4. Database with automated backups
- `[you]` Create the database and a dedicated user: `CREATE USER 'neas'@'localhost' IDENTIFIED BY '...'; GRANT ALL ON neas.* TO 'neas'@'localhost';`
- `[code]` `deploy/backup.sh` dumps the database and `storage/app`, verifies the archives, deletes old ones (`BACKUP_KEEP_DAYS`), and posts to `BACKUP_ALERT_WEBHOOK` on failure. Scheduled nightly by `deploy/cron.txt`.
- `[you]` Set `BACKUP_RCLONE_REMOTE` to an off-site bucket (`rclone config`). **A backup that lives only on the same server is not a backup.** Also enable your host's disk snapshots.
- **Restore drill (do it once before launch):**
  `gunzip -c db-YYYYMMDD-HHMMSS.sql.gz | mysql -u neas -p neas` and `tar -xzf files-YYYYMMDD-HHMMSS.tar.gz -C /var/www/neas/shared`. Time it and write the time down.

## 5. Redis, queue workers, scheduler `[code + you]`
- `.env`: `CACHE_STORE=redis SESSION_DRIVER=redis QUEUE_CONNECTION=redis`. Set a Redis password; bind to 127.0.0.1.
- Workers and Reverb: copy `deploy/supervisor.conf` to `/etc/supervisor/conf.d/neas.conf`, then `supervisorctl reread && supervisorctl update`.
- Scheduler: install `deploy/cron.txt` for `www-data`. Jobs: auto-release orders, unanswered orders, price alerts, storage settlement, storage expiry alerts, unpaid tour seats, weather alerts, failed-job pruning.

## 6. Files `[you]`
- Private files (ID documents, land titles, case photos) are on the `local` disk: `storage/app/private`. They are never in `public/` and are included in backups.
- Public uploads: `php artisan storage:link`. If you run more than one server, move both disks to S3-compatible storage (`FILESYSTEM_DISK=s3`) so files are shared.
- Use a deploy layout with a shared `storage/` (`/var/www/neas/shared/storage`) so releases do not lose uploads.

## 7. Email and SMS `[you]`
- SMTP: fill `MAIL_*`. Send a test: `php artisan tinker --execute="Mail::raw('ok', fn(\$m)=>\$m->to('you@domain')->subject('NeAS test'));"`.
- SMS: `[code]` `AfricasTalkingSmsGateway` is included and selected by `SMS_DRIVER=africastalking`. `[you]` Create the account, set `AT_USERNAME`, `AT_API_KEY`, and apply for a Sender ID with the operators (takes days: start early). **This adapter was written against the provider's documented API but has not been run against the live service: send yourself an OTP before launch.**
- USSD/SMS replies: set `NEAS_USSD_SECRET` and give the same secret to your aggregator.

## 8. Production settings `[code]` verified by `php artisan neas:preflight`
`APP_DEBUG=false`, `APP_ENV=production`, https `APP_URL`, real DB, async queue, live mail and SMS, `NEAS_SIMULATE_GATEWAYS=false`, no demo users, config cached. Run it after every deploy (the deploy script does).

## 9. Monitoring and alerts
- `[you]` External uptime monitor (UptimeRobot, Better Stack, etc.) on `https://app.example.co.tz/up` every minute, alerting by SMS/WhatsApp/email.
- `[code]` `deploy/healthcheck.sh` (every 5 min) alerts on: site down, no queue worker, Reverb down, more than 10 failed jobs, disk at 90%, certificate within 14 days. It alerts on change only and sends "RECOVERED".
- `[code]` Application errors: `LOG_STACK=daily,slack` + `LOG_LEVEL=error` + `LOG_SLACK_WEBHOOK_URL` sends every exception to your channel. For grouped errors with stack traces, add Sentry or Flare later (`composer require sentry/sentry-laravel`, then `SENTRY_LARAVEL_DSN`).
- `[you]` Logrotate for `/var/log/neas-*.log` and `/var/log/nginx`.

## 10. Deploy, update, roll back
- Deploy: `cd /var/www/neas/current && git pull && bash deploy/deploy.sh` (backup, maintenance mode, install, build, migrate, cache, preflight, restart workers, back up).
- Roll back: `git checkout <previous tag>`, `bash deploy/deploy.sh`. If a migration must be undone, restore the pre-deploy backup (section 4).
- **PWA updates:** to ship a new app version to installed phones, change `VERSION` in `public/sw.js` (the deploy itself already changes the built file names). Users see "A new version of NeAS is ready" and tap Update.

## 11. PWA test checklist `[you]` on real devices
Automated checks (`node tests/pwa/e2e.mjs`) already cover: worker registers, installable per Chrome, offline page, private pages not cached, forms blocked offline, update toast and cache cleanup. Still test by hand:
- Android Chrome: open the HTTPS site, wait about 15 seconds, tap **Install**; open from the home screen (no browser bar); turn on airplane mode and open it (offline page, not a browser error); turn it off (page recovers); deploy a new `VERSION` and confirm the Update toast.
- Desktop Chrome/Edge: install icon in the address bar; app opens in its own window; DevTools, Application, Service Workers shows the current version; Lighthouse PWA audit.
- iPhone Safari: Share, Add to Home Screen (no install prompt exists on iOS; the site shows a hint).
- Sign in on the installed app, sign out, confirm another person on the same phone cannot see the previous account's pages offline (they are never stored).
