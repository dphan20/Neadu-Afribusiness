#!/usr/bin/env bash
# Zero-surprise deploy.  Usage on the server:  cd /var/www/neas/current && bash deploy/deploy.sh
# Assumes the code is already updated (git pull / rsync) and .env exists.
set -Eeuo pipefail
cd "$(dirname "$0")/.."
trap 'echo "DEPLOY FAILED. Site left in maintenance mode: fix, then run: php artisan up" >&2' ERR

php -r 'exit(version_compare(PHP_VERSION,"8.3.0",">=")?0:1);' || { echo "PHP 8.3+ required"; exit 1; }
bash deploy/backup.sh                                   # always a fresh backup first
php artisan down --retry=30 --refresh=15 || true

composer install --no-dev --prefer-dist --optimize-autoloader --no-interaction
CI=true pnpm install --frozen-lockfile
pnpm run build

php artisan migrate --force
php artisan storage:link 2>/dev/null || true
php artisan optimize:clear
php artisan config:cache && php artisan route:cache && php artisan view:cache && php artisan event:cache

php artisan neas:preflight                              # stops here if anything unsafe is configured
php artisan queue:restart                               # workers pick up the new code
sudo supervisorctl restart neas-reverb 2>/dev/null || true
sudo systemctl reload php8.3-fpm 2>/dev/null || true
php artisan up
echo "Deployed. Verify: $(grep -E '^APP_URL=' .env | cut -d= -f2-)/up"
