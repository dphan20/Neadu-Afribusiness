#!/usr/bin/env bash
# Nightly backup: database dump + private/public files, compressed, rotated, optionally copied off-site.
# Restore steps are in deploy/RUNBOOK.md. Run by cron (deploy/cron.txt).
set -Eeuo pipefail
. "$(dirname "$0")/lib.sh"
trap 'alert "BACKUP FAILED at line $LINENO"' ERR

DIR="$(envget BACKUP_DIR)"; DIR="${DIR:-/var/backups/neas}"
KEEP="$(envget BACKUP_KEEP_DAYS)"; KEEP="${KEEP:-14}"
STAMP="$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DIR"; chmod 700 "$DIR"

DRIVER="$(envget DB_CONNECTION)"
DB="$(envget DB_DATABASE)"; USER="$(envget DB_USERNAME)"; PASS="$(envget DB_PASSWORD)"; HOST="$(envget DB_HOST)"; PORT="$(envget DB_PORT)"
OUT="$DIR/db-$STAMP.sql.gz"
case "$DRIVER" in
  mysql|mariadb) MYSQL_PWD="$PASS" mysqldump --single-transaction --quick --routines --no-tablespaces -h "${HOST:-127.0.0.1}" -P "${PORT:-3306}" -u "$USER" "$DB" | gzip -9 > "$OUT" ;;
  pgsql)         PGPASSWORD="$PASS" pg_dump -h "${HOST:-127.0.0.1}" -p "${PORT:-5432}" -U "$USER" "$DB" | gzip -9 > "$OUT" ;;
  sqlite)        sqlite3 "$APP_DIR/database/database.sqlite" ".backup '$DIR/db-$STAMP.sqlite'" && gzip -9 "$DIR/db-$STAMP.sqlite" && OUT="$DIR/db-$STAMP.sqlite.gz" ;;
  *) alert "BACKUP: unsupported DB_CONNECTION=$DRIVER"; exit 1 ;;
esac
[ -s "$OUT" ] || { alert "BACKUP: empty database dump"; exit 1; }
gzip -t "$OUT"   # integrity check

# Uploaded files (private documents + public uploads)
FILES="$DIR/files-$STAMP.tar.gz"
tar -czf "$FILES" -C "$APP_DIR" storage/app 2>/dev/null || tar -czf "$FILES" -C "${SHARED_DIR:-$APP_DIR}" storage/app
gzip -t "$FILES"

# Off-site copy (a backup on the same server is not a backup)
REMOTE="$(envget BACKUP_RCLONE_REMOTE)"
if [ -n "$REMOTE" ]; then rclone copy "$OUT" "$REMOTE" && rclone copy "$FILES" "$REMOTE"; else echo "WARNING: BACKUP_RCLONE_REMOTE not set, no off-site copy" >&2; fi

find "$DIR" -type f \( -name 'db-*' -o -name 'files-*' \) -mtime +"$KEEP" -delete
echo "$(date -Is) backup ok: $(basename "$OUT") $(du -h "$OUT" | cut -f1), $(basename "$FILES") $(du -h "$FILES" | cut -f1)"
