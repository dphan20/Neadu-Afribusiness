$ErrorActionPreference = "Stop"

Push-Location $PSScriptRoot
try {
    if (-not (Test-Path ".\artisan")) {
        throw "Run this setup script from the Neadu_Agribussiness project folder."
    }

    composer install
    if ($LASTEXITCODE -ne 0) {
        throw "Composer dependency installation failed."
    }

    if (-not (Test-Path ".\.env")) {
        Copy-Item ".\.env.example" ".\.env"
    }

    if ((Get-Content ".\.env") -match "^APP_KEY=$") {
        php artisan key:generate
        if ($LASTEXITCODE -ne 0) {
            throw "Laravel application key generation failed."
        }
    }

    php artisan migrate --seed
    if ($LASTEXITCODE -ne 0) {
        throw "Database migration or seeding failed."
    }
}
finally {
    Pop-Location
}
