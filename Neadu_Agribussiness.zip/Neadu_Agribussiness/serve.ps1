# NeAS local launcher (no Node needed). Run from the project folder:  .\serve.ps1
# Checks the setup, rebuilds Laravel's caches (big speed-up), starts the server with OPcache on, then times a few pages.
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
$port = 8000

if (-not (Test-Path .\artisan)) { Write-Host "Run this from the project folder." -ForegroundColor Red; exit 1 }
if (-not (Test-Path .\vendor\autoload.php)) { Write-Host "vendor\ is missing. Run: composer install" -ForegroundColor Red; exit 1 }
if (-not (Test-Path .\public\build\manifest.json)) { Write-Host "public\build is missing (styles). Re-extract the project zip; Node is not needed to run it." -ForegroundColor Red; exit 1 }
if (Test-Path .\public\hot) { Remove-Item .\public\hot -Force; Write-Host "Removed stale public\hot (it pointed pages at a Vite server that is not running)." -ForegroundColor Yellow }

# 1. Is MySQL answering? (a stopped or hung MySQL makes every page wait)
$envFile = Get-Content .\.env | Where-Object { $_ -match '^(DB_HOST|DB_PORT)=' }
$dbHost = ($envFile | Where-Object { $_ -like 'DB_HOST=*' }) -replace 'DB_HOST=', ''
$dbPort = ($envFile | Where-Object { $_ -like 'DB_PORT=*' }) -replace 'DB_PORT=', ''
if (-not $dbHost) { $dbHost = "127.0.0.1" }; if (-not $dbPort) { $dbPort = 3306 }
$tcp = New-Object System.Net.Sockets.TcpClient
$ok = $false
try { $ok = $tcp.ConnectAsync($dbHost, [int]$dbPort).Wait(3000) } catch {}
$tcp.Close()
if (-not $ok) { Write-Host "MySQL is NOT answering on ${dbHost}:${dbPort}. Start MySQL (XAMPP / Laragon / service) first." -ForegroundColor Red; exit 1 }
Write-Host "MySQL is up." -ForegroundColor Green

# 2. Caches: config, routes, views and events are compiled once instead of on every request.
php artisan optimize:clear | Out-Null
php artisan config:cache | Out-Null
php artisan route:cache | Out-Null
php artisan view:cache | Out-Null
php artisan event:cache | Out-Null
Write-Host "Caches built. (After editing .env or routes, run: php artisan optimize:clear)" -ForegroundColor Green

# 2b. A stuck earlier `php artisan serve` still holding the port is the usual reason every page times out. Free it.
Get-Process php -ErrorAction SilentlyContinue | ForEach-Object { Write-Host ("Stopping old PHP process {0}" -f $_.Id) -ForegroundColor Yellow; Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 1
$busy = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
if ($busy) { $owner = (Get-Process -Id $busy[0].OwningProcess -ErrorAction SilentlyContinue).ProcessName; Write-Host "Port $port is used by '$owner'. Using port 8081 instead." -ForegroundColor Yellow; $port = 8081 }

# 3. Start the server in its own window with OPcache enabled for the CLI (PHP files are compiled once, not per request).
$php = (Get-Command php).Source
$args = @("-d", "opcache.enable_cli=1", "-d", "opcache.memory_consumption=128", "-d", "opcache.validate_timestamps=1", "-d", "opcache.revalidate_freq=2",
          "-d", "realpath_cache_size=4096K", "-d", "realpath_cache_ttl=600", "-d", "max_execution_time=60",
          "-S", "127.0.0.1:$port", "-t", (Join-Path $PSScriptRoot "public"), (Join-Path $PSScriptRoot "vendor\laravel\framework\src\Illuminate\Foundation\resources\server.php"))
$srv = Start-Process -FilePath $php -ArgumentList $args -PassThru -WorkingDirectory (Join-Path $PSScriptRoot "public") -WindowStyle Minimized -RedirectStandardError "$env:TEMP\neas-server.log"
Start-Sleep -Seconds 2
if ($srv.HasExited) { Write-Host "The PHP server stopped at once. Its message:" -ForegroundColor Red; Get-Content "$env:TEMP\neas-server.log" -ErrorAction SilentlyContinue; exit 1 }

# 4. Self-test: time the pages. Anything over about 2 seconds is reported.
foreach ($path in @("/up", "/login", "/admin/login", "/build/manifest.json")) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try { $r = Invoke-WebRequest -Uri "http://127.0.0.1:$port$path" -UseBasicParsing -TimeoutSec 15; $code = $r.StatusCode } catch { $code = "FAILED: " + $_.Exception.Message }
    $sw.Stop()
    $color = if ($sw.Elapsed.TotalSeconds -gt 2) { "Yellow" } else { "Green" }
    Write-Host ("{0,-22} {1,-8} {2:N2}s" -f $path, $code, $sw.Elapsed.TotalSeconds) -ForegroundColor $color
}
Write-Host ""
Write-Host "Open http://127.0.0.1:$port/login  (admin console: /admin/login). Close the minimized PHP window or press Enter here to stop." -ForegroundColor Cyan
Read-Host | Out-Null
Stop-Process -Id $srv.Id -Force -ErrorAction SilentlyContinue
