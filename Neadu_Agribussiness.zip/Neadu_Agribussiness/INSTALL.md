# NeAS: Producer + Buyer + Expert + Trainer + Transporter (merged update)

Copy this folder over your project (files merge, nothing else is removed), then from the project root:

```bash
php artisan migrate
php artisan db:seed          # local only: demo users, producer, buyer market, expert/trainer and transporter data
php artisan storage:link
php artisan serve
```

Open http://127.0.0.1:8000/login. Demo accounts (phone 2557000000NN, password from DemoUsersSeeder: `1234`):
00 Producer · 01 Buyer · 02 Expert (/expert) · 03 Trainer (/trainer) · 04 Transporter (/transporter) · 05 Land owner (/landowner) · 06 Warehouse owner (/warehouse) · 08 Admin (/admin/vehicles verifies vehicles).

Admin review pages: /admin/review/documents (land title documents, BR-08) and /admin/review/listings (storage, tour and land approval).
R2/R3 flags used here: `storage_receipt`, `storage_alerts`, `contracts` (lease draft). Turn on with `php artisan neas:flag <name> on`.

Scheduler (cron): `* * * * * php artisan schedule:run`

What this update does
- Restores Producer wiring that the Buyer build had overwritten: routes, config/neas.php keys, Order/Listing/User/ProduceListing relations, seeders.
- Adds Expert (case queue, AI correction, advice, consultation earnings), Trainer (tours, attendees, certificates) and shared pages (/me/*: notifications, chat, wallet, profile, settings).
- Uses your Transporter update (routes/transporter.php) and fixes the broken `\App\Support\App\Support\Money` class path in the buyer views.
- Tours are behind feature flag `tours` (the seeder turns it on locally; production: `php artisan neas:flag tours on`).
- Land owner: land listings (farmland, factory, service-centre sites) with a private title document, Verified badge after admin approval, enquiries (message, visit, offer), lease draft (R3). Land search is at /land for every role.
- Warehouse owner: facilities (secure warehouse, port, grain; cold/dry/fumigation), accept or decline bookings, receipts (R2), expiry alerts (R2). Escrow bookings are paid to the owner minus the platform fee after the period ends (`storage:settle`, daily).
- Shared: /me/identity (NIDA) for roles that have no identity page of their own.

## NeAS console (Role 9, Admin) - separate sign-in

- Sign in at `/admin/login`. It uses its own `admin` auth guard: it never signs in to the marketplace, the marketplace login refuses admin-only accounts, and there is no admin registration or role switcher.
- Create admins from the terminal: `php artisan admin:create "Name" name@neas.co.tz --scope=finance` (scopes: super, support, verification, finance). Password needs 12+ characters.
- Local demo (after `php artisan db:seed`): admin.super@neas.test, admin.support@neas.test, admin.verification@neas.test, admin.finance@neas.test - password `ConsoleDemo#2026`. Remove before production.
- Least privilege (ADM-08): support = users, disputes, listings; verification = documents, vehicles, listings; finance = escrow, payouts, refunds, reconciliation; super = everything plus reference data, admin scopes, audit log.
- The console session ends after `neas.admin.idle_minutes` (30) of inactivity. Refunds above `neas.refund.two_person_above_tzs` need a second admin.

## AI (Gemini)

Set `GEMINI_API_KEY` (and optionally `GEMINI_MODEL`) in `.env`, then `php artisan config:clear`. With a key set, the producer photo diagnosis uses Gemini; without one it falls back to the deterministic local stand-in. "Ask AI" (`/me/ask`, every role) takes a question plus an optional photo. Run `php artisan migrate` for the `ai_queries` table.

## Fast, stoppable Ask AI + SEO (update)
- Answers now stream: the first words show in about a second. **Stop** ends the answer (and stops Gemini); **Delete** removes one answer, **Delete all answers** clears the history. No migration needed.
- Speed knobs in `.env` (all optional): `GEMINI_THINKING_LEVEL=minimal` (fastest; use `low` if answers get too shallow), `GEMINI_ASK_MAX_TOKENS=700`, `GEMINI_TIMEOUT=30`. If your `.env` has `GEMINI_THINKING_LEVEL=high` or a large `GEMINI_MAX_OUTPUT_TOKENS`, that is what made answers slow. Then run `php artisan config:clear`.
- SEO: per-page title/description/canonical/Open Graph, `noindex` on every signed-in page, JSON-LD on the home page, dynamic `/robots.txt` and `/sitemap.xml`.

## One-command setup
`bash scripts/setup.sh --seed` runs: PHP check, `composer install` (from lock), `.env` from `.env.example`, key, migrate, seed, `pnpm install --frozen-lockfile`, build, tests.
If composer says packages need PHP >= 8.4, the lock was resolved on 8.4: run `bash scripts/setup.sh --fix-lock --seed` once (needs Packagist) and commit the new `composer.lock`.
Deployment ZIP: exclude `node_modules`, `vendor`, `.env`, `public/build`.

## Landing page, PWA and production
- Landing page: `resources/views/welcome.blade.php`, `public/css/landing.css`, pictures in `public/images/gallery/` (original files, untouched).
- PWA: `public/manifest.webmanifest`, `public/sw.js` (change `VERSION` to ship an update), `public/offline.html`, `public/js/pwa.js`, icons in `public/icons/`. Pages are never cached. Test: `node --test tests/pwa/sw.test.mjs` and `node tests/pwa/e2e.mjs`.
- Local testing: use `php artisan serve` (http://127.0.0.1:8000) or a virtual host so the site is at the web root. A sub-folder URL such as `/Neadu_Agribussiness/public` breaks the root-relative manifest and service worker.
- Production: see `deploy/RUNBOOK.md`; run `php artisan neas:preflight` before go-live.
