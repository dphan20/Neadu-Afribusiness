# Neadu Agribusiness System

The Laravel application lives in this folder. Open it in XAMPP at:

`http://localhost/Neadu_Agribussiness/`

The root `.htaccess` forwards web requests to Laravel's `public` directory. The landing page, phone/PIN sign-in, role workspaces and admin console are Laravel routes and views.

## Database

The local database is the `neadu_agribusiness` schema in XAMPP MySQL. phpMyAdmin is available at `http://localhost/phpmyadmin/`. Laravel reads the connection settings from `.env`.

To initialize or update the schema and seed reference/demo data, run in PowerShell from this folder:

```powershell
php artisan migrate --seed
```

If you use a MySQL installation that requires a password, update `DB_PASSWORD` in `.env` before running the migration command.

## Accounts and workspaces

Create an account at `/register` with a mobile number, a 6–12 digit PIN, and one or more roles. You can switch between assigned roles from the top navigation. Administrators can manage all users and role assignments at `/admin/users`.

In non-production environments, `php artisan db:seed` creates one demo account for each of the nine roles. Demo PIN is `1234`; demo phone numbers are `255700000000` through `255700000008` in this order: Producer, Buyer, Expert, Trainer, Transporter, Land owner, Warehouse owner, Trader, Administrator. Demo seeding is disabled in production.

## Local setup

Requirements: PHP 8.4.1 or newer for the locked Composer dependencies, Composer, and Apache `mod_rewrite` enabled. Run `.\setup.ps1` from this folder for Composer setup and database initialization. Alternatively, serve the app with `php artisan serve`.

Routes are in `routes/`, backend code is in `app/`, views are in `resources/views/`, and schema changes are in `database/migrations/`.

## Validation

Run `php artisan test` for the application tests and `npm run build` for the frontend asset build.
