<?php $__env->startSection('title', 'Bookings'); ?>
<?php $__env->startSection('trainer'); ?>
<div class="workspace-heading"><div><a class="back-link" href="<?php echo e(route('trainer.dashboard')); ?>">← Overview</a><span class="eyebrow">S-28 · TUR-02</span><h1>Bookings &amp; payments</h1><p>Every seat across your tours. Unpaid seats are released automatically when the hold timer ends.</p></div></div>
<section class="panel data-panel">
    <form method="get" class="filter-bar"><label><span class="sr-only">Status</span><select name="status" onchange="this.form.submit()"><option value="">All statuses</option><?php $__currentLoopData = ['reserved', 'paid', 'completed', 'expired', 'cancelled', 'refunded']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s); ?>" <?php if($status === $s): echo 'selected'; endif; ?>><?php echo e(ucfirst($s)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label></form>
    <?php if($bookings->isEmpty()): ?><div class="empty-state"><span class="empty-mark">0</span><h3>No bookings</h3><p>Bookings appear once attendees reserve seats.</p></div>
    <?php else: ?><div class="table-wrap"><table class="data-table"><thead><tr><th>Attendee</th><th>Tour</th><th>Seats</th><th>Amount</th><th>Status</th><th>Hold / paid</th></tr></thead><tbody>
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($b->attendee?->name); ?></td><td><a class="text-link" href="<?php echo e(route('trainer.tours.show', $b->tour->listing)); ?>"><?php echo e($b->tour->listing->title); ?></a></td><td><?php echo e($b->seats); ?></td><td><?php echo e(\App\Support\Money::tzs($b->total_minor)); ?></td>
        <td><span class="by-chip st-<?php echo e(in_array($b->status, ['paid', 'completed'], true) ? 'released' : ($b->status === 'reserved' ? 'pending' : 'refunded')); ?>"><?php echo e(ucfirst($b->status)); ?></span></td>
        <td><?php echo e($b->status === 'reserved' ? 'Pay by '.$b->expires_at?->format('d M H:i') : ($b->paid_at ? 'Paid '.$b->paid_at->format('d M H:i') : '—')); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody></table></div><?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('trainer.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/trainer/bookings.blade.php ENDPATH**/ ?>