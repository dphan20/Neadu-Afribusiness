<?php $__env->startSection('title', 'Messages'); ?>
<?php $__env->startSection('heading', 'Messages'); ?>
<?php $__env->startSection('lead', 'Chats with buyers and experts.'); ?>
<?php $__env->startSection('body'); ?>
<p><a class="button button-primary button-small" href="<?php echo e(route('me.chat.new')); ?>">✉ <?php echo e(__('chat.new_message')); ?></a></p>
<?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php ($other = $c->participants->where('id','!=',auth()->id())->pluck('name')->implode(', ')); ?>
<a class="p-card" style="display:block" href="<?php echo e(route('me.chat.show',$c)); ?>"><b><?php echo e($other ?: 'Conversation'); ?></b><p class="p-muted"><?php echo e($c->order?->listing?->title ?? 'Expert advice'); ?></p></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="p-card">No conversations yet.</div><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('producer.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/producer/chat/index.blade.php ENDPATH**/ ?>