<?php $__env->startSection('title', $listing->title); ?>
<?php $__env->startSection('buyer'); ?>
<?php ($p = $listing->produce); ?>
<?php ($qty = (float) ($p?->quantity ?? 0)); ?>
<div class="workspace-heading"><div><a class="back-link" href="<?php echo e(route('buyer.market')); ?>">← Find produce</a><span class="eyebrow">S-09 · LISTING</span><h1><?php echo e($listing->title); ?></h1><p><?php echo e($listing->district?->name); ?><?php echo e($listing->district && $listing->region ? ', ' : ''); ?><?php echo e($listing->region?->name); ?></p></div>
    <form method="post" action="<?php echo e(route('buyer.favourite', $listing)); ?>"><?php echo csrf_field(); ?><button class="button button-outline"><?php echo e($isFavourite ? '★ Saved to favourites' : '☆ Save to favourites'); ?></button></form></div>
<div class="by-split">
    <div class="by-stack">
        <section class="panel">
            <div class="by-row" style="gap:10px;overflow:auto">
                <?php $__empty_1 = true; $__currentLoopData = $listing->photos ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="by-thumb" style="width:220px;height:150px;flex:none"><img src="<?php echo e(\Illuminate\Support\Str::startsWith($ph, 'http') ? $ph : asset('storage/'.$ph)); ?>" alt="Produce photo"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="by-thumb" style="width:100%;height:150px"><?php echo e(mb_substr($p?->crop?->name_en ?? $listing->title, 0, 1)); ?><small style="font-size:12px;margin-left:8px">No photos uploaded</small></div>
                <?php endif; ?>
            </div>
            <dl class="by-kv" style="margin-top:16px">
                <dt>Product</dt><dd><?php echo e($p?->crop?->name_en); ?> / <?php echo e($p?->crop?->name_sw); ?></dd>
                <dt>Price</dt><dd><?php echo e(\App\Support\Money::tzs($listing->price_minor, $listing->currency)); ?> per <?php echo e($p?->unit?->code); ?></dd>
                <dt>Available</dt><dd><?php echo e(rtrim(rtrim((string) $p?->quantity, '0'), '.')); ?> <?php echo e($p?->unit?->code); ?></dd>
                <dt>Quality</dt><dd><?php echo e($p?->grade ? 'Grade '.$p->grade : 'Not graded'); ?><?php echo e($p?->quality_notes ? ' · '.$p->quality_notes : ''); ?></dd>
                <dt>Harvested</dt><dd><?php echo e($p?->harvest_date?->format('d M Y') ?? '—'); ?></dd>
                <?php if($reference): ?><dt>Market price</dt><dd><?php echo e(\App\Support\Money::tzs($reference->price_minor)); ?> <small>(<?php echo e($reference->source); ?>, <?php echo e($reference->recorded_on); ?>)</small></dd><?php endif; ?>
            </dl>
        </section>
        <section class="panel">
            <span class="eyebrow">SELLER</span>
            <h2 style="margin:4px 0"><?php echo e($listing->owner?->name); ?> <?php if($listing->owner?->isIdentityVerified()): ?><span class="by-chip">✓ ID verified</span><?php endif; ?> <?php if($listing->verified): ?><span class="by-chip">✓ Listing verified</span><?php endif; ?></h2>
            <p class="compact-copy"><?php echo e($ratingCount ? '★ '.$ratingAvg.' from '.$ratingCount.' '.($ratingCount === 1 ? 'rating' : 'ratings') : 'No ratings yet'); ?></p>
            <div class="by-row">
                <form method="post" action="<?php echo e(route('buyer.chat.start')); ?>"><?php echo csrf_field(); ?><input type="hidden" name="listing" value="<?php echo e($listing->uuid); ?>"><button class="button button-outline button-small">Chat with seller</button></form>
                <a class="button button-outline button-small" href="<?php echo e(route('buyer.contracts.create', ['listing' => $listing->uuid])); ?>">Offer a contract (R3)</a>
            </div>
        </section>
        <section class="panel">
            <span class="eyebrow">LOCATION</span>
            <?php if($listing->lat && $listing->lng): ?>
                <?php ($la = (float) $listing->lat); ?><?php ($ln = (float) $listing->lng); ?>
                <iframe title="Listing location map" loading="lazy" style="width:100%;height:260px;border:0;border-radius:12px;margin-top:8px"
                    src="https://www.openstreetmap.org/export/embed.html?bbox=<?php echo e($ln - 0.05); ?>%2C<?php echo e($la - 0.05); ?>%2C<?php echo e($ln + 0.05); ?>%2C<?php echo e($la + 0.05); ?>&amp;layer=mapnik&amp;marker=<?php echo e($la); ?>%2C<?php echo e($ln); ?>"></iframe>
            <?php else: ?>
                <p class="compact-copy">The seller has not pinned an exact location. Area: <?php echo e($listing->district?->name); ?> <?php echo e($listing->region?->name); ?>.</p>
            <?php endif; ?>
        </section>
    </div>
    <aside class="panel" style="position:sticky;top:16px">
        <span class="eyebrow">S-11 · PLACE ORDER</span>
        <?php if($listing->user_id === auth()->id()): ?>
            <p>This is your own listing.</p>
        <?php else: ?>
        <form method="post" action="<?php echo e(route('buyer.orders.store', $listing)); ?>" class="by-form" id="orderForm">
            <?php echo csrf_field(); ?>
            <label>Quantity
                <select name="mode" id="mode"><option value="full">Full lot (<?php echo e(rtrim(rtrim((string) $p?->quantity, '0'), '.')); ?> <?php echo e($p?->unit?->code); ?>)</option><option value="part" <?php if(old('mode') === 'part'): echo 'selected'; endif; ?>>Part of the lot</option></select></label>
            <label id="qtyWrap" style="display:none">Quantity (<?php echo e($p?->unit?->code); ?>)<input type="number" step="any" min="0.001" max="<?php echo e($qty); ?>" name="quantity" id="qty" value="<?php echo e(old('quantity')); ?>"></label>
            <label>Delivery<select name="delivery_option"><option value="pickup">I will collect (pickup)</option><option value="delivery">Deliver to me (choose transporter after)</option></select></label>
            <label>Note to producer (optional)<textarea name="note" maxlength="500"><?php echo e(old('note')); ?></textarea></label>
            <dl class="by-kv" style="grid-template-columns:1fr auto">
                <dt>Goods</dt><dd id="sub">—</dd><dt>Escrow fee (<?php echo e($feeBps / 100); ?>%)</dt><dd id="fee">—</dd><dt><b>Total in escrow</b></dt><dd id="tot">—</dd>
            </dl>
            <button class="button button-primary button-full">Send order to producer</button>
            <p class="compact-copy">The producer has 24 hours to accept, reject or counter. You only pay after they accept; the money stays in escrow until you confirm receipt.</p>
        </form>
        <?php endif; ?>
    </aside>
</div>
<script>
(() => {
    const price = <?php echo e((int) $listing->price_minor); ?>, full = <?php echo e($qty); ?>, bps = <?php echo e((int) $feeBps); ?>;
    const mode = document.getElementById('mode'), qty = document.getElementById('qty'), wrap = document.getElementById('qtyWrap');
    const fmt = m => new Intl.NumberFormat('en-US').format(Math.floor(m / 100)) + ' TZS';
    function calc() {
        wrap.style.display = mode.value === 'part' ? 'grid' : 'none';
        const q = mode.value === 'full' ? full : parseFloat(qty.value || 0);
        const sub = Math.round(q * price), fee = Math.floor(sub * bps / 10000);
        document.getElementById('sub').textContent = fmt(sub); document.getElementById('fee').textContent = fmt(fee); document.getElementById('tot').textContent = fmt(sub + fee);
    }
    mode?.addEventListener('change', calc); qty?.addEventListener('input', calc); calc();
})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('buyer.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/buyer/listing.blade.php ENDPATH**/ ?>