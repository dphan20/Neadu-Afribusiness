<?php if(auth()->guard()->check()): ?>
<?php if (! (request()->routeIs('me.ask'))): ?>
<button type="button" class="ai-fab" data-ai-open aria-haspopup="dialog" aria-label="Ask AI"><?php echo $__env->make('layouts.partials.icon-sparkles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><span>Ask AI</span></button>
<dialog class="ai-dialog" id="ai-dialog" aria-labelledby="ai-title">
    <form class="ai-form" method="post" action="<?php echo e(route('me.ask.send')); ?>" enctype="multipart/form-data" data-ask-stream="#ai-out" data-ask-url="<?php echo e(route('me.ask.stream')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="page" value="<?php echo e(request()->path()); ?>">
        <header class="ai-head">
            <span class="ai-badge"><?php echo $__env->make('layouts.partials.icon-sparkles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
            <div><h2 id="ai-title">NeAS AI</h2><p>Ask in Kiswahili or English</p></div>
            <button type="button" class="ai-x" data-ai-close aria-label="Close">&times;</button>
        </header>
        <div class="ai-thread" id="ai-out" aria-live="polite">
            <div class="ai-empty">
                <b>How can I help?</b>
                <div class="ai-chips">
                    <button type="button" data-ai-suggest="What is wrong with my crop? I will add a photo.">Sick crop</button>
                    <button type="button" data-ai-suggest="Bei ya mahindi leo ni kiasi gani?">Bei ya mahindi</button>
                    <button type="button" data-ai-suggest="How can I store my harvest to avoid losses?">Storing harvest</button>
                    <button type="button" data-ai-suggest="Ninawezaje kupata mnunuzi wa mazao yangu?">Find a buyer</button>
                </div>
            </div>
        </div>
        <?php echo $__env->make('me.partials.ai-composer', ['id' => 'ai'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <footer class="ai-foot"><a href="<?php echo e(route('me.ask')); ?>">All my answers</a><span>AI can be wrong. Check medicine and dosing with an expert.</span></footer>
    </form>
</dialog>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/layouts/partials/ai-widget.blade.php ENDPATH**/ ?>