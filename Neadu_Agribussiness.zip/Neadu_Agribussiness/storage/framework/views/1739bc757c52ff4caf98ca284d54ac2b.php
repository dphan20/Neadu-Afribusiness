
<link rel="manifest" href="<?php echo e(asset('manifest.webmanifest')); ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('icons/favicon-32.png')); ?>">
<link rel="apple-touch-icon" href="<?php echo e(asset('icons/apple-touch-icon.png')); ?>">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="NeAS">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="stylesheet" href="<?php echo e(asset('css/pwa.css')); ?>?v=<?php echo e(filemtime(public_path('css/pwa.css'))); ?>">
<script src="<?php echo e(asset('js/pwa.js')); ?>?v=<?php echo e(filemtime(public_path('js/pwa.js'))); ?>" defer></script>

<script>window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); window.__neasInstall = e; });</script>
<link rel="stylesheet" href="/css/ai.css?v=<?php echo e(filemtime(public_path('css/ai.css'))); ?>">
<script src="/js/voice.js?v=<?php echo e(filemtime(public_path('js/voice.js'))); ?>" defer></script>
<script src="/js/ai.js?v=<?php echo e(filemtime(public_path('js/ai.js'))); ?>" defer></script>
<?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/layouts/partials/pwa.blade.php ENDPATH**/ ?>