<?php $__env->startSection('title', 'Jobs'); ?>

<?php $__env->startSection('body'); ?>
<h1>Available jobs</h1>
<p class="tr-lead">Open transport jobs and requests sent to you, with distance and price.</p>

<?php if (! ($identityVerified)): ?>
    <div class="tr-alert">Verify your identity (NIDA) to accept jobs. <a href="<?php echo e(route('transporter.identity')); ?>">Verify now</a></div>
<?php endif; ?>
<?php if(! $hasAnyVehicle): ?>
    <div class="tr-alert">Register a vehicle to accept jobs. <a href="<?php echo e(route('transporter.vehicles')); ?>">Add a vehicle</a></div>
<?php elseif($vehicles->isEmpty()): ?>
    <div class="tr-alert">None of your vehicles is verified yet. Jobs are shown, but you can accept only after the NeAS team approves a vehicle.</div>
<?php endif; ?>
<?php $__errorArgs = ['job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="tr-alert"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<div class="tr-row" style="margin-bottom:12px">
    <span class="tr-muted"><?php echo e($jobs->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('job', $jobs->count())); ?></span>
    <span>
        Sort:
        <a href="<?php echo e(route('transporter.jobs', ['sort' => 'new'])); ?>" <?php if($sort === 'new'): ?> style="font-weight:700" <?php endif; ?>>Newest</a> ·
        <a href="<?php echo e(route('transporter.jobs', ['sort' => 'price'])); ?>" <?php if($sort === 'price'): ?> style="font-weight:700" <?php endif; ?>>Highest price</a> ·
        <a href="<?php echo e(route('transporter.jobs', ['sort' => 'distance'])); ?>" <?php if($sort === 'distance'): ?> style="font-weight:700" <?php endif; ?>>Shortest</a>
    </span>
</div>

<?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php ($d = $j['delivery']); ?>
    <div class="tr-card">
        <div class="tr-row">
            <b><?php echo e($d->order?->listing?->title ?? 'Delivery'); ?></b>
            <span class="tr-chip <?php echo e($j['direct'] ? 'info' : ''); ?>"><?php echo e($j['direct'] ? 'Request for you' : 'Open job'); ?></span>
        </div>
        <div class="tr-kv">
            <div><small>Distance</small><b><?php echo e(number_format($j['km'], 1)); ?> km</b></div>
            <div><small>Price</small><b>TSh <?php echo e(number_format($j['price'] / 100)); ?></b></div>
            <div><small>Load</small><b><?php echo e($j['weight'] !== null ? number_format($j['weight']).' kg' : 'Not weighed'); ?></b></div>
            <div><small>Per km</small><b><?php echo e($j['per_km'] !== null ? 'TSh '.number_format($j['per_km']) : '—'); ?></b></div>
        </div>
        <p class="tr-muted">
            Pickup: <?php echo e($d->order?->listing?->region?->name ?? 'see map'); ?>

            (<a target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=<?php echo e($d->pickup_lat); ?>,<?php echo e($d->pickup_lng); ?>">map</a>)
            → Drop-off:
            <a target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=<?php echo e($d->drop_lat); ?>,<?php echo e($d->drop_lng); ?>"><?php echo e(number_format($d->drop_lat, 3)); ?>, <?php echo e(number_format($d->drop_lng, 3)); ?></a>
        </p>

        <?php if($vehicles->isNotEmpty() && $j['fits']->isEmpty()): ?>
            <p class="tr-muted" style="color:var(--color-error)">This load is heavier than any of your verified vehicles can carry.</p>
        <?php elseif($vehicles->isNotEmpty()): ?>
            <form class="tr-form" method="post" action="<?php echo e(route('transporter.jobs.accept', $d)); ?>">
                <?php echo csrf_field(); ?>
                <div class="tr-two">
                    <div><label for="v-<?php echo e($d->uuid); ?>">Vehicle</label>
                        <select id="v-<?php echo e($d->uuid); ?>" name="vehicle"><?php $__currentLoopData = $j['fits']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($v->uuid); ?>"><?php echo e($v->typeLabel()); ?> · <?php echo e(str_starts_with($v->plate, 'BIC-') ? 'no plate' : $v->plate); ?> · <?php echo e(number_format((float) $v->capacity_kg)); ?> kg</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="tr-actions" style="align-items:flex-end;margin:0">
                        <button class="button button-primary" type="submit">Accept job</button>
                        <?php if($j['direct']): ?>
                            <button class="button button-outline" type="submit" formaction="<?php echo e(route('transporter.jobs.release', $d)); ?>">Decline</button>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="tr-card tr-empty">No open jobs right now. New jobs appear here when a producer or buyer books delivery.</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('transporter.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/transporter/jobs.blade.php ENDPATH**/ ?>