<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Certificates · <?php echo e($tour->listing->title); ?></title>
<style>
 body{margin:0;font-family:Georgia,serif;color:#1b3a24;background:#eee}
 .cert{width:960px;max-width:100%;height:640px;margin:20px auto;background:#fffdf5;border:10px double #2f7d3c;box-sizing:border-box;padding:48px;text-align:center;page-break-after:always;display:flex;flex-direction:column;justify-content:center;gap:10px}
 .cert h1{font-size:42px;margin:0;letter-spacing:2px}.cert .name{font-size:36px;border-bottom:2px solid #c9972b;display:inline-block;padding:0 24px;margin:8px auto}
 .cert small{color:#555;font-family:Arial,sans-serif}.bar{display:flex;justify-content:space-between;margin-top:30px;font-family:Arial,sans-serif;font-size:13px}
 .noprint{text-align:center;padding:12px;font-family:Arial,sans-serif}@media print{.noprint{display:none}body{background:#fff}.cert{margin:0;width:auto;height:98vh}}
</style></head><body>
<div class="noprint"><button onclick="window.print()">Print / save as PDF</button> · <?php echo e($bookings->count()); ?> certificate(s)</div>
<?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<section class="cert"><small>NENDU AGRIBUSINESS SYSTEM</small><h1>Certificate of Completion</h1><p>This certifies that</p><div><span class="name"><?php echo e($b->attendee?->name); ?></span></div>
<p>successfully attended the agri-tour</p><h2 style="margin:0"><?php echo e($tour->listing->title); ?></h2>
<p><?php echo e($tour->route); ?> · <?php echo e($tour->starts_at->format('d M Y')); ?><?php if($tour->ends_at && ! $tour->ends_at->isSameDay($tour->starts_at)): ?> – <?php echo e($tour->ends_at->format('d M Y')); ?><?php endif; ?></p>
<p><small>Learning goals: <?php echo e(implode(' · ', $tour->learning_goals ?? [])); ?></small></p>
<div class="bar"><span>Organiser: <?php echo e($tour->listing->owner?->name); ?></span><span>Certificate no. <b><?php echo e($b->certificate_no); ?></b></span><span>Issued <?php echo e($b->certificate_issued_at?->format('d M Y')); ?></span></div>
<small>Verify at <?php echo e(url('/certificates/'.$b->certificate_no)); ?></small></section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p style="text-align:center;font-family:Arial">No certificates were issued for this tour.</p><?php endif; ?>
</body></html>
<?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/trainer/certificates.blade.php ENDPATH**/ ?>