<?php $__env->startSection('title', __('chat.forward_title')); ?>
<?php $__env->startSection('admin_active', 'messages'); ?>
<?php $__env->startSection('heading', __('chat.forward_title')); ?>
<?php $__env->startSection('lead', ''); ?>
<?php $__env->startSection('admin_body'); ?>
<?php echo $__env->make('partials.chat-forward-body', ['area' => 'admin'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/admin/messages/forward.blade.php ENDPATH**/ ?>