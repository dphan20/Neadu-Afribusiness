<?php $__env->startSection('title', $role->label().' workspace'); ?>

<?php $__env->startSection('content'); ?>
<main class="workspace-shell">
    <aside class="workspace-sidebar">
        <div class="workspace-person">
            <span class="avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></span>
            <span><b><?php echo e(auth()->user()->name); ?></b><small><?php echo e($role->label()); ?></small></span>
        </div>
        <nav class="workspace-nav" aria-label="Workspace navigation">
            <a class="active" href="<?php echo e(route('dashboard')); ?>"><span class="nav-mark">01</span>Overview</a>
            <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(($links[$key] ?? route('workspace.section', $key))); ?>"><span class="nav-mark"><?php echo e(str_pad((string) $loop->iteration + 1, 2, '0', STR_PAD_LEFT)); ?></span><?php echo e($item['label']); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
        <div class="sidebar-note"><b>Need a hand?</b><p>Support is available for account and transaction questions.</p><a href="mailto:support@neas.example">Contact support</a></div>
    </aside>

    <section class="workspace-main">
        <div class="workspace-heading">
            <div><span class="eyebrow"><?php echo e($role->swahiliLabel()); ?></span><h1>Habari, <?php echo e(explode(' ', auth()->user()->name)[0]); ?></h1><p>Your workspace at a glance. Choose a section to manage today's work.</p></div>
            <span class="status-chip <?php echo e(auth()->user()->isIdentityVerified() ? 'status-good' : 'status-warn'); ?>">
                <span class="status-dot"></span><?php echo e(auth()->user()->isIdentityVerified() ? 'Identity verified' : 'Identity review required'); ?>

            </span>
        </div>

        <div class="metric-grid">
            <?php $__currentLoopData = $metrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="metric-card metric-<?php echo e($metric['tone']); ?>">
                    <span class="metric-label"><?php echo e($metric['label']); ?></span>
                    <strong><?php echo e($metric['value']); ?></strong>
                    <span class="metric-caption"><?php echo e($role->label()); ?> workspace</span>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php ($tools = [
            'P' => ['producer.home', 'PRODUCER TOOLS', 'Sell, ship, store and get advice', 'Open producer workspace', 'Listings, orders, delivery, storage, diagnosis, alerts, weather'],
            'E' => ['expert.dashboard', 'EXPERT TOOLS', 'Answer cases and publish advice', 'Open expert workspace', 'Case queue, AI corrections, advice, consultation earnings'],
            'G' => ['trainer.tours', 'TRAINER TOOLS', 'Run agri-tours', 'Open trainer workspace', 'Create tours, manage attendees, certificates, payouts'],
            'L' => ['landowner.listings', 'LAND OWNER TOOLS', 'List land and answer enquiries', 'Open land workspace', 'Farmland and sites, title documents, enquiries, offers, lease drafts'],
            'W' => ['warehouse.facilities', 'WAREHOUSE TOOLS', 'Fill your storage', 'Open warehouse workspace', 'Facilities, booking requests, receipts, expiry alerts, payouts'],
            'R' => ['trader.home', 'TRADER TOOLS', 'Sell machinery and technology', 'Open trader workspace', 'Machinery listings, quote requests, business profile'],
            'T' => ['transporter.home', 'TRANSPORTER TOOLS', 'Find jobs and drive trips', 'Open transporter workspace', 'Vehicles, jobs, trip mode with GPS, delivery proof'],
        ]); ?>
        <?php if(isset($tools[$role->value]) && \Illuminate\Support\Facades\Route::has($tools[$role->value][0])): ?>
            <?php ([$toolRoute, $toolEyebrow, $toolTitle, $toolCta, $toolText] = $tools[$role->value]); ?>
            <div class="panel" style="margin-bottom:14px"><div class="panel-heading"><div><span class="eyebrow"><?php echo e($toolEyebrow); ?></span><h2><?php echo e($toolTitle); ?></h2></div></div>
                <div class="action-grid"><a class="action-card" href="<?php echo e(route($toolRoute)); ?>"><span><b><?php echo e($toolCta); ?></b><small><?php echo e($toolText); ?></small></span><span class="action-arrow">→</span></a></div></div>
        <?php endif; ?>

        <div class="panel" style="margin-bottom:14px"><div class="panel-heading"><div><span class="eyebrow">AI ASSISTANT</span><h2>Ask about anything you can photograph</h2></div></div>
            <div class="action-grid"><a class="action-card" href="<?php echo e(route('me.ask')); ?>"><span><b>Ask AI</b><small>Take a photo of a plant, animal, fish, produce, machine or land and ask your question</small></span><span class="action-arrow">→</span></a></div></div>

        <div class="workspace-columns">
            <section class="panel panel-main">
                <div class="panel-heading"><div><span class="eyebrow">YOUR WORKSPACE</span><h2>Get things moving</h2></div><span class="panel-count"><?php echo e(count($navigation)); ?> sections</span></div>
                <div class="action-grid">
                    <?php $__currentLoopData = $navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="action-card" href="<?php echo e(($links[$key] ?? route('workspace.section', $key))); ?>">
                            <span class="action-index"><?php echo e(str_pad((string) $loop->iteration, 2, '0', STR_PAD_LEFT)); ?></span>
                            <span><b><?php echo e($item['label']); ?></b><small>Open <?php echo e(strtolower($item['label'])); ?> workspace</small></span>
                            <span class="action-arrow" aria-hidden="true">→</span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <aside class="panel guidance-panel">
                <span class="guidance-icon">N</span>
                <span class="eyebrow">ACCOUNT CHECKLIST</span>
                <h2>Keep your account ready</h2>
                <p>Complete identity verification before listing produce, accepting orders or receiving payouts.</p>
                <div class="check-row"><span class="<?php echo e(auth()->user()->phone_verified_at ? 'check-done' : 'check-pending'); ?>"><?php echo e(auth()->user()->phone_verified_at ? '✓' : '·'); ?></span><span><b>Phone number</b><small><?php echo e(auth()->user()->phone_verified_at ? 'Verified' : 'Verification required'); ?></small></span></div>
                <div class="check-row"><span class="<?php echo e(auth()->user()->isIdentityVerified() ? 'check-done' : 'check-pending'); ?>"><?php echo e(auth()->user()->isIdentityVerified() ? '✓' : '·'); ?></span><span><b>Identity</b><small><?php echo e(auth()->user()->isIdentityVerified() ? 'Verified' : 'NIDA review required'); ?></small></span></div>
                <a class="text-link" href="<?php echo e(route('workspace.section', 'profile')); ?>">Review my profile <span aria-hidden="true">→</span></a>
            </aside>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/dashboard/index.blade.php ENDPATH**/ ?>