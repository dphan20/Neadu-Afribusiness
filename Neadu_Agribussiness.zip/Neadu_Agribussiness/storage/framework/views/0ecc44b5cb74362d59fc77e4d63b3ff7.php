<?php $__env->startSection('title', 'My facilities'); ?>
<?php $__env->startSection('heading', 'My storage facilities'); ?>
<?php $__env->startSection('lead', 'Rates are per kg per day. Producers book space; you accept or decline.'); ?>
<?php $__env->startSection('head-action'); ?><a class="button button-primary" href="<?php echo e(route('warehouse.facilities.create')); ?>">Add facility</a><?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<?php if(session('status')): ?><div class="flash" role="status"><?php echo e(session('status')); ?></div><?php endif; ?>
<?php if($errors->any()): ?><div class="flash flash-error" role="alert"><?php echo e($errors->first()); ?></div><?php endif; ?>
<?php $__empty_1 = true; $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="p-card"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><b><?php echo e($f->title); ?></b><span class="p-tag"><?php echo e(ucfirst(str_replace('_',' ',$f->status))); ?></span></div>
<p class="p-muted"><?php echo e(\App\Http\Controllers\Warehouse\WarehouseController::TYPES[$f->storage?->facility_type] ?? '—'); ?> · <?php echo e(number_format((float) $f->storage?->capacity_kg)); ?> kg · TSh <?php echo e(number_format($f->price_minor/100,2)); ?> per kg per day · <?php echo e($f->region?->name); ?>

<?php if($f->storage?->conditions): ?> · <?php echo e(implode(', ', array_map(fn($c)=>\App\Http\Controllers\Warehouse\WarehouseController::CONDITIONS[$c] ?? $c, $f->storage->conditions))); ?><?php endif; ?>
<?php if($f->moderation_note): ?> · Review note: <?php echo e($f->moderation_note); ?><?php endif; ?> <?php if(($pending[$f->id] ?? 0)>0): ?>· <a href="<?php echo e(route('warehouse.bookings')); ?>"><?php echo e($pending[$f->id]); ?> requests waiting</a><?php endif; ?></p>
<div class="p-actions"><a class="button button-outline button-small" href="<?php echo e(route('warehouse.facilities.edit',$f)); ?>">Edit</a>
<?php if($f->status==='active'): ?><form method="post" action="<?php echo e(route('warehouse.facilities.status',[$f,'pause'])); ?>"><?php echo csrf_field(); ?><button class="button button-outline button-small">Pause</button></form><?php endif; ?>
<?php if($f->status==='paused'): ?><form method="post" action="<?php echo e(route('warehouse.facilities.status',[$f,'resume'])); ?>"><?php echo csrf_field(); ?><button class="button button-outline button-small">Resume</button></form><?php endif; ?>
<?php if($f->status!=='closed'): ?><form method="post" action="<?php echo e(route('warehouse.facilities.status',[$f,'close'])); ?>"><?php echo csrf_field(); ?><button class="button button-danger-quiet button-small">Close</button></form><?php endif; ?></div></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="p-card">No facilities yet.</div><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('producer.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/warehouse/facilities.blade.php ENDPATH**/ ?>