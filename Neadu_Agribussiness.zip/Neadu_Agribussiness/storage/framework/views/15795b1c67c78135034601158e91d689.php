<?php ($isAdminArea = ($area ?? 'me') === 'admin'); ?>
<form class="p-card pf" method="get" action="<?php echo e(route($isAdminArea ? 'admin.messages.new' : 'me.chat.new')); ?>">
    <label for="q"><?php echo e(__('chat.search')); ?></label>
    <input id="q" name="q" value="<?php echo e($q); ?>" maxlength="60" autocomplete="off">
    <label for="role"><?php echo e(__('chat.to')); ?></label>
    <select id="role" name="role">
        <option value=""><?php echo e(__('chat.any_role')); ?></option>
        <?php $__currentLoopData = \App\Enums\UserRole::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($r->value); ?>" <?php if($role === $r->value): echo 'selected'; endif; ?>><?php echo e($r === \App\Enums\UserRole::Admin ? 'NeAS support' : $r->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="button button-primary"><?php echo e(__('chat.search_go')); ?></button>
</form>
<?php if($errors->any()): ?><div class="p-card" role="alert" style="border-color:var(--color-error)"><?php echo e($errors->first()); ?></div><?php endif; ?>
<?php $__empty_1 = true; $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="p-card">
        <b><?php echo e($p->name); ?></b> <span class="p-muted"><?php echo e($messaging->roleLabels($p)); ?></span>
        <details>
            <summary style="cursor:pointer">✉ <?php echo e(__('chat.write')); ?></summary>
            <form method="post" class="pf" action="<?php echo e(route($isAdminArea ? 'admin.messages.start' : 'me.chat.start')); ?>"><?php echo csrf_field(); ?>
                <input type="hidden" name="user" value="<?php echo e($p->uuid); ?>">
                <textarea name="body" required maxlength="2000" placeholder="<?php echo e(__('chat.write_placeholder')); ?>"></textarea>
                <button class="button button-primary button-small"><?php echo e(__('chat.send')); ?></button>
            </form>
        </details>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="p-card p-muted"><?php echo e(mb_strlen(trim($q)) >= 2 || $role !== '' ? __('chat.no_people') : __('chat.type_to_search')); ?></div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Neadu_Agribussiness\resources\views/partials/chat-compose-body.blade.php ENDPATH**/ ?>