<?php

declare(strict_types=1);

namespace App\Broadcasting;

use App\Models\Delivery;
use App\Models\User;

/** Only the buyer, the seller and the assigned transporter of a delivery may listen to its live channel. */
final class DeliveryChannel
{
    public function join(User $user, string $uuid): bool
    {
        $delivery = Delivery::query()->with('order:id,buyer_id,seller_id')->where('uuid', $uuid)->first();
        if ($delivery === null) {
            return false;
        }

        $allowed = array_filter([
            $delivery->order?->buyer_id, $delivery->order?->seller_id, $delivery->transporter_id,
        ], static fn ($id): bool => $id !== null);

        return in_array($user->id, array_map('intval', $allowed), true);
    }
}
