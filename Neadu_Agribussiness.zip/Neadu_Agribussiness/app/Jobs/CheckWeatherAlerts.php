<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Enums\WeatherCondition;
use App\Models\Region;
use App\Models\RoleProfile;
use App\Models\User;
use App\Services\NotificationService;
use App\Services\Weather\WeatherServiceInterface;
use App\Services\WeatherService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Cache;
use Throwable;

/**
 * WTH-02 / NTF-03 (hourly, TECH-07): for every region that has active users, look at the next two days and warn about
 * thunderstorms, heavy rain or strong wind. One alert per region per event per 6 hours; in-app + SMS, WhatsApp if SMS fails.
 */
final class CheckWeatherAlerts implements ShouldQueue
{
    use Queueable;

    public const DEDUPE_HOURS = 6;

    public function handle(WeatherServiceInterface $forecasts, WeatherService $weather, NotificationService $notes): void
    {
        $byRegion = RoleProfile::query()
            ->join('users', 'users.id', '=', 'role_profiles.user_id')
            ->where('users.status', 'active')
            ->whereNotNull('role_profiles.region_id')
            ->get(['role_profiles.region_id', 'role_profiles.user_id'])
            ->groupBy('region_id');

        foreach ($byRegion as $regionId => $rows) {
            $region = Region::query()->find((int) $regionId);
            if ($region === null) {
                continue;
            }

            [$lat, $lng] = $weather->coordinates($region);
            $forecast = $forecasts->getForecast($lat, $lng, $region->name);
            if ($forecast['daily'] === []) {
                continue; // provider down and nothing cached: nothing to warn about
            }

            $users = User::query()->whereIn('id', $rows->pluck('user_id')->unique()->all())->where('status', 'active')->get();

            foreach ($this->events(array_slice($forecast['daily'], 0, 2)) as $event => $wind) {
                // Cache::add is atomic: only the first run in the window gets true.
                if (! Cache::add("weather-alert:{$region->id}:{$event}", true, now()->addHours(self::DEDUPE_HOURS))) {
                    continue;
                }
                $message = (string) __('weather.alert.'.$event, ['region' => $region->name, 'kmh' => (int) round($wind)], 'sw');

                foreach ($users as $user) {
                    $content = ['message' => $message, 'region' => $region->name, 'event' => $event];
                    $notes->notify($user, 'weather.alert', $content);
                    try {
                        $notes->notify($user, 'weather.alert', $content, 'sms');
                    } catch (Throwable) {
                        $notes->notify($user, 'weather.alert', $content, 'whatsapp');
                    }
                }
            }
        }
    }

    /**
     * @param  list<array{rain_mm: float, wind_kmh: float, code: int}>  $days
     * @return array<string, float> event => strongest wind seen (used only by the wind message)
     */
    private function events(array $days): array
    {
        $limit = config('neas.weather.severe');
        $found = [];
        foreach ($days as $d) {
            if ($d['code'] >= 95) {
                $found['thunderstorm'] = $d['wind_kmh'];
            }
            if (WeatherCondition::fromCode($d['code'])->isHeavyRain() || $d['rain_mm'] >= $limit['rain_mm']) {
                $found['heavy_rain'] = $d['wind_kmh'];
            }
            if ($d['wind_kmh'] >= $limit['wind_kmh']) {
                $found['wind'] = max($found['wind'] ?? 0.0, $d['wind_kmh']);
            }
        }

        return $found;
    }
}
