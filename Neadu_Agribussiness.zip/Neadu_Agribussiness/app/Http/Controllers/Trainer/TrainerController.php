<?php

declare(strict_types=1);

namespace App\Http\Controllers\Trainer;

use App\Enums\ListingType;
use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\District;
use App\Models\Listing;
use App\Models\Message;
use App\Models\Region;
use App\Models\Tour;
use App\Models\TourBooking;
use App\Services\NotificationService;
use App\Services\TourService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

/** S-29 manage agri-tours (TUR-01..04), R2. */
class TrainerController extends Controller
{
    public function tours(Request $request): View
    {
        $tours = Listing::query()->with('tour')->where('user_id', $request->user()->id)->where('type', 'tour')->latest()->get();
        $booked = TourBooking::query()->whereIn('listing_id', $tours->pluck('id'))->whereIn('status', ['paid', 'completed'])->selectRaw('listing_id, SUM(seats) s')->groupBy('listing_id')->pluck('s', 'listing_id');

        return view('trainer.tours', compact('tours', 'booked'));
    }

    public function form(Request $request, ?Listing $listing = null): View
    {
        if ($listing) {
            $this->own($request, $listing);
            $listing->load('tour');
        }

        return view('trainer.form', ['listing' => $listing, 'regions' => Region::query()->orderBy('name')->get(), 'districts' => District::query()->orderBy('name')->get()]);
    }

    public function save(Request $request, ?Listing $listing = null): RedirectResponse
    {
        if ($listing) {
            $this->own($request, $listing);
        }
        $d = $request->validate([
            'title' => ['required', 'string', 'max:120'], 'route' => ['required', 'string', 'max:200'], 'region_id' => ['required', 'exists:regions,id'], 'district_id' => ['required', 'exists:districts,id'],
            'starts_at' => ['required', 'date', 'after:now'], 'ends_at' => ['nullable', 'date', 'after:starts_at'], 'seats' => ['required', 'integer', 'between:1,500'],
            'price' => ['required', 'regex:/^\d{1,12}(\.\d{1,2})?$/'], 'itinerary' => ['required', 'string', 'max:3000'], 'goals' => ['required', 'string', 'max:2000'],
            'photos' => [$listing ? 'nullable' : 'required', 'array', 'max:6'], 'photos.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:5120'], 'submit' => ['nullable', 'boolean'],
        ]);

        DB::transaction(function () use ($request, $listing, $d): void {
            $lines = fn (string $t) => array_values(array_filter(array_map('trim', preg_split('/\R/', $t) ?: [])));
            $base = ['title' => $d['title'], 'region_id' => $d['region_id'], 'district_id' => $d['district_id'], 'price_minor' => Money::fromMajor($d['price'])->minor];
            if ($listing === null) {
                $listing = Listing::query()->create($base + ['user_id' => $request->user()->id, 'type' => ListingType::Tour, 'status' => ! empty($d['submit']) ? 'pending_review' : 'draft', 'photos' => []]);
            } else {
                $listing->forceFill($base + (! empty($d['submit']) && in_array($listing->status, ['draft', 'rejected'], true) ? ['status' => 'pending_review'] : []))->save();
            }
            $photos = array_merge($listing->photos ?? [], array_map(fn ($f) => $f->store("listings/{$listing->uuid}", 'public'), $request->file('photos', [])));
            $listing->forceFill(['photos' => $photos])->save();
            Tour::query()->updateOrCreate(['listing_id' => $listing->id], [
                'route' => $d['route'], 'starts_at' => $d['starts_at'], 'ends_at' => $d['ends_at'] ?? null, 'seats' => $d['seats'],
                'itinerary' => ['stops' => $lines($d['itinerary']), 'goals' => $lines($d['goals'])],
            ]);
        });

        return redirect()->route('trainer.tours')->with('status', ! empty($d['submit']) ? 'Tour submitted for review.' : 'Tour saved.');
    }

    public function attendees(Request $request, Listing $listing): View
    {
        $this->own($request, $listing);
        $listing->load('tour');
        $bookings = TourBooking::query()->with('user')->where('listing_id', $listing->id)->whereIn('status', ['paid', 'completed'])->get();

        return view('trainer.attendees', compact('listing', 'bookings'));
    }

    /** TUR-03: one message to everyone who booked. */
    public function groupMessage(Request $request, Listing $listing, NotificationService $notes): RedirectResponse
    {
        $this->own($request, $listing);
        $d = $request->validate(['body' => ['required', 'string', 'max:2000']]);
        $bookings = TourBooking::query()->with('user')->where('listing_id', $listing->id)->whereIn('status', ['paid', 'completed'])->get();
        if ($bookings->isEmpty()) {
            return back()->withErrors(['body' => 'There are no attendees yet.']);
        }

        $c = Conversation::query()->where('listing_id', $listing->id)->whereNull('order_id')->first() ?? Conversation::query()->create(['listing_id' => $listing->id]);
        $c->participants()->syncWithoutDetaching($bookings->pluck('user_id')->push($request->user()->id)->unique()->all());
        Message::query()->create(['conversation_id' => $c->id, 'sender_id' => $request->user()->id, 'kind' => 'text', 'body' => $d['body']]);
        foreach ($bookings as $b) {
            $notes->notify($b->user, 'tour.message', ['message' => "{$listing->title}: ".mb_substr($d['body'], 0, 120)]);
        }

        return back()->with('status', 'Message sent to '.$bookings->count().' attendees.');
    }

    public function complete(Request $request, Listing $listing, TourService $service): RedirectResponse
    {
        $this->own($request, $listing);

        try {
            $n = $service->complete($listing, $request->user());
        } catch (DomainException $e) {
            return back()->withErrors(['tour' => $e->getMessage()]);
        }

        return redirect()->route('trainer.tours')->with('status', "Tour completed. {$n} certificates issued and your payout is in your wallet.");
    }

    public function close(Request $request, Listing $listing): RedirectResponse
    {
        $this->own($request, $listing);
        if (TourBooking::query()->where('listing_id', $listing->id)->where('status', 'paid')->exists()) {
            return back()->withErrors(['tour' => 'Complete the tour or refund attendees before closing it.']);
        }
        $listing->forceFill(['status' => 'closed'])->save();

        return back()->with('status', 'Tour closed.');
    }

    private function own(Request $request, Listing $listing): void
    {
        abort_unless($listing->user_id === $request->user()->id && $listing->type->value === 'tour', 404);
    }
}
