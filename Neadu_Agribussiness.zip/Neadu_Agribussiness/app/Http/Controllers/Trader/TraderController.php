<?php

declare(strict_types=1);

namespace App\Http\Controllers\Trader;

use App\Enums\ListingType;
use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\District;
use App\Models\FeatureFlag;
use App\Models\Listing;
use App\Models\Machine;
use App\Models\MachineQuote;
use App\Models\Region;
use App\Models\RoleProfile;
use App\Services\NotificationService;
use App\Support\Money;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** Trader / technology provider (R): manage machinery and technology listings, answer quote, financing and rental requests, business profile. */
class TraderController extends Controller
{
    public const CATEGORIES = [
        'tractor' => 'Tractor / power tiller', 'planter' => 'Planter / seeder', 'harvester' => 'Harvester / thresher', 'sprayer' => 'Sprayer',
        'irrigation' => 'Irrigation / pump', 'drying' => 'Dryer / solar drying', 'cold_chain' => 'Cold chain / storage tech', 'processing' => 'Processing / milling',
        'livestock_tech' => 'Livestock / dairy equipment', 'fisheries_tech' => 'Fisheries / aquaculture equipment', 'sensors' => 'Drone / sensors / IoT', 'software' => 'Software / mobile app', 'other' => 'Other equipment',
    ];

    public const SECTORS = ['crop' => 'Crops', 'livestock' => 'Livestock', 'fisheries' => 'Fisheries', 'post_harvest' => 'Post-harvest', 'general' => 'General'];

    public const CONDITIONS = ['new' => 'New', 'used' => 'Used', 'refurbished' => 'Refurbished'];

    public const OFFERS = ['sale' => 'Sale', 'financing' => 'Financing', 'rental' => 'Rental'];

    public const SERVICES = ['sales' => 'Sales', 'installation' => 'Installation', 'maintenance' => 'Maintenance and repairs', 'training' => 'Operator training', 'delivery' => 'Delivery', 'spare_parts' => 'Spare parts'];

    /* ------------------------------------------------------------------ overview */

    public function home(Request $request): View
    {
        $user = $request->user();
        $counts = $this->mine($request)->selectRaw('status, COUNT(*) n')->groupBy('status')->pluck('n', 'status');
        $ids = $this->ownIds($request);
        $quotes = MachineQuote::query()->whereIn('listing_id', $ids);
        $profile = $this->profileOf($user->id);

        return view('trader.home', [
            'counts' => $counts,
            'open' => (clone $quotes)->where('status', 'open')->count(),
            'quotedMonth' => (int) (clone $quotes)->where('status', 'quoted')->where('replied_at', '>=', now()->startOfMonth())->sum('quoted_minor'),
            'recent' => (clone $quotes)->with(['listing', 'user'])->latest()->limit(6)->get(),
            'profile' => $profile,
            'profileDone' => filled($profile->business['name'] ?? null) && filled($profile->business['phone'] ?? null),
            'total' => $counts->sum(),
        ]);
    }

    /* ------------------------------------------------------------------ machinery */

    public function machines(Request $request): View
    {
        $q = trim((string) $request->query('q', ''));
        $status = (string) $request->query('status', '');

        $machines = $this->mine($request)->with(['machine', 'region'])
            ->withCount(['quotes as open_quotes' => fn (Builder $b) => $b->where('status', 'open')])
            ->when($status !== '', fn (Builder $b) => $b->where('status', $status))
            ->when($q !== '', fn (Builder $b) => $b->where(fn (Builder $w) => $w->where('title', 'like', '%'.$q.'%')
                ->orWhereHas('machine', fn (Builder $m) => $m->where('brand', 'like', '%'.$q.'%')->orWhere('model', 'like', '%'.$q.'%'))))
            ->latest()->paginate(15)->withQueryString();

        return view('trader.machines', ['machines' => $machines, 'q' => $q, 'status' => $status]);
    }

    public function form(Request $request, ?Listing $listing = null): View
    {
        if ($listing) {
            $this->own($request, $listing);
            $listing->load('machine');
        }

        return view('trader.form', [
            'listing' => $listing, 'machine' => $listing?->machine, 'regions' => Region::query()->orderBy('name')->get(), 'districts' => District::query()->orderBy('name')->get(),
            'financing' => FeatureFlag::isEnabled('financing'), 'rental' => FeatureFlag::isEnabled('rental'),
        ]);
    }

    public function save(Request $request, ?Listing $listing = null): RedirectResponse
    {
        if ($listing) {
            $this->own($request, $listing);
        }
        $d = $request->validate([
            'title' => ['required', 'string', 'max:120'], 'category' => ['required', 'in:'.implode(',', array_keys(self::CATEGORIES))], 'sector' => ['required', 'in:'.implode(',', array_keys(self::SECTORS))],
            'brand' => ['nullable', 'string', 'max:80'], 'model' => ['nullable', 'string', 'max:80'], 'year' => ['nullable', 'integer', 'between:1980,'.((int) date('Y') + 1)],
            'condition' => ['required', 'in:'.implode(',', array_keys(self::CONDITIONS))], 'warranty' => ['nullable', 'string', 'max:120'],
            'price' => ['required', 'regex:/^\d{1,11}(\.\d{1,2})?$/'], 'stock' => ['required', 'integer', 'between:0,100000'],
            'offers' => ['required', 'array', 'min:1'], 'offers.*' => ['in:'.implode(',', array_keys(self::OFFERS))], 'rental_rate' => ['nullable', 'regex:/^\d{1,9}(\.\d{1,2})?$/'],
            'region_id' => ['required', 'exists:regions,id'], 'district_id' => ['required', 'exists:districts,id'],
            'lat' => ['nullable', 'numeric', 'between:-12,0'], 'lng' => ['nullable', 'numeric', 'between:29,41'],
            'description' => ['nullable', 'string', 'max:2000'],
            'spec_key' => ['nullable', 'array', 'max:20'], 'spec_key.*' => ['nullable', 'string', 'max:60'], 'spec_value' => ['nullable', 'array', 'max:20'], 'spec_value.*' => ['nullable', 'string', 'max:120'],
            'photos' => ['nullable', 'array', 'max:8'], 'photos.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'remove_photos' => ['nullable', 'array'], 'remove_photos.*' => ['string', 'max:255'],
            'brochure' => ['nullable', 'file', 'mimes:pdf', 'max:8192'], 'remove_brochure' => ['nullable', 'boolean'], 'submit' => ['nullable', 'boolean'],
        ]);

        if (! District::query()->whereKey($d['district_id'])->where('region_id', $d['region_id'])->exists()) {
            return back()->withInput()->withErrors(['district_id' => 'This district is not in the region you chose.']);
        }
        if (in_array('rental', $d['offers'], true) && blank($d['rental_rate'] ?? null)) {
            return back()->withInput()->withErrors(['rental_rate' => 'Enter the rental rate per day, or untick Rental.']);
        }
        $submit = ! empty($d['submit']);
        $keep = array_values(array_diff($listing?->photos ?? [], $d['remove_photos'] ?? []));
        if ($submit && count($keep) + count($request->file('photos', [])) < 1) {
            return back()->withInput()->withErrors(['photos' => 'Add at least one photo before submitting for review.']);
        }
        if (count($keep) + count($request->file('photos', [])) > 8) {
            return back()->withInput()->withErrors(['photos' => 'A listing can have at most 8 photos.']);
        }
        if ($submit && ! $request->user()->isIdentityVerified()) {
            return redirect()->route('me.identity')->with('status', 'Verify your identity (NIDA) before submitting a listing.');
        }

        $specs = collect($d['spec_key'] ?? [])->map(fn ($k, $i): array => ['k' => trim((string) $k), 'v' => trim((string) (($d['spec_value'] ?? [])[$i] ?? ''))])
            ->filter(fn (array $r): bool => $r['k'] !== '' && $r['v'] !== '')->values()->take(20)->all();

        $listing = DB::transaction(function () use ($request, $listing, $d, $submit, $specs, $keep): Listing {
            $base = [
                'title' => $d['title'], 'region_id' => $d['region_id'], 'district_id' => $d['district_id'], 'lat' => $d['lat'] ?? null, 'lng' => $d['lng'] ?? null,
                'price_minor' => Money::fromMajor($d['price'])->minor,
            ];
            if ($listing === null) {
                $listing = Listing::query()->create($base + ['user_id' => $request->user()->id, 'type' => ListingType::Machine, 'status' => $submit ? 'pending_review' : 'draft', 'photos' => []]);
            } else {
                $status = $listing->status;
                if ($submit && in_array($status, ['draft', 'rejected'], true)) {
                    $status = 'pending_review';
                } elseif ($status === 'sold_out' && (int) $d['stock'] > 0) {
                    $status = 'active';
                } elseif ($status === 'active' && (int) $d['stock'] === 0) {
                    $status = 'sold_out';
                }
                $listing->forceFill($base + ['status' => $status])->save();
            }

            $dir = "listings/{$listing->uuid}";
            foreach (array_diff($listing->photos ?? [], $keep) as $gone) {
                if (str_starts_with($gone, $dir.'/')) {
                    Storage::disk('public')->delete($gone);
                }
            }
            $listing->forceFill(['photos' => array_merge($keep, array_map(fn ($f) => $f->store($dir, 'public'), $request->file('photos', [])))])->save();

            $machine = Machine::query()->firstOrNew(['listing_id' => $listing->id]);
            $brochure = $machine->brochure_path;
            if (($request->boolean('remove_brochure') || $request->hasFile('brochure')) && $brochure && str_starts_with($brochure, $dir.'/')) {
                Storage::disk('public')->delete($brochure);
                $brochure = null;
            }
            if ($request->hasFile('brochure')) {
                $brochure = $request->file('brochure')->store($dir, 'public');
            }
            $machine->forceFill([
                'sector' => $d['sector'], 'category' => $d['category'], 'brand' => $d['brand'] ?? null, 'model' => $d['model'] ?? null, 'year' => $d['year'] ?? null,
                'machine_condition' => $d['condition'], 'warranty' => $d['warranty'] ?? null, 'stock' => (int) $d['stock'], 'offers' => array_values($d['offers']),
                'rental_rate_minor' => in_array('rental', $d['offers'], true) ? Money::fromMajor($d['rental_rate'])->minor : null,
                'description' => $d['description'] ?? null, 'specs' => $specs, 'brochure_path' => $brochure,
            ])->save();
            AuditLog::record('machine.saved', $listing, [], ['status' => $listing->status]);

            return $listing;
        });

        return redirect()->route('trader.machines')->with('status', $listing->status === 'pending_review' ? 'Submitted for review. You will be notified when it is live.' : 'Saved.');
    }

    public function setStatus(Request $request, Listing $listing, string $to): RedirectResponse
    {
        $this->own($request, $listing);
        abort_unless(in_array($to, ['pause', 'resume', 'close', 'soldout', 'reopen'], true), 404);
        $machine = $listing->machine()->first();

        if ($to === 'pause' && $listing->status === 'active') {
            $listing->forceFill(['status' => 'paused'])->save();
        } elseif ($to === 'resume' && $listing->status === 'paused') {
            $listing->forceFill(['status' => 'active'])->save();
        } elseif ($to === 'soldout' && $listing->status === 'active') {
            $machine?->forceFill(['stock' => 0])->save();
            $listing->forceFill(['status' => 'sold_out'])->save();
        } elseif ($to === 'reopen' && $listing->status === 'closed') {
            $listing->forceFill(['status' => 'draft'])->save(); // goes through review again
        } elseif ($to === 'close' && $listing->status !== 'closed') {
            if ($listing->quotes()->where('status', 'open')->exists()) {
                return back()->withErrors(['machine' => 'Answer the open quote requests before closing this listing.']);
            }
            $listing->forceFill(['status' => 'closed'])->save();
        } else {
            return back()->withErrors(['machine' => 'That change is not possible while the listing is '.str_replace('_', ' ', $listing->status).'.']);
        }
        AuditLog::record('machine.'.$to, $listing, [], ['status' => $listing->status]);

        return back()->with('status', 'Listing updated.');
    }

    public function duplicate(Request $request, Listing $listing): RedirectResponse
    {
        $this->own($request, $listing);
        $machine = $listing->machine()->first();

        $copy = DB::transaction(function () use ($listing, $machine): Listing {
            $copy = $listing->replicate(['uuid', 'verified', 'verified_at', 'verified_by', 'moderation_note', 'created_at', 'updated_at', 'deleted_at']);
            $copy->forceFill(['title' => Str::limit('Copy of '.$listing->title, 120, ''), 'status' => 'draft', 'photos' => [], 'verified' => false])->save();
            $paths = [];
            foreach ($listing->photos ?? [] as $p) {
                if (Storage::disk('public')->exists($p)) {
                    Storage::disk('public')->copy($p, $to = "listings/{$copy->uuid}/".basename($p));
                    $paths[] = $to;
                }
            }
            $copy->forceFill(['photos' => $paths])->save();
            if ($machine) {
                $m = $machine->replicate(['listing_id', 'brochure_path', 'created_at', 'updated_at']);
                $m->forceFill(['listing_id' => $copy->id])->save();
            }

            return $copy;
        });

        return redirect()->route('trader.machines.edit', $copy)->with('status', 'Copied as a draft. Change what is different and submit it.');
    }

    public function destroy(Request $request, Listing $listing): RedirectResponse
    {
        $this->own($request, $listing);
        if ($listing->quotes()->where('status', 'open')->exists()) {
            return back()->withErrors(['machine' => 'Answer the open quote requests before deleting this listing.']);
        }
        $listing->forceFill(['status' => 'closed'])->save();
        $listing->delete(); // soft delete: past quotes and the audit trail stay readable
        AuditLog::record('machine.deleted', $listing, [], []);

        return redirect()->route('trader.machines')->with('status', 'Listing deleted.');
    }

    /** Download the whole catalogue as a spreadsheet (CSV, opens in Excel). */
    public function export(Request $request): StreamedResponse
    {
        $rows = $this->mine($request)->with(['machine', 'region'])->withCount(['quotes as open_quotes' => fn (Builder $b) => $b->where('status', 'open')])->latest()->get();

        return $this->csv('machinery-'.now()->format('Y-m-d').'.csv', ['Title', 'Category', 'Brand', 'Model', 'Year', 'Condition', 'Price (TSh)', 'Stock', 'Offers', 'Status', 'Region', 'Open requests', 'Created'],
            $rows->map(fn (Listing $l): array => [
                $l->title, self::CATEGORIES[$l->machine?->category] ?? '', $l->machine?->brand, $l->machine?->model, $l->machine?->year, $l->machine?->machine_condition,
                number_format($l->price_minor / 100, 2, '.', ''), $l->machine?->stock, implode('/', $l->machine?->offers ?? []), $l->status, $l->region?->name, $l->open_quotes, $l->created_at?->format('Y-m-d'),
            ])->all());
    }

    /* ------------------------------------------------------------------ quote inbox */

    public function quotes(Request $request): View
    {
        $status = (string) $request->query('status', '');
        $kind = (string) $request->query('kind', '');
        $q = trim((string) $request->query('q', ''));

        $quotes = MachineQuote::query()->with(['listing.machine', 'user'])->whereIn('listing_id', $this->ownIds($request))
            ->when(in_array($status, ['open', 'quoted', 'declined', 'withdrawn'], true), fn (Builder $b) => $b->where('status', $status))
            ->when(in_array($kind, ['quote', 'financing', 'rental'], true), fn (Builder $b) => $b->where('kind', $kind))
            ->when($q !== '', fn (Builder $b) => $b->where(fn (Builder $w) => $w->whereHas('user', fn (Builder $u) => $u->where('name', 'like', '%'.$q.'%'))->orWhereHas('listing', fn (Builder $l) => $l->where('title', 'like', '%'.$q.'%'))))
            ->orderByRaw("status = 'open' desc")->latest()->paginate(15)->withQueryString();

        return view('trader.quotes', ['quotes' => $quotes, 'status' => $status, 'kind' => $kind, 'q' => $q]);
    }

    public function reply(Request $request, MachineQuote $quote, NotificationService $notes): RedirectResponse
    {
        $this->ownQuote($request, $quote);
        if (! in_array($quote->status, ['open', 'quoted'], true)) {
            return back()->withErrors(['quote' => 'This request is closed.']);
        }
        $d = $request->validate([
            'price' => ['required', 'regex:/^\d{1,12}(\.\d{1,2})?$/'], 'message' => ['nullable', 'string', 'max:1000'], 'valid_days' => ['required', 'integer', 'between:1,90'],
        ]);
        $quote->forceFill([
            'status' => 'quoted', 'quoted_minor' => Money::fromMajor($d['price'])->minor, 'reply' => $d['message'] ?? null, 'replied_at' => now(),
            'valid_until' => now()->addDays((int) $d['valid_days'])->toDateString(), 'decline_reason' => null,
        ])->save();
        $notes->notify($quote->user, 'machinery.quoted', ['quote' => $quote->uuid, 'message' => 'Umepata bei ya '.$quote->listing->title.': TSh '.number_format($quote->quoted_minor / 100).'.']);
        AuditLog::record('machine.quote_sent', $quote, [], ['quoted_minor' => $quote->quoted_minor]);

        return back()->with('status', 'Quotation sent to the buyer.');
    }

    public function decline(Request $request, MachineQuote $quote, NotificationService $notes): RedirectResponse
    {
        $this->ownQuote($request, $quote);
        if (! in_array($quote->status, ['open', 'quoted'], true)) {
            return back()->withErrors(['quote' => 'This request is closed.']);
        }
        $d = $request->validate(['reason' => ['required', 'string', 'max:200']]);
        $quote->forceFill(['status' => 'declined', 'decline_reason' => $d['reason'], 'replied_at' => now()])->save();
        $notes->notify($quote->user, 'machinery.declined', ['quote' => $quote->uuid, 'message' => 'Ombi lako la '.$quote->listing->title.' limekataliwa: '.$d['reason']]);

        return back()->with('status', 'Request declined.');
    }

    public function quotesExport(Request $request): StreamedResponse
    {
        $rows = MachineQuote::query()->with(['listing', 'user'])->whereIn('listing_id', $this->ownIds($request))->latest()->get();

        return $this->csv('quote-requests-'.now()->format('Y-m-d').'.csv', ['Reference', 'Date', 'Machine', 'Buyer', 'Phone', 'Type', 'Quantity', 'Months', 'Status', 'Quoted (TSh)', 'Valid until', 'Message'],
            $rows->map(fn (MachineQuote $q): array => [
                $q->reference(), $q->created_at?->format('Y-m-d'), $q->listing?->title, $q->user?->name, $q->user?->phone, $q->kind, $q->quantity, $q->months, $q->status,
                $q->quoted_minor !== null ? number_format($q->quoted_minor / 100, 2, '.', '') : '', $q->valid_until?->format('Y-m-d'), $q->message,
            ])->all());
    }

    /* ------------------------------------------------------------------ business profile */

    public function profile(Request $request): View
    {
        return view('trader.profile', [
            'profile' => $this->profileOf($request->user()->id), 'regions' => Region::query()->orderBy('name')->get(), 'districts' => District::query()->orderBy('name')->get(),
        ]);
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        $d = $request->validate([
            'name' => ['required', 'string', 'max:120'], 'about' => ['nullable', 'string', 'max:1500'], 'licence' => ['nullable', 'string', 'max:60'], 'since' => ['nullable', 'integer', 'between:1950,'.date('Y')],
            'services' => ['nullable', 'array'], 'services.*' => ['in:'.implode(',', array_keys(self::SERVICES))],
            'phone' => ['required', 'regex:/^\+?[0-9 ]{9,20}$/'], 'whatsapp' => ['nullable', 'regex:/^\+?[0-9 ]{9,20}$/'], 'email' => ['nullable', 'email', 'max:120'], 'website' => ['nullable', 'url', 'max:160'],
            'address' => ['nullable', 'string', 'max:200'], 'hours' => ['nullable', 'string', 'max:120'],
            'region_id' => ['nullable', 'exists:regions,id'], 'district_id' => ['nullable', 'exists:districts,id'],
        ]);
        if (! empty($d['district_id']) && ! District::query()->whereKey($d['district_id'])->where('region_id', $d['region_id'] ?? 0)->exists()) {
            return back()->withInput()->withErrors(['district_id' => 'This district is not in the region you chose.']);
        }

        $profile = $this->profileOf($request->user()->id);
        $profile->forceFill([
            'region_id' => $d['region_id'] ?? null, 'district_id' => $d['district_id'] ?? null,
            'business' => ['name' => $d['name'], 'about' => $d['about'] ?? null, 'licence' => $d['licence'] ?? null, 'since' => $d['since'] ?? null, 'services' => array_values($d['services'] ?? []),
                'phone' => $d['phone'], 'whatsapp' => $d['whatsapp'] ?? null, 'email' => $d['email'] ?? null, 'website' => $d['website'] ?? null, 'address' => $d['address'] ?? null, 'hours' => $d['hours'] ?? null],
        ])->save();

        return back()->with('status', 'Business profile saved.');
    }

    /* ------------------------------------------------------------------ helpers */

    /** @return Builder<Listing> */
    private function mine(Request $request): Builder
    {
        return Listing::query()->where('user_id', $request->user()->id)->where('type', 'machine');
    }

    /** @return \Illuminate\Support\Collection<int, int> listings including deleted ones, so past quotes stay visible */
    private function ownIds(Request $request): \Illuminate\Support\Collection
    {
        return Listing::withTrashed()->where('user_id', $request->user()->id)->where('type', 'machine')->pluck('id');
    }

    private function own(Request $request, Listing $listing): void
    {
        abort_unless($listing->user_id === $request->user()->id && $listing->type === ListingType::Machine, 404);
    }

    private function ownQuote(Request $request, MachineQuote $quote): void
    {
        abort_unless($this->ownIds($request)->contains($quote->listing_id), 404);
    }

    private function profileOf(int $userId): RoleProfile
    {
        return RoleProfile::query()->firstOrNew(['user_id' => $userId, 'role' => 'R']);
    }

    /** @param list<string> $head @param list<array<int, mixed>> $rows */
    private function csv(string $name, array $head, array $rows): StreamedResponse
    {
        $safe = static fn (mixed $v): string => preg_match('/^[=+\-@\t\r]/', (string) $v) ? "'".$v : (string) ($v ?? ''); // spreadsheet formula injection

        return response()->streamDownload(function () use ($head, $rows, $safe): void {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel shows Kiswahili letters correctly
            fputcsv($out, $head);
            foreach ($rows as $r) {
                fputcsv($out, array_map($safe, $r));
            }
            fclose($out);
        }, $name, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }
}
