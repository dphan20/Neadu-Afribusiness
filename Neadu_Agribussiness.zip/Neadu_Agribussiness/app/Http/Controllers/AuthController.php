<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\UserRole;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Models\User;
use App\Models\UserRoleAssignment;
use App\Support\Phone;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class AuthController extends Controller
{
    /** bcrypt of a throw-away string: checked when the account does not exist so response time does not reveal which logins are registered. */
    private const DUMMY_HASH = '$2y$12$DIccuzVEfr3H4kP2NFbYRe9kArRiA666F9/Td3IVL4bYX7MtxtBOe';

    public function loginForm(): View
    {
        return view('auth.login');
    }

    public function registerForm(): View
    {
        return view('auth.register', ['roles' => UserRole::cases()]);
    }

    public function login(LoginRequest $request): RedirectResponse
    {
        $user = $this->findUser($request->validated('login'));
        $locked = $user?->locked_until !== null && $user->locked_until->isFuture();

        if ($user === null || $user->pin_hash === null) {
            Hash::check($request->validated('pin'), self::DUMMY_HASH);
        }

        if (
            $user === null
            || $user->status !== 'active'
            || $user->pin_hash === null
            || $locked
            || ! Hash::check($request->validated('pin'), $user->pin_hash)
        ) {
            if ($user !== null && $user->status === 'active' && ! $locked) {
                $attempts = $user->failed_pin_attempts + 1;
                $shouldLock = $attempts >= 5;
                $user->forceFill([
                    'failed_pin_attempts' => $shouldLock ? 0 : $attempts,
                    'locked_until' => $shouldLock ? now()->addMinutes(15) : null,
                ])->save();
            }

            return back()
                ->withErrors(['login' => __('The email/phone number or password is incorrect.')])
                ->onlyInput('login');
        }

        if ($user->failed_pin_attempts > 0 || $user->locked_until !== null) {
            $user->forceFill(['failed_pin_attempts' => 0, 'locked_until' => null])->save();
        }

        $roles = $user->roleAssignments()->where('role', '!=', UserRole::Admin->value)->pluck('role');
        if ($roles->isEmpty()) {
            if ($user->roleAssignments()->where('role', UserRole::Admin->value)->exists()) {
                return back()->withErrors(['login' => __('Administrator accounts sign in through the NeAS console, not this page.')])->onlyInput('login');
            }

            return back()->withErrors(['login' => __('This account has no assigned role. Contact support.')]);
        }

        Auth::login($user);
        $request->session()->regenerate();
        $request->session()->put('active_role', $roles->first());

        return redirect()->to(UserRole::from($roles->first())->dashboardPath());
    }

    public function register(RegisterRequest $request): RedirectResponse
    {
        $data = $request->validated();

        $user = DB::transaction(function () use ($data): User {
            $user = User::query()->create([
                'name' => $data['name'],
                'email' => $data['email'] ?? null,
                'phone' => $data['phone'] ?? null,
                'username' => null,
            ]);
            $user->forceFill(['pin_hash' => $data['pin']])->save();

            foreach ($data['roles'] as $role) {
                UserRoleAssignment::query()->create(['user_id' => $user->id, 'role' => $role]);
            }

            return $user;
        });

        Auth::login($user);
        $request->session()->regenerate();
        $request->session()->put('active_role', $data['roles'][0]);

        return redirect()->to(UserRole::from($data['roles'][0])->dashboardPath());
    }

    /** Email (contains "@") or phone in any common format: 0712 345 678, +255712345678, 255712345678. */
    private function findUser(string $login): ?User
    {
        $login = trim($login);

        if (str_contains($login, '@')) {
            return User::query()->where('email', mb_strtolower($login))->first();
        }

        // The raw value is also tried so accounts saved before normalisation still work.
        return User::query()
            ->where(static fn ($q) => $q->where('phone', Phone::normalize($login))->orWhere('phone', $login))
            ->first();
    }

    public function logout(): RedirectResponse
    {
        Auth::logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();

        return redirect()->route('home');
    }

    public function switchRole(): RedirectResponse
    {
        $data = request()->validate(['role' => ['required', 'string']]);
        $role = UserRole::tryFrom($data['role']);

        abort_unless(
            $role !== null && $role !== UserRole::Admin && auth()->user()->roleAssignments()->where('role', $role->value)->exists(),
            403
        );

        request()->session()->put('active_role', $role->value);

        return redirect()->to($role->dashboardPath());
    }
}
