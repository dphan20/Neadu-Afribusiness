<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Conversation;
use App\Services\MessagingService;
use App\Models\Tour;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Group chat for each tour: the organiser and every booked attendee. Only participants can read or write. */
class TrainerChatController extends Controller
{
    public function index(): View
    {
        $conversations = Conversation::query()->with(['participants', 'messages'])->whereNotNull('tour_id')
            ->visibleTo(auth()->user())->latest('updated_at')->get();

        return view('trainer.chat-index', ['conversations' => $conversations, 'tours' => Tour::query()->with('listing')->whereIn('id', $conversations->pluck('tour_id'))->get()->keyBy('id')]);
    }

    public function show(string $uuid): View
    {
        $conversation = $this->mine($uuid)->load(['participants']);
        $conversation->markReadBy(auth()->user());

        return view('trainer.chat', ['conversation' => $conversation, 'tour' => Tour::query()->with('listing')->find($conversation->tour_id)]);
    }

    public function send(Request $request, string $uuid): RedirectResponse
    {
        $conversation = $this->mine($uuid);
        $d = $request->validate(['body' => ['required', 'string', 'max:2000']]);
        app(MessagingService::class)->send($conversation, $request->user(), $d['body']);

        return redirect()->route('trainer.chat.show', $conversation)->withFragment('latest');
    }

    private function mine(string $uuid): Conversation
    {
        return Conversation::query()->where('uuid', $uuid)->whereNotNull('tour_id')->whereHas('participants', fn ($q) => $q->where('users.id', auth()->id()))->firstOrFail();
    }
}
