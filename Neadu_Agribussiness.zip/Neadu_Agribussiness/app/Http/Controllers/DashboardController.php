<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\UserRole;
use App\Models\Delivery;
use App\Models\DiagnosisCase;
use App\Models\LedgerEntry;
use App\Models\Listing;
use App\Models\Order;
use App\Models\PriceRecord;
use App\Models\StorageBooking;
use App\Models\Vehicle;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Route;
use Illuminate\View\View;

class DashboardController extends Controller
{
    /** @var array<string, array{label: string, roles: list<UserRole>}> */
    private const NAV_ITEMS = [
        'market' => ['label' => 'Marketplace', 'roles' => [UserRole::Producer, UserRole::Buyer, UserRole::Trader]],
        'listings' => ['label' => 'My listings', 'roles' => [UserRole::Producer, UserRole::LandOwner, UserRole::WarehouseOwner, UserRole::Trader, UserRole::Trainer]],
        'orders' => ['label' => 'Orders', 'roles' => [UserRole::Producer, UserRole::Buyer]],
        'delivery' => ['label' => 'Transport jobs', 'roles' => [UserRole::Transporter, UserRole::Producer, UserRole::Buyer]],
        'storage' => ['label' => 'Storage', 'roles' => [UserRole::Producer, UserRole::WarehouseOwner]],
        'diagnosis' => ['label' => 'Expert cases', 'roles' => [UserRole::Producer, UserRole::Expert]],
        'tours' => ['label' => 'Agri-tours', 'roles' => [UserRole::Trainer]],
        'machinery' => ['label' => 'Machinery', 'roles' => [UserRole::Trader, UserRole::Buyer]],
        'land' => ['label' => 'Land', 'roles' => [UserRole::LandOwner, UserRole::Buyer]],
        'prices' => ['label' => 'Market prices', 'roles' => [UserRole::Producer, UserRole::Buyer, UserRole::Trader]],
        'messages' => ['label' => 'Messages', 'roles' => [UserRole::Producer, UserRole::Buyer, UserRole::Expert, UserRole::Trainer, UserRole::Transporter, UserRole::LandOwner, UserRole::WarehouseOwner, UserRole::Trader, UserRole::Admin]],
        'wallet' => ['label' => 'Wallet & payouts', 'roles' => [UserRole::Producer, UserRole::Buyer, UserRole::Expert, UserRole::Trainer, UserRole::Transporter, UserRole::LandOwner, UserRole::WarehouseOwner, UserRole::Trader, UserRole::Admin]],
        'profile' => ['label' => 'My profile', 'roles' => [UserRole::Producer, UserRole::Buyer, UserRole::Expert, UserRole::Trainer, UserRole::Transporter, UserRole::LandOwner, UserRole::WarehouseOwner, UserRole::Trader, UserRole::Admin]],
    ];

    public function index(): View|RedirectResponse
    {
        $role = $this->activeRole();
        if ($role === UserRole::Admin) {
            return redirect('/admin');
        }

        if ($role === UserRole::Buyer) {
            return redirect()->route('buyer.dashboard');
        }
        if ($role === UserRole::Expert) {
            return redirect()->route('expert.dashboard');
        }
        if ($role === UserRole::Trainer) {
            return redirect()->route('trainer.dashboard');
        }
        if ($role === UserRole::Trader && Route::has('trader.home')) {
            return redirect()->route('trader.home');
        }

        $user = auth()->user();
        $metrics = match ($role) {
            UserRole::Producer => [
                ['label' => 'Active listings', 'value' => Listing::query()->where('user_id', $user->id)->where('status', 'active')->count(), 'tone' => 'green'],
                ['label' => 'Orders to fulfil', 'value' => Order::query()->where('seller_id', $user->id)->whereIn('status', ['pending', 'held', 'in_transit'])->count(), 'tone' => 'gold'],
                ['label' => 'Identity', 'value' => $user->isIdentityVerified() ? 'Verified' : 'Needs review', 'tone' => $user->isIdentityVerified() ? 'green' : 'amber'],
            ],
            UserRole::Buyer => [
                ['label' => 'Open orders', 'value' => Order::query()->where('buyer_id', $user->id)->whereIn('status', ['pending', 'held', 'in_transit'])->count(), 'tone' => 'green'],
                ['label' => 'Completed orders', 'value' => Order::query()->where('buyer_id', $user->id)->whereIn('status', ['released', 'refunded'])->count(), 'tone' => 'blue'],
                ['label' => 'Marketplace', 'value' => Listing::query()->where('status', 'active')->count().' listings', 'tone' => 'gold'],
            ],
            UserRole::Expert => [
                ['label' => 'Cases awaiting review', 'value' => DiagnosisCase::query()->where('expert_id', $user->id)->whereNull('expert_reply')->count(), 'tone' => 'gold'],
                ['label' => 'Cases answered', 'value' => DiagnosisCase::query()->where('expert_id', $user->id)->whereNotNull('expert_reply')->count(), 'tone' => 'green'],
                ['label' => 'Expert profile', 'value' => $user->isIdentityVerified() ? 'Verified' : 'In progress', 'tone' => 'blue'],
            ],
            UserRole::Trainer => [
                ['label' => 'Published tours', 'value' => Listing::query()->where('user_id', $user->id)->where('type', 'tour')->where('status', 'active')->count(), 'tone' => 'green'],
                ['label' => 'Draft tours', 'value' => Listing::query()->where('user_id', $user->id)->where('type', 'tour')->where('status', 'draft')->count(), 'tone' => 'gold'],
                ['label' => 'Account status', 'value' => ucfirst($user->status), 'tone' => 'blue'],
            ],
            UserRole::Transporter => [
                ['label' => 'Available jobs', 'value' => Delivery::query()->whereNull('transporter_id')->where('status', 'requested')->count(), 'tone' => 'gold'],
                ['label' => 'My active trips', 'value' => Delivery::query()->where('transporter_id', $user->id)->whereNotIn('status', ['delivered', 'cancelled'])->count(), 'tone' => 'green'],
                ['label' => 'Registered vehicles', 'value' => Vehicle::query()->where('user_id', $user->id)->count(), 'tone' => 'blue'],
            ],
            UserRole::LandOwner => [
                ['label' => 'Active land listings', 'value' => Listing::query()->where('user_id', $user->id)->where('type', 'land')->where('status', 'active')->count(), 'tone' => 'green'],
                ['label' => 'Awaiting review', 'value' => Listing::query()->where('user_id', $user->id)->where('type', 'land')->where('status', 'pending_review')->count(), 'tone' => 'gold'],
                ['label' => 'Account status', 'value' => ucfirst($user->status), 'tone' => 'blue'],
            ],
            UserRole::WarehouseOwner => [
                ['label' => 'Active facilities', 'value' => Listing::query()->where('user_id', $user->id)->where('type', 'storage')->where('status', 'active')->count(), 'tone' => 'green'],
                ['label' => 'Booking requests', 'value' => StorageBooking::query()->whereHas('facilityListing', fn (Builder $query) => $query->where('user_id', $user->id))->where('status', 'requested')->count(), 'tone' => 'gold'],
                ['label' => 'Active bookings', 'value' => StorageBooking::query()->whereHas('facilityListing', fn (Builder $query) => $query->where('user_id', $user->id))->where('status', 'accepted')->count(), 'tone' => 'blue'],
            ],
            UserRole::Trader => [
                ['label' => 'Active machinery listings', 'value' => Listing::query()->where('user_id', $user->id)->where('type', 'machine')->where('status', 'active')->count(), 'tone' => 'green'],
                ['label' => 'Draft listings', 'value' => Listing::query()->where('user_id', $user->id)->where('type', 'machine')->where('status', 'draft')->count(), 'tone' => 'gold'],
                ['label' => 'Account status', 'value' => ucfirst($user->status), 'tone' => 'blue'],
            ],
            UserRole::Admin => [],
        };

        $navigation = $this->navigationFor($role);

        $links = $this->realLinks($role);

        return view('dashboard.index', compact('role', 'metrics', 'navigation', 'links'));
    }

    public function section(string $section): View|RedirectResponse
    {
        $role = $this->activeRole();
        if ($role === UserRole::Admin) {
            return redirect('/admin');
        }

        if ($role === UserRole::Buyer) {
            $map = ['market' => 'buyer.market', 'orders' => 'buyer.orders', 'delivery' => 'buyer.orders', 'prices' => 'buyer.alerts', 'messages' => 'buyer.chat'];
            if (isset($map[$section])) {
                return redirect()->route($map[$section]);
            }
        }

        if ($role === UserRole::Expert) {
            $map = ['diagnosis' => 'expert.cases', 'messages' => 'expert.chat', 'wallet' => 'expert.earnings', 'profile' => 'expert.profile'];
            if (isset($map[$section])) {
                return redirect()->route($map[$section]);
            }
        }

        if ($role === UserRole::Trainer) {
            $map = ['tours' => 'trainer.tours', 'listings' => 'trainer.tours', 'messages' => 'trainer.chat', 'wallet' => 'trainer.earnings', 'profile' => 'trainer.profile'];
            if (isset($map[$section])) {
                return redirect()->route($map[$section]);
            }
        }

        $navigation = $this->navigationFor($role);
        abort_unless(isset($navigation[$section]), 404);
        $user = auth()->user();

        [$title, $description, $columns, $rows] = match ($section) {
            'market' => $this->listingTable(Listing::query()->with('owner')->where('status', 'active')->latest()),
            'listings' => $this->listingTable(Listing::query()->with('owner')->where('user_id', $user->id)->latest()),
            'machinery' => $this->listingTable(Listing::query()->with('owner')->where('type', 'machine')->where('status', 'active')->latest()),
            'tours' => $this->listingTable(Listing::query()->with('owner')->where('type', 'tour')->where('user_id', $user->id)->latest()),
            'land' => $this->listingTable(Listing::query()->with('owner')->where('type', 'land')->where('status', 'active')->latest()),
            'orders' => $this->orderTable(
                Order::query()->with(['buyer', 'seller', 'listing'])
                    ->where(fn (Builder $query) => $query->where('buyer_id', $user->id)->orWhere('seller_id', $user->id))
                    ->latest()
            ),
            'delivery' => $this->deliveryTable(
                Delivery::query()->with('order')->where(fn (Builder $query) => $query
                    ->where('transporter_id', $user->id)
                    ->orWhere(fn (Builder $open) => $open->whereNull('transporter_id')->where('status', 'requested')))
                    ->latest()
            ),
            'storage' => $this->storageTable(StorageBooking::query()
                ->with('facilityListing')
                ->where(fn (Builder $query) => $query->where('user_id', $user->id)
                    ->orWhereHas('facilityListing', fn (Builder $listing) => $listing->where('user_id', $user->id)))
                ->latest()),
            'diagnosis' => $this->diagnosisTable(DiagnosisCase::query()
                ->where(fn (Builder $query) => $query->where('user_id', $user->id)->orWhere('expert_id', $user->id))
                ->latest()),
            'prices' => $this->priceTable(PriceRecord::query()->with(['crop', 'market', 'region'])->latest('recorded_on')),
            'messages' => ['Messages', 'Your conversations are only shown to their participants.', [], collect()],
            'wallet' => ['Wallet & payouts', 'Ledger entries recorded for your account.', ['Date', 'Account', 'Debit (minor TZS)', 'Credit (minor TZS)'],
                LedgerEntry::query()->where(fn (Builder $query) => $query
                    ->where('account', 'seller:'.$user->id)
                    ->orWhere('account', 'buyer:'.$user->id)
                    ->orWhere('account', 'transporter:'.$user->id))
                    ->latest('created_at')->get()
                    ->map(fn ($entry) => [$entry->created_at?->format('d-m-Y') ?? '—', $entry->account, number_format($entry->debit_minor), number_format($entry->credit_minor)])],
            'profile' => ['My profile', 'Your account and identity-verification status.', ['Name', 'Phone', 'Status', 'Verification'],
                collect([[$user->name, $user->phone, ucfirst($user->status), ucfirst($user->verification_level)]])],
            default => abort(404),
        };

        $links = $this->realLinks($role);

        return view('dashboard.section', compact('role', 'navigation', 'section', 'title', 'description', 'columns', 'rows', 'links'));
    }

    /**
     * Section key => URL of the real working page (add / edit / manage) for this role. The generic /workspace tables are
     * read-only, so wherever a working page exists the menu goes there instead.
     *
     * @return array<string, string>
     */
    private function realLinks(UserRole $role): array
    {
        $me = ['messages' => 'me.chat.index', 'wallet' => 'me.wallet', 'profile' => 'me.profile'];
        $map = match ($role) {
            UserRole::Producer => $me + ['listings' => 'producer.listings.index', 'orders' => 'producer.orders.index', 'storage' => 'producer.storage.index',
                'diagnosis' => 'producer.diagnosis.index', 'prices' => 'me.alerts.index', 'land' => 'land.index', 'profile' => 'producer.profile'],
            UserRole::Transporter => $me + ['delivery' => 'transporter.jobs', 'wallet' => 'transporter.earnings'],
            UserRole::LandOwner => $me + ['listings' => 'landowner.listings', 'land' => 'land.index'],
            UserRole::WarehouseOwner => $me + ['listings' => 'warehouse.facilities', 'storage' => 'warehouse.bookings'],
            UserRole::Trader => $me + ['listings' => 'trader.machines', 'machinery' => 'trader.machines', 'market' => 'machinery.index', 'prices' => 'me.alerts.index'],
            default => [],
        };

        $links = [];
        foreach ($map as $section => $name) {
            if (Route::has($name)) {
                $links[$section] = route($name);
            }
        }

        return $links;
    }

    private function activeRole(): UserRole
    {
        $user = auth()->user();
        $active = UserRole::tryFrom((string) request()->session()->get('active_role', ''));

        if ($active !== null && $user->roleAssignments()->where('role', $active->value)->exists()) {
            return $active;
        }

        $first = $user->roleAssignments()->value('role');
        abort_if($first === null, 403, 'No role is assigned to this account.');

        $role = UserRole::from($first);
        request()->session()->put('active_role', $role->value);

        return $role;
    }

    /** @return array<string, array{label: string, roles: list<UserRole>}> */
    private function navigationFor(UserRole $role): array
    {
        return array_filter(self::NAV_ITEMS, static fn (array $item): bool => in_array($role, $item['roles'], true));
    }

    /** @return array{string, string, list<string>, Collection<int, array<int, string>>} */
    private function listingTable(Builder $query): array
    {
        $rows = $query->get()->map(static fn (Listing $listing): array => [
            $listing->title,
            ucfirst($listing->type->value),
            ucfirst(str_replace('_', ' ', $listing->status)),
            $listing->owner?->name ?? '—',
            number_format($listing->price_minor).' '.$listing->currency,
        ]);

        return ['Listings', 'Browse listing details and current review status.', ['Title', 'Category', 'Status', 'Owner', 'Price'], $rows];
    }

    /** @return array{string, string, list<string>, Collection<int, array<int, string>>} */
    private function orderTable(Builder $query): array
    {
        $rows = $query->get()->map(static fn (Order $order): array => [
            '#'.$order->id,
            $order->listing?->title ?? '—',
            $order->buyer?->name ?? '—',
            $order->seller?->name ?? '—',
            ucfirst(str_replace('_', ' ', $order->status->value)),
            number_format($order->subtotal_minor).' '.$order->currency,
        ]);

        return ['Orders', 'Track order status and escrow totals.', ['Order', 'Listing', 'Buyer', 'Seller', 'Status', 'Subtotal'], $rows];
    }

    /** @return array{string, string, list<string>, Collection<int, array<int, string>>} */
    private function deliveryTable(Builder $query): array
    {
        $rows = $query->get()->map(static fn (Delivery $delivery): array => [
            '#'.$delivery->id,
            '#'.$delivery->order_id,
            ucfirst(str_replace('_', ' ', $delivery->status)),
            number_format($delivery->price_minor).' TZS',
            $delivery->created_at?->format('d-m-Y') ?? '—',
        ]);

        return ['Transport jobs', 'Available jobs and your current deliveries.', ['Delivery', 'Order', 'Status', 'Price', 'Created'], $rows];
    }

    /** @return array{string, string, list<string>, Collection<int, array<int, string>>} */
    private function storageTable(Builder $query): array
    {
        $rows = $query->get()->map(static fn (StorageBooking $booking): array => [
            $booking->facilityListing?->title ?? '—',
            number_format((float) $booking->quantity_kg).' kg',
            $booking->starts_on.' – '.$booking->ends_on,
            ucfirst($booking->status),
            number_format($booking->price_minor).' TZS',
        ]);

        return ['Storage bookings', 'Bookings you requested and requests for your facilities.', ['Facility', 'Quantity', 'Period', 'Status', 'Price'], $rows];
    }

    /** @return array{string, string, list<string>, Collection<int, array<int, string>>} */
    private function diagnosisTable(Builder $query): array
    {
        $rows = $query->get()->map(static fn (DiagnosisCase $case): array => [
            $case->subject,
            $case->result ?? 'Awaiting analysis',
            $case->confidence === null ? '—' : $case->confidence.'%',
            $case->expert_reply === null ? 'Awaiting expert' : 'Answered',
            $case->created_at?->format('d-m-Y') ?? '—',
        ]);

        return ['Diagnosis & expert cases', 'Case history and the current expert-response status.', ['Type', 'Result', 'Confidence', 'Expert response', 'Created'], $rows];
    }

    /** @return array{string, string, list<string>, Collection<int, array<int, string>>} */
    private function priceTable(Builder $query): array
    {
        $rows = $query->limit(100)->get()->map(static fn (PriceRecord $record): array => [
            $record->crop?->name_en ?? '—',
            $record->market?->name ?? '—',
            $record->region?->name ?? '—',
            number_format($record->price_minor).' TZS',
            $record->recorded_on,
            $record->source,
        ]);

        return ['Market prices', 'Reference prices with their source and recorded date.', ['Produce', 'Market', 'Region', 'Price', 'Recorded', 'Source'], $rows];
    }
}
