<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use App\Services\MessagingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * COM-01: forward a message to anyone, delete it (for me / for everyone) and delete a whole chat.
 * One controller serves every role's chat screens and the NeAS console; the route name prefix (`me.` or `admin.`) picks the area.
 */
class ChatMessageController extends Controller
{
    private const MAX_TARGETS = 10;

    public function __construct(private readonly MessagingService $messaging) {}

    public function forwardForm(Request $request, Message $message): View
    {
        $user = $request->user();
        abort_unless($this->messaging->canSee($user, $message), 404);

        $q = (string) $request->query('q', '');
        $role = (string) $request->query('role', '');
        $recent = Conversation::query()->visibleTo($user)->with(['participants.roleAssignments', 'order.listing', 'listing'])
            ->withMax('messages', 'created_at')->orderByDesc('messages_max_created_at')->limit(30)->get();

        return view($this->admin($request) ? 'admin.messages.forward' : 'producer.chat.forward', [
            'message' => $message, 'recent' => $recent, 'q' => $q, 'role' => $role,
            'people' => $this->messaging->directory($user, $q, $role), 'messaging' => $this->messaging,
        ]);
    }

    public function forward(Request $request, Message $message): RedirectResponse
    {
        $user = $request->user();
        abort_unless($this->messaging->canSee($user, $message), 404);

        $d = $request->validate([
            'conversations' => ['nullable', 'array', 'max:'.self::MAX_TARGETS], 'conversations.*' => ['uuid'],
            'users' => ['nullable', 'array', 'max:'.self::MAX_TARGETS], 'users.*' => ['uuid'],
        ]);

        $targets = collect();
        foreach ($d['conversations'] ?? [] as $uuid) {
            $conversation = Conversation::query()->visibleTo($user)->where('uuid', $uuid)->first();
            if ($conversation !== null) {
                $targets->put($conversation->id, $conversation);
            }
        }
        foreach ($d['users'] ?? [] as $uuid) {
            $to = User::query()->where('uuid', $uuid)->first();
            if ($to !== null && $this->messaging->canMessage($user, $to)) {
                $direct = $this->messaging->direct($user, $to);
                $targets->put($direct->id, $direct);
            }
        }
        $targets = $targets->take(self::MAX_TARGETS)->values();

        if ($targets->isEmpty()) {
            return back()->withErrors(['to' => __('chat.pick_one')]);
        }

        $sent = $this->messaging->forward($message, $user, $targets);
        if ($sent === 0) {
            return back()->withErrors(['to' => __('chat.forward_failed')]);
        }

        return redirect()->route($this->admin($request) ? 'admin.messages.show' : 'me.chat.show', $targets->first())
            ->with('status', __('chat.forwarded_to', ['count' => $sent]))->withFragment('latest');
    }

    public function destroy(Request $request, Message $message): RedirectResponse
    {
        $user = $request->user();
        abort_unless($this->messaging->canSee($user, $message), 404);
        $scope = $request->validate(['scope' => ['required', 'in:me,everyone']])['scope'];

        if ($scope === 'everyone') {
            abort_unless($this->messaging->deleteForEveryone($message, $user), 403);
        } else {
            $this->messaging->deleteForMe($message, $user);
        }

        return back()->with('status', __('chat.deleted_ok'));
    }

    public function clear(Request $request, Conversation $conversation): RedirectResponse
    {
        abort_unless($conversation->hasParticipant($request->user()), 404);
        $this->messaging->hideConversation($conversation, $request->user());

        return redirect()->route($this->admin($request) ? 'admin.messages' : 'me.chat.index')->with('status', __('chat.chat_deleted'));
    }

    private function admin(Request $request): bool
    {
        return $request->routeIs('admin.*');
    }
}
