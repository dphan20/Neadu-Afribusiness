<?php

declare(strict_types=1);

namespace App\Http\Controllers\Expert;

use App\Http\Controllers\Controller;
use App\Models\AdvicePost;
use App\Models\DiagnosisCase;
use App\Services\LedgerService;
use App\Services\NotificationService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** S-37 expert case queue (DIA-03/05) and published advice. */
class ExpertController extends Controller
{
    public function queue(Request $request): View
    {
        $cases = DiagnosisCase::query()->with('user')->where('expert_id', $request->user()->id)->orderByRaw('expert_reply IS NOT NULL')->latest()->get();
        $rated = DiagnosisCase::query()->where('expert_id', $request->user()->id)->whereNotNull('expert_rating');

        return view('expert.queue', ['cases' => $cases, 'rating' => $rated->count() ? round((float) $rated->avg('expert_rating'), 1) : null, 'ratingCount' => $rated->count()]);
    }

    public function show(Request $request, DiagnosisCase $case): View
    {
        abort_unless($case->expert_id === $request->user()->id, 404);
        $case->load('user', 'conversation');

        return view('expert.case', compact('case'));
    }

    /** The case photo is private: only the expert the case is assigned to may open it. */
    public function photo(Request $request, DiagnosisCase $case): StreamedResponse
    {
        abort_unless($case->expert_id === $request->user()->id, 404);
        abort_unless(Storage::disk('local')->exists($case->photo_path), 404);

        return Storage::disk('local')->response($case->photo_path);
    }

    /** Reply, and tell the AI engine whether it was right (DIA-05, feeds retraining). */
    public function reply(Request $request, DiagnosisCase $case, LedgerService $ledger, NotificationService $notes): RedirectResponse
    {
        abort_unless($case->expert_id === $request->user()->id, 404);
        $d = $request->validate([
            'reply' => ['required', 'string', 'min:5', 'max:3000'], 'ai_correct' => ['required', 'boolean'],
            'expert_correction' => ['nullable', 'string', 'max:1000', 'required_if:ai_correct,0'],
        ]);

        DB::transaction(function () use ($case, $d, $request, $ledger, $notes): void {
            $first = $case->expert_reply === null;
            $fee = $first ? (int) config('neas.expert.fee_tzs') * 100 : 0;
            $case->forceFill([
                'expert_reply' => $d['reply'], 'ai_correct' => (bool) $d['ai_correct'], 'expert_correction' => $d['expert_correction'] ?? null,
                'replied_at' => now(), 'fee_minor' => $case->fee_minor ?: $fee,
            ])->save();
            if ($fee > 0) {
                $ledger->post([['account' => 'platform:float', 'debit' => $fee], ['account' => 'expert:'.$request->user()->id, 'credit' => $fee]], null, null, 'Consultation '.$case->uuid);
            }
            $notes->notify($case->user, 'diagnosis.reply', ['case' => $case->uuid, 'message' => 'Mtaalamu amejibu ombi lako la ushauri.']);
        });

        return back()->with('status', 'Reply sent.');
    }

    public function advice(Request $request): View
    {
        return view('expert.advice', ['posts' => AdvicePost::query()->where('expert_id', $request->user()->id)->latest()->get()]);
    }

    public function advicePublish(Request $request): RedirectResponse
    {
        $d = $request->validate(['category' => ['required', 'in:crop,livestock,fish'], 'title' => ['required', 'string', 'max:150'], 'body' => ['required', 'string', 'min:20', 'max:5000']]);
        AdvicePost::query()->create($d + ['expert_id' => $request->user()->id, 'published_at' => now()]);

        return back()->with('status', 'Advice published. Producers can read it now.');
    }

    public function adviceDelete(Request $request, AdvicePost $post): RedirectResponse
    {
        abort_unless($post->expert_id === $request->user()->id, 404);
        $post->delete();

        return back()->with('status', 'Advice removed.');
    }

    /** Public feed for everyone. */
    public function feed(): View
    {
        return view('expert.feed', ['posts' => AdvicePost::query()->with('expert')->whereNotNull('published_at')->latest('published_at')->paginate(10)]);
    }
}
