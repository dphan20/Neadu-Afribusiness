<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\ListingType;
use App\Enums\UserRole;
use App\Models\AuditLog;
use App\Models\Conversation;
use App\Models\FeeRule;
use App\Models\LedgerEntry;
use App\Models\Listing;
use App\Models\Message;
use App\Models\Payout;
use App\Models\Region;
use App\Models\RoleProfile;
use App\Models\Tour;
use App\Models\TourBooking;
use App\Models\TourReview;
use App\Models\User;
use App\Services\LedgerService;
use App\Support\Money;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

/** Role 4 - Trainer / entrepreneur: S-29 create tours, S-28 bookings, attendees, certificates, reviews, S-45 payouts. */
class TrainerController extends Controller
{
    /* ------------------------------------------------------------------ overview */

    public function dashboard(): View
    {
        $me = auth()->user();
        $tours = $this->myTours()->get();
        $stats = $this->stats($me);
        $paidOpen = TourBooking::query()->where('status', 'paid')->whereHas('tour.listing', fn ($q) => $q->where('user_id', $me->id))->get();

        return view('trainer.dashboard', [
            'metrics' => [
                ['label' => 'Live tours', 'value' => $tours->filter(fn (Tour $t) => $t->listing->status === 'active' && $t->state === 'scheduled')->count(), 'tone' => 'green'],
                ['label' => 'Seats sold (upcoming)', 'value' => (int) $paidOpen->sum('seats'), 'tone' => 'blue'],
                ['label' => 'Unpaid reservations', 'value' => TourBooking::query()->where('status', 'reserved')->where('expires_at', '>', now())->whereHas('tour.listing', fn ($q) => $q->where('user_id', $me->id))->count(), 'tone' => 'gold'],
                ['label' => 'Available balance', 'value' => Money::tzs($this->balance($me->id)), 'tone' => 'green'],
            ],
            'upcoming' => $tours->filter(fn (Tour $t) => $t->state === 'scheduled')->sortBy('starts_at')->take(5),
            'stats' => $stats,
        ]);
    }

    /* ------------------------------------------------------------------ tours (S-29) */

    public function tours(Request $request): View
    {
        $tab = $request->query('tab', 'all');
        $tours = $this->myTours()->get()->filter(fn (Tour $t) => match ($tab) {
            'draft' => in_array($t->listing->status, ['draft', 'rejected'], true) && $t->state === 'scheduled',
            'review' => $t->listing->status === 'pending_review',
            'live' => $t->listing->status === 'active' && $t->state === 'scheduled',
            'past' => $t->state !== 'scheduled',
            default => true,
        });

        return view('trainer.tours', ['tours' => $tours->values(), 'tab' => $tab, 'verified' => auth()->user()->isIdentityVerified()]);
    }

    public function tourForm(?string $uuid = null): View
    {
        $tour = $uuid ? $this->myTour($uuid)->load('listing') : null;

        return view('trainer.tour-form', ['tour' => $tour, 'regions' => Region::query()->orderBy('name')->get(), 'verified' => auth()->user()->isIdentityVerified(), 'taken' => $tour?->seatsTaken() ?? 0]);
    }

    public function saveTour(Request $request, ?string $uuid = null): RedirectResponse
    {
        $me = auth()->user();
        $existing = $uuid ? $this->myTour($uuid)->load('listing') : null;
        abort_if($existing && $existing->state !== 'scheduled', 409, 'This tour is already finished.');

        $d = $request->validate([
            'title' => ['required', 'string', 'max:160'], 'description' => ['required', 'string', 'min:20', 'max:4000'], 'route' => ['required', 'string', 'max:255'],
            'starts_at' => ['required', 'date', $existing ? 'date' : 'after:now'], 'ends_at' => ['required', 'date', 'after:starts_at'],
            'price' => ['required', 'numeric', 'min:0', 'max:50000000'], 'seats' => ['required', 'integer', 'between:1,500'],
            'region_id' => ['nullable', 'exists:regions,id'], 'meeting_point' => ['required', 'string', 'max:255'], 'hold_minutes' => ['required', 'integer', 'between:10,1440'],
            'itinerary' => ['required', 'array', 'min:1', 'max:14'], 'itinerary.*.title' => ['required', 'string', 'max:120'], 'itinerary.*.details' => ['nullable', 'string', 'max:500'],
            'goals' => ['required', 'array', 'min:1', 'max:10'], 'goals.*' => ['required', 'string', 'max:160'],
            'photos' => ['nullable', 'array', 'max:4'], 'photos.*' => ['image', 'max:4096'], 'intent' => ['required', 'in:draft,submit'],
        ]);
        $priceMinor = (int) round($d['price'] * 100);
        $taken = $existing?->seatsTaken() ?? 0;
        if ($existing && $taken > 0 && $priceMinor !== (int) $existing->listing->price_minor) {
            return back()->withInput()->withErrors(['price' => 'The price cannot change once seats are booked.']);
        }
        if ($d['seats'] < $taken) {
            return back()->withInput()->withErrors(['seats' => "{$taken} seat(s) are already booked, so you cannot go lower."]);
        }
        if ($d['intent'] === 'submit' && ! $me->isIdentityVerified()) { // BR-01
            return back()->withInput()->withErrors(['intent' => 'Only identity-verified organisers can publish a tour. Save it as a draft until you are verified.']);
        }
        $itinerary = collect($d['itinerary'])->map(fn ($i) => ['title' => $i['title'], 'details' => $i['details'] ?? ''])->values()->all();
        $photos = $existing?->listing->photos ?? [];
        foreach ($request->file('photos', []) as $file) {
            $photos[] = $file->store('tours', 'public');
        }

        $tour = DB::transaction(function () use ($me, $d, $existing, $priceMinor, $itinerary, $photos): Tour {
            $status = $existing?->listing->status ?? 'draft';
            if ($d['intent'] === 'submit' && in_array($status, ['draft', 'rejected'], true)) {
                $status = 'pending_review'; // BR-07: reviewed before going live
            }
            $listing = $existing?->listing ?? new Listing(['user_id' => $me->id, 'type' => ListingType::Tour]);
            $listing->fill(['title' => $d['title'], 'price_minor' => $priceMinor, 'currency' => 'TZS', 'region_id' => $d['region_id'] ?? null, 'photos' => $photos, 'status' => $status])->save();
            $tour = $existing ?? new Tour(['listing_id' => $listing->id]);
            $tour->fill([
                'description' => $d['description'], 'route' => $d['route'], 'starts_at' => Carbon::parse($d['starts_at']), 'ends_at' => Carbon::parse($d['ends_at']),
                'seats' => $d['seats'], 'itinerary' => $itinerary, 'learning_goals' => array_values($d['goals']), 'meeting_point' => $d['meeting_point'], 'hold_minutes' => $d['hold_minutes'],
            ])->save();

            return $tour;
        });
        $tour->load('listing');

        return redirect()->route('trainer.tours.show', $tour->listing)->with('status', $tour->listing->status === 'pending_review' ? 'Tour submitted for review. Bookings open once it is approved.' : 'Tour saved.');
    }

    /* ------------------------------------------------------------------ one tour: attendees, bookings, messages (S-28) */

    public function showTour(string $uuid): View
    {
        $tour = $this->myTour($uuid)->load(['listing', 'bookings.attendee', 'reviews.attendee']);
        $bookings = $tour->bookings->sortByDesc('id')->values();
        $paying = $bookings->whereIn('status', ['paid', 'completed']);

        return view('trainer.tour', [
            'tour' => $tour, 'bookings' => $bookings, 'taken' => $tour->seatsTaken(), 'revenue' => (int) $paying->sum('total_minor'),
            'conversation' => Conversation::query()->where('tour_id', $tour->id)->first(), 'simulate' => (bool) config('neas.simulate_gateways'), 'feeBps' => $this->feeBps(),
            'avg' => round((float) $tour->reviews->avg('stars'), 1),
        ]);
    }

    public function submitTour(string $uuid): RedirectResponse
    {
        $tour = $this->myTour($uuid)->load('listing');
        abort_unless(in_array($tour->listing->status, ['draft', 'rejected'], true) && $tour->state === 'scheduled', 409);
        if (! auth()->user()->isIdentityVerified()) {
            return back()->with('error', 'Only identity-verified organisers can publish a tour.');
        }
        $tour->listing->update(['status' => 'pending_review']);

        return back()->with('status', 'Submitted for review.');
    }

    /** Pause or reopen ticket sales on a live tour. */
    public function toggleSales(string $uuid): RedirectResponse
    {
        $tour = $this->myTour($uuid)->load('listing');
        abort_unless(in_array($tour->listing->status, ['active', 'closed'], true) && $tour->state === 'scheduled', 409);
        $tour->listing->update(['status' => $tour->listing->status === 'active' ? 'closed' : 'active']);

        return back()->with('status', $tour->listing->status === 'active' ? 'Bookings reopened.' : 'Bookings paused.');
    }

    /** Cancelling refunds every paid seat from escrow and frees the reservations. */
    public function cancelTour(string $uuid, LedgerService $ledger): RedirectResponse
    {
        $tour = $this->myTour($uuid)->load(['listing', 'bookings']);
        abort_unless($tour->state === 'scheduled', 409);
        DB::transaction(function () use ($tour, $ledger): void {
            foreach ($tour->bookings->where('status', 'paid') as $b) {
                $this->refund($b, $ledger, 'Tour cancelled by organiser');
            }
            $tour->bookings()->where('status', 'reserved')->update(['status' => 'cancelled']);
            $tour->update(['state' => 'cancelled']);
            $tour->listing->update(['status' => 'closed']);
            AuditLog::record('tour.cancelled', $tour->listing, [], ['state' => 'cancelled']);
        });

        return redirect()->route('trainer.tours')->with('status', 'Tour cancelled and paid seats refunded.');
    }

    public function attendance(Request $request, string $uuid): RedirectResponse
    {
        $tour = $this->myTour($uuid);
        abort_unless($tour->state === 'scheduled', 409);
        $present = array_map('intval', (array) $request->input('attended', []));
        $tour->bookings()->where('status', 'paid')->get()->each(fn (TourBooking $b) => $b->update(['attended' => in_array($b->id, $present, true)]));

        return back()->with('status', 'Attendance saved.');
    }

    /** TUR-03: close the tour, issue certificates to attendees who were present, release the money to the organiser. */
    public function completeTour(string $uuid, LedgerService $ledger): RedirectResponse
    {
        $tour = $this->myTour($uuid)->load(['listing', 'bookings']);
        abort_unless($tour->state === 'scheduled' && in_array($tour->listing->status, ['active', 'closed'], true), 409);
        if ($tour->starts_at->isFuture() && ! config('neas.simulate_gateways')) {
            return back()->with('error', 'You can complete the tour once it has started.');
        }
        $paid = $tour->bookings->where('status', 'paid');
        DB::transaction(function () use ($tour, $paid, $ledger): void {
            $gross = (int) $paid->sum('total_minor');
            if ($gross > 0) {
                $fee = (new Money($gross))->percentBps($this->feeBps())->minor;
                $ledger->post([
                    ['account' => 'escrow', 'debit' => $gross],
                    ['account' => 'trainer:'.$tour->listing->user_id, 'credit' => $gross - $fee],
                    ['account' => 'platform_fee', 'credit' => $fee],
                ], null, null, 'Tour '.$tour->listing->uuid.' released');
            }
            foreach ($paid as $b) {
                $b->update(['status' => 'completed'] + ($b->attended ? ['certificate_no' => 'NEAS-'.strtoupper(Str::random(8)), 'certificate_issued_at' => now()] : []));
            }
            $tour->bookings()->where('status', 'reserved')->update(['status' => 'cancelled']);
            $tour->update(['state' => 'completed', 'completed_at' => now()]);
            $tour->listing->update(['status' => 'closed']);
        });

        return back()->with('status', 'Tour completed. Certificates issued and '.Money::tzs($paid->sum('total_minor') - (new Money((int) $paid->sum('total_minor')))->percentBps($this->feeBps())->minor).' added to your balance.');
    }

    /** Release a single unpaid reservation early, or refund one paid seat before the tour is completed. */
    public function bookingAction(Request $request, string $uuid, LedgerService $ledger): RedirectResponse
    {
        $booking = $this->myBooking($uuid);
        $action = $request->validate(['action' => ['required', 'in:release,refund']])['action'];
        if ($action === 'release' && $booking->status === 'reserved') {
            $booking->update(['status' => 'cancelled']);
        } elseif ($action === 'refund' && $booking->status === 'paid' && $booking->tour->state === 'scheduled') {
            DB::transaction(fn () => $this->refund($booking, $ledger, 'Refunded by organiser'));
        } else {
            abort(409);
        }

        return back()->with('status', $action === 'release' ? 'Seat released.' : 'Seat refunded to the attendee.');
    }

    /** All bookings across my tours. */
    public function bookings(Request $request): View
    {
        $status = $request->query('status');
        $bookings = TourBooking::query()->with(['tour.listing', 'attendee'])->whereHas('tour.listing', fn ($q) => $q->where('user_id', auth()->id()))
            ->when($status, fn ($q, $s) => $q->where('status', $s))->latest()->get();

        return view('trainer.bookings', ['bookings' => $bookings, 'status' => $status]);
    }

    /* ------------------------------------------------------------------ group message & certificates */

    public function groupMessage(Request $request, string $uuid): RedirectResponse
    {
        $tour = $this->myTour($uuid)->load(['listing', 'bookings']);
        $d = $request->validate(['body' => ['required', 'string', 'max:2000']]);
        $attendees = $tour->bookings->whereIn('status', ['reserved', 'paid', 'completed'])->pluck('user_id')->unique();
        if ($attendees->isEmpty()) {
            return back()->with('error', 'No attendees to message yet.');
        }
        $conversation = Conversation::query()->where('tour_id', $tour->id)->first() ?? Conversation::create(['tour_id' => $tour->id]);
        $conversation->participants()->syncWithoutDetaching($attendees->push(auth()->id())->unique()->all());
        Message::create(['conversation_id' => $conversation->id, 'sender_id' => auth()->id(), 'kind' => 'text', 'body' => $d['body']]);
        $conversation->touch();

        return back()->with('status', 'Message sent to '.($attendees->count()).' attendee(s).');
    }

    public function certificates(string $uuid): View
    {
        $tour = $this->myTour($uuid)->load(['listing.owner', 'bookings.attendee']);
        abort_unless($tour->state === 'completed', 404);

        return view('trainer.certificates', ['tour' => $tour, 'bookings' => $tour->bookings->whereNotNull('certificate_no')->values()]);
    }

    /** Public check that a certificate is genuine. */
    public function verifyCertificate(string $number): View
    {
        $booking = TourBooking::query()->with(['tour.listing.owner', 'attendee'])->where('certificate_no', $number)->first();

        return view('certificates.verify', ['booking' => $booking, 'number' => $number]);
    }

    /* ------------------------------------------------------------------ demo stand-in for the attendee app */

    public function simulate(Request $request, string $uuid, LedgerService $ledger): RedirectResponse
    {
        abort_unless(config('neas.simulate_gateways'), 404);
        $tour = $this->myTour($uuid)->load('listing');
        $d = $request->validate(['action' => ['required', 'in:book,pay,review,approve'], 'booking' => ['nullable', 'string'], 'seats' => ['nullable', 'integer', 'between:1,10']]);

        if ($d['action'] === 'approve') {
            abort_unless($tour->listing->status === 'pending_review', 409);
            $tour->listing->update(['status' => 'active']);

            return back()->with('status', 'Simulated: admin approved the listing. Bookings are open.');
        }
        if ($d['action'] === 'book') {
            abort_unless($tour->listing->status === 'active' && $tour->state === 'scheduled', 409);
            $seats = (int) ($d['seats'] ?? 1);
            $attendee = User::query()->where('id', '!=', auth()->id())->whereHas('roleAssignments', fn ($q) => $q->whereIn('role', [UserRole::Buyer->value, UserRole::Producer->value]))
                ->whereDoesntHave('tourBookings', fn ($q) => $q->where('tour_id', $tour->id)->whereIn('status', ['reserved', 'paid', 'completed']))->inRandomOrder()->first();
            abort_if($attendee === null, 422, 'No other Buyer or Producer account is available to simulate a booking.');
            $made = DB::transaction(function () use ($tour, $seats, $attendee): bool {
                Tour::query()->whereKey($tour->id)->lockForUpdate()->first(); // no overselling
                if ($tour->seatsLeft() < $seats) {
                    return false;
                }
                TourBooking::create(['tour_id' => $tour->id, 'user_id' => $attendee->id, 'seats' => $seats, 'total_minor' => $seats * $tour->listing->price_minor, 'expires_at' => now()->addMinutes($tour->hold_minutes)]);

                return true;
            });

            return $made ? back()->with('status', "Simulated: {$attendee->name} reserved {$seats} seat(s) and has {$tour->hold_minutes} minutes to pay.") : back()->with('error', 'Not enough seats left.');
        }
        $booking = $this->myBooking((string) $d['booking']);
        if ($d['action'] === 'pay' && $booking->status === 'reserved' && $booking->expires_at?->isFuture()) {
            DB::transaction(function () use ($booking, $ledger): void {
                $ledger->post([['account' => 'attendee:'.$booking->user_id, 'debit' => $booking->total_minor], ['account' => 'escrow', 'credit' => $booking->total_minor]], null, null, 'Tour seat '.$booking->uuid.' paid');
                $booking->update(['status' => 'paid', 'paid_at' => now()]);
            });
        }
        if ($d['action'] === 'review' && $booking->status === 'completed' && ! TourReview::query()->where('tour_booking_id', $booking->id)->exists()) {
            TourReview::create(['tour_id' => $booking->tour_id, 'tour_booking_id' => $booking->id, 'attendee_id' => $booking->user_id, 'organiser_id' => auth()->id(), 'stars' => random_int(4, 5), 'comment' => 'Learned a lot and well organised.']);
        }

        return back()->with('status', 'Simulated: '.$d['action']);
    }

    /* ------------------------------------------------------------------ S-45 earnings */

    public function earnings(): View
    {
        $me = auth()->user();
        $account = 'trainer:'.$me->id;
        $heldGross = (int) TourBooking::query()->where('status', 'paid')->whereHas('tour.listing', fn ($q) => $q->where('user_id', $me->id))->sum('total_minor');

        return view('trainer.earnings', [
            'balance' => $this->balance($me->id), 'earned' => (int) LedgerEntry::query()->where('account', $account)->where('memo', 'like', 'Tour%')->sum('credit_minor'),
            'pending' => $heldGross - (new Money($heldGross))->percentBps($this->feeBps())->minor,
            'entries' => LedgerEntry::query()->where('account', $account)->latest('id')->limit(50)->get(),
            'payouts' => Payout::query()->where('user_id', $me->id)->latest()->limit(10)->get(), 'phone' => $me->phone, 'verified' => $me->isIdentityVerified(),
        ]);
    }

    public function payout(Request $request, LedgerService $ledger): RedirectResponse
    {
        $me = auth()->user();
        if (! $me->isIdentityVerified()) { // BR-01
            return back()->with('error', 'Payouts are available once your identity is verified.');
        }
        $d = $request->validate(['amount' => ['required', 'numeric', 'min:1000'], 'provider' => ['required', 'in:mpesa,tigopesa,airtelmoney,halopesa,bank'], 'destination' => ['required', 'string', 'max:40']]);
        $amount = (int) round($d['amount'] * 100);

        $error = DB::transaction(function () use ($me, $amount, $d, $ledger): ?string {
            User::query()->whereKey($me->id)->lockForUpdate()->first();
            if ($amount > $this->balance($me->id)) {
                return 'That is more than your available balance.';
            }
            $payout = Payout::create(['user_id' => $me->id, 'amount_minor' => $amount, 'provider' => $d['provider'], 'destination' => $d['destination']]);
            $ledger->post([['account' => 'trainer:'.$me->id, 'debit' => $amount], ['account' => 'payout_pending', 'credit' => $amount]], null, null, 'Payout '.$payout->uuid.' requested');
            if (config('neas.simulate_gateways')) {
                $ledger->post([['account' => 'payout_pending', 'debit' => $amount], ['account' => 'payouts', 'credit' => $amount]], null, null, 'Payout '.$payout->uuid.' paid');
                $payout->update(['state' => 'paid']);
            }

            return null;
        });

        return $error ? back()->withInput()->with('error', $error) : back()->with('status', config('neas.simulate_gateways') ? 'Payout sent to your account.' : 'Payout requested. It is sent after the provider confirms.');
    }

    /* ------------------------------------------------------------------ profile (TUR-04) */

    public function profile(): View
    {
        $me = auth()->user();

        return view('trainer.profile', [
            'me' => $me, 'data' => $this->profileData($me), 'stats' => $this->stats($me),
            'reviews' => TourReview::query()->with(['attendee', 'tour.listing'])->where('organiser_id', $me->id)->latest()->limit(20)->get(),
        ]);
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        $d = $request->validate(['organisation' => ['nullable', 'string', 'max:120'], 'bio' => ['nullable', 'string', 'max:800'], 'website' => ['nullable', 'url', 'max:160']]);
        $profile = RoleProfile::query()->firstOrNew(['user_id' => auth()->id(), 'role' => UserRole::Trainer->value]);
        $profile->business = array_merge(is_array($profile->business) ? $profile->business : [], array_filter($d, fn ($v) => $v !== null));
        $profile->save();

        return back()->with('status', 'Profile saved.');
    }

    /* ------------------------------------------------------------------ helpers */

    private function myTours()
    {
        return Tour::query()->with('listing')->whereHas('listing', fn ($q) => $q->where('user_id', auth()->id())->where('type', ListingType::Tour->value));
    }

    private function myTour(string $listingUuid): Tour
    {
        return Tour::query()->whereHas('listing', fn ($q) => $q->where('user_id', auth()->id())->where('type', ListingType::Tour->value)->where('uuid', $listingUuid))->firstOrFail();
    }

    private function myBooking(string $uuid): TourBooking
    {
        return TourBooking::query()->with('tour.listing')->where('uuid', $uuid)->whereHas('tour.listing', fn ($q) => $q->where('user_id', auth()->id()))->firstOrFail();
    }

    private function refund(TourBooking $b, LedgerService $ledger, string $memo): void
    {
        $ledger->post([['account' => 'escrow', 'debit' => $b->total_minor], ['account' => 'attendee:'.$b->user_id, 'credit' => $b->total_minor]], null, null, $memo.' '.$b->uuid);
        $b->update(['status' => 'refunded']);
    }

    /** @return array<string, mixed> */
    private function profileData(User $u): array
    {
        $b = RoleProfile::query()->where('user_id', $u->id)->where('role', UserRole::Trainer->value)->value('business');
        $b = is_string($b) ? json_decode($b, true) : $b;

        return is_array($b) ? $b : [];
    }

    /** @return array{tours:int, attendees:int, reviews:int, avg:float} */
    private function stats(User $u): array
    {
        $reviews = TourReview::query()->where('organiser_id', $u->id);
        $mine = fn ($q) => $q->whereHas('tour.listing', fn ($l) => $l->where('user_id', $u->id));

        return [
            'tours' => Tour::query()->where('state', 'completed')->whereHas('listing', fn ($q) => $q->where('user_id', $u->id))->count(),
            'attendees' => (int) $mine(TourBooking::query()->where('status', 'completed'))->sum('seats'),
            'reviews' => $reviews->count(), 'avg' => round((float) $reviews->avg('stars'), 1),
        ];
    }

    private function balance(int $userId): int
    {
        $row = LedgerEntry::query()->where('account', 'trainer:'.$userId)->selectRaw('COALESCE(SUM(credit_minor),0) c, COALESCE(SUM(debit_minor),0) d')->first();

        return (int) $row->c - (int) $row->d;
    }

    private function feeBps(): int
    {
        return (int) (FeeRule::query()->where('key', 'platform_fee')->where('active', true)->value('bps') ?? 250);
    }
}
