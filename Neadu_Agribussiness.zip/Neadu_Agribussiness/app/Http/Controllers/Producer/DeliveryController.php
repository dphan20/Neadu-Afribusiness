<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Http\Controllers\Controller;
use App\Models\Delivery;
use App\Models\Order;
use App\Services\DeliveryPlanner;
use App\Support\Money;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** LOG-02/04: book a transporter with a suggested price, then follow the trip live. */
class DeliveryController extends Controller
{
    public function create(Request $request, Order $order, DeliveryPlanner $planner): View
    {
        $this->ownOrder($request, $order);
        $order->load('listing.produce.unit');
        $kg = $planner->orderWeightKg($order);

        return view('producer.delivery.create', [
            'order' => $order, 'kg' => $kg, 'transporters' => $planner->suggestTransporters($kg),
        ]);
    }

    /** JSON: suggested price for the coordinates typed so far (used by the booking form). */
    public function quote(Request $request, Order $order, DeliveryPlanner $planner): JsonResponse
    {
        $this->ownOrder($request, $order);
        $d = $request->validate([
            'drop_lat' => ['required', 'numeric', 'between:-12,0'], 'drop_lng' => ['required', 'numeric', 'between:29,41'],
            'pickup_lat' => ['nullable', 'numeric', 'between:-12,0'], 'pickup_lng' => ['nullable', 'numeric', 'between:29,41'],
        ]);
        $order->load('listing.produce.unit');
        $pLat = $d['pickup_lat'] ?? $order->listing?->lat;
        $pLng = $d['pickup_lng'] ?? $order->listing?->lng;
        if ($pLat === null || $pLng === null) {
            return response()->json(['message' => 'Add a pickup location.'], 422);
        }
        $km = $planner->distanceKm((float) $pLat, (float) $pLng, (float) $d['drop_lat'], (float) $d['drop_lng']);
        $minor = $planner->suggestPrice($km, $planner->orderWeightKg($order));

        return response()->json(['distance_km' => $km, 'price_minor' => $minor, 'price' => (new Money($minor))->format()]);
    }

    public function store(Request $request, Order $order, DeliveryPlanner $planner): RedirectResponse
    {
        $this->ownOrder($request, $order);
        $d = $request->validate([
            'drop_lat' => ['required', 'numeric', 'between:-12,0'], 'drop_lng' => ['required', 'numeric', 'between:29,41'],
            'pickup_lat' => ['nullable', 'numeric', 'between:-12,0'], 'pickup_lng' => ['nullable', 'numeric', 'between:29,41'],
            'transporter_id' => ['nullable', 'integer', 'exists:users,id'],
            'price' => ['nullable', 'regex:/^\d{1,12}(\.\d{1,2})?$/'],
        ]);

        try {
            $delivery = $planner->book($order, $request->user(), [
                'pickup_lat' => $d['pickup_lat'] ?? null, 'pickup_lng' => $d['pickup_lng'] ?? null,
                'drop_lat' => (float) $d['drop_lat'], 'drop_lng' => (float) $d['drop_lng'],
                'transporter_id' => $d['transporter_id'] ?? null,
                'price_minor' => isset($d['price']) ? Money::fromMajor($d['price'])->minor : null,
            ]);
        } catch (DomainException $e) {
            return back()->withErrors(['delivery' => $e->getMessage()])->withInput();
        }

        return redirect()->route('me.delivery.show', $delivery)->with('status', 'Delivery booked.');
    }

    public function show(Request $request, Delivery $delivery): View
    {
        $this->ownDelivery($request, $delivery);
        $delivery->load(['order.listing', 'transporter']);

        return view('producer.delivery.show', compact('delivery'));
    }

    /** LOG-04: latest points for the live map (the page polls this). */
    public function track(Request $request, Delivery $delivery): JsonResponse
    {
        $this->ownDelivery($request, $delivery);
        $points = $delivery->trackingPoints()->orderByDesc('recorded_at')->limit(50)->get()->reverse()->values();

        return response()->json([
            'status' => $delivery->status,
            'pickup' => [(float) $delivery->pickup_lat, (float) $delivery->pickup_lng],
            'drop' => [(float) $delivery->drop_lat, (float) $delivery->drop_lng],
            'points' => $points->map(fn ($p) => ['lat' => (float) $p->lat, 'lng' => (float) $p->lng, 'at' => $p->recorded_at->toIso8601String()]),
            'latest' => $points->last() ? ['lat' => (float) $points->last()->lat, 'lng' => (float) $points->last()->lng] : null,
        ]);
    }

    private function ownOrder(Request $request, Order $order): void
    {
        abort_unless(in_array($request->user()->id, [$order->seller_id, $order->buyer_id], true), 404);
    }

    private function ownDelivery(Request $request, Delivery $delivery): void
    {
        $uid = $request->user()->id;
        abort_unless($delivery->transporter_id === $uid || $delivery->order()->where(fn ($q) => $q->where('seller_id', $uid)->orWhere('buyer_id', $uid))->exists(), 404);
    }
}
