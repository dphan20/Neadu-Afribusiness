<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Enums\EscrowState;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Rating;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

/** MKT-09 / BR-06: rate the buyer once, after the order is released. */
class RatingController extends Controller
{
    public function store(Request $request, Order $order): RedirectResponse
    {
        abort_unless($order->seller_id === $request->user()->id, 404);
        $data = $request->validate(['stars' => ['required', 'integer', 'between:1,5'], 'comment' => ['nullable', 'string', 'max:500']]);

        if ($order->status !== EscrowState::Released) {
            return back()->withErrors(['rating' => 'You can rate the buyer after the payout is released.']);
        }
        if (Rating::query()->where('order_id', $order->id)->where('rater_id', $request->user()->id)->exists()) {
            return back()->withErrors(['rating' => 'You have already rated this buyer.']);
        }

        Rating::query()->create([
            'order_id' => $order->id, 'rater_id' => $request->user()->id, 'ratee_id' => $order->buyer_id,
            'stars' => $data['stars'], 'comment' => $data['comment'] ?? null,
        ]);

        return back()->with('status', 'Thank you. Your rating was saved.');
    }
}
