<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\Order;
use App\Models\User;
use App\Services\MessagingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** COM-01: text, photo and voice-note chat for every role: direct messages to anyone, plus listing and order chats. */
class ChatController extends Controller
{
    public function __construct(private readonly MessagingService $messaging) {}

    public function index(Request $request): View
    {
        $user = $request->user();
        $conversations = Conversation::query()->with(['participants.roleAssignments', 'order.listing', 'listing', 'lastMessage'])
            ->withMax('messages', 'created_at')->visibleTo($user)
            ->orderByDesc('messages_max_created_at')->get();

        return view('producer.chat.index', ['conversations' => $conversations, 'unread' => $this->messaging->unreadCounts($user), 'messaging' => $this->messaging]);
    }

    /** Find anyone (producer, buyer, transporter, expert, trainer, land or warehouse owner, trader, NeAS support) and write to them. */
    public function compose(Request $request): View
    {
        $q = (string) $request->query('q', '');
        $role = (string) $request->query('role', '');

        return view('producer.chat.new', [
            'q' => $q, 'role' => $role, 'people' => $this->messaging->directory($request->user(), $q, $role), 'messaging' => $this->messaging,
        ]);
    }

    public function start(Request $request): RedirectResponse
    {
        $d = $request->validate(['user' => ['required', 'uuid'], 'body' => ['required', 'string', 'max:2000']]);
        $to = User::query()->where('uuid', $d['user'])->firstOrFail();
        if (! $this->messaging->canMessage($request->user(), $to)) {
            return back()->withErrors(['body' => 'You cannot message this person.'])->withInput();
        }

        $conversation = $this->messaging->direct($request->user(), $to);
        $this->messaging->send($conversation, $request->user(), $d['body']);

        return redirect()->route('me.chat.show', $conversation)->withFragment('latest');
    }

    public function show(Request $request, Conversation $conversation): View
    {
        $this->member($request, $conversation);
        $conversation->load(['participants.roleAssignments', 'order.listing', 'listing']);
        $messages = $conversation->messagesFor($request->user());
        $conversation->markReadBy($request->user());

        return view('producer.chat.show', ['conversation' => $conversation, 'messages' => $messages, 'messaging' => $this->messaging]);
    }

    public function send(Request $request, Conversation $conversation): RedirectResponse
    {
        $this->member($request, $conversation);
        $d = $request->validate([
            'body' => ['nullable', 'string', 'max:2000'],
            'voice' => ['nullable', 'file', 'mimetypes:audio/webm,video/webm,audio/ogg,audio/mpeg,audio/mp4,audio/x-m4a,audio/wav,audio/x-wav', 'max:5120'],
            'photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
        ]);
        if (empty($d['body']) && ! $request->hasFile('voice') && ! $request->hasFile('photo')) {
            return back()->withErrors(['body' => 'Write a message or attach a voice note or photo.']);
        }

        $this->messaging->send($conversation, $request->user(), $d['body'] ?? null, $request->file('voice'), $request->file('photo'));

        return redirect()->route('me.chat.show', $conversation)->withFragment('latest');
    }

    /** Voice notes and photos are private: only the conversation's participants can fetch them. */
    public function file(Request $request, Message $message): StreamedResponse
    {
        $this->member($request, $message->conversation);
        abort_if($message->file_path === null, 404);
        $disk = Storage::disk('local')->exists($message->file_path) ? 'local' : 'public'; // older buyer / expert photos were stored publicly
        abort_unless(Storage::disk($disk)->exists($message->file_path), 404);

        return Storage::disk($disk)->response($message->file_path);
    }

    /** In-order chat between the producer and the buyer (created on first open). */
    public function forOrder(Request $request, Order $order): RedirectResponse
    {
        abort_unless(in_array($request->user()->id, [$order->seller_id, $order->buyer_id], true), 404);

        $conversation = Conversation::query()->where('order_id', $order->id)->first();
        if ($conversation === null) {
            $conversation = Conversation::query()->create(['order_id' => $order->id, 'listing_id' => $order->listing_id]);
            $conversation->participants()->attach([$order->seller_id, $order->buyer_id]);
        }

        return redirect()->route('me.chat.show', $conversation);
    }

    /** Chat about a listing, before any order exists. */
    public function forListing(Request $request, \App\Models\Listing $listing): RedirectResponse
    {
        abort_if($listing->user_id === $request->user()->id, 404);
        $conversation = Conversation::query()->whereNull('order_id')->where('listing_id', $listing->id)
            ->whereHas('participants', fn ($q) => $q->whereKey($request->user()->id))->first();
        if ($conversation === null) {
            $conversation = Conversation::query()->create(['listing_id' => $listing->id]);
            $conversation->participants()->attach([$request->user()->id, $listing->user_id]);
        }

        return redirect()->route('me.chat.show', $conversation);
    }

    private function member(Request $request, Conversation $conversation): void
    {
        abort_unless($conversation->hasParticipant($request->user()), 404);
    }
}
