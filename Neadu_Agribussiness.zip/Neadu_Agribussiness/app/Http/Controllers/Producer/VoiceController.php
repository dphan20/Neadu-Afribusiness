<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Http\Controllers\Controller;
use App\Services\VoiceAssistant;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** VOI-01..04 (R2): Kiswahili voice assistant. Speech-to-text happens in the browser; this takes the text. */
class VoiceController extends Controller
{
    public function index(): View
    {
        return view('producer.voice.index');
    }

    public function command(Request $request, VoiceAssistant $assistant): JsonResponse
    {
        $d = $request->validate(['text' => ['required', 'string', 'max:300']]);

        return response()->json($assistant->handle($request->user(), $d['text']));
    }
}
