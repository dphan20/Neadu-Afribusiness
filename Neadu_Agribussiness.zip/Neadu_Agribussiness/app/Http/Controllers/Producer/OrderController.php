<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\OrderWorkflow;
use App\Services\PayoutService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use InvalidArgumentException;

/** MKT-04/05/07: receive orders, answer within 24h, ship, and see the payout receipt. */
class OrderController extends Controller
{
    public function index(Request $request): View
    {
        $filter = $request->query('filter', 'all');
        $orders = Order::query()->with(['listing', 'buyer'])->where('seller_id', $request->user()->id)
            ->when($filter === 'awaiting', fn ($q) => $q->whereIn('status', ['pending', 'held'])->whereNull('accepted_at')->whereNull('rejected_at'))
            ->when($filter === 'open', fn ($q) => $q->whereIn('status', ['held', 'in_transit', 'delivered', 'disputed'])->whereNotNull('accepted_at'))
            ->when($filter === 'done', fn ($q) => $q->whereIn('status', ['released', 'refunded']))
            ->latest()->get();

        return view('producer.orders.index', compact('orders', 'filter'));
    }

    public function show(Request $request, Order $order, PayoutService $payouts): View
    {
        $this->own($request, $order);
        $order->load(['listing.produce.crop', 'listing.produce.unit', 'buyer', 'deliveries.transporter', 'dispute', 'ratings']);

        return view('producer.orders.show', [
            'order' => $order, 'fee' => $payouts->feeFor((int) $order->subtotal_minor),
            'rated' => $order->ratings->contains('rater_id', $request->user()->id),
            'activeDelivery' => $order->deliveries->firstWhere(fn ($d) => $d->status !== 'cancelled'),
        ]);
    }

    public function accept(Request $request, Order $order, OrderWorkflow $workflow): RedirectResponse
    {
        $this->own($request, $order);

        return $this->attempt(fn () => $workflow->accept($order, $request->user()), 'Order accepted. The buyer has been notified.');
    }

    public function reject(Request $request, Order $order, OrderWorkflow $workflow): RedirectResponse
    {
        $this->own($request, $order);
        $data = $request->validate(['reason' => ['required', 'string', 'max:250']]);

        return $this->attempt(fn () => $workflow->reject($order, $request->user(), $data['reason']), 'Order rejected. Any payment is refunded.');
    }

    public function counter(Request $request, Order $order, OrderWorkflow $workflow): RedirectResponse
    {
        $this->own($request, $order);
        $data = $request->validate(['price' => ['required', 'regex:/^\d{1,12}(\.\d{1,2})?$/']]);

        return $this->attempt(fn () => $workflow->counter($order, $request->user(), Money::fromMajor($data['price'])->minor), 'Counter-offer sent to the buyer.');
    }

    public function ship(Request $request, Order $order, OrderWorkflow $workflow): RedirectResponse
    {
        $this->own($request, $order);

        return $this->attempt(fn () => $workflow->ship($order, $request->user()), 'Marked as shipped.');
    }

    public function receipt(Request $request, Order $order, PayoutService $payouts): View
    {
        $this->own($request, $order);

        return view('producer.orders.receipt', ['r' => $payouts->receipt($order)]);
    }

    private function own(Request $request, Order $order): void
    {
        abort_unless($order->seller_id === $request->user()->id, 404);
    }

    private function attempt(callable $fn, string $ok): RedirectResponse
    {
        try {
            $fn();
        } catch (DomainException|InvalidArgumentException $e) {
            return back()->withErrors(['order' => $e->getMessage()])->withInput();
        }

        return back()->with('status', $ok);
    }
}
