<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Enums\EscrowState;
use App\Http\Controllers\Controller;
use App\Models\DiagnosisCase;
use App\Models\Listing;
use App\Models\Order;
use App\Models\PriceAlert;
use App\Services\ProducerQueries;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Producer home: onboarding checklist (ACC-01..04) and today's work at a glance. */
class HomeController extends Controller
{
    public function index(Request $request, ProducerQueries $queries): View
    {
        $user = $request->user();
        $profile = $user->producerProfile;

        $checklist = [
            ['label' => 'Phone verified (OTP)', 'done' => $user->phone_verified_at !== null, 'href' => route('producer.phone')],
            ['label' => 'Identity verified (NIDA)', 'done' => $user->isIdentityVerified(), 'href' => route('producer.identity')],
            ['label' => 'Producer profile (location and produce)', 'done' => $profile !== null && $profile->region_id !== null, 'href' => route('producer.profile')],
        ];

        $stats = [
            ['label' => 'Orders to answer', 'value' => $queries->awaitingOrders($user)->count(), 'href' => route('producer.orders.index', ['filter' => 'awaiting'])],
            ['label' => 'Active listings', 'value' => Listing::query()->where('user_id', $user->id)->where('type', 'produce')->where('status', 'active')->count(), 'href' => route('producer.listings.index')],
            ['label' => 'In transit', 'value' => Order::query()->where('seller_id', $user->id)->where('status', EscrowState::InTransit->value)->count(), 'href' => route('producer.orders.index')],
            ['label' => 'Open diagnoses', 'value' => DiagnosisCase::query()->where('user_id', $user->id)->whereNull('expert_reply')->whereNotNull('escalated_at')->count(), 'href' => route('producer.diagnosis.index')],
            ['label' => 'Price alerts', 'value' => PriceAlert::query()->where('user_id', $user->id)->where('active', true)->count(), 'href' => route('me.alerts.index')],
        ];

        return view('producer.home', compact('checklist', 'stats'));
    }
}
