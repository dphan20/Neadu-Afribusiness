<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Http\Controllers\Controller;
use App\Models\DiagnosisCase;
use App\Services\DiagnosisService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** DIA-01..04: take a photo, get a Kiswahili diagnosis, chat with or escalate to an expert. */
class DiagnosisController extends Controller
{
    public function index(Request $request): View
    {
        return view('producer.diagnosis.index', ['cases' => DiagnosisCase::query()->where('user_id', $request->user()->id)->latest()->get()]);
    }

    public function create(): View
    {
        return view('producer.diagnosis.create');
    }

    public function store(Request $request, DiagnosisService $service): RedirectResponse
    {
        $d = $request->validate([
            'kind' => ['required', 'in:crop,livestock,fish'], 'subject' => ['required', 'string', 'max:120'],
            'photo' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:8192'],
        ]);
        try {
            $case = $service->diagnose($request->user(), $request->file('photo'), $d['subject'], $d['kind']);
        } catch (DomainException $e) {
            return back()->withInput()->withErrors(['photo' => $e->getMessage()]);
        }

        return redirect()->route('producer.diagnosis.show', $case);
    }

    public function show(Request $request, DiagnosisCase $case): View
    {
        $this->own($request, $case);
        $case->load('expert', 'conversation');

        return view('producer.diagnosis.show', compact('case'));
    }

    public function photo(Request $request, DiagnosisCase $case): StreamedResponse
    {
        abort_unless($case->user_id === $request->user()->id || $case->expert_id === $request->user()->id, 404);
        abort_unless(Storage::disk('local')->exists($case->photo_path), 404);

        return Storage::disk('local')->response($case->photo_path);
    }

    public function chat(Request $request, DiagnosisCase $case, DiagnosisService $service): RedirectResponse
    {
        $this->own($request, $case);

        try {
            $conversation = $service->openExpertChat($case);
        } catch (DomainException $e) {
            return back()->withErrors(['diagnosis' => $e->getMessage()]);
        }

        return redirect()->route('me.chat.show', $conversation);
    }

    public function escalate(Request $request, DiagnosisCase $case, DiagnosisService $service): RedirectResponse
    {
        $this->own($request, $case);

        try {
            $service->escalate($case);
        } catch (DomainException $e) {
            return back()->withErrors(['diagnosis' => $e->getMessage()]);
        }

        return back()->with('status', 'Sent to an expert. You will get a reply here.');
    }

    /** The producer rates the expert's help once the expert has replied. */
    public function rate(Request $request, DiagnosisCase $case): RedirectResponse
    {
        $this->own($request, $case);
        $d = $request->validate(['stars' => ['required', 'integer', 'between:1,5']]);
        if ($case->expert_reply === null || $case->expert_rating !== null) {
            return back()->withErrors(['diagnosis' => 'You can rate once, after the expert has replied.']);
        }
        $case->forceFill(['expert_rating' => $d['stars']])->save();

        return back()->with('status', 'Thank you for rating the expert.');
    }

    private function own(Request $request, DiagnosisCase $case): void
    {
        abort_unless($case->user_id === $request->user()->id, 404);
    }
}
