<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Http\Controllers\Controller;
use App\Models\District;
use App\Models\Listing;
use App\Models\Region;
use App\Models\StorageBooking;
use App\Services\StorageBookingService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** STO-02/03: search warehouses, request space, pay by escrow or invoice. */
class StorageController extends Controller
{
    public function index(Request $request, StorageBookingService $service): View
    {
        $filters = $request->validate([
            'region_id' => ['nullable', 'integer'], 'district_id' => ['nullable', 'integer'],
            'min_kg' => ['nullable', 'numeric', 'min:0'], 'q' => ['nullable', 'string', 'max:80'],
        ]);

        return view('producer.storage.index', [
            'facilities' => $service->search($filters)->paginate(12)->withQueryString(), 'filters' => $filters,
            'regions' => Region::query()->orderBy('name')->get(), 'districts' => District::query()->orderBy('name')->get(),
        ]);
    }

    public function show(Listing $listing): View
    {
        abort_unless($listing->type->value === 'storage' && $listing->status === 'active', 404);
        $listing->load(['storage', 'owner']);

        return view('producer.storage.show', compact('listing'));
    }

    public function store(Request $request, Listing $listing, StorageBookingService $service): RedirectResponse
    {
        abort_unless($listing->type->value === 'storage', 404);
        $d = $request->validate([
            'quantity_kg' => ['required', 'numeric', 'gt:0', 'max:99999999'],
            'starts_on' => ['required', 'date', 'after_or_equal:today'],
            'ends_on' => ['required', 'date', 'after_or_equal:starts_on'],
            'payment_method' => ['required', 'in:escrow,invoice'],
        ]);

        try {
            $service->request($request->user(), $listing, (float) $d['quantity_kg'], $d['starts_on'], $d['ends_on'], $d['payment_method']);
        } catch (DomainException $e) {
            return back()->withErrors(['storage' => $e->getMessage()])->withInput();
        }

        return redirect()->route('producer.storage.mine')->with('status', 'Storage requested. The warehouse owner will respond.');
    }

    public function mine(Request $request): View
    {
        $bookings = StorageBooking::query()->with('facilityListing')->where('user_id', $request->user()->id)->latest()->get();

        return view('producer.storage.mine', compact('bookings'));
    }

    public function cancel(Request $request, StorageBooking $booking, StorageBookingService $service): RedirectResponse
    {
        try {
            $service->cancel($booking, $request->user());
        } catch (DomainException $e) {
            return back()->withErrors(['storage' => $e->getMessage()]);
        }

        return back()->with('status', 'Request cancelled.');
    }
}
