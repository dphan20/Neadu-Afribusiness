<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Enums\ProduceCategory;
use App\Http\Controllers\Controller;
use App\Http\Requests\Producer\ListingRequest;
use App\Models\Crop;
use App\Models\District;
use App\Models\Listing;
use App\Models\Region;
use App\Models\Unit;
use App\Services\ListingService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** MKT-01/02/10: a producer's own produce listings. */
class ListingController extends Controller
{
    public function index(Request $request): View
    {
        $listings = Listing::query()->with('produce.crop', 'produce.unit')->where('user_id', $request->user()->id)
            ->where('type', 'produce')->latest()->get();

        return view('producer.listings.index', compact('listings'));
    }

    public function create(Request $request): View
    {
        $profile = $request->user()->producerProfile;

        return view('producer.listings.form', $this->formData(null) + [
            'defaults' => [
                'region_id' => $profile?->region_id, 'district_id' => $profile?->district_id,
                'category' => ($profile?->business['producer_type'] ?? null) === null ? 'crop'
                    : \App\Enums\ProducerType::from($profile->business['producer_type'])->defaultCategory()->value,
            ],
        ]);
    }

    public function store(ListingRequest $request, ListingService $service): RedirectResponse
    {
        $listing = $service->create($request->user(), $request->validated(), $request->file('photos', []), $request->file('video'));

        return redirect()->route('producer.listings.index')->with('status', $listing->status === 'draft'
            ? 'Draft saved.' : 'Listing submitted for review. It goes live once approved.');
    }

    public function edit(Request $request, Listing $listing): View
    {
        $this->own($request, $listing);
        $listing->load('produce');

        return view('producer.listings.form', $this->formData($listing) + ['defaults' => []]);
    }

    public function update(ListingRequest $request, Listing $listing, ListingService $service): RedirectResponse
    {
        $this->own($request, $listing);

        return $this->attempt(fn () => $service->update($listing, $request->validated(), $request->file('photos', []), $request->file('video')), 'Listing updated.', route('producer.listings.index'));
    }

    public function submit(Request $request, Listing $listing, ListingService $service): RedirectResponse
    {
        $this->own($request, $listing);

        return $this->attempt(fn () => $service->submit($listing), 'Submitted for review.');
    }

    public function pause(Request $request, Listing $listing, ListingService $service): RedirectResponse
    {
        $this->own($request, $listing);

        return $this->attempt(fn () => $service->pause($listing), 'Listing paused. Buyers no longer see it.');
    }

    public function resume(Request $request, Listing $listing, ListingService $service): RedirectResponse
    {
        $this->own($request, $listing);

        return $this->attempt(fn () => $service->resume($listing), 'Listing is live again.');
    }

    public function close(Request $request, Listing $listing, ListingService $service): RedirectResponse
    {
        $this->own($request, $listing);

        return $this->attempt(fn () => $service->close($listing), 'Listing closed.');
    }

    private function own(Request $request, Listing $listing): void
    {
        abort_unless($listing->user_id === $request->user()->id && $listing->type->value === 'produce', 404);
    }

    private function attempt(callable $fn, string $ok, ?string $to = null): RedirectResponse
    {
        try {
            $fn();
        } catch (DomainException $e) {
            return back()->withErrors(['listing' => $e->getMessage()])->withInput();
        }

        return ($to ? redirect($to) : back())->with('status', $ok);
    }

    /** @return array<string, mixed> */
    private function formData(?Listing $listing): array
    {
        return [
            'listing' => $listing, 'categories' => ProduceCategory::cases(),
            'crops' => Crop::query()->with('category')->orderBy('name_en')->get()
                ->map(fn (Crop $c) => ['id' => $c->id, 'name' => $c->name_en.' / '.$c->name_sw, 'category' => ProduceCategory::fromCategorySlug($c->category->slug)->value]),
            'regions' => Region::query()->orderBy('name')->get(), 'districts' => District::query()->orderBy('name')->get(),
            'units' => Unit::query()->orderBy('name_en')->get(),
        ];
    }
}
