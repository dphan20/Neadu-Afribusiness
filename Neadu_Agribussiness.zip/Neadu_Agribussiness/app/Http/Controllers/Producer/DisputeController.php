<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Enums\EscrowState;
use App\Http\Controllers\Controller;
use App\Models\Dispute;
use App\Models\Order;
use App\Services\NotificationService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** MKT-08 / BR-05: open a dispute with evidence (3 days to add evidence, 5 working days to decide). */
class DisputeController extends Controller
{
    public function store(Request $request, Order $order, NotificationService $notes): RedirectResponse
    {
        abort_unless($order->seller_id === $request->user()->id, 404);
        $data = $request->validate([
            'reason' => ['required', 'string', 'min:10', 'max:1000'],
            'evidence' => ['required', 'array', 'min:1', 'max:5'],
            'evidence.*' => ['file', 'mimes:jpg,jpeg,png,webp,pdf', 'max:5120'],
        ]);

        try {
            DB::transaction(function () use ($request, $order, $data, $notes): void {
                $order = Order::query()->lockForUpdate()->findOrFail($order->id);
                if ($order->dispute()->exists()) {
                    throw new DomainException('A dispute is already open for this order.');
                }
                if (! in_array($order->status, [EscrowState::Held, EscrowState::InTransit, EscrowState::Delivered], true)) {
                    throw new DomainException('A dispute can only be opened on a paid order that is not yet released.');
                }

                $dispute = Dispute::query()->create([
                    'order_id' => $order->id, 'opener_id' => $request->user()->id, 'reason' => $data['reason'],
                    'evidence' => $this->storeEvidence($order, $request->file('evidence')),
                    'evidence_until' => now()->addDays((int) config('neas.dispute.evidence_days')),
                    'decide_by' => now()->addWeekdays((int) config('neas.dispute.decide_working_days')),
                ]);
                $order->transitionTo(EscrowState::Disputed);
                $notes->notify($order->buyer, 'dispute.opened', ['dispute' => $dispute->uuid, 'message' => 'Muuzaji amefungua mgogoro kuhusu oda yako. Unaweza kuongeza ushahidi.']);
            });
        } catch (DomainException $e) {
            return back()->withErrors(['dispute' => $e->getMessage()]);
        }

        return back()->with('status', 'Dispute opened. Our team will decide within 5 working days.');
    }

    public function addEvidence(Request $request, Dispute $dispute): RedirectResponse
    {
        abort_unless($dispute->opener_id === $request->user()->id, 404);
        $request->validate(['evidence' => ['required', 'array', 'min:1', 'max:5'], 'evidence.*' => ['file', 'mimes:jpg,jpeg,png,webp,pdf', 'max:5120']]);

        if ($dispute->decision !== null || $dispute->evidence_until->isPast()) {
            return back()->withErrors(['dispute' => 'The evidence window for this dispute has closed.']);
        }

        $dispute->forceFill(['evidence' => array_merge($dispute->evidence ?? [], $this->storeEvidence($dispute->order, $request->file('evidence')))])->save();

        return back()->with('status', 'Evidence added.');
    }

    public function file(Request $request, Dispute $dispute, int $index): StreamedResponse
    {
        abort_unless($dispute->opener_id === $request->user()->id || $dispute->order->seller_id === $request->user()->id, 404);
        $item = ($dispute->evidence ?? [])[$index] ?? null;
        abort_if($item === null || ! Storage::disk('local')->exists($item['path']), 404);

        return Storage::disk('local')->response($item['path'], $item['name']);
    }

    /** @param array<int, \Illuminate\Http\UploadedFile> $files @return list<array{path: string, name: string}> */
    private function storeEvidence(Order $order, array $files): array
    {
        return array_values(array_map(fn ($f) => [
            'path' => $f->store('disputes/'.$order->uuid, 'local'), 'name' => $f->getClientOriginalName(),
        ], $files));
    }
}
