<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Http\Controllers\Controller;
use App\Models\Crop;
use App\Models\Market;
use App\Models\PriceAlert;
use App\Models\PriceRecord;
use App\Support\Money;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** PRC-03: alerts for a product (and optionally a market) rising above or falling below a price. */
class PriceAlertController extends Controller
{
    public function index(Request $request): View
    {
        return view('producer.alerts.index', [
            'alerts' => PriceAlert::query()->with(['crop', 'market'])->where('user_id', $request->user()->id)->latest()->get(),
            'crops' => Crop::query()->orderBy('name_en')->get(), 'markets' => Market::query()->orderBy('name')->get(),
            'latest' => PriceRecord::query()->with(['crop', 'market'])->orderByDesc('recorded_on')->orderByDesc('id')->limit(6)->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $d = $request->validate([
            'crop_id' => ['required', 'integer', 'exists:crops,id'], 'market_id' => ['nullable', 'integer', 'exists:markets,id'],
            'condition' => ['required', 'in:above,below'], 'threshold' => ['required', 'regex:/^\d{1,12}(\.\d{1,2})?$/'],
            'channels' => ['required', 'array', 'min:1'], 'channels.*' => ['in:sms,whatsapp,in_app'],
        ]);

        PriceAlert::query()->create([
            'user_id' => $request->user()->id, 'crop_id' => $d['crop_id'], 'market_id' => $d['market_id'] ?? null,
            'condition' => $d['condition'], 'threshold_minor' => Money::fromMajor($d['threshold'])->minor,
            'channels' => array_values(array_unique($d['channels'])), 'active' => true,
        ]);

        return back()->with('status', 'Alert saved.');
    }

    public function toggle(Request $request, PriceAlert $alert): RedirectResponse
    {
        abort_unless($alert->user_id === $request->user()->id, 404);
        $alert->forceFill(['active' => ! $alert->active])->save();

        return back();
    }

    public function destroy(Request $request, PriceAlert $alert): RedirectResponse
    {
        abort_unless($alert->user_id === $request->user()->id, 404);
        $alert->delete();

        return back()->with('status', 'Alert deleted.');
    }
}
