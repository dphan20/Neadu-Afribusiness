<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Http\Controllers\Controller;
use App\Services\CreditScoreService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** CRS-01..03 (R3): score, the factors behind it, tips, and consent before any lender sees it. */
class CreditScoreController extends Controller
{
    public function index(Request $request, CreditScoreService $service): View
    {
        $snapshot = $service->snapshot($request->user());

        return view('producer.credit.index', [
            'score' => $snapshot->score, 'factors' => $snapshot->factors, 'consent' => $request->user()->credit_share_consent,
            'min' => CreditScoreService::BASE, 'max' => CreditScoreService::MAX,
        ]);
    }

    public function consent(Request $request, CreditScoreService $service): RedirectResponse
    {
        $d = $request->validate(['consent' => ['required', 'boolean']]);
        $service->setConsent($request->user(), (bool) $d['consent']);

        return back()->with('status', $d['consent'] ? 'Lenders you apply to can now see your score.' : 'Sharing turned off. Lenders can no longer see your score.');
    }
}
