<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Enums\ProducerType;
use App\Enums\UserRole;
use App\Http\Controllers\Controller;
use App\Models\Crop;
use App\Models\District;
use App\Models\Region;
use App\Models\RoleProfile;
use App\Services\IdentityService;
use App\Services\OtpService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

/** ACC-01/02 phone OTP, ACC-03 NIDA verification, ACC-04 producer profile. */
class OnboardingController extends Controller
{
    public function phone(Request $request): View
    {
        return view('producer.phone', ['verified' => $request->user()->phone_verified_at !== null]);
    }

    public function sendOtp(Request $request, OtpService $otp): RedirectResponse
    {
        try {
            $otp->issue($request->user()->phone);
        } catch (DomainException $e) {
            return back()->withErrors(['code' => $e->getMessage()]);
        }

        return back()->with('status', 'We sent a 6-digit code by SMS.');
    }

    public function verifyOtp(Request $request, OtpService $otp): RedirectResponse
    {
        $data = $request->validate(['code' => ['required', 'digits:6']]);

        if (! $otp->verify($request->user(), $data['code'])) {
            return back()->withErrors(['code' => 'That code is wrong or has expired.']);
        }

        return redirect()->route('producer.identity')->with('status', 'Phone number verified.');
    }

    public function identity(Request $request): View
    {
        $user = $request->user();

        return view('producer.identity', ['user' => $user, 'masked' => $user->maskedNida()]);
    }

    public function verifyIdentity(Request $request, IdentityService $identity): RedirectResponse
    {
        $data = $request->validate(['nida_number' => ['required', 'digits:20']]);

        try {
            $identity->verifyNida($request->user(), $data['nida_number']);
        } catch (DomainException $e) {
            return back()->withErrors(['nida_number' => $e->getMessage()])->onlyInput();
        }

        return redirect()->route('producer.profile')->with('status', 'Identity verified. You can now list, sell and ship.');
    }

    public function profile(Request $request): View
    {
        $profile = $request->user()->producerProfile;

        return view('producer.profile', [
            'profile' => $profile, 'business' => $profile?->business ?? [],
            'types' => ProducerType::cases(), 'regions' => Region::query()->orderBy('name')->get(),
            'districts' => District::query()->orderBy('name')->get(), 'crops' => Crop::query()->orderBy('name_en')->get(),
        ]);
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'producer_type' => ['required', Rule::in(array_map(fn (ProducerType $t) => $t->value, ProducerType::cases()))],
            'region_id' => ['required', 'integer', 'exists:regions,id'],
            'district_id' => ['required', 'integer', Rule::exists('districts', 'id')->where('region_id', $request->input('region_id'))],
            'crop_ids' => ['required', 'array', 'min:1'],
            'crop_ids.*' => ['integer', 'exists:crops,id'],
            'farm_name' => ['nullable', 'string', 'max:120'],
        ]);

        RoleProfile::query()->updateOrCreate(
            ['user_id' => $request->user()->id, 'role' => UserRole::Producer->value],
            [
                'region_id' => $data['region_id'], 'district_id' => $data['district_id'],
                'business' => [
                    'producer_type' => $data['producer_type'], 'crop_ids' => array_map('intval', $data['crop_ids']),
                    'farm_name' => $data['farm_name'] ?? null,
                ],
            ],
        );

        return redirect()->route('producer.home')->with('status', 'Profile saved.');
    }
}
