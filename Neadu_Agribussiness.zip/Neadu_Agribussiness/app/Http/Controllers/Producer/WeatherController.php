<?php

declare(strict_types=1);

namespace App\Http\Controllers\Producer;

use App\Http\Controllers\Controller;
use App\Models\Crop;
use App\Models\Region;
use App\Services\ProducerQueries;
use App\Services\Weather\WeatherServiceInterface;
use App\Services\WeatherService;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\View\View;

/** S-32 / WTH-01..05: forecast with its source and last-updated time, severe alerts and indicative planting / harvest windows. */
class WeatherController extends Controller
{
    public function index(Request $request, WeatherServiceInterface $forecasts, WeatherService $weather, ProducerQueries $queries): View
    {
        // Kiswahili is the default; a signed-in person who chose English sees English.
        app()->setLocale($request->user()->language === 'en' ? 'en' : 'sw');

        $region = Region::query()->find($request->query('region_id')) ?? $queries->producerRegion($request->user())
            ?? Region::query()->where('name', 'Dodoma')->first();

        [$lat, $lng] = $weather->coordinates($region);
        $forecast = $forecasts->getForecast($lat, $lng, $region?->name ?? 'Dodoma');
        $days = $forecast['daily'];

        $cropIds = $request->user()->producerProfile?->business['crop_ids'] ?? [];
        $crops = $cropIds !== [] ? Crop::query()->whereIn('id', $cropIds)->get() : Crop::query()->get();
        $windows = $crops->map(fn (Crop $c) => ['crop' => $c, 'window' => $weather->window($c->slug, now())])->filter(fn ($w) => $w['window'] !== null)->values();

        return view('producer.weather.index', [
            'region' => $region, 'regions' => Region::query()->orderBy('name')->get(),
            'forecast' => $forecast, 'days' => $days, 'alerts' => $weather->alerts($days), 'windows' => $windows,
            'hint' => $weather->rainHint($days),
            'updatedAt' => $forecast['fetched_at'] !== null ? Carbon::parse($forecast['fetched_at'])->timezone('Africa/Dar_es_Salaam')->format('d M Y H:i') : null,
        ]);
    }
}
