<?php

declare(strict_types=1);

namespace App\Http\Controllers\Transporter;

use App\Enums\VehicleType;
use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Delivery;
use App\Models\Vehicle;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

/** LOG-01 / S-21: register vehicles (type, capacity, plate, licence, photo); the NeAS team verifies them. */
class VehicleController extends Controller
{
    public function index(Request $request): View
    {
        return view('transporter.vehicles', [
            'vehicles' => Vehicle::query()->where('user_id', $request->user()->id)->latest()->get(),
            'types' => VehicleType::cases(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'type' => ['required', Rule::in(array_map(fn (VehicleType $t): string => $t->value, VehicleType::cases()))],
            'capacity_kg' => ['required', 'numeric', 'gt:0'],
            'plate' => ['nullable', 'string', 'max:16'],
            'licence' => ['nullable', 'string', 'max:40'],
            'photo' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);

        $type = VehicleType::from($data['type']);
        [$plate, $errors] = $this->checkTypeRules($type, $data, null);
        if ($errors !== []) {
            return back()->withErrors($errors)->withInput();
        }

        $vehicle = Vehicle::query()->create([
            'user_id' => $request->user()->id, 'type' => $type->value, 'plate' => $plate,
            'capacity_kg' => $data['capacity_kg'], 'licence_document' => trim((string) ($data['licence'] ?? '')) ?: null,
            'photo_path' => $request->file('photo')->store('vehicles', 'public'),
        ]);
        AuditLog::record('vehicle.registered', $vehicle, [], ['type' => $type->value, 'plate' => $plate]);

        return redirect()->route('transporter.vehicles')->with('status', 'Vehicle submitted. The NeAS team will verify it before you can accept jobs.');
    }

    /** Any vehicle can be edited. A change to type, plate, licence, photo or a bigger capacity sends it back to verification. */
    public function update(Request $request, Vehicle $vehicle): RedirectResponse
    {
        abort_unless((int) $vehicle->user_id === $request->user()->id, 404);
        if (Delivery::query()->where('vehicle_id', $vehicle->id)->whereIn('status', Delivery::ACTIVE)->exists()) {
            return back()->withErrors(['vehicle' => 'This vehicle is on an active trip. Finish the trip before editing it.']);
        }

        $data = $request->validate([
            'type' => ['required', Rule::in(array_map(fn (VehicleType $t): string => $t->value, VehicleType::cases()))],
            'capacity_kg' => ['required', 'numeric', 'gt:0'],
            'plate' => ['nullable', 'string', 'max:16'],
            'licence' => ['nullable', 'string', 'max:40'],
            'photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);
        $type = VehicleType::from($data['type']);
        [$plate, $errors] = $this->checkTypeRules($type, $data, $vehicle);
        if ($errors !== []) {
            return back()->withErrors($errors)->withInput();
        }

        $licence = trim((string) ($data['licence'] ?? '')) ?: null;
        $critical = $vehicle->type !== $type->value || $vehicle->plate !== $plate || $vehicle->licence_document !== $licence
            || (float) $data['capacity_kg'] > (float) $vehicle->capacity_kg || $request->hasFile('photo');

        $vehicle->fill(['type' => $type->value, 'plate' => $plate, 'capacity_kg' => $data['capacity_kg'], 'licence_document' => $licence]);
        if ($request->hasFile('photo')) {
            $vehicle->photo_path = $request->file('photo')->store('vehicles', 'public');
        }
        if ($critical || ! $vehicle->isVerified()) {
            $vehicle->verification_status = 'pending';
            $vehicle->reject_reason = null;
        }
        $vehicle->save();
        AuditLog::record('vehicle.updated', $vehicle, [], ['critical' => $critical]);

        return redirect()->route('transporter.vehicles')->with('status', $critical || ! $vehicle->isVerified() ? 'Vehicle updated and sent for verification again.' : 'Vehicle updated.');
    }

    public function destroy(Request $request, Vehicle $vehicle): RedirectResponse
    {
        abort_unless((int) $vehicle->user_id === $request->user()->id, 404);
        if (Delivery::query()->where('vehicle_id', $vehicle->id)->whereIn('status', Delivery::ACTIVE)->exists()) {
            return back()->withErrors(['vehicle' => 'This vehicle is on an active trip.']);
        }

        // Free the plate for re-registration; the row stays for past deliveries.
        $vehicle->forceFill(['plate' => $vehicle->plate.'#'.$vehicle->id])->save();
        $vehicle->delete();

        return redirect()->route('transporter.vehicles')->with('status', 'Vehicle removed.');
    }

    /**
     * @param  array<string, mixed>  $data
     * @return array{0: string, 1: array<string, string>} normalised plate and field errors
     */
    private function checkTypeRules(VehicleType $type, array $data, ?Vehicle $existing): array
    {
        $errors = [];
        if ((float) $data['capacity_kg'] > $type->maxCapacityKg()) {
            $errors['capacity_kg'] = 'A '.strtolower($type->label()).' can be registered for up to '.number_format($type->maxCapacityKg()).' kg.';
        }
        if ($type->needsLicence() && trim((string) ($data['licence'] ?? '')) === '') {
            $errors['licence'] = 'Enter the driving licence number.';
        }

        if (! $type->needsPlate()) {
            return [$existing?->plate !== null && str_starts_with($existing->plate, 'BIC-') ? $existing->plate : 'BIC-'.strtoupper(Str::random(8)), $errors];
        }

        $plate = strtoupper((string) preg_replace('/[^A-Za-z0-9]/', '', (string) ($data['plate'] ?? '')));
        if (strlen($plate) < 3) {
            $errors['plate'] = 'Enter the number plate.';
        } elseif (Vehicle::withTrashed()->where('plate', $plate)->when($existing, fn ($q) => $q->whereKeyNot($existing->id))->exists()) {
            $errors['plate'] = 'This number plate is already registered.';
        }

        return [$plate, $errors];
    }
}
