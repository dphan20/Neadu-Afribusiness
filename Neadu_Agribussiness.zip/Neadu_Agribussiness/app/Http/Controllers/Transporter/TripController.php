<?php

declare(strict_types=1);

namespace App\Http\Controllers\Transporter;

use App\Events\DeliveryStatusChanged;
use App\Http\Controllers\Controller;
use App\Models\Delivery;
use App\Services\TransportService;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** LOG-04 .. LOG-06 / S-20: driver trip mode, GPS sync and proof of delivery. */
class TripController extends Controller
{
    public function __construct(private readonly TransportService $transport) {}

    public function index(Request $request): View
    {
        $driver = $request->user();

        return view('transporter.trips', [
            'active' => $this->transport->activeTrips($driver),
            'history' => Delivery::query()->with('order.listing')->where('transporter_id', $driver->id)->where('status', 'delivered')
                ->latest('delivered_at')->limit(25)->get(),
        ]);
    }

    public function show(Request $request, Delivery $delivery): View
    {
        $this->mine($request, $delivery);
        $delivery->load(['order.listing.produce.crop', 'order.listing.produce.unit', 'order.listing.region', 'vehicle', 'trackingPoints']);

        return view('transporter.trip', [
            'delivery' => $delivery, 'step' => $this->transport->step($delivery), 'steps' => TransportService::STEPS,
            'navUrl' => $this->transport->navUrl($delivery), 'km' => $this->transport->distanceKm($delivery),
            'weight' => $this->transport->weightKg($delivery), 'attemptsLeft' => max(0, TransportService::MAX_CODE_ATTEMPTS - (int) $delivery->code_attempts),
            'lastPoint' => $delivery->trackingPoints->sortByDesc('recorded_at')->first(),
        ]);
    }

    /** Plain form fallback for the next-step button (the page script normally handles it, offline included). */
    public function advance(Request $request, Delivery $delivery): RedirectResponse
    {
        $this->mine($request, $delivery);
        $data = $request->validate(['to' => ['required', 'string']]);

        try {
            $this->transport->advance($delivery, $request->user(), $data['to']);
        } catch (DomainException $e) {
            return back()->withErrors(['trip' => $e->getMessage()]);
        }

        $this->broadcastStatus($delivery);

        return redirect()->route('transporter.trips.show', $delivery);
    }

    public function confirmCode(Request $request, Delivery $delivery): RedirectResponse
    {
        $this->mine($request, $delivery);
        $data = $request->validate(['code' => ['required', 'string', 'max:12']]);

        try {
            $this->transport->confirmWithCode($delivery, $request->user(), $data['code']);
        } catch (DomainException $e) {
            return back()->withErrors(['code' => $e->getMessage()]);
        }

        return $this->delivered($delivery);
    }

    public function confirmProof(Request $request, Delivery $delivery): RedirectResponse
    {
        $this->mine($request, $delivery);
        $data = $request->validate([
            'recipient' => ['required', 'string', 'max:120'],
            'photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:6144'],
            'signature' => ['nullable', 'string', 'max:600000'],
        ]);

        try {
            $this->transport->confirmWithProof($delivery, $request->user(), $data['recipient'], $request->file('photo'), $data['signature'] ?? null);
        } catch (DomainException $e) {
            return back()->withErrors(['proof' => $e->getMessage()])->withInput($request->only('recipient'));
        }

        return $this->delivered($delivery);
    }

    /**
     * LOG-05: the page posts its offline buffer here (GPS points and status taps, oldest first).
     * Steps already applied are ignored, so replaying the buffer is safe.
     */
    public function sync(Request $request, Delivery $delivery): JsonResponse
    {
        $this->mine($request, $delivery);
        $request->validate([
            'events' => ['required', 'array', 'max:200'],
            'events.*.type' => ['required', 'in:point,status'],
            'events.*.lat' => ['nullable', 'numeric', 'between:-90,90'],
            'events.*.lng' => ['nullable', 'numeric', 'between:-180,180'],
            'events.*.t' => ['nullable', 'numeric'],
            'events.*.accuracy' => ['nullable', 'numeric', 'min:0'],
            'events.*.speed' => ['nullable', 'numeric', 'min:0'],
            'events.*.to' => ['nullable', 'string', 'max:16'],
        ]);

        $driver = $request->user();
        $errors = [];
        $points = [];
        $saved = 0;
        foreach ($request->input('events') as $event) {
            if ($event['type'] === 'point') {
                $points[] = $event;

                continue;
            }
            $saved += $this->transport->recordPoints($delivery, $driver, $points);
            $points = [];
            try {
                $this->transport->advance($delivery, $driver, (string) ($event['to'] ?? ''), isset($event['lat']) ? (float) $event['lat'] : null, isset($event['lng']) ? (float) $event['lng'] : null);
            } catch (DomainException $e) {
                $errors[] = $e->getMessage();
            }
        }
        $saved += $this->transport->recordPoints($delivery, $driver, $points);

        $delivery->refresh();
        $this->broadcastStatus($delivery);
        $step = $this->transport->step($delivery);

        return response()->json([
            'status' => $delivery->status, 'label' => $step['label'], 'next' => $step['next'], 'action' => $step['action'],
            'nav' => $this->transport->navUrl($delivery), 'points_saved' => $saved, 'errors' => $errors,
        ]);
    }

    private function delivered(Delivery $delivery): RedirectResponse
    {
        $delivery->refresh();
        $this->broadcastStatus($delivery);

        return redirect()->route('transporter.trips')->with('status', 'Delivered. TSh '.number_format(intdiv((int) $delivery->price_minor, 100)).' was released from escrow to your earnings.');
    }

    /** LOG-04: tells the buyer's open tracking page that the step bar moved. */
    private function broadcastStatus(Delivery $delivery): void
    {
        DeliveryStatusChanged::dispatch($delivery->uuid, (string) $delivery->fresh()?->status);
    }

    private function mine(Request $request, Delivery $delivery): void
    {
        abort_unless((int) $delivery->transporter_id === $request->user()->id, 404);
    }
}
