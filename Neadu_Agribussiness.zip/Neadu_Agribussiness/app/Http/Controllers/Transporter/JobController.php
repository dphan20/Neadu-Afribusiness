<?php

declare(strict_types=1);

namespace App\Http\Controllers\Transporter;

use App\Http\Controllers\Controller;
use App\Models\Delivery;
use App\Models\Vehicle;
use App\Services\TransportService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** LOG-03 / S-19: open jobs and requests addressed to the driver, with distance and price. */
class JobController extends Controller
{
    public function __construct(private readonly TransportService $transport) {}

    public function index(Request $request): View
    {
        $driver = $request->user();
        $vehicles = Vehicle::query()->where('user_id', $driver->id)->where('verification_status', 'verified')->orderBy('capacity_kg')->get();

        $jobs = $this->transport->jobsFor($driver)->map(function (Delivery $d) use ($vehicles): array {
            $weight = $this->transport->weightKg($d);
            $km = $this->transport->distanceKm($d);

            return [
                'delivery' => $d, 'km' => $km, 'weight' => $weight, 'price' => (int) $d->price_minor,
                'per_km' => $km > 0 ? (int) round(((int) $d->price_minor / 100) / $km) : null,
                'direct' => $d->transporter_id !== null,
                'fits' => $vehicles->filter(fn (Vehicle $v): bool => $weight === null || (float) $v->capacity_kg >= $weight)->values(),
            ];
        });

        $sort = in_array($request->query('sort'), ['price', 'distance'], true) ? $request->query('sort') : 'new';
        $jobs = match ($sort) {
            'price' => $jobs->sortByDesc('price')->values(),
            'distance' => $jobs->sortBy('km')->values(),
            default => $jobs->values(),
        };

        return view('transporter.jobs', [
            'jobs' => $jobs, 'vehicles' => $vehicles, 'sort' => $sort,
            'identityVerified' => $driver->isIdentityVerified(),
            'hasAnyVehicle' => Vehicle::query()->where('user_id', $driver->id)->exists(),
        ]);
    }

    public function accept(Request $request, Delivery $delivery): RedirectResponse
    {
        $data = $request->validate(['vehicle' => ['required', 'string']]);
        $vehicle = Vehicle::query()->where('user_id', $request->user()->id)->where('uuid', $data['vehicle'])->first();
        if ($vehicle === null) {
            return back()->withErrors(['vehicle' => 'Choose one of your vehicles.']);
        }

        try {
            $trip = $this->transport->accept($delivery, $request->user(), $vehicle);
        } catch (DomainException $e) {
            return back()->withErrors(['job' => $e->getMessage()]);
        }

        return redirect()->route('transporter.trips.show', $trip)->with('status', 'Job accepted. Head to the pickup point.');
    }

    public function release(Request $request, Delivery $delivery): RedirectResponse
    {
        try {
            $this->transport->release($delivery, $request->user());
        } catch (DomainException $e) {
            return back()->withErrors(['job' => $e->getMessage()]);
        }

        return redirect()->route('transporter.jobs')->with('status', 'Job returned to the open board.');
    }
}
