<?php

declare(strict_types=1);

namespace App\Http\Controllers\Transporter;

use App\Http\Controllers\Controller;
use App\Models\Delivery;
use App\Models\District;
use App\Models\Region;
use App\Models\RoleProfile;
use App\Models\Vehicle;
use App\Services\IdentityService;
use App\Services\TransportService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** S-19 / S-21 landing page, earnings and identity check for the transporter role. */
class WorkspaceController extends Controller
{
    public function __construct(private readonly TransportService $transport) {}

    public function home(Request $request): View
    {
        $user = $request->user();
        $vehicles = Vehicle::query()->where('user_id', $user->id)->get();
        $earnings = $this->transport->earnings($user);

        $backhaul = collect();
        if ($this->transport->backhaulEnabled()) {
            $last = Delivery::query()->where('transporter_id', $user->id)->where('status', 'delivered')
                ->where('delivered_at', '>=', now()->subDays(3))->latest('delivered_at')->first();
            $backhaul = $last === null ? collect() : $this->transport->backhaul($last);
        }

        return view('transporter.home', [
            'trips' => $this->transport->activeTrips($user),
            'openJobs' => $this->transport->jobsFor($user)->count(),
            'vehicles' => $vehicles,
            'verifiedVehicles' => $vehicles->filter(fn (Vehicle $v): bool => $v->isVerified())->count(),
            'balance' => $earnings['balance'],
            'backhaul' => $backhaul,
            'identityVerified' => $user->isIdentityVerified(),
            'transport' => $this->transport,
        ]);
    }

    public function profile(Request $request): View
    {
        return view('transporter.profile', [
            'profile' => RoleProfile::query()->firstOrNew(['user_id' => $request->user()->id, 'role' => 'T']),
            'regions' => Region::query()->orderBy('name')->get(), 'districts' => District::query()->orderBy('name')->get(),
        ]);
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        $d = $request->validate([
            'name' => ['required', 'string', 'max:120'], 'about' => ['nullable', 'string', 'max:1000'],
            'phone' => ['required', 'regex:/^\+?[0-9 ]{9,20}$/'], 'whatsapp' => ['nullable', 'regex:/^\+?[0-9 ]{9,20}$/'], 'email' => ['nullable', 'email', 'max:120'],
            'hours' => ['nullable', 'string', 'max:120'], 'goods' => ['nullable', 'array'], 'goods.*' => ['in:grains,vegetables,fruit,livestock,fish,fertiliser,machinery,other'],
            'region_id' => ['nullable', 'exists:regions,id'], 'district_id' => ['nullable', 'exists:districts,id'],
        ]);
        if (! empty($d['district_id']) && ! District::query()->whereKey($d['district_id'])->where('region_id', $d['region_id'] ?? 0)->exists()) {
            return back()->withInput()->withErrors(['district_id' => 'This district is not in the region you chose.']);
        }
        $profile = RoleProfile::query()->firstOrNew(['user_id' => $request->user()->id, 'role' => 'T']);
        $profile->forceFill([
            'region_id' => $d['region_id'] ?? null, 'district_id' => $d['district_id'] ?? null,
            'business' => ['name' => $d['name'], 'about' => $d['about'] ?? null, 'phone' => $d['phone'], 'whatsapp' => $d['whatsapp'] ?? null,
                'email' => $d['email'] ?? null, 'hours' => $d['hours'] ?? null, 'goods' => array_values($d['goods'] ?? [])],
        ])->save();

        return back()->with('status', 'Transport profile saved.');
    }

    public function earnings(Request $request): View
    {
        return view('transporter.earnings', $this->transport->earnings($request->user()));
    }

    public function identity(Request $request): View
    {
        $user = $request->user();

        return view('transporter.identity', ['user' => $user, 'masked' => $user->maskedNida()]);
    }

    public function verifyIdentity(Request $request, IdentityService $identity): RedirectResponse
    {
        $data = $request->validate(['nida_number' => ['required', 'digits:20']]);

        try {
            $identity->verifyNida($request->user(), $data['nida_number']);
        } catch (DomainException $e) {
            return back()->withErrors(['nida_number' => $e->getMessage()])->onlyInput();
        }

        return redirect()->route('transporter.home')->with('status', 'Identity verified. You can now accept jobs once a vehicle is verified.');
    }
}
