<?php

declare(strict_types=1);

namespace App\Http\Controllers\Landowner;

use App\Enums\ListingType;
use App\Http\Controllers\Controller;
use App\Models\District;
use App\Models\LandEnquiry;
use App\Models\LandPlot;
use App\Models\Listing;
use App\Models\Region;
use App\Models\VerificationDocument;
use App\Services\NotificationService;
use App\Services\VerificationService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

/** Land owner: S-27 manage land (LND-01/02/03), S-26 enquiries (LND-04) and lease drafts (LND-05, R3). */
class LandController extends Controller
{
    public function listings(Request $request): View
    {
        $lands = Listing::query()->with(['land', 'region'])->where('user_id', $request->user()->id)->where('type', 'land')->latest()->get();
        $docs = VerificationDocument::query()->where('user_id', $request->user()->id)->where('subject_type', 'land')->whereIn('subject_id', $lands->pluck('id'))->latest()->get()->groupBy('subject_id');
        $open = LandEnquiry::query()->whereIn('listing_id', $lands->pluck('id'))->where('status', 'open')->selectRaw('listing_id, COUNT(*) n')->groupBy('listing_id')->pluck('n', 'listing_id');

        return view('landowner.listings', compact('lands', 'docs', 'open'));
    }

    public function form(Request $request, ?Listing $listing = null): View
    {
        if ($listing) {
            $this->own($request, $listing);
            $listing->load('land');
        }

        return view('landowner.form', [
            'listing' => $listing, 'land' => $listing?->land, 'regions' => Region::query()->orderBy('name')->get(), 'districts' => District::query()->orderBy('name')->get(),
            'docs' => $listing ? VerificationDocument::query()->where('subject_type', 'land')->where('subject_id', $listing->id)->latest()->get() : collect(),
        ]);
    }

    public function save(Request $request, VerificationService $verification, ?Listing $listing = null): RedirectResponse
    {
        if ($listing) {
            $this->own($request, $listing);
        }
        $d = $request->validate([
            'title' => ['required', 'string', 'max:120'], 'region_id' => ['required', 'exists:regions,id'], 'district_id' => ['required', 'exists:districts,id'],
            'lat' => ['nullable', 'numeric', 'between:-12,0'], 'lng' => ['nullable', 'numeric', 'between:29,41'],
            'site_type' => ['required', 'in:farmland,factory,service_centre'], 'size_acres' => ['required', 'numeric', 'gt:0', 'max:1000000'],
            'tenure' => ['required', 'in:lease,sale'], 'rent_period' => ['nullable', 'required_if:tenure,lease', 'in:month,year'],
            'price' => ['required', 'regex:/^\d{1,12}(\.\d{1,2})?$/'], 'soil' => ['nullable', 'string', 'max:80'], 'water' => ['nullable', 'string', 'max:80'],
            'road_access' => ['nullable', 'boolean'],
            'photos' => ['nullable', 'array', 'max:6'], 'photos.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'title_document' => ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:8192'], 'submit' => ['nullable', 'boolean'],
        ]);
        $submit = ! empty($d['submit']);
        $user = $request->user();

        if ($submit && ! $user->isIdentityVerified()) {
            return redirect()->route('me.identity')->with('status', 'Verify your identity (NIDA) before submitting a land listing.');
        }
        if ($submit) {
            $hasDoc = $request->hasFile('title_document') || ($listing && VerificationDocument::query()->where('subject_type', 'land')->where('subject_id', $listing->id)->where('status', '!=', 'rejected')->exists());
            if (! $hasDoc) {
                return back()->withErrors(['title_document' => 'Upload the title or ownership document so the NeAS team can verify the land.'])->withInput();
            }
        }

        $listing = DB::transaction(function () use ($request, $listing, $d, $submit, $user, $verification): Listing {
            $base = [
                'title' => $d['title'], 'region_id' => $d['region_id'], 'district_id' => $d['district_id'], 'lat' => $d['lat'] ?? null, 'lng' => $d['lng'] ?? null,
                'price_minor' => Money::fromMajor($d['price'])->minor,
            ];
            if ($listing === null) {
                $listing = Listing::query()->create($base + ['user_id' => $user->id, 'type' => ListingType::Land, 'status' => $submit ? 'pending_review' : 'draft', 'photos' => []]);
            } else {
                // BR-08: any edit to a verified listing sends it back for admin review.
                $status = $listing->status === 'closed' ? 'closed' : ($submit || in_array($listing->status, ['active', 'pending_review'], true) ? 'pending_review' : $listing->status);
                $listing->forceFill($base + ['status' => $status, 'verified' => false, 'verified_at' => null, 'verified_by' => null])->save();
            }
            $listing->forceFill(['photos' => array_merge($listing->photos ?? [], array_map(fn ($f) => $f->store("listings/{$listing->uuid}", 'public'), $request->file('photos', [])))])->save();
            LandPlot::query()->updateOrCreate(['listing_id' => $listing->id], [
                'size_acres' => $d['size_acres'], 'tenure' => $d['tenure'], 'rent_period' => $d['tenure'] === 'lease' ? $d['rent_period'] : null, 'site_type' => $d['site_type'],
                'soil' => $d['soil'] ?? null, 'water' => $d['water'] ?? null, 'road_access' => ! empty($d['road_access']),
            ]);
            if ($request->hasFile('title_document')) {
                $verification->submit($user, 'land', $listing->id, 'title_deed', $request->file('title_document'));
            }

            return $listing;
        });

        return redirect()->route('landowner.listings')->with('status', $listing->status === 'pending_review' ? 'Submitted. The NeAS team will review your document before the land shows as Verified.' : 'Draft saved.');
    }

    public function close(Request $request, Listing $listing): RedirectResponse
    {
        $this->own($request, $listing);
        $listing->forceFill(['status' => 'closed'])->save();

        return back()->with('status', 'Listing closed.');
    }

    /* ------------------------------------------------------------------ enquiries (LND-04) */

    public function enquiries(Request $request): View
    {
        $items = LandEnquiry::query()->with(['listing', 'user'])->whereHas('listing', fn ($q) => $q->where('user_id', $request->user()->id))
            ->orderByRaw("status = 'open' desc")->latest()->get();

        return view('landowner.enquiries', compact('items'));
    }

    public function reply(Request $request, LandEnquiry $enquiry, NotificationService $notes): RedirectResponse
    {
        $enquiry->load('listing', 'user');
        abort_unless($enquiry->listing->user_id === $request->user()->id, 404);
        $d = $request->validate(['reply' => ['required', 'string', 'max:1500'], 'decision' => ['nullable', 'in:accepted,declined']]);
        if ($enquiry->status !== 'open' && ! empty($d['decision'])) {
            return back()->withErrors(['reply' => 'This enquiry was already decided.']);
        }
        $enquiry->forceFill([
            'reply' => $d['reply'], 'replied_at' => now(),
            'status' => $enquiry->kind !== 'message' && ! empty($d['decision']) ? $d['decision'] : ($enquiry->kind === 'message' ? 'accepted' : $enquiry->status),
        ])->save();
        $notes->notify($enquiry->user, 'land.reply', ['enquiry' => $enquiry->uuid, 'message' => "Mmiliki wa {$enquiry->listing->title} amejibu: ".mb_substr($d['reply'], 0, 100)]);

        return back()->with('status', 'Reply sent.');
    }

    /** LND-05 (R3): a lease draft from a template. NeAS does not execute the lease. */
    public function lease(Request $request, LandEnquiry $enquiry): View
    {
        $enquiry->load('listing.land', 'listing.owner', 'listing.region', 'user');
        abort_unless($enquiry->listing->user_id === $request->user()->id && $enquiry->kind === 'offer' && $enquiry->status === 'accepted' && $enquiry->listing->land?->tenure === 'lease', 404);

        return view('landowner.lease', ['e' => $enquiry, 'l' => $enquiry->listing, 'land' => $enquiry->listing->land]);
    }

    private function own(Request $request, Listing $listing): void
    {
        abort_unless($listing->user_id === $request->user()->id && $listing->type->value === 'land', 404);
    }
}
