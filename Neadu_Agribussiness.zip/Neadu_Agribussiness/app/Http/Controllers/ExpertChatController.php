<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Conversation;
use App\Models\DiagnosisCase;
use App\Models\FeatureFlag;
use App\Models\Message;
use App\Services\MessagingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** S-42 / COM-01: chat with producers about a case; COM-02 voice calls (R2). Only participants can read or write. */
class ExpertChatController extends Controller
{
    public function index(): View
    {
        $conversations = Conversation::query()->with(['participants', 'messages'])
            ->visibleTo(auth()->user())->latest('updated_at')->get();

        return view('expert.chat-index', ['conversations' => $conversations, 'cases' => DiagnosisCase::query()->whereIn('id', $conversations->pluck('diagnosis_case_id')->filter())->get()->keyBy('id')]);
    }

    public function show(string $uuid): View
    {
        $conversation = $this->mine($uuid)->load(['participants']);
        $conversation->markReadBy(auth()->user());
        $other = $conversation->participants->firstWhere('id', '!=', auth()->id());

        return view('expert.chat', [
            'conversation' => $conversation, 'other' => $other, 'voice' => $this->voiceEnabled(),
            'case' => $conversation->diagnosis_case_id ? DiagnosisCase::query()->find($conversation->diagnosis_case_id) : null,
        ]);
    }

    public function send(Request $request, string $uuid): RedirectResponse
    {
        $conversation = $this->mine($uuid);
        $d = $request->validate(['body' => ['required_without:photo', 'nullable', 'string', 'max:2000'], 'photo' => ['nullable', 'image', 'max:4096']]);
        app(MessagingService::class)->send($conversation, $request->user(), $d['body'] ?? null, null, $request->file('photo'));

        return redirect()->route('expert.chat.show', $conversation)->withFragment('latest');
    }

    /** Start (or reopen) the conversation for a case the expert has taken. */
    public function start(Request $request): RedirectResponse
    {
        $d = $request->validate(['case' => ['required', 'uuid']]);
        $case = DiagnosisCase::query()->where('expert_id', auth()->id())->where('uuid', $d['case'])->firstOrFail();
        $conversation = Conversation::query()->where('diagnosis_case_id', $case->id)->first() ?? Conversation::create(['diagnosis_case_id' => $case->id]);
        $conversation->participants()->syncWithoutDetaching([auth()->id(), $case->user_id]);

        return redirect()->route('expert.chat.show', $conversation);
    }

    /**
     * COM-02 (R2): logs a call request in the thread so the producer sees it. The call itself uses the phone network
     * (tel: link on the chat page) until an in-app voice provider is connected.
     */
    public function call(string $uuid): RedirectResponse
    {
        abort_unless($this->voiceEnabled(), 404);
        $conversation = $this->mine($uuid);
        Message::create(['conversation_id' => $conversation->id, 'sender_id' => auth()->id(), 'kind' => 'call', 'body' => 'Voice call requested. Please pick up or call back.']);
        $conversation->touch();

        return back()->with('status', 'Call request sent in the chat.');
    }

    private function voiceEnabled(): bool
    {
        return app()->environment('local', 'testing') || (bool) FeatureFlag::query()->where('key', 'voice')->value('enabled');
    }

    private function mine(string $uuid): Conversation
    {
        return Conversation::query()->where('uuid', $uuid)->whereHas('participants', fn ($q) => $q->where('users.id', auth()->id()))->firstOrFail();
    }
}
