<?php

declare(strict_types=1);

namespace App\Http\Controllers\Shared;

use App\Enums\ListingType;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Trader\TraderController;
use App\Models\FeatureFlag;
use App\Models\Listing;
use App\Models\MachineQuote;
use App\Models\Region;
use App\Models\RoleProfile;
use App\Services\NotificationService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Machinery market for every signed-in role (MCH-01..04): browse, ask for a quote, financing or rental, follow the answer. */
class MachineryController extends Controller
{
    public function index(Request $request): View
    {
        $q = trim((string) $request->query('q', ''));
        $category = (string) $request->query('category', '');
        $condition = (string) $request->query('condition', '');
        $offer = (string) $request->query('offer', '');
        $region = (int) $request->query('region', 0);

        $machines = Listing::query()->with(['machine', 'region', 'owner'])->where('type', 'machine')->where('status', 'active')
            ->whereHas('machine')
            ->when($q !== '', fn (Builder $b) => $b->where(fn (Builder $w) => $w->where('title', 'like', '%'.$q.'%')
                ->orWhereHas('machine', fn (Builder $m) => $m->where('brand', 'like', '%'.$q.'%')->orWhere('model', 'like', '%'.$q.'%')->orWhere('description', 'like', '%'.$q.'%'))))
            ->when(isset(TraderController::CATEGORIES[$category]), fn (Builder $b) => $b->whereHas('machine', fn (Builder $m) => $m->where('category', $category)))
            ->when(isset(TraderController::CONDITIONS[$condition]), fn (Builder $b) => $b->whereHas('machine', fn (Builder $m) => $m->where('machine_condition', $condition)))
            ->when(isset(TraderController::OFFERS[$offer]), fn (Builder $b) => $b->whereHas('machine', fn (Builder $m) => $m->whereJsonContains('offers', $offer)))
            ->when($region > 0, fn (Builder $b) => $b->where('region_id', $region))
            ->latest()->paginate(12)->withQueryString();

        return view('machinery.index', [
            'machines' => $machines, 'q' => $q, 'category' => $category, 'condition' => $condition, 'offer' => $offer, 'region' => $region,
            'regions' => Region::query()->orderBy('name')->get(),
        ]);
    }

    public function show(Request $request, Listing $listing): View
    {
        $listing = $this->visible($request, $listing);
        $listing->load(['machine', 'region', 'district', 'owner']);

        return view('machinery.show', [
            'listing' => $listing, 'machine' => $listing->machine,
            'seller' => RoleProfile::query()->where('user_id', $listing->user_id)->where('role', 'R')->first(),
            'mine' => MachineQuote::query()->where('listing_id', $listing->id)->where('user_id', $request->user()->id)->latest()->limit(3)->get(),
            'financing' => FeatureFlag::isEnabled('financing'), 'rental' => FeatureFlag::isEnabled('rental'),
            'isOwner' => $listing->user_id === $request->user()->id,
        ]);
    }

    public function sheet(Request $request, Listing $listing): View
    {
        $listing = $this->visible($request, $listing);
        $listing->load(['machine', 'region', 'district', 'owner']);

        return view('machinery.sheet', ['listing' => $listing, 'machine' => $listing->machine, 'seller' => RoleProfile::query()->where('user_id', $listing->user_id)->where('role', 'R')->first()]);
    }

    public function request(Request $request, Listing $listing, NotificationService $notes): RedirectResponse
    {
        $listing = $this->visible($request, $listing);
        $user = $request->user();
        abort_if($listing->user_id === $user->id, 403, 'You cannot request a quote on your own listing.');
        $machine = $listing->machine()->firstOrFail();
        $d = $request->validate([
            'kind' => ['required', 'in:quote,financing,rental'], 'quantity' => ['required', 'integer', 'between:1,100'],
            'months' => ['nullable', 'integer', 'between:1,60'], 'message' => ['nullable', 'string', 'max:500'],
        ]);

        $needs = ['quote' => 'sale', 'financing' => 'financing', 'rental' => 'rental'][$d['kind']];
        if (! in_array($needs, $machine->offers ?? ['sale'], true)) {
            return back()->withInput()->withErrors(['kind' => 'The seller does not offer this option for this machine.']);
        }
        if ($d['kind'] !== 'quote' && ! FeatureFlag::isEnabled($d['kind'])) {
            return back()->withInput()->withErrors(['kind' => 'This option is not available yet.']);
        }
        if ($d['kind'] !== 'quote' && empty($d['months'])) {
            return back()->withInput()->withErrors(['months' => 'Say for how many months.']);
        }
        if (MachineQuote::query()->where('listing_id', $listing->id)->where('user_id', $user->id)->where('kind', $d['kind'])->where('status', 'open')->exists()) {
            return redirect()->route('machinery.requests')->with('status', 'You already have an open request for this machine. The seller will answer it.');
        }

        $quote = MachineQuote::query()->create([
            'listing_id' => $listing->id, 'user_id' => $user->id, 'kind' => $d['kind'], 'quantity' => $d['quantity'],
            'months' => $d['kind'] === 'quote' ? null : $d['months'], 'message' => $d['message'] ?? null, 'status' => 'open',
        ]);
        $notes->notify($listing->owner, 'machinery.request', ['quote' => $quote->uuid, 'message' => $user->name.' ameomba '.($d['kind'] === 'quote' ? 'bei' : ($d['kind'] === 'financing' ? 'mkopo' : 'kukodi')).' ya '.$listing->title.'.']);

        return redirect()->route('machinery.requests')->with('status', 'Request sent. The seller will reply here and by notification.');
    }

    public function mine(Request $request): View
    {
        return view('machinery.requests', [
            'quotes' => MachineQuote::query()->with(['listing.machine', 'listing.owner'])->where('user_id', $request->user()->id)->latest()->paginate(15),
        ]);
    }

    public function withdraw(Request $request, MachineQuote $quote): RedirectResponse
    {
        abort_unless($quote->user_id === $request->user()->id, 404);
        if (! in_array($quote->status, ['open', 'quoted'], true)) {
            return back()->withErrors(['quote' => 'This request is already closed.']);
        }
        $quote->forceFill(['status' => 'withdrawn'])->save();

        return back()->with('status', 'Request withdrawn.');
    }

    /** Printable quotation (use the browser's Save as PDF). Only the buyer and the seller can open it. */
    public function document(Request $request, MachineQuote $quote): View
    {
        $quote->load(['listing' => fn ($q) => $q->withTrashed(), 'listing.machine', 'listing.owner', 'user']);
        abort_unless($quote->user_id === $request->user()->id || $quote->listing?->user_id === $request->user()->id, 404);
        abort_unless($quote->status === 'quoted' && $quote->quoted_minor !== null, 404);

        return view('machinery.document', ['quote' => $quote, 'seller' => RoleProfile::query()->where('user_id', $quote->listing->user_id)->where('role', 'R')->first()]);
    }

    /** Active machine listings are public to signed-in users; the owner can also see theirs while editing. */
    private function visible(Request $request, Listing $listing): Listing
    {
        abort_unless($listing->type === ListingType::Machine, 404);
        abort_unless($listing->status === 'active' || $listing->user_id === $request->user()->id, 404);

        return $listing;
    }
}
