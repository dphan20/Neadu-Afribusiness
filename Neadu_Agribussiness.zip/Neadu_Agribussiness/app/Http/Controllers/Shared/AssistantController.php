<?php

declare(strict_types=1);

namespace App\Http\Controllers\Shared;

use App\Http\Controllers\Controller;
use App\Models\AiQuery;
use App\Services\Ai\GeminiClient;
use App\Services\AssistantService;
use DomainException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** Ask AI: every signed-in role can take or upload a photo and ask about it. */
class AssistantController extends Controller
{
    public function index(Request $request): View
    {
        return view('me.ask', [
            'history' => AiQuery::query()->where('user_id', $request->user()->id)->where('answer', '!=', '')->latest()->limit(20)->get(),
            'ready' => filled(config('services.gemini.key')),
            'streamUrl' => route('me.ask.stream'),
        ]);
    }

    public function send(Request $request, AssistantService $assistant): RedirectResponse
    {
        $d = $request->validate([
            'question' => ['required', 'string', 'min:3', 'max:1000'],
            'page' => ['nullable', 'string', 'max:120'],
            'photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:8192'],
        ]);

        try {
            $query = $assistant->ask($request->user(), $d['question'], $request->file('photo'), $d['page'] ?? null);
        } catch (DomainException $e) {
            return back()->withInput()->withErrors(['question' => $e->getMessage()]);
        }

        return redirect()->route('me.ask')->with('answered', $query->uuid);
    }

    /**
     * Live answer (Server-Sent Events over a normal POST): the first words reach the screen in about a second.
     * Events: {"start":{uuid,delete,photo}} then many {"t":"text"} then {"done":true}, or {"error":"..."}.
     * The browser's Stop button closes the connection; the next write notices it and generation is cancelled.
     */
    public function stream(Request $request, AssistantService $assistant): StreamedResponse
    {
        $d = $request->validate([
            'question' => ['required', 'string', 'min:3', 'max:1000'],
            'page' => ['nullable', 'string', 'max:120'],
            'photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:8192'],
        ]);
        $user = $request->user();
        $photo = $request->file('photo');
        $page = $d['page'] ?? null;

        $request->session()->save(); // release the session now so other tabs and pages stay responsive during the answer
        ignore_user_abort(true);     // we finish (save the partial answer, delete the photo of an empty one) after Stop
        @set_time_limit(90);

        return response()->stream(function () use ($assistant, $user, $d, $photo, $page): void {
            if (! app()->runningUnitTests()) {
                @ini_set('zlib.output_compression', '0');
                if (function_exists('apache_setenv')) {
                    @apache_setenv('no-gzip', '1');
                }
                while (ob_get_level() > 0) {
                    @ob_end_flush();
                }
            }
            $send = static function (array $event): bool {
                echo 'data: '.json_encode($event, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)."\n\n";
                if (! app()->runningUnitTests()) {
                    @flush();
                }

                return ! connection_aborted();
            };
            echo ':'.str_repeat(' ', 2048)."\n\n"; // push past proxy and Apache buffers so the first word is not held back
            @flush();

            try {
                $assistant->stream(
                    $user, $d['question'], $photo, $page,
                    static fn (AiQuery $q): bool => $send(['start' => [
                        'uuid' => $q->uuid,
                        'delete' => route('me.ask.destroy', $q),
                        'photo' => $q->photo_path ? route('me.ask.photo', $q) : null,
                    ]]),
                    static fn (string $text): bool => $send(['t' => $text]),
                );
                $send(['done' => true]);
            } catch (DomainException $e) {
                $send(['error' => $e->getMessage()]);
            }
        }, 200, [
            'Content-Type' => 'text/event-stream; charset=utf-8',
            'Cache-Control' => 'no-cache, no-transform',
            'X-Accel-Buffering' => 'no',
            'Connection' => 'keep-alive',
        ]);
    }

    /** Voice to text: the browser records a short clip (WAV), Gemini writes down what was said in Kiswahili or English. */
    public function transcribe(Request $request, GeminiClient $gemini): JsonResponse
    {
        @set_time_limit(120);
        $request->validate(['audio' => ['required', 'file', 'max:6144'], 'lang' => ['nullable', 'string', 'max:8']]);
        $file = $request->file('audio');
        try {
            $text = $gemini->transcribe($file->getRealPath(), $file->getMimeType() ?: 'audio/wav', (string) $request->input('lang', 'sw-TZ'));
        } catch (DomainException $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }

        return response()->json(['text' => $text]);
    }

    /** Delete one answered question (and its photo). */
    public function destroy(Request $request, AiQuery $query, AssistantService $assistant): JsonResponse|RedirectResponse
    {
        abort_unless($query->user_id === $request->user()->id, 404);
        $assistant->forget($query);

        return $request->expectsJson() ? response()->json(['deleted' => true]) : back()->with('status', 'Deleted.');
    }

    /** Delete the whole Ask AI history of the signed-in user. */
    public function clear(Request $request, AssistantService $assistant): JsonResponse|RedirectResponse
    {
        $count = $assistant->forgetAll($request->user());

        return $request->expectsJson() ? response()->json(['deleted' => $count]) : back()->with('status', 'All questions and answers were deleted.');
    }

    public function photo(Request $request, AiQuery $query): StreamedResponse
    {
        abort_unless($query->user_id === $request->user()->id && $query->photo_path && Storage::disk('local')->exists($query->photo_path), 404);

        return Storage::disk('local')->response($query->photo_path);
    }
}
