<?php

declare(strict_types=1);

namespace App\Http\Controllers\Shared;

use App\Enums\UserRole;
use App\Http\Controllers\Controller;
use App\Models\Listing;
use App\Models\LedgerEntry;
use App\Models\NotificationLog;
use App\Models\PayoutRequest;
use App\Models\Rating;
use App\Models\StorageBooking;
use App\Models\TourReview;
use App\Models\AuditLog;
use App\Services\IdentityService;
use App\Services\VerificationService;
use App\Services\WalletService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** S-43 notifications, S-44 profile, S-45 wallet, S-46 settings, S-47 help — for every role. */
class MeController extends Controller
{
    public function notifications(Request $request): View
    {
        $items = NotificationLog::query()->where('user_id', $request->user()->id)->latest()->limit(100)->get();
        NotificationLog::query()->where('user_id', $request->user()->id)->whereNull('read_at')->update(['read_at' => now()]);

        return view('me.notifications', compact('items'));
    }

    public function profile(Request $request): View
    {
        $user = $request->user();
        $avg = Rating::query()->where('ratee_id', $user->id)->avg('stars');
        $tourAvg = TourReview::query()->where('organiser_id', $user->id)->avg('stars');

        return view('me.profile', [
            'user' => $user, 'rating' => $avg === null ? null : round((float) $avg, 1), 'ratingCount' => Rating::query()->where('ratee_id', $user->id)->count(),
            'tourRating' => $tourAvg === null ? null : round((float) $tourAvg, 1), 'roles' => $user->roleAssignments->map(fn ($r) => UserRole::from($r->role)),
            'expert' => $user->hasRole(UserRole::Expert), 'docs' => \App\Models\VerificationDocument::query()->where('user_id', $user->id)->latest()->get(),
        ]);
    }

    /** ACC-03 for roles without their own identity page (land owner, warehouse owner, expert, trainer, trader). */
    public function identity(Request $request): View
    {
        return view('me.identity', ['user' => $request->user(), 'masked' => $request->user()->maskedNida()]);
    }

    public function verifyIdentity(Request $request, IdentityService $identity): RedirectResponse
    {
        $d = $request->validate(['nida_number' => ['required', 'digits:20']]);

        try {
            $identity->verifyNida($request->user(), $d['nida_number']);
        } catch (DomainException $e) {
            return back()->withErrors(['nida_number' => $e->getMessage()])->onlyInput();
        }

        return redirect()->route('me.profile')->with('status', 'Identity verified. You can now list and receive payouts.');
    }

    public function uploadDocument(Request $request, VerificationService $verification): RedirectResponse
    {
        $d = $request->validate(['kind' => ['required', 'in:id_document,business_licence,professional_certificate'], 'file' => ['required', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:8192']]);
        $verification->submit($request->user(), 'user', null, $d['kind'], $request->file('file'));

        return back()->with('status', 'Document sent for review.');
    }

    public function wallet(Request $request, WalletService $wallet): View
    {
        $user = $request->user();
        $entries = LedgerEntry::query()->whereIn('account', $wallet->accounts($user))->latest('created_at')->limit(100)->get();

        return view('me.wallet', [
            'balance' => $wallet->balance($user), 'entries' => $entries,
            'payouts' => PayoutRequest::query()->where('user_id', $user->id)->latest()->get(),
        ]);
    }

    public function payout(Request $request, WalletService $wallet): RedirectResponse
    {
        $d = $request->validate(['amount' => ['required', 'regex:/^\d{1,12}$/'], 'method' => ['required', 'in:mpesa,tigopesa,airtelmoney,halopesa,bank'], 'destination' => ['required', 'string', 'max:60']]);

        try {
            $wallet->requestPayout($request->user(), (int) $d['amount'] * 100, $d['method'], $d['destination']);
        } catch (DomainException $e) {
            return back()->withErrors(['payout' => $e->getMessage()])->withInput();
        }

        return back()->with('status', 'Payout requested. You will be paid after review.');
    }

    public function settings(Request $request): View
    {
        return view('me.settings', ['user' => $request->user()]);
    }

    public function updateSettings(Request $request): RedirectResponse
    {
        $d = $request->validate(['language' => ['required', 'in:sw,en'], 'name' => ['required', 'string', 'min:2', 'max:120']]);
        $request->user()->forceFill(['language' => $d['language'], 'name' => $d['name']])->save();
        $request->session()->put('locale', $d['language']);

        return back()->with('status', 'Settings saved.');
    }

    public function changePin(Request $request): RedirectResponse
    {
        $d = $request->validate(['current_pin' => ['required', 'string'], 'pin' => ['required', 'string', 'min:8', 'max:64', 'confirmed']]);
        if (! Hash::check($d['current_pin'], (string) $request->user()->pin_hash)) {
            return back()->withErrors(['current_pin' => 'Your current PIN is wrong.']);
        }
        $request->user()->forceFill(['pin_hash' => $d['pin']])->save();

        return back()->with('status', 'PIN changed.');
    }

    /** NFR-C4: the user can download everything we hold about them. */
    public function export(Request $request): StreamedResponse
    {
        $u = $request->user();
        $data = [
            'user' => $u->only(['uuid', 'name', 'phone', 'language', 'status', 'verification_level', 'created_at']),
            'roles' => $u->roleAssignments->pluck('role'),
            'listings' => Listing::query()->where('user_id', $u->id)->get(['uuid', 'type', 'title', 'price_minor', 'status', 'created_at']),
            'orders' => \App\Models\Order::query()->where(fn ($q) => $q->where('buyer_id', $u->id)->orWhere('seller_id', $u->id))->get(['uuid', 'quantity', 'subtotal_minor', 'status', 'created_at']),
            'notifications' => NotificationLog::query()->where('user_id', $u->id)->get(['type', 'channel', 'content', 'created_at']),
        ];

        return response()->streamDownload(fn () => print(json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)), 'neas-my-data.json', ['Content-Type' => 'application/json']);
    }

    /** NFR-C4: delete my account. Personal data is removed; financial records stay as the law requires. */
    public function destroy(Request $request): RedirectResponse
    {
        $request->validate(['pin' => ['required', 'string']]);
        $u = $request->user();
        if (! Hash::check($request->input('pin'), (string) $u->pin_hash)) {
            return back()->withErrors(['pin' => 'Your PIN is wrong.']);
        }
        if (\App\Models\Order::query()->where(fn ($q) => $q->where('buyer_id', $u->id)->orWhere('seller_id', $u->id))->whereIn('status', ['pending', 'held', 'in_transit', 'delivered', 'disputed'])->exists()) {
            return back()->withErrors(['pin' => 'Finish your open orders before deleting your account.']);
        }
        AuditLog::record('user.deleted', $u, ['phone' => $u->phone], []);
        $u->forceFill(['name' => 'Deleted user', 'phone' => 'deleted-'.$u->id, 'nida_number' => null, 'nida_hash' => null, 'pin_hash' => null, 'status' => 'suspended'])->save();
        $u->delete();
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home')->with('status', 'Your account was deleted.');
    }

    public function help(): View
    {
        return view('me.help');
    }

    /** STO-04 (R2): printable storage receipt for the producer and the warehouse owner. */
    public function storageReceipt(Request $request, StorageBooking $booking): View
    {
        $booking->load('facilityListing.storage', 'facilityListing.owner', 'user');
        $uid = $request->user()->id;
        abort_unless($booking->receipt_no !== null && in_array($uid, [$booking->user_id, $booking->facilityListing->user_id], true), 404);

        return view('me.storage-receipt', ['b' => $booking]);
    }

    /** Verification documents are private to their owner and admins. */
    public function document(Request $request, \App\Models\VerificationDocument $document): StreamedResponse
    {
        abort_unless($document->user_id === $request->user()->id || $request->user()->hasRole(UserRole::Admin), 404);
        abort_unless(Storage::disk('local')->exists($document->path), 404);

        return Storage::disk('local')->response($document->path);
    }
}
