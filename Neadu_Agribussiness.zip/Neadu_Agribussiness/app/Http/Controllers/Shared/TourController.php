<?php

declare(strict_types=1);

namespace App\Http\Controllers\Shared;

use App\Http\Controllers\Controller;
use App\Models\Listing;
use App\Models\TourBooking;
use App\Models\TourReview;
use App\Services\TourService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;

/** S-28 tours for attendees (TUR-02/04). */
class TourController extends Controller
{
    public function index(): View
    {
        $tours = Listing::query()->with(['tour', 'owner', 'region'])->where('type', 'tour')->where('status', 'active')
            ->whereHas('tour', fn ($q) => $q->where('state', 'scheduled')->where('starts_at', '>', now()))->get()->sortBy(fn ($l) => $l->tour->starts_at);

        return view('tours.index', compact('tours'));
    }

    public function show(Listing $listing, TourService $service): View
    {
        abort_unless($listing->type->value === 'tour' && $listing->status === 'active', 404);
        $listing->load(['tour', 'owner', 'region']);

        return view('tours.show', ['listing' => $listing, 'free' => $service->freeSeats($listing),
            'rating' => ($a = TourReview::query()->where('organiser_id', $listing->user_id)->avg('stars')) === null ? null : round((float) $a, 1)]);
    }

    public function book(Request $request, Listing $listing, TourService $service): RedirectResponse
    {
        $d = $request->validate(['seats' => ['required', 'integer', 'between:1,20']]);

        try {
            $b = $service->book($request->user(), $listing, (int) $d['seats']);
        } catch (DomainException $e) {
            return back()->withErrors(['tour' => $e->getMessage()]);
        }

        return redirect()->route('tours.mine')->with('status', 'Seats held for '.($b->tour->hold_minutes ?: TourService::HOLD_MINUTES).' minutes. Pay to confirm.');
    }

    public function mine(Request $request): View
    {
        return view('tours.mine', ['bookings' => TourBooking::query()->with(['tour.listing'])->where('user_id', $request->user()->id)->latest()->get()]);
    }

    public function pay(Request $request, TourBooking $booking, TourService $service): RedirectResponse
    {
        abort_unless($booking->user_id === $request->user()->id, 404);
        $d = $request->validate(['provider' => ['required', 'in:mpesa,tigopesa,airtelmoney,halopesa,bank'], 'phone' => ['required', 'regex:/^\+?[0-9]{9,15}$/']]);

        try {
            $service->pay($booking, $request->user(), $d['provider'], ltrim($d['phone'], '+'));
        } catch (DomainException $e) {
            return back()->withErrors(['tour' => $e->getMessage()]);
        }

        return back()->with('status', 'Payment received. Your seats are confirmed.');
    }

    public function rate(Request $request, TourBooking $booking): RedirectResponse
    {
        abort_unless($booking->user_id === $request->user()->id && $booking->status === 'completed' && $booking->certificate_no !== null, 404);
        $booking->loadMissing('tour.listing');
        $d = $request->validate(['stars' => ['required', 'integer', 'between:1,5'], 'comment' => ['nullable', 'string', 'max:500']]);
        TourReview::query()->firstOrCreate(['tour_booking_id' => $booking->id], ['tour_id' => $booking->tour_id, 'attendee_id' => $request->user()->id, 'organiser_id' => $booking->tour->listing->user_id, 'stars' => $d['stars'], 'comment' => $d['comment'] ?? null]);

        return back()->with('status', 'Thank you for rating this tour.');
    }

    /** TUR-03 certificate: print-ready page. */
    public function certificate(Request $request, TourBooking $booking): Response
    {
        abort_unless($booking->user_id === $request->user()->id && $booking->status === 'completed' && $booking->certificate_no !== null, 404);
        $booking->load('tour.listing.owner');

        return response(view('tours.certificate', ['b' => $booking, 'user' => $request->user()])->render(), 200, ['Content-Type' => 'text/html; charset=utf-8']);
    }
}
