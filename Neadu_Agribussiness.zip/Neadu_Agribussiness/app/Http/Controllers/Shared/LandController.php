<?php

declare(strict_types=1);

namespace App\Http\Controllers\Shared;

use App\Http\Controllers\Controller;
use App\Models\District;
use App\Models\LandEnquiry;
use App\Models\Listing;
use App\Models\Region;
use App\Services\NotificationService;
use App\Support\Money;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** S-25 land search, S-26 land detail (Verified badge, BR-08) and enquiries from buyers, producers and anyone else signed in. */
class LandController extends Controller
{
    public function index(Request $request): View
    {
        $f = $request->validate([
            'region_id' => ['nullable', 'integer'], 'district_id' => ['nullable', 'integer'], 'site_type' => ['nullable', 'in:farmland,factory,service_centre'],
            'tenure' => ['nullable', 'in:lease,sale'], 'min_acres' => ['nullable', 'numeric', 'min:0'], 'verified' => ['nullable', 'boolean'],
        ]);
        $lands = Listing::query()->with(['land', 'region', 'district', 'owner'])->where('type', 'land')->where('status', 'active')
            ->when($f['region_id'] ?? null, fn ($q, $v) => $q->where('region_id', $v))
            ->when($f['district_id'] ?? null, fn ($q, $v) => $q->where('district_id', $v))
            ->when($request->boolean('verified'), fn ($q) => $q->where('verified', true))
            ->whereHas('land', fn ($q) => $q->when($f['site_type'] ?? null, fn ($s, $v) => $s->where('site_type', $v))
                ->when($f['tenure'] ?? null, fn ($s, $v) => $s->where('tenure', $v))->when($f['min_acres'] ?? null, fn ($s, $v) => $s->where('size_acres', '>=', $v)))
            ->latest()->get();

        return view('land.index', ['lands' => $lands, 'f' => $f, 'regions' => Region::query()->orderBy('name')->get(), 'districts' => District::query()->orderBy('name')->get()]);
    }

    public function show(Listing $listing): View
    {
        abort_unless($listing->type->value === 'land' && ($listing->status === 'active' || $listing->user_id === auth()->id()), 404);
        $listing->load(['land', 'region', 'district', 'owner']);

        return view('land.show', ['l' => $listing, 'land' => $listing->land]);
    }

    public function enquire(Request $request, Listing $listing, NotificationService $notes): RedirectResponse
    {
        abort_unless($listing->type->value === 'land' && $listing->status === 'active', 404);
        if ($listing->user_id === $request->user()->id) {
            return back()->withErrors(['enquiry' => 'This is your own listing.']);
        }
        $d = $request->validate([
            'kind' => ['required', 'in:message,visit,offer'], 'message' => ['nullable', 'required_if:kind,message', 'string', 'max:1500'],
            'visit_on' => ['nullable', 'required_if:kind,visit', 'date', 'after:today'], 'offer' => ['nullable', 'required_if:kind,offer', 'regex:/^\d{1,12}(\.\d{1,2})?$/'],
        ]);
        $e = LandEnquiry::query()->create([
            'listing_id' => $listing->id, 'user_id' => $request->user()->id, 'kind' => $d['kind'], 'message' => $d['message'] ?? null,
            'visit_on' => $d['kind'] === 'visit' ? $d['visit_on'] : null, 'offer_minor' => $d['kind'] === 'offer' ? Money::fromMajor($d['offer'])->minor : null,
        ]);
        $label = ['message' => 'ujumbe', 'visit' => 'ombi la kutembelea', 'offer' => 'ofa'][$d['kind']];
        $notes->notify($listing->owner, 'land.enquiry', ['enquiry' => $e->uuid, 'message' => "Una {$label} jipya kwenye {$listing->title}."]);

        return redirect()->route('land.enquiries')->with('status', 'Sent to the land owner.');
    }

    public function mine(Request $request): View
    {
        return view('land.mine', ['items' => LandEnquiry::query()->with('listing')->where('user_id', $request->user()->id)->latest()->get()]);
    }
}
