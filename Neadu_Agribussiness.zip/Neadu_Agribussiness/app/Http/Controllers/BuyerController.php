<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\EscrowState;
use App\Enums\ListingType;
use App\Enums\UserRole;
use App\Models\AuditLog;
use App\Models\Crop;
use App\Models\Delivery;
use App\Models\District;
use App\Models\Dispute;
use App\Models\FeeRule;
use App\Models\Favourite;
use App\Models\Listing;
use App\Models\Order;
use App\Models\Payment;
use App\Models\PriceAlert;
use App\Models\PriceRecord;
use App\Models\Rating;
use App\Models\Region;
use App\Models\Market;
use App\Models\TrackingPoint;
use App\Models\User;
use App\Models\WantedRequest;
use App\Services\LedgerService;
use App\Services\PaymentService;
use App\Support\Money;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\View\View;

/** Role 2 - Buyer workspace: S-08, S-09, S-11, S-12, S-14, S-15, S-16, S-17/18, MKT-11, PRC-03. */
class BuyerController extends Controller
{
    private const OPEN_STATES = ['pending', 'held', 'in_transit', 'delivered', 'disputed'];

    /* ------------------------------------------------------------------ overview */

    public function dashboard(): View
    {
        $uid = auth()->id();
        $orders = Order::query()->where('buyer_id', $uid);
        $metrics = [
            ['label' => 'Open orders', 'value' => (clone $orders)->whereIn('status', self::OPEN_STATES)->count(), 'tone' => 'green'],
            ['label' => 'Awaiting your action', 'value' => (clone $orders)->where(fn ($q) => $q
                ->whereNotNull('counter_unit_price_minor')->where('status', 'pending')
                ->orWhere(fn ($p) => $p->where('status', 'pending')->whereNotNull('accepted_at'))
                ->orWhere('status', 'delivered'))->count(), 'tone' => 'gold'],
            ['label' => 'Funds in escrow', 'value' => Money::tzs((clone $orders)->whereIn('status', ['held', 'in_transit', 'delivered', 'disputed'])->get()->sum(fn (Order $o) => $o->total())), 'tone' => 'blue'],
            ['label' => 'Favourites', 'value' => Favourite::query()->where('user_id', $uid)->count(), 'tone' => 'gold'],
        ];
        $recent = Order::query()->with(['listing', 'seller'])->where('buyer_id', $uid)->latest()->limit(5)->get();

        return view('buyer.dashboard', compact('metrics', 'recent'));
    }

    /* ------------------------------------------------------------------ S-08 search */

    public function market(Request $request): View
    {
        $f = $request->validate([
            'q' => ['nullable', 'string', 'max:80'], 'crop' => ['nullable', 'integer'], 'region' => ['nullable', 'integer'],
            'district' => ['nullable', 'integer'], 'min_price' => ['nullable', 'numeric', 'min:0'], 'max_price' => ['nullable', 'numeric', 'min:0'],
            'min_qty' => ['nullable', 'numeric', 'min:0'], 'grade' => ['nullable', 'string', 'max:16'],
            'lat' => ['nullable', 'numeric', 'between:-90,90'], 'lng' => ['nullable', 'numeric', 'between:-180,180'], 'max_km' => ['nullable', 'numeric', 'min:1'],
            'sort' => ['nullable', 'in:newest,price_asc,price_desc,distance'],
        ]);

        $query = Listing::query()->with(['owner', 'produce.crop', 'produce.unit', 'region', 'district'])
            ->where('type', ListingType::Produce->value)->where('status', 'active');
        if (! empty($f['q'])) {
            $query->where('title', 'like', '%'.$f['q'].'%');
        }
        if (! empty($f['region'])) {
            $query->where('region_id', $f['region']);
        }
        if (! empty($f['district'])) {
            $query->where('district_id', $f['district']);
        }
        if (isset($f['min_price']) && $f['min_price'] !== '') {
            $query->where('price_minor', '>=', (int) round($f['min_price'] * 100));
        }
        if (isset($f['max_price']) && $f['max_price'] !== '') {
            $query->where('price_minor', '<=', (int) round($f['max_price'] * 100));
        }
        $query->whereHas('produce', function ($p) use ($f): void {
            if (! empty($f['crop'])) {
                $p->where('crop_id', $f['crop']);
            }
            if (! empty($f['grade'])) {
                $p->where('grade', $f['grade']);
            }
            if (isset($f['min_qty']) && $f['min_qty'] !== '') {
                $p->where('quantity', '>=', $f['min_qty']);
            }
        });

        $listings = $query->latest()->get();
        $hasPoint = isset($f['lat'], $f['lng']) && $f['lat'] !== '' && $f['lng'] !== '';
        foreach ($listings as $l) {
            $l->distance_km = ($hasPoint && $l->lat !== null && $l->lng !== null)
                ? round($this->haversine((float) $f['lat'], (float) $f['lng'], (float) $l->lat, (float) $l->lng), 1) : null;
        }
        if ($hasPoint && ! empty($f['max_km'])) {
            $listings = $listings->filter(fn ($l) => $l->distance_km !== null && $l->distance_km <= (float) $f['max_km']);
        }
        $listings = match ($f['sort'] ?? 'newest') {
            'price_asc' => $listings->sortBy('price_minor'),
            'price_desc' => $listings->sortByDesc('price_minor'),
            'distance' => $listings->sortBy(fn ($l) => $l->distance_km ?? PHP_INT_MAX),
            default => $listings,
        };
        $favourites = Favourite::query()->where('user_id', auth()->id())->pluck('listing_id')->all();

        return view('buyer.market', [
            'listings' => $listings->values(), 'f' => $f, 'favourites' => $favourites,
            'crops' => Crop::query()->orderBy('name_en')->get(), 'regions' => Region::query()->orderBy('name')->get(),
            'districts' => District::query()->orderBy('name')->get(),
        ]);
    }

    /* ------------------------------------------------------------------ S-09 listing detail */

    public function listing(Listing $listing): View
    {
        abort_unless($listing->type === ListingType::Produce && $listing->status === 'active', 404);
        $listing->load(['owner', 'produce.crop', 'produce.unit', 'region', 'district']);
        $seller = $listing->owner;
        $sellerRating = Rating::query()->where('ratee_id', $seller->id);
        $reference = $listing->produce
            ? PriceRecord::query()->where('crop_id', $listing->produce->crop_id)->latest('recorded_on')->first() : null;

        return view('buyer.listing', [
            'listing' => $listing, 'ratingAvg' => round((float) $sellerRating->avg('stars'), 1), 'ratingCount' => $sellerRating->count(),
            'isFavourite' => Favourite::query()->where(['user_id' => auth()->id(), 'listing_id' => $listing->id])->exists(),
            'reference' => $reference, 'feeBps' => $this->feeBps(),
        ]);
    }

    /* ------------------------------------------------------------------ favourites / wanted / alerts */

    public function toggleFavourite(Listing $listing): RedirectResponse
    {
        $key = ['user_id' => auth()->id(), 'listing_id' => $listing->id];
        $existing = Favourite::query()->where($key)->first();
        $existing ? $existing->delete() : Favourite::create($key);

        return back()->with('status', $existing ? 'Removed from favourites.' : 'Saved to favourites.');
    }

    public function favourites(): View
    {
        $items = Favourite::query()->with(['listing.owner', 'listing.produce.crop', 'listing.produce.unit', 'listing.region'])
            ->where('user_id', auth()->id())->latest()->get()->filter(fn ($f) => $f->listing !== null);

        return view('buyer.favourites', compact('items'));
    }

    public function wanted(): View
    {
        return view('buyer.wanted', [
            'requests' => WantedRequest::query()->with(['crop', 'region'])->where('user_id', auth()->id())->latest()->get(),
            'crops' => Crop::query()->orderBy('name_en')->get(), 'regions' => Region::query()->orderBy('name')->get(),
        ]);
    }

    public function storeWanted(Request $request): RedirectResponse
    {
        $d = $request->validate([
            'crop_id' => ['required', 'exists:crops,id'], 'region_id' => ['nullable', 'exists:regions,id'],
            'quantity' => ['required', 'numeric', 'gt:0'], 'max_price' => ['nullable', 'numeric', 'min:0'],
            'needed_by' => ['nullable', 'date', 'after_or_equal:today'], 'note' => ['nullable', 'string', 'max:500'],
        ]);
        WantedRequest::create([
            'user_id' => auth()->id(), 'crop_id' => $d['crop_id'], 'region_id' => $d['region_id'] ?? null, 'quantity' => $d['quantity'],
            'max_price_minor' => isset($d['max_price']) && $d['max_price'] !== null ? (int) round($d['max_price'] * 100) : null,
            'needed_by' => $d['needed_by'] ?? null, 'note' => $d['note'] ?? null,
        ]);

        return back()->with('status', 'Your wanted-to-buy request is posted.');
    }

    public function closeWanted(string $uuid): RedirectResponse
    {
        WantedRequest::query()->where('user_id', auth()->id())->where('uuid', $uuid)->firstOrFail()->update(['status' => 'closed']);

        return back()->with('status', 'Request closed.');
    }

    public function alerts(): View
    {
        $alerts = PriceAlert::query()->with(['crop', 'market'])->where('user_id', auth()->id())->latest()->get();
        $latest = [];
        foreach ($alerts as $a) {
            $latest[$a->id] = PriceRecord::query()->where('crop_id', $a->crop_id)
                ->when($a->market_id, fn ($q) => $q->where('market_id', $a->market_id))->latest('recorded_on')->first();
        }

        return view('buyer.alerts', [
            'alerts' => $alerts, 'latest' => $latest, 'crops' => Crop::query()->orderBy('name_en')->get(),
            'markets' => Market::query()->orderBy('name')->get(),
            'prices' => PriceRecord::query()->with(['crop', 'market'])->latest('recorded_on')->limit(12)->get(),
        ]);
    }

    public function storeAlert(Request $request): RedirectResponse
    {
        $d = $request->validate([
            'crop_id' => ['required', 'exists:crops,id'], 'market_id' => ['nullable', 'exists:markets,id'],
            'condition' => ['required', 'in:above,below'], 'threshold' => ['required', 'numeric', 'gt:0'],
            'channels' => ['required', 'array', 'min:1'], 'channels.*' => ['in:in_app,sms'],
        ]);
        PriceAlert::create([
            'user_id' => auth()->id(), 'crop_id' => $d['crop_id'], 'market_id' => $d['market_id'] ?? null, 'condition' => $d['condition'],
            'threshold_minor' => (int) round($d['threshold'] * 100), 'channels' => array_values($d['channels']),
        ]);

        return back()->with('status', 'Price alert created.');
    }

    public function deleteAlert(string $uuid): RedirectResponse
    {
        PriceAlert::query()->where('user_id', auth()->id())->where('uuid', $uuid)->firstOrFail()->delete();

        return back()->with('status', 'Price alert removed.');
    }

    /* ------------------------------------------------------------------ S-11 order */

    public function orders(Request $request): View
    {
        $filter = $request->query('status');
        $orders = Order::query()->with(['listing', 'seller'])->where('buyer_id', auth()->id())
            ->when($filter, fn ($q) => $q->where('status', $filter))->latest()->get();

        return view('buyer.orders', ['orders' => $orders, 'filter' => $filter]);
    }

    public function storeOrder(Request $request, Listing $listing): RedirectResponse
    {
        abort_unless($listing->type === ListingType::Produce && $listing->status === 'active', 404);
        abort_if($listing->user_id === auth()->id(), 403, 'You cannot buy your own listing.');
        $listing->load('produce');
        $available = (float) ($listing->produce?->quantity ?? 0);

        $d = $request->validate([
            'mode' => ['required', 'in:full,part'],
            'quantity' => ['required_if:mode,part', 'nullable', 'numeric', 'gt:0', 'max:'.$available],
            'delivery_option' => ['required', 'in:pickup,delivery'], 'note' => ['nullable', 'string', 'max:500'],
        ]);
        $qty = $d['mode'] === 'full' ? $available : (float) $d['quantity'];
        abort_if($qty <= 0, 422);
        $subtotal = (int) round($qty * $listing->price_minor);
        $fee = (new Money($subtotal))->percentBps($this->feeBps())->minor; // OPEN-Q2: fee charged to the buyer on top

        $order = Order::create([
            'buyer_id' => auth()->id(), 'seller_id' => $listing->user_id, 'listing_id' => $listing->id, 'quantity' => $qty,
            'unit_price_minor' => $listing->price_minor, 'subtotal_minor' => $subtotal, 'fee_minor' => $fee, 'currency' => $listing->currency,
            'delivery_option' => $d['delivery_option'], 'buyer_note' => $d['note'] ?? null,
            'accept_by' => now()->addHours((int) config('neas.accept_window_hours')),
        ]);
        AuditLog::record('order.created', $order, [], ['status' => 'pending', 'quantity' => $qty]);

        return redirect()->route('buyer.orders.show', $order)->with('status', 'Order sent. The producer has '.config('neas.accept_window_hours').' hours to respond.');
    }

    public function showOrder(string $uuid): View
    {
        $order = $this->myOrder($uuid);
        $order->load(['listing.produce.crop', 'listing.produce.unit', 'seller', 'delivery.points', 'delivery.transporter', 'dispute', 'ratings']);

        return view('buyer.order', [
            'order' => $order, 'myRating' => $order->ratings->firstWhere('rater_id', auth()->id()),
            'simulate' => (bool) config('neas.simulate_gateways'),
        ]);
    }

    /** MKT-04: buyer accepts the producer's counter-offer, or cancels while still pending. */
    public function respondCounter(Request $request, string $uuid): RedirectResponse
    {
        $order = $this->myOrder($uuid);
        abort_unless($order->status === EscrowState::Pending, 409);
        $action = $request->validate(['action' => ['required', 'in:accept,decline']])['action'];

        if ($action === 'decline') {
            $order->forceFill(['rejected_reason' => 'Cancelled by buyer'])->save();
            $order->transitionTo(EscrowState::Refunded); // nothing was paid yet, so this just closes the order

            return redirect()->route('buyer.orders')->with('status', 'Order cancelled.');
        }
        abort_if($order->counter_unit_price_minor === null, 409);

        $qty = (float) ($order->counter_quantity ?? $order->quantity);
        $subtotal = (int) round($qty * $order->counter_unit_price_minor);
        $order->forceFill([
            'quantity' => $qty, 'unit_price_minor' => $order->counter_unit_price_minor, 'subtotal_minor' => $subtotal,
            'fee_minor' => (new Money($subtotal))->percentBps($this->feeBps())->minor,
            'counter_unit_price_minor' => null, 'counter_quantity' => null, 'accepted_at' => now(),
        ])->save();
        AuditLog::record('order.counter_accepted', $order, [], ['subtotal_minor' => $subtotal]);

        return back()->with('status', 'Counter-offer accepted. You can now pay into escrow.');
    }

    /* ------------------------------------------------------------------ S-12 escrow payment */

    public function payForm(string $uuid): View|RedirectResponse
    {
        $order = $this->myOrder($uuid)->load(['listing', 'seller']);
        if (! $this->canPay($order)) {
            return redirect()->route('buyer.orders.show', $order)->with('error', 'This order is not ready for payment yet.');
        }

        return view('buyer.pay', compact('order'));
    }

    public function pay(Request $request, string $uuid, PaymentService $payments): RedirectResponse
    {
        $order = $this->myOrder($uuid);
        abort_unless($this->canPay($order), 409);
        $d = $request->validate([
            'provider' => ['required', 'in:mpesa,tigopesa,airtelmoney,halopesa,bank'],
            'phone' => ['required_unless:provider,bank', 'nullable', 'string', 'regex:/^\+?[0-9 ]{9,20}$/'],
            'bank_account' => ['required_if:provider,bank', 'nullable', 'string', 'max:40'],
        ]);

        try {
            // Phase 4: locked, idempotent, one open payment per order. Live mode charges the gateway and waits for the signed callback.
            $payment = $payments->start($order, $d['provider'], (string) ($d['phone'] ?? $d['bank_account']));
        } catch (\DomainException $e) {
            return redirect()->route('buyer.orders.show', $order)->with('error', $e->getMessage());
        }

        if ($payment->state === 'held') {
            return redirect()->route('buyer.orders.show', $order)->with('status', 'Payment received and held in escrow.');
        }

        return redirect()->route('buyer.orders.show', $order)->with('status', 'Payment request sent. Approve it on your phone; escrow starts when the provider confirms.');
    }

    /* ------------------------------------------------------------------ S-14 confirm receipt */

    public function confirm(string $uuid, LedgerService $ledger): RedirectResponse
    {
        $order = $this->myOrder($uuid);
        abort_unless(in_array($order->status, [EscrowState::Held, EscrowState::InTransit, EscrowState::Delivered], true), 409);

        try {
            $this->release($order, $ledger);
        } catch (\DomainException $e) {
            return redirect()->route('buyer.orders.show', $order)->with('error', $e->getMessage());
        }

        return redirect()->route('buyer.orders.show', $order)->with('status', 'Receipt confirmed. Payment released to the producer. Please rate them.');
    }

    /**
     * Shared by buyer confirmation and the 48h auto-confirm command (MKT-06).
     * Locks the order, does nothing if it was already released (no double payout) and refuses to pay out escrow that was never funded.
     */
    public function release(Order $order, LedgerService $ledger): void
    {
        DB::transaction(function () use ($order, $ledger): void {
            $order = Order::query()->lockForUpdate()->findOrFail($order->id);
            if ($order->status === EscrowState::Released) {
                return;
            }
            if (! in_array($order->status, [EscrowState::Held, EscrowState::InTransit, EscrowState::Delivered], true)) {
                throw new \DomainException('This order cannot be released in its current state.');
            }
            $funded = (int) \App\Models\LedgerEntry::query()->where('order_id', $order->id)->where('account', 'escrow')
                ->selectRaw('COALESCE(SUM(credit_minor),0) - COALESCE(SUM(debit_minor),0) AS b')->value('b');
            if ($funded < $order->total()) {
                throw new \DomainException('Escrow for this order is not fully funded. Contact support.');
            }

            while ($order->status !== EscrowState::Delivered) {
                $order->transitionTo($order->status === EscrowState::Held ? EscrowState::InTransit : EscrowState::Delivered);
            }
            $order->forceFill(['delivered_at' => $order->delivered_at ?? now()])->save();
            $order->transitionTo(EscrowState::Released);
            $ledger->post([
                ['account' => 'escrow', 'debit' => $order->total()],
                ['account' => 'seller:'.$order->seller_id, 'credit' => $order->subtotal_minor],
                ['account' => 'platform_fee', 'credit' => $order->fee_minor],
            ], $order->id, null, 'Escrow released');
            Payment::query()->where('order_id', $order->id)->where('state', 'held')->update(['state' => 'released']);
        });
    }

    /* ------------------------------------------------------------------ S-15 dispute */

    public function disputeForm(string $uuid): View|RedirectResponse
    {
        $order = $this->myOrder($uuid)->load(['listing', 'seller', 'dispute', 'delivery.points']);
        if ($order->dispute) {
            return view('buyer.dispute', ['order' => $order, 'dispute' => $order->dispute]);
        }
        if (! in_array($order->status, [EscrowState::Held, EscrowState::InTransit, EscrowState::Delivered], true)) {
            return redirect()->route('buyer.orders.show', $order)->with('error', 'A dispute can only be opened on paid, unreleased orders.');
        }

        return view('buyer.dispute', ['order' => $order, 'dispute' => null]);
    }

    public function openDispute(Request $request, string $uuid): RedirectResponse
    {
        $order = $this->myOrder($uuid);
        abort_unless(in_array($order->status, [EscrowState::Held, EscrowState::InTransit, EscrowState::Delivered], true), 409);
        abort_if($order->dispute()->exists(), 409);
        $d = $request->validate([
            'reason' => ['required', 'in:not_delivered,wrong_quantity,poor_quality,not_as_described,other'],
            'details' => ['required', 'string', 'min:10', 'max:1500'],
            'photos' => ['nullable', 'array', 'max:6'], 'photos.*' => ['file', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);
        $files = [];
        foreach ($request->file('photos', []) as $photo) {
            $files[] = $photo->store('disputes/'.$order->uuid, 'local'); // private: served only through disputePhoto()
        }

        DB::transaction(function () use ($order, $d, $files): void {
            Dispute::create([
                'order_id' => $order->id, 'opener_id' => auth()->id(), 'reason' => $d['reason'],
                'evidence' => ['details' => $d['details'], 'photos' => $files],
                'evidence_until' => now()->addDays(3), 'decide_by' => now()->addWeekdays(5), // BR-05
            ]);
            $order->transitionTo(EscrowState::Disputed); // funds stay frozen in escrow
        });

        return redirect()->route('buyer.orders.dispute', $order)->with('status', 'Dispute opened. Funds are frozen while NeAS reviews the evidence.');
    }

    /** Dispute photos are private: only the buyer who opened it (admins use their own route). Older photos may still sit on the public disk. */
    public function disputePhoto(string $uuid, int $index): \Symfony\Component\HttpFoundation\StreamedResponse
    {
        $order = $this->myOrder($uuid)->load('dispute');
        $path = $order->dispute?->evidence['photos'][$index] ?? null;
        abort_if($path === null, 404);
        $disk = \Illuminate\Support\Facades\Storage::disk('local')->exists($path) ? 'local' : 'public';
        abort_unless(\Illuminate\Support\Facades\Storage::disk($disk)->exists($path), 404);

        return \Illuminate\Support\Facades\Storage::disk($disk)->response($path);
    }

    /* ------------------------------------------------------------------ S-16 rating */

    public function rate(Request $request, string $uuid): RedirectResponse
    {
        $order = $this->myOrder($uuid);
        abort_unless($order->status === EscrowState::Released, 409); // BR-06: only after completion
        abort_if(Rating::query()->where(['order_id' => $order->id, 'rater_id' => auth()->id()])->exists(), 409);
        $d = $request->validate(['stars' => ['required', 'integer', 'between:1,5'], 'comment' => ['nullable', 'string', 'max:600']]);
        Rating::create(['order_id' => $order->id, 'rater_id' => auth()->id(), 'ratee_id' => $order->seller_id, 'stars' => $d['stars'], 'comment' => $d['comment'] ?? null]);

        return back()->with('status', 'Thank you. Your rating was saved.');
    }

    /* ------------------------------------------------------------------ S-17 / S-18 delivery */

    public function deliveryForm(string $uuid): View|RedirectResponse
    {
        $order = $this->myOrder($uuid)->load(['listing', 'delivery']);
        if ($order->delivery !== null) {
            return redirect()->route('buyer.orders.track', $order);
        }
        if (! in_array($order->status, [EscrowState::Pending, EscrowState::Held], true)) {
            return redirect()->route('buyer.orders.show', $order)->with('error', 'Delivery can only be requested before dispatch.');
        }
        $transporters = User::query()->whereHas('roleAssignments', fn ($q) => $q->where('role', UserRole::Transporter->value))
            ->where('status', 'active')->get()
            ->each(fn (User $u) => $u->setRelation('vehicles', \App\Models\Vehicle::query()->where('user_id', $u->id)->get()));

        return view('buyer.delivery', [
            'order' => $order, 'transporters' => $transporters,
            'pickup' => [$order->listing->lat ?? -6.1630, $order->listing->lng ?? 35.7516],
        ]);
    }

    public function requestDelivery(Request $request, string $uuid): RedirectResponse
    {
        $order = $this->myOrder($uuid)->load('listing');
        abort_if($order->delivery()->exists(), 409);
        abort_unless(in_array($order->status, [EscrowState::Pending, EscrowState::Held], true), 409);
        $d = $request->validate([
            'transporter_id' => ['required', 'integer'], 'vehicle_id' => ['nullable', 'integer'],
            'drop_lat' => ['required', 'numeric', 'between:-90,90'], 'drop_lng' => ['required', 'numeric', 'between:-180,180'],
        ]);
        $transporter = User::query()->whereHas('roleAssignments', fn ($q) => $q->where('role', UserRole::Transporter->value))->findOrFail($d['transporter_id']);
        $vehicle = isset($d['vehicle_id']) ? \App\Models\Vehicle::query()->where('user_id', $transporter->id)->findOrFail($d['vehicle_id']) : null;

        $pLat = (float) ($order->listing->lat ?? -6.1630);
        $pLng = (float) ($order->listing->lng ?? 35.7516);
        $km = $this->haversine($pLat, $pLng, (float) $d['drop_lat'], (float) $d['drop_lng']);
        $price = (int) (config('neas.delivery.base_minor') + round($km * config('neas.delivery.per_km_minor')));
        $code = (string) random_int(1000, 9999); // BR-09: handover code, stored hashed

        $delivery = Delivery::create([
            'order_id' => $order->id, 'transporter_id' => $transporter->id, 'vehicle_id' => $vehicle?->id,
            'pickup_lat' => $pLat, 'pickup_lng' => $pLng, 'drop_lat' => $d['drop_lat'], 'drop_lng' => $d['drop_lng'],
            'price_minor' => $price, 'status' => 'requested', 'delivery_code_hash' => Hash::make($code),
        ]);
        $order->update(['delivery_option' => 'delivery']);

        return redirect()->route('buyer.orders.track', $order)
            ->with('status', 'Delivery requested from '.$transporter->name.'.')
            ->with('delivery_code', $code);
    }

    public function track(string $uuid): View|RedirectResponse
    {
        $order = $this->myOrder($uuid)->load(['listing', 'delivery.points', 'delivery.transporter', 'delivery.vehicle']);
        if ($order->delivery === null) {
            return redirect()->route('buyer.orders.delivery', $order);
        }

        return view('buyer.track', ['order' => $order, 'delivery' => $order->delivery, 'simulate' => (bool) config('neas.simulate_gateways')]);
    }

    /* ------------------------------------------------------------------ demo-only counterpart actions */

    /**
     * Stand-in for the producer / transporter workspaces so the buyer flow can be exercised end to end.
     * Only available while config('neas.simulate_gateways') is true.
     */
    public function simulate(Request $request, string $uuid): RedirectResponse
    {
        abort_unless(config('neas.simulate_gateways'), 404);
        $order = $this->myOrder($uuid);
        $action = $request->validate(['action' => ['required', 'in:accept,reject,counter,ship,deliver,track']])['action'];

        match ($action) {
            'accept' => $order->status === EscrowState::Pending ? $order->forceFill(['accepted_at' => now()])->save() : null,
            'reject' => $this->simulateReject($order),
            'counter' => $order->status === EscrowState::Pending
                ? $order->forceFill(['counter_unit_price_minor' => (int) round($order->unit_price_minor * 0.95), 'accepted_at' => null])->save() : null,
            'ship' => $order->status === EscrowState::Held ? $order->transitionTo(EscrowState::InTransit) : null,
            'deliver' => $this->simulateDeliver($order),
            'track' => $this->simulateTrack($order),
        };

        return back()->with('status', 'Simulated producer/transporter action: '.$action);
    }

    private function simulateReject(Order $order): void
    {
        if ($order->status === EscrowState::Pending) {
            $order->forceFill(['rejected_reason' => 'Producer declined'])->save();
            $order->transitionTo(EscrowState::Refunded);
        }
    }

    private function simulateDeliver(Order $order): void
    {
        if ($order->status === EscrowState::InTransit) {
            $order->transitionTo(EscrowState::Delivered);
            $order->forceFill(['delivered_at' => now(), 'auto_release_at' => now()->addHours((int) config('neas.auto_confirm_hours'))])->save();
            Delivery::query()->where('order_id', $order->id)->update(['status' => 'delivered']);
        }
    }

    private function simulateTrack(Order $order): void
    {
        $d = $order->delivery;
        if ($d === null) {
            return;
        }
        $n = $d->points()->count();
        $t = min(1.0, ($n + 1) / 5);
        TrackingPoint::create([
            'delivery_id' => $d->id, 'recorded_at' => now(),
            'lat' => $d->pickup_lat + ($d->drop_lat - $d->pickup_lat) * $t, 'lng' => $d->pickup_lng + ($d->drop_lng - $d->pickup_lng) * $t,
        ]);
        if ($d->status === 'requested') {
            $d->update(['status' => 'in_transit']);
        }
    }

    /* ------------------------------------------------------------------ helpers */

    private function myOrder(string $uuid): Order
    {
        return Order::query()->where('buyer_id', auth()->id())->where('uuid', $uuid)->firstOrFail();
    }

    private function canPay(Order $order): bool
    {
        return $order->status === EscrowState::Pending && $order->accepted_at !== null && $order->counter_unit_price_minor === null;
    }

    private function feeBps(): int
    {
        return (int) (FeeRule::query()->where('key', 'platform_fee')->where('active', true)->value('bps') ?? 250);
    }

    private function haversine(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $r = 6371.0;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;

        return $r * 2 * atan2(sqrt($a), sqrt(1 - $a));
    }
}
