<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\UserRole;
use App\Models\AdvicePost;
use App\Models\AiCorrection;
use App\Models\AuditLog;
use App\Models\Consultation;
use App\Models\Crop;
use App\Models\DiagnosisCase;
use App\Models\ExpertReview;
use App\Models\FeatureFlag;
use App\Models\FeeRule;
use App\Models\LedgerEntry;
use App\Models\Payout;
use App\Models\Region;
use App\Models\RoleProfile;
use App\Models\User;
use App\Services\LedgerService;
use App\Support\Money;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

/** Role 3 - Expert workspace: S-37 case queue, advice, consultations, S-45 earnings, S-44 profile & badge. */
class ExpertController extends Controller
{
    public const DOMAINS = ['crop' => 'Crops', 'livestock' => 'Livestock', 'fisheries' => 'Fisheries'];

    /* ------------------------------------------------------------------ overview */

    public function dashboard(): View
    {
        $me = auth()->user();
        $stats = $this->stats($me);
        $metrics = [
            ['label' => 'New cases in queue', 'value' => $this->queueQuery($me)->count(), 'tone' => 'gold'],
            ['label' => 'My open cases', 'value' => DiagnosisCase::query()->where('expert_id', $me->id)->where('status', 'in_review')->count(), 'tone' => 'blue'],
            ['label' => 'Answered', 'value' => $stats['answered'], 'tone' => 'green'],
            ['label' => 'Available balance', 'value' => Money::tzs($this->balance($me->id)), 'tone' => 'green'],
        ];

        return view('expert.dashboard', [
            'metrics' => $metrics, 'badge' => $this->badge($me, $stats),
            'queue' => $this->queueQuery($me)->with('producer')->latest()->limit(5)->get(),
            'consultations' => Consultation::query()->with('producer')->where('expert_id', $me->id)->whereIn('status', ['requested', 'accepted'])->latest()->limit(4)->get(),
        ]);
    }

    /* ------------------------------------------------------------------ S-37 case queue */

    public function cases(Request $request): View
    {
        $me = auth()->user();
        $f = $request->validate(['tab' => ['nullable', 'in:new,mine,answered'], 'domain' => ['nullable', 'in:crop,livestock,fisheries'], 'q' => ['nullable', 'string', 'max:80']]);
        $tab = $f['tab'] ?? 'new';

        $query = match ($tab) {
            'mine' => DiagnosisCase::query()->where('expert_id', $me->id)->where('status', 'in_review'),
            'answered' => DiagnosisCase::query()->where('expert_id', $me->id)->where('status', 'answered'),
            default => $this->queueQuery($me),
        };
        $cases = $query->with(['producer'])
            ->when($f['domain'] ?? null, fn ($q, $d) => $q->where('domain', $d))
            ->when($f['q'] ?? null, fn ($q, $s) => $q->where(fn ($w) => $w->where('subject', 'like', "%{$s}%")->orWhere('result', 'like', "%{$s}%")))
            ->latest()->get();

        return view('expert.cases', [
            'cases' => $cases, 'tab' => $tab, 'f' => $f,
            'counts' => [
                'new' => $this->queueQuery($me)->count(),
                'mine' => DiagnosisCase::query()->where('expert_id', $me->id)->where('status', 'in_review')->count(),
                'answered' => DiagnosisCase::query()->where('expert_id', $me->id)->where('status', 'answered')->count(),
            ],
        ]);
    }

    public function showCase(string $uuid): View
    {
        $me = auth()->user();
        $case = DiagnosisCase::query()->with(['producer', 'corrections'])->where('uuid', $uuid)->firstOrFail();
        abort_unless($case->expert_id === $me->id || ($case->expert_id === null && $case->status === 'escalated'), 404);

        return view('expert.case', [
            'case' => $case, 'mine' => $case->expert_id === $me->id,
            'myCorrection' => $case->corrections->firstWhere('expert_id', $me->id),
            'feedbackEnabled' => $this->feedbackEnabled(),
            'fee' => (int) ($this->profileData($me)['fee_minor'] ?? 500_000),
            'consultation' => Consultation::query()->where('diagnosis_case_id', $case->id)->where('expert_id', $me->id)->latest()->first(),
        ]);
    }

    /** The case photo is private: only the assigned expert, or any expert while the case is still in the queue. */
    public function photo(string $uuid): StreamedResponse
    {
        $case = DiagnosisCase::query()->where('uuid', $uuid)->firstOrFail();
        abort_unless($case->expert_id === auth()->id() || ($case->expert_id === null && $case->status === 'escalated'), 404);
        abort_unless($case->photo_path && Storage::disk('local')->exists($case->photo_path), 404);

        return Storage::disk('local')->response($case->photo_path);
    }

    /** Take an escalated case. Atomic, so two experts cannot claim the same one. */
    public function claim(string $uuid): RedirectResponse
    {
        $case = DiagnosisCase::query()->where('uuid', $uuid)->firstOrFail();
        $won = DiagnosisCase::query()->whereKey($case->id)->whereNull('expert_id')->where('status', 'escalated')
            ->update(['expert_id' => auth()->id(), 'status' => 'in_review', 'claimed_at' => now(), 'ai_result' => $case->ai_result ?? $case->result]);
        if ($won === 0) {
            return redirect()->route('expert.cases')->with('error', 'Another expert already took this case.');
        }
        AuditLog::record('diagnosis.claimed', $case, ['status' => 'escalated'], ['status' => 'in_review']);

        return redirect()->route('expert.cases.show', $case)->with('status', 'Case assigned to you.');
    }

    /** DIA-03: reply to the producer, optionally correcting the AI result. */
    public function reply(Request $request, string $uuid): RedirectResponse
    {
        $case = $this->myCase($uuid);
        abort_unless(in_array($case->status, ['in_review', 'answered'], true), 409);
        $d = $request->validate(['expert_reply' => ['required', 'string', 'min:10', 'max:3000'], 'corrected_result' => ['nullable', 'string', 'max:160']]);

        $before = ['result' => $case->result, 'expert_reply' => $case->expert_reply];
        $case->forceFill([
            'expert_reply' => $d['expert_reply'], 'status' => 'answered', 'answered_at' => $case->answered_at ?? now(), 'replied_at' => now(),
            'result' => filled($d['corrected_result'] ?? null) ? $d['corrected_result'] : $case->result,
        ])->save();
        AuditLog::record('diagnosis.answered', $case, $before, ['result' => $case->result, 'expert_reply' => $case->expert_reply]);

        return redirect()->route('expert.cases.show', $case)->with('status', 'Your reply was sent to the producer.');
    }

    /** DIA-05 (R3): rate the AI result; stored for retraining. */
    public function aiFeedback(Request $request, string $uuid): RedirectResponse
    {
        abort_unless($this->feedbackEnabled(), 404);
        $case = $this->myCase($uuid);
        $d = $request->validate([
            'verdict' => ['required', 'in:correct,partial,incorrect'],
            'corrected_result' => ['required_unless:verdict,correct', 'nullable', 'string', 'max:160'], 'notes' => ['nullable', 'string', 'max:1000'],
        ]);
        AiCorrection::updateOrCreate(
            ['diagnosis_case_id' => $case->id, 'expert_id' => auth()->id()],
            ['ai_result' => $case->ai_result ?? $case->result, 'ai_confidence' => $case->confidence, 'verdict' => $d['verdict'],
                'corrected_result' => $d['verdict'] === 'correct' ? null : $d['corrected_result'], 'notes' => $d['notes'] ?? null, 'exported_at' => null]
        );

        return back()->with('status', 'Thank you. Your assessment will be used to improve the AI.');
    }

    /* ------------------------------------------------------------------ advice (publish) */

    /** Public advice feed (/advice) for every signed-in role. */
    public function feed(): View
    {
        return view('expert.feed', ['posts' => AdvicePost::query()->with(['expert', 'crop'])->where('status', 'published')->whereNotNull('published_at')->latest('published_at')->paginate(10)]);
    }


    public function advice(): View
    {
        return view('expert.advice', [
            'posts' => AdvicePost::query()->with('crop')->where('user_id', auth()->id())->latest()->get(),
            'verified' => auth()->user()->isIdentityVerified(),
        ]);
    }

    public function adviceForm(?string $uuid = null): View
    {
        $post = $uuid ? AdvicePost::query()->where('user_id', auth()->id())->where('uuid', $uuid)->firstOrFail() : null;

        return view('expert.advice-form', [
            'post' => $post, 'crops' => Crop::query()->orderBy('name_en')->get(), 'regions' => Region::query()->orderBy('name')->get(),
            'verified' => auth()->user()->isIdentityVerified(),
        ]);
    }

    public function saveAdvice(Request $request, ?string $uuid = null): RedirectResponse
    {
        $me = auth()->user();
        $d = $request->validate([
            'title' => ['required', 'string', 'max:160'], 'body' => ['required', 'string', 'min:30', 'max:8000'],
            'domain' => ['required', 'in:crop,livestock,fisheries'], 'crop_id' => ['nullable', 'exists:crops,id'], 'region_id' => ['nullable', 'exists:regions,id'],
            'language' => ['required', 'in:sw,en'], 'intent' => ['required', 'in:draft,publish'],
        ]);
        // Publishing needs a verified expert identity (ACC-05); drafts are always allowed.
        if ($d['intent'] === 'publish' && ! $me->isIdentityVerified()) {
            return back()->withInput()->withErrors(['intent' => 'Only verified experts can publish advice. Save it as a draft until your identity is verified.']);
        }
        $post = $uuid ? AdvicePost::query()->where('user_id', $me->id)->where('uuid', $uuid)->firstOrFail() : new AdvicePost(['user_id' => $me->id]);
        $publish = $d['intent'] === 'publish';
        $post->fill([
            'title' => $d['title'], 'body' => $d['body'], 'domain' => $d['domain'], 'crop_id' => $d['crop_id'] ?? null, 'region_id' => $d['region_id'] ?? null,
            'language' => $d['language'], 'status' => $publish ? 'published' : 'draft', 'published_at' => $publish ? ($post->published_at ?? now()) : null,
        ])->save();

        return redirect()->route('expert.advice')->with('status', $publish ? 'Advice published.' : 'Draft saved.');
    }

    public function toggleAdvice(string $uuid): RedirectResponse
    {
        $post = AdvicePost::query()->where('user_id', auth()->id())->where('uuid', $uuid)->firstOrFail();
        if ($post->status === 'draft' && ! auth()->user()->isIdentityVerified()) {
            return back()->with('error', 'Only verified experts can publish advice.');
        }
        $post->update($post->status === 'published' ? ['status' => 'draft', 'published_at' => null] : ['status' => 'published', 'published_at' => now()]);

        return back()->with('status', $post->status === 'published' ? 'Advice published.' : 'Advice unpublished.');
    }

    public function deleteAdvice(string $uuid): RedirectResponse
    {
        AdvicePost::query()->where('user_id', auth()->id())->where('uuid', $uuid)->firstOrFail()->delete();

        return back()->with('status', 'Advice deleted.');
    }

    /* ------------------------------------------------------------------ consultations */

    public function consultations(): View
    {
        return view('expert.consultations', [
            'items' => Consultation::query()->with(['producer', 'diagnosisCase'])->where('expert_id', auth()->id())->latest()->get(),
            'simulate' => (bool) config('neas.simulate_gateways'), 'feeBps' => $this->feeBps(),
        ]);
    }

    /** Expert offers a paid consultation to the producer of a case. */
    public function offerConsultation(Request $request, string $uuid): RedirectResponse
    {
        $case = $this->myCase($uuid);
        $d = $request->validate(['topic' => ['required', 'string', 'max:160'], 'mode' => ['required', 'in:chat,voice'], 'fee' => ['required', 'numeric', 'min:500', 'max:5000000']]);
        Consultation::create([
            'expert_id' => auth()->id(), 'producer_id' => $case->user_id, 'diagnosis_case_id' => $case->id, 'topic' => $d['topic'], 'mode' => $d['mode'],
            'fee_minor' => (int) round($d['fee'] * 100), 'status' => 'accepted',
        ]);

        return redirect()->route('expert.consultations')->with('status', 'Consultation offered. The producer pays into escrow to start.');
    }

    public function respondConsultation(Request $request, string $uuid): RedirectResponse
    {
        $c = $this->myConsultation($uuid);
        abort_unless($c->status === 'requested', 409);
        $action = $request->validate(['action' => ['required', 'in:accept,decline']])['action'];
        $c->update(['status' => $action === 'accept' ? 'accepted' : 'declined']);

        return back()->with('status', $action === 'accept' ? 'Consultation accepted. Waiting for the producer to pay into escrow.' : 'Consultation declined.');
    }

    /** Releases the escrowed fee to the expert (minus the platform fee, OPEN-Q2). */
    public function completeConsultation(string $uuid, LedgerService $ledger): RedirectResponse
    {
        $c = $this->myConsultation($uuid);
        abort_unless($c->status === 'accepted', 409);
        if ($c->payment_state !== 'held') {
            return back()->with('error', 'The producer has not paid into escrow yet.');
        }
        $platform = (new Money($c->fee_minor))->percentBps($this->feeBps())->minor;
        DB::transaction(function () use ($c, $ledger, $platform): void {
            $ledger->post([
                ['account' => 'escrow', 'debit' => $c->fee_minor],
                ['account' => 'expert:'.$c->expert_id, 'credit' => $c->fee_minor - $platform],
                ['account' => 'platform_fee', 'credit' => $platform],
            ], null, null, 'Consultation '.$c->uuid.' released');
            $c->update(['status' => 'completed', 'payment_state' => 'released', 'completed_at' => now()]);
        });

        return back()->with('status', 'Consultation completed. '.Money::tzs($c->fee_minor - $platform).' added to your balance.');
    }

    /** Demo stand-in for the producer app (request, pay, review). Only while simulate_gateways is on. */
    public function simulate(Request $request, LedgerService $ledger): RedirectResponse
    {
        abort_unless(config('neas.simulate_gateways'), 404);
        $d = $request->validate(['action' => ['required', 'in:request,pay,review'], 'uuid' => ['nullable', 'string']]);
        $me = auth()->user();

        if ($d['action'] === 'request') {
            $producer = DiagnosisCase::query()->where('expert_id', $me->id)->latest()->value('user_id')
                ?? User::query()->whereHas('roleAssignments', fn ($q) => $q->where('role', UserRole::Producer->value))->value('id');
            abort_if($producer === null, 422, 'No producer account exists to simulate a request.');
            Consultation::create(['expert_id' => $me->id, 'producer_id' => $producer, 'topic' => 'Pest control advice for my maize', 'mode' => 'chat',
                'fee_minor' => (int) ($this->profileData($me)['fee_minor'] ?? 500_000)]);

            return back()->with('status', 'Simulated: a producer requested a consultation.');
        }
        $c = $this->myConsultation((string) $d['uuid']);
        if ($d['action'] === 'pay' && $c->status === 'accepted' && $c->payment_state === 'unpaid') {
            DB::transaction(function () use ($c, $ledger): void {
                $ledger->post([['account' => 'producer:'.$c->producer_id, 'debit' => $c->fee_minor], ['account' => 'escrow', 'credit' => $c->fee_minor]], null, null, 'Consultation '.$c->uuid.' funded');
                $c->update(['payment_state' => 'held']);
            });
        }
        if ($d['action'] === 'review' && $c->status === 'completed' && ! ExpertReview::query()->where('consultation_id', $c->id)->exists()) {
            ExpertReview::create(['expert_id' => $c->expert_id, 'producer_id' => $c->producer_id, 'consultation_id' => $c->id, 'stars' => random_int(4, 5), 'comment' => 'Very helpful advice, thank you.']);
        }

        return back()->with('status', 'Simulated: '.$d['action']);
    }

    /* ------------------------------------------------------------------ S-45 earnings */

    public function earnings(): View
    {
        $me = auth()->user();
        $account = 'expert:'.$me->id;
        $entries = LedgerEntry::query()->where('account', $account)->latest('id')->limit(50)->get();

        return view('expert.earnings', [
            'balance' => $this->balance($me->id),
            'earned' => (int) LedgerEntry::query()->where('account', $account)->where('memo', 'like', 'Consultation%')->sum('credit_minor'),
            'pending' => Consultation::query()->where('expert_id', $me->id)->where('status', 'accepted')->where('payment_state', 'held')->get()
                ->sum(fn (Consultation $c) => $c->fee_minor - (new Money($c->fee_minor))->percentBps($this->feeBps())->minor),
            'entries' => $entries, 'payouts' => Payout::query()->where('user_id', $me->id)->latest()->limit(10)->get(),
            'phone' => $me->phone,
        ]);
    }

    public function payout(Request $request, LedgerService $ledger): RedirectResponse
    {
        $me = auth()->user();
        if (! $me->isIdentityVerified()) { // BR-01
            return back()->with('error', 'Payouts are available once your identity is verified.');
        }
        $d = $request->validate([
            'amount' => ['required', 'numeric', 'min:1000'], 'provider' => ['required', 'in:mpesa,tigopesa,airtelmoney,halopesa,bank'],
            'destination' => ['required', 'string', 'max:40'],
        ]);
        $amount = (int) round($d['amount'] * 100);

        $error = DB::transaction(function () use ($me, $amount, $d, $ledger): ?string {
            User::query()->whereKey($me->id)->lockForUpdate()->first(); // serialise concurrent payouts
            if ($amount > $this->balance($me->id)) {
                return 'That is more than your available balance.';
            }
            $payout = Payout::create(['user_id' => $me->id, 'amount_minor' => $amount, 'provider' => $d['provider'], 'destination' => $d['destination']]);
            $ledger->post([['account' => 'expert:'.$me->id, 'debit' => $amount], ['account' => 'payout_pending', 'credit' => $amount]], null, null, 'Payout '.$payout->uuid.' requested');
            if (config('neas.simulate_gateways')) {
                $ledger->post([['account' => 'payout_pending', 'debit' => $amount], ['account' => 'payouts', 'credit' => $amount]], null, null, 'Payout '.$payout->uuid.' paid');
                $payout->update(['state' => 'paid']);
            }

            return null;
        });

        return $error ? back()->withInput()->with('error', $error) : back()->with('status', config('neas.simulate_gateways') ? 'Payout sent to your account.' : 'Payout requested. It is sent after the provider confirms.');
    }

    /* ------------------------------------------------------------------ S-44 profile, badge, ratings */

    public function profile(): View
    {
        $me = auth()->user();
        $stats = $this->stats($me);

        return view('expert.profile', [
            'me' => $me, 'data' => $this->profileData($me), 'stats' => $stats, 'badge' => $this->badge($me, $stats),
            'reviews' => ExpertReview::query()->with('producer')->where('expert_id', $me->id)->latest()->limit(20)->get(),
            'regions' => Region::query()->orderBy('name')->get(),
            'credentials' => $this->credentials($me),
        ]);
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        $me = auth()->user();
        $d = $request->validate([
            'specialties' => ['required', 'array', 'min:1'], 'specialties.*' => ['in:crop,livestock,fisheries'], 'bio' => ['nullable', 'string', 'max:800'],
            'years' => ['nullable', 'integer', 'between:0,60'], 'fee' => ['required', 'numeric', 'min:500', 'max:5000000'], 'region_id' => ['nullable', 'exists:regions,id'],
            'credentials' => ['nullable', 'array', 'max:5'], 'credentials.*' => ['file', 'mimes:pdf,jpg,jpeg,png', 'max:5120'],
        ]);
        $profile = RoleProfile::query()->firstOrNew(['user_id' => $me->id, 'role' => UserRole::Expert->value]);
        $business = is_array($profile->business) ? $profile->business : [];
        $profile->business = array_merge($business, [
            'specialties' => array_values($d['specialties']), 'bio' => $d['bio'] ?? null, 'years' => $d['years'] ?? null, 'fee_minor' => (int) round($d['fee'] * 100),
        ]);
        $profile->region_id = $d['region_id'] ?? $profile->region_id;

        $docs = $this->credentials($me);
        foreach ($request->file('credentials', []) as $file) {
            $docs[] = $file->store('credentials/'.$me->uuid, 'local'); // private disk, never public
        }
        $profile->documents = json_encode($docs);
        $profile->save();

        return back()->with('status', 'Profile saved.'.($request->hasFile('credentials') ? ' Your credentials were submitted for review.' : ''));
    }

    /* ------------------------------------------------------------------ helpers */

    private function queueQuery(User $me)
    {
        $specialties = $this->profileData($me)['specialties'] ?? null;

        return DiagnosisCase::query()->whereNull('expert_id')->where('status', 'escalated')
            ->when($specialties, fn ($q, $s) => $q->whereIn('domain', $s));
    }

    private function myCase(string $uuid): DiagnosisCase
    {
        return DiagnosisCase::query()->where('expert_id', auth()->id())->where('uuid', $uuid)->firstOrFail();
    }

    private function myConsultation(string $uuid): Consultation
    {
        return Consultation::query()->where('expert_id', auth()->id())->where('uuid', $uuid)->firstOrFail();
    }

    /** @return array<string, mixed> */
    private function profileData(User $u): array
    {
        $b = RoleProfile::query()->where('user_id', $u->id)->where('role', UserRole::Expert->value)->value('business');
        $b = is_string($b) ? json_decode($b, true) : $b;

        return is_array($b) ? $b : [];
    }

    /** @return list<string> */
    private function credentials(User $u): array
    {
        $p = RoleProfile::query()->where('user_id', $u->id)->where('role', UserRole::Expert->value)->first();
        $docs = $p?->documents ? json_decode((string) $p->documents, true) : [];

        return is_array($docs) ? array_values($docs) : [];
    }

    /** @return array{answered:int, reviews:int, avg:float, consultations:int} */
    private function stats(User $u): array
    {
        $reviews = ExpertReview::query()->where('expert_id', $u->id);

        return [
            'answered' => DiagnosisCase::query()->where('expert_id', $u->id)->where('status', 'answered')->count(),
            'reviews' => $reviews->count(), 'avg' => round((float) $reviews->avg('stars'), 1),
            'consultations' => Consultation::query()->where('expert_id', $u->id)->where('status', 'completed')->count(),
        ];
    }

    /** ACC-05 badge: needs a verified identity; higher tiers are earned from answered cases and ratings. */
    private function badge(User $u, array $s): array
    {
        if (! $u->isIdentityVerified()) {
            return ['label' => 'Not verified', 'tone' => 'muted', 'hint' => 'Complete identity verification to earn the Verified expert badge and publish advice.'];
        }
        if ($s['answered'] >= 50 && $s['reviews'] >= 10 && $s['avg'] >= 4.5) {
            return ['label' => 'Top expert', 'tone' => 'gold', 'hint' => 'Top tier: 50+ answered cases and 4.5★ or better.'];
        }
        if ($s['answered'] >= 10 && $s['reviews'] >= 3 && $s['avg'] >= 4.0) {
            return ['label' => 'Trusted expert', 'tone' => 'green', 'hint' => 'Next: 50 answered cases and 4.5★ for Top expert.'];
        }

        return ['label' => 'Verified expert', 'tone' => 'green', 'hint' => 'Next: 10 answered cases and 4★ from 3 reviews for Trusted expert.'];
    }

    private function balance(int $userId): int
    {
        $row = LedgerEntry::query()->where('account', 'expert:'.$userId)->selectRaw('COALESCE(SUM(credit_minor),0) c, COALESCE(SUM(debit_minor),0) d')->first();

        return (int) $row->c - (int) $row->d;
    }

    private function feedbackEnabled(): bool
    {
        return app()->environment('local', 'testing') || (bool) FeatureFlag::query()->where('key', 'ai_feedback')->value('enabled');
    }

    private function feeBps(): int
    {
        return (int) (FeeRule::query()->where('key', 'platform_fee')->where('active', true)->value('bps') ?? 250);
    }
}
