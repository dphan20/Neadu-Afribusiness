<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\UserRole;
use App\Models\AuditLog;
use App\Models\Delivery;
use App\Models\Dispute;
use App\Models\Listing;
use App\Models\Order;
use App\Models\Region;
use App\Models\User;
use App\Models\UserRoleAssignment;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class AdminController extends Controller
{
    public function index(): View
    {
        $metrics = [
            ['label' => 'Registered users', 'value' => User::query()->count(), 'tone' => 'green'],
            ['label' => 'Active listings', 'value' => Listing::query()->where('status', 'active')->count(), 'tone' => 'blue'],
            ['label' => 'Open orders', 'value' => Order::query()->whereIn('status', ['pending', 'held', 'in_transit', 'disputed'])->count(), 'tone' => 'gold'],
            ['label' => 'Open disputes', 'value' => Dispute::query()->whereNull('decision')->count(), 'tone' => 'red'],
        ];
        // ADM-06: GMV (goods value of paid orders, TSh), delivery performance and dispute rate.
        $paid = Order::query()->whereNotIn('status', ['pending']);
        $orders = Order::query()->count();
        $deliveries = Delivery::query()->count();
        $metrics = array_merge($metrics, [
            ['label' => 'Orders (all time)', 'value' => $orders, 'tone' => 'blue'],
            ['label' => 'GMV, TSh (paid orders)', 'value' => intdiv((int) (clone $paid)->whereNotIn('status', ['refunded'])->sum('subtotal_minor'), 100), 'tone' => 'green'],
            ['label' => 'Deliveries completed, %', 'value' => $deliveries === 0 ? 0 : (int) round(100 * Delivery::query()->where('status', 'delivered')->count() / $deliveries), 'tone' => 'green'],
            ['label' => 'Dispute rate, % of orders', 'value' => $orders === 0 ? 0 : (int) round(100 * Dispute::query()->count() / $orders), 'tone' => 'red'],
            ['label' => 'Waiting for review', 'value' => Listing::query()->where('status', 'pending_review')->count(), 'tone' => 'gold'],
        ]);

        $recentUsers = User::query()->with('roleAssignments')->latest()->limit(6)->get();
        $recentAudit = AuditLog::query()->latest('created_at')->limit(6)->get();

        return view('admin.index', compact('metrics', 'recentUsers', 'recentAudit'));
    }

    public function users(Request $request): View
    {
        $filters = $request->validate([
            'q' => ['nullable', 'string', 'max:100'],
            'role' => ['nullable', Rule::in(array_map(static fn (UserRole $role): string => $role->value, UserRole::cases()))],
            'status' => ['nullable', Rule::in(['active', 'suspended'])],
        ]);

        $users = User::query()
            ->with('roleAssignments')
            ->when($filters['q'] ?? null, static fn (Builder $query, string $term) => $query->where(
                static fn (Builder $nested) => $nested->where('name', 'like', '%'.$term.'%')
                    ->orWhere('phone', 'like', '%'.$term.'%')
                    ->orWhere('email', 'like', '%'.$term.'%')
            ))
            ->when($filters['role'] ?? null, static fn (Builder $query, string $role) => $query->whereHas(
                'roleAssignments',
                static fn (Builder $roles) => $roles->where('role', $role)
            ))
            ->when($filters['status'] ?? null, static fn (Builder $query, string $status) => $query->where('status', $status))
            ->latest()
            ->paginate(15)
            ->withQueryString();

        $roleOptions = UserRole::cases();
        $counts = [
            'all' => User::query()->count(),
            'active' => User::query()->where('status', 'active')->count(),
            'suspended' => User::query()->where('status', 'suspended')->count(),
        ];

        return view('admin.users', compact('users', 'roleOptions', 'counts', 'filters'));
    }

    public function updateStatus(Request $request, User $user): RedirectResponse
    {
        $data = $request->validate([
            'status' => ['required', Rule::in(['active', 'suspended'])],
            'reason' => ['nullable', 'required_if:status,suspended', 'string', 'max:200'], // ADM-02: a suspension always records why
        ]);

        abort_if($user->is(auth()->user()) && $data['status'] === 'suspended', 422, 'You cannot suspend your own account.');

        if ($user->hasRole(UserRole::Admin) && $data['status'] === 'suspended') {
            $activeAdmins = User::query()
                ->where('status', 'active')
                ->whereHas('roleAssignments', static fn (Builder $query) => $query->where('role', UserRole::Admin->value))
                ->count();
            abort_if($activeAdmins <= 1, 422, 'The last active administrator cannot be suspended.');
        }

        $before = ['status' => $user->status, 'reason' => $user->suspension_reason];
        $user->forceFill(['status' => $data['status'], 'suspension_reason' => $data['status'] === 'suspended' ? $data['reason'] : null])->save();
        AuditLog::record('admin.user_status_changed', $user, $before, ['status' => $data['status'], 'reason' => $data['reason'] ?? null]);

        return back()->with('status', 'User status updated.');
    }

    public function assignRole(Request $request, User $user): RedirectResponse
    {
        $data = $request->validate([
            'role' => ['required', Rule::in(array_map(static fn (UserRole $role): string => $role->value, UserRole::cases()))],
        ]);

        $assignment = UserRoleAssignment::query()->firstOrCreate([
            'user_id' => $user->id,
            'role' => $data['role'],
        ]);

        if ($assignment->wasRecentlyCreated) {
            AuditLog::record('admin.user_role_assigned', $user, [], ['role' => $data['role']]);
        }

        return back()->with('status', 'Role assigned.');
    }

    public function removeRole(User $user, UserRoleAssignment $assignment): RedirectResponse
    {
        abort_unless($assignment->user_id === $user->id, 404);
        abort_if($user->roleAssignments()->count() <= 1, 422, 'Every account must retain at least one role.');
        abort_if($user->is(auth()->user()) && $assignment->role === UserRole::Admin->value, 422, 'You cannot remove your own administrator role.');
        if ($assignment->role === UserRole::Admin->value) {
            $activeAdmins = User::query()
                ->where('status', 'active')
                ->whereHas('roleAssignments', static fn (Builder $query) => $query->where('role', UserRole::Admin->value))
                ->count();
            abort_if($user->status === 'active' && $activeAdmins <= 1, 422, 'The last active administrator cannot be removed.');
        }

        $role = $assignment->role;
        DB::transaction(function () use ($assignment, $user, $role): void {
            $assignment->delete();
            AuditLog::record('admin.user_role_removed', $user, ['role' => $role], []);
        });

        return back()->with('status', 'Role removed.');
    }

    public function section(string $section): View
    {
        $screens = [
            'verification' => ['title' => 'Identity verification', 'description' => 'Review user identity-verification status.', 'columns' => ['Name', 'Phone', 'Level', 'Account status'], 'rows' => User::query()->where('verification_level', 'phone')->latest()->limit(100)->get()->map(static fn (User $user): array => [$user->name, $user->phone ?? $user->email, ucfirst($user->verification_level), ucfirst($user->status)])],
            'disputes' => ['title' => 'Disputes & escrow', 'description' => 'Monitor active disputes and their order references.', 'columns' => ['Dispute', 'Order', 'Reason', 'Evidence deadline', 'Decision'], 'rows' => Dispute::query()->with('order')->whereNull('decision')->latest()->limit(100)->get()->map(static fn (Dispute $dispute): array => ['#'.$dispute->id, '#'.$dispute->order_id, $dispute->reason, $dispute->evidence_until, 'Awaiting decision'])],
            'listings' => ['title' => 'Listing moderation', 'description' => 'Review submitted listings before publication.', 'columns' => ['Listing', 'Type', 'Owner', 'Status', 'Submitted'], 'rows' => Listing::query()->with('owner')->where('status', 'pending_review')->latest()->limit(100)->get()->map(static fn (Listing $listing): array => [$listing->title, ucfirst($listing->type->value), $listing->owner?->name ?? '—', ucfirst(str_replace('_', ' ', $listing->status)), $listing->created_at?->format('d-m-Y') ?? '—'])],
            'finance' => ['title' => 'Finance & reconciliation', 'description' => 'Ledger balances are shown as integer TZS minor units.', 'columns' => ['Account', 'Debits (minor TZS)', 'Credits (minor TZS)', 'Difference'], 'rows' => DB::table('ledger_entries')->select('account')->selectRaw('SUM(debit_minor) as debits, SUM(credit_minor) as credits')->groupBy('account')->orderBy('account')->limit(100)->get()->map(static fn (object $row): array => [$row->account, number_format((int) $row->debits), number_format((int) $row->credits), number_format((int) $row->debits - (int) $row->credits)])],
            'reference' => ['title' => 'Reference data', 'description' => 'Current configured regions and market coverage.', 'columns' => ['Region', 'Markets'], 'rows' => Region::query()->withCount('markets')->orderBy('name')->get()->map(static fn (Region $region): array => [$region->name, (string) $region->markets_count])],
            'reports' => ['title' => 'Platform reports', 'description' => 'Operational totals from registered users, listings and orders.', 'columns' => ['Measure', 'Current total'], 'rows' => collect([['Users', (string) User::query()->count()], ['Active listings', (string) Listing::query()->where('status', 'active')->count()], ['Orders', (string) Order::query()->count()], ['Open disputes', (string) Dispute::query()->whereNull('decision')->count()]])],
            'activity' => ['title' => 'Admin activity log', 'description' => 'Append-only record of administrative and workflow actions.', 'columns' => ['Time', 'Actor', 'Action', 'Target'], 'rows' => AuditLog::query()->with('actor')->latest('created_at')->limit(100)->get()->map(static fn (AuditLog $log): array => [$log->created_at?->format('d-m-Y H:i') ?? '—', $log->actor?->name ?? 'System', $log->action, class_basename($log->target_type).' #'.$log->target_id])],
        ];

        abort_unless(isset($screens[$section]), 404);
        $screen = $screens[$section];

        return view('admin.section', ['section' => $section, ...$screen]);
    }
}
