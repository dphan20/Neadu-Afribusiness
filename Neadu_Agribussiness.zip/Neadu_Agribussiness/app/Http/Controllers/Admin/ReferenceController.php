<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Category;
use App\Models\Crop;
use App\Models\District;
use App\Models\FeatureFlag;
use App\Models\FeeRule;
use App\Models\Market;
use App\Models\Region;
use App\Models\Unit;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** S-52 / ADM-05: crops, categories, units, regions, districts, markets and fee rules. Every change is audited (ADM-07). */
class ReferenceController extends Controller
{
    /** @return array<string, array{label: string, model: class-string, fields: array<string, array{label: string, type: string, rules: list<string>|string, options?: string}>, show: list<string>}> */
    private function entities(): array
    {
        return [
            'regions' => ['label' => 'Regions', 'model' => Region::class, 'show' => ['name'], 'fields' => ['name' => ['label' => 'Name', 'type' => 'text', 'rules' => 'required|string|max:80']]],
            'districts' => ['label' => 'Districts', 'model' => District::class, 'show' => ['name', 'region_id'], 'fields' => [
                'region_id' => ['label' => 'Region', 'type' => 'select', 'options' => 'regions', 'rules' => 'required|exists:regions,id'],
                'name' => ['label' => 'Name', 'type' => 'text', 'rules' => 'required|string|max:80'],
            ]],
            'markets' => ['label' => 'Markets', 'model' => Market::class, 'show' => ['name', 'region_id'], 'fields' => [
                'region_id' => ['label' => 'Region', 'type' => 'select', 'options' => 'regions', 'rules' => 'required|exists:regions,id'],
                'name' => ['label' => 'Name', 'type' => 'text', 'rules' => 'required|string|max:80'],
            ]],
            'categories' => ['label' => 'Categories', 'model' => Category::class, 'show' => ['slug', 'name_en', 'name_sw'], 'fields' => [
                'slug' => ['label' => 'Slug', 'type' => 'text', 'rules' => 'required|alpha_dash|max:40'], 'name_en' => ['label' => 'English name', 'type' => 'text', 'rules' => 'required|string|max:80'],
                'name_sw' => ['label' => 'Kiswahili name', 'type' => 'text', 'rules' => 'required|string|max:80'],
            ]],
            'crops' => ['label' => 'Crops, livestock and fish', 'model' => Crop::class, 'show' => ['slug', 'name_en', 'name_sw', 'category_id'], 'fields' => [
                'category_id' => ['label' => 'Category', 'type' => 'select', 'options' => 'categories', 'rules' => 'required|exists:categories,id'],
                'slug' => ['label' => 'Slug', 'type' => 'text', 'rules' => 'required|alpha_dash|max:40'], 'name_en' => ['label' => 'English name', 'type' => 'text', 'rules' => 'required|string|max:80'],
                'name_sw' => ['label' => 'Kiswahili name', 'type' => 'text', 'rules' => 'required|string|max:80'],
            ]],
            'units' => ['label' => 'Units', 'model' => Unit::class, 'show' => ['code', 'name_en', 'kg_factor_milli'], 'fields' => [
                'code' => ['label' => 'Code', 'type' => 'text', 'rules' => 'required|alpha_dash|max:16'], 'name_en' => ['label' => 'English name', 'type' => 'text', 'rules' => 'required|string|max:60'],
                'name_sw' => ['label' => 'Kiswahili name', 'type' => 'text', 'rules' => 'required|string|max:60'],
                'kg_factor_milli' => ['label' => 'Kilograms x 1000 (blank = not convertible)', 'type' => 'number', 'rules' => 'nullable|integer|min:1'],
            ]],
            'fee_rules' => ['label' => 'Fee rules', 'model' => FeeRule::class, 'show' => ['key', 'bps', 'min_minor', 'active'], 'fields' => [
                'key' => ['label' => 'Key (platform_fee)', 'type' => 'text', 'rules' => 'required|alpha_dash|max:60'],
                'bps' => ['label' => 'Fee in basis points (250 = 2.5%)', 'type' => 'number', 'rules' => 'required|integer|between:0,3000'],
                'min_minor' => ['label' => 'Minimum fee (minor units, 100 = TSh 1)', 'type' => 'number', 'rules' => 'nullable|integer|min:0'],
                'note' => ['label' => 'Note', 'type' => 'text', 'rules' => 'nullable|string|max:200'],
            ]],
        ];
    }

    public function index(Request $request, ?string $entity = null): View
    {
        $entities = $this->entities();
        $entity ??= 'regions';
        abort_unless(isset($entities[$entity]), 404);
        $def = $entities[$entity];
        $options = [];
        foreach ($def['fields'] as $f) {
            if (($f['type'] ?? '') === 'select') {
                $options[$f['options']] = $this->entities()[$f['options']]['model']::query()->orderBy('id')->get()->mapWithKeys(fn ($m) => [$m->id => $m->name ?? $m->name_en])->all();
            }
        }

        return view('admin.reference', [
            'entities' => $entities, 'entity' => $entity, 'def' => $def, 'rows' => $def['model']::query()->orderBy('id')->limit(500)->get(),
            'options' => $options, 'flags' => FeatureFlag::query()->orderBy('release')->orderBy('key')->get(),
        ]);
    }

    public function store(Request $request, string $entity): RedirectResponse
    {
        $def = $this->def($entity);
        $data = $request->validate($this->rules($def));
        $model = $def['model']::query()->create($data);
        AuditLog::record("reference.{$entity}.created", $model, [], $data);

        return back()->with('status', 'Added.');
    }

    public function update(Request $request, string $entity, int $id): RedirectResponse
    {
        $def = $this->def($entity);
        $model = $def['model']::query()->findOrFail($id);
        $data = $request->validate($this->rules($def));
        if ($entity === 'fee_rules') {
            $data['active'] = $request->boolean('active');
        }
        $before = $model->only(array_keys($data));
        $model->forceFill($data)->save();
        AuditLog::record("reference.{$entity}.updated", $model, $before, $data);

        return back()->with('status', 'Saved.');
    }

    public function destroy(string $entity, int $id): RedirectResponse
    {
        $model = $this->def($entity)['model']::query()->findOrFail($id);
        AuditLog::record("reference.{$entity}.deleted", $model, $model->getAttributes(), []);
        $model->delete();

        return back()->with('status', 'Removed (soft-deleted; existing records keep their link).');
    }

    public function toggleFlag(FeatureFlag $flag): RedirectResponse
    {
        $before = ['enabled' => $flag->enabled];
        $flag->forceFill(['enabled' => ! $flag->enabled])->save();
        AuditLog::record('feature_flag.toggled', $flag, $before, ['enabled' => $flag->enabled]);

        return back()->with('status', "{$flag->key} is now ".($flag->enabled ? 'on' : 'off').'.');
    }

    /** @return array{label: string, model: class-string, fields: array<string, mixed>, show: list<string>} */
    private function def(string $entity): array
    {
        $entities = $this->entities();
        abort_unless(isset($entities[$entity]), 404);

        return $entities[$entity];
    }

    /** @return array<string, string> */
    private function rules(array $def): array
    {
        return array_map(fn (array $f) => $f['rules'], $def['fields']);
    }
}
