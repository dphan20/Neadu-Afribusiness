<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Listing;
use App\Models\VerificationDocument;
use App\Services\NotificationService;
use App\Services\VerificationService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** LND-03 / BR-08: admins review land documents and approve or reject submitted listings. */
class ReviewController extends Controller
{
    public function documents(): View
    {
        $docs = VerificationDocument::query()->with('user')->whereIn('subject_type', ['land', 'user'])
            ->orderByRaw("status = 'pending' desc")->latest()->limit(200)->get();
        $titles = Listing::query()->whereIn('id', $docs->where('subject_type', 'land')->pluck('subject_id'))->pluck('title', 'id');

        return view('admin.documents', compact('docs', 'titles'));
    }

    public function file(VerificationDocument $document): StreamedResponse
    {
        abort_unless(Storage::disk('local')->exists($document->path), 404);

        return Storage::disk('local')->response($document->path);
    }

    public function decideDocument(Request $request, VerificationDocument $document, VerificationService $service): RedirectResponse
    {
        $d = $request->validate(['decision' => ['required', 'in:approve,reject'], 'reason' => ['nullable', 'required_if:decision,reject', 'string', 'max:200']]);

        try {
            $service->decide($document, $request->user(), $d['decision'] === 'approve', $d['reason'] ?? null);
        } catch (DomainException $e) {
            return back()->withErrors(['review' => $e->getMessage()]);
        }

        return back()->with('status', 'Document '.($d['decision'] === 'approve' ? 'approved.' : 'rejected.'));
    }

    public function listings(): View
    {
        $items = Listing::query()->with(['owner', 'region'])->whereIn('type', ['storage', 'tour', 'land'])->where('status', 'pending_review')->latest()->get();
        $landDocs = VerificationDocument::query()->where('subject_type', 'land')->whereIn('subject_id', $items->pluck('id'))->latest()->get()->groupBy('subject_id');

        $active = Listing::query()->with('owner')->where('status', 'active')->latest()->limit(60)->get();

        return view('admin.review-listings', compact('items', 'landDocs', 'active'));
    }

    /** ADM-02: take down a prohibited or misleading active listing, with a recorded reason. */
    public function removeListing(Request $request, Listing $listing, NotificationService $notes): RedirectResponse
    {
        abort_unless(in_array($listing->status, ['active', 'paused', 'pending_review'], true), 404);
        $d = $request->validate(['reason' => ['required', 'string', 'min:5', 'max:200']]);
        $before = ['status' => $listing->status];
        $listing->forceFill(['status' => 'removed', 'moderation_note' => $d['reason'], 'verified' => false])->save();
        AuditLog::record('listing.removed', $listing, $before, ['reason' => $d['reason']]);
        $notes->notify($listing->owner, 'listing.removed', ['listing' => $listing->uuid, 'message' => "Tangazo lako {$listing->title} limeondolewa: {$d['reason']}"]);

        return back()->with('status', 'Listing removed.');
    }

    public function decideListing(Request $request, Listing $listing, NotificationService $notes): RedirectResponse
    {
        abort_unless($listing->status === 'pending_review', 404);
        $d = $request->validate(['decision' => ['required', 'in:approve,reject'], 'reason' => ['nullable', 'required_if:decision,reject', 'string', 'max:200']]);

        if ($d['decision'] === 'approve') {
            // BR-08: land only becomes Verified through an approved title document.
            if ($listing->type->value === 'land' && ! VerificationDocument::query()->where('subject_type', 'land')->where('subject_id', $listing->id)->where('status', 'approved')->exists()) {
                return back()->withErrors(['review' => 'Approve the land title document first. Land is verified through its document.']);
            }
            $listing->forceFill(['status' => 'active', 'moderation_note' => null, 'verified' => true, 'verified_at' => now(), 'verified_by' => $request->user()->id])->save();
        } else {
            $listing->forceFill(['status' => 'rejected', 'moderation_note' => $d['reason'], 'verified' => false])->save();
        }
        AuditLog::record('listing.'.$d['decision'], $listing, [], ['reason' => $d['reason'] ?? null]);
        $notes->notify($listing->owner, 'listing.decided', ['listing' => $listing->uuid, 'message' => $d['decision'] === 'approve' ? "Tangazo lako {$listing->title} limekubaliwa." : "Tangazo lako {$listing->title} limekataliwa: {$d['reason']}"]);

        return back()->with('status', 'Listing '.($d['decision'] === 'approve' ? 'approved.' : 'rejected.'));
    }
}
