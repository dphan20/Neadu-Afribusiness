<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Enums\UserRole;
use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Models\AuditLog;
use App\Models\User;
use App\Support\Phone;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

/** Separate console sign-in (admin guard). Only accounts holding the Admin role can use it. */
class AdminAuthController extends Controller
{
    public function form(): View|RedirectResponse
    {
        if (Auth::guard('admin')->check()) {
            return redirect()->route('admin.dashboard');
        }

        return view('admin.login');
    }

    public function login(LoginRequest $request): RedirectResponse
    {
        $login = trim($request->validated('login'));
        $user = str_contains($login, '@')
            ? User::query()->where('email', mb_strtolower($login))->first()
            : User::query()->where(fn ($q) => $q->where('phone', Phone::normalize($login))->orWhere('phone', $login))->first();

        $isAdmin = $user !== null && $user->roleAssignments()->where('role', UserRole::Admin->value)->exists();
        $locked = $user?->locked_until !== null && $user->locked_until->isFuture();
        $fail = fn () => back()->withErrors(['login' => __('The email/phone number or password is incorrect.')])->onlyInput('login');

        if (! $isAdmin || $user->status !== 'active' || $locked || $user->pin_hash === null) {
            return $fail(); // same message for every cause, so the console does not reveal which accounts are admins
        }

        if (! Hash::check($request->validated('pin'), $user->pin_hash)) {
            $attempts = $user->failed_pin_attempts + 1;
            $lock = $attempts >= 5;
            $user->forceFill(['failed_pin_attempts' => $lock ? 0 : $attempts, 'locked_until' => $lock ? now()->addMinutes(15) : null])->save();

            return $fail();
        }

        $user->forceFill(['failed_pin_attempts' => 0, 'locked_until' => null])->save();

        Auth::shouldUse('admin');
        Auth::guard('admin')->login($user);
        $request->session()->regenerate();
        $request->session()->put('admin_last_seen', time());
        AuditLog::record('admin.sign_in', $user, [], ['ip' => $request->ip()]);

        return redirect()->intended(route('admin.dashboard'));
    }

    public function logout(): RedirectResponse
    {
        Auth::shouldUse('admin');
        $user = Auth::guard('admin')->user();
        if ($user !== null) {
            AuditLog::record('admin.sign_out', $user);
        }
        Auth::guard('admin')->logout();
        request()->session()->forget('admin_last_seen');
        request()->session()->regenerateToken();

        return redirect()->route('admin.login')->with('status', 'Signed out of the NeAS console.');
    }
}
