<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Enums\UserRole;
use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\RoleProfile;
use App\Models\User;
use App\Support\AdminScope;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

/** ADM-08: a super admin narrows each admin to support, verification or finance. */
class AdminAccessController extends Controller
{
    public function index(): View
    {
        $admins = User::query()->whereHas('roleAssignments', fn ($q) => $q->where('role', UserRole::Admin->value))->orderBy('name')->get()
            ->each(fn (User $u) => $u->setAttribute('scope', AdminScope::of($u)));

        return view('admin.admins', ['admins' => $admins, 'scopes' => AdminScope::SCOPES]);
    }

    public function update(Request $request, User $user): RedirectResponse
    {
        $d = $request->validate(['scope' => ['required', Rule::in(array_keys(AdminScope::SCOPES))]]);
        abort_unless($user->hasRole(UserRole::Admin), 404);
        if ($user->is($request->user()) && $d['scope'] !== 'super') {
            return back()->withErrors(['scope' => 'You cannot narrow your own access.']);
        }
        $before = ['scope' => AdminScope::of($user)];
        $profile = RoleProfile::query()->firstOrNew(['user_id' => $user->id, 'role' => UserRole::Admin->value]);
        $profile->forceFill(['business' => array_merge($profile->business ?? [], ['scope' => $d['scope']])])->save();
        AuditLog::record('admin.scope_changed', $user, $before, ['scope' => $d['scope']]);

        return back()->with('status', "{$user->name} is now {$d['scope']}.");
    }
}
