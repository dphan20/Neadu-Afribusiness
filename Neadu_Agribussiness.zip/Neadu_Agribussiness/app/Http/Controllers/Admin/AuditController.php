<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** ADM-07: who did what, when, with the before and after values. Read-only. */
class AuditController extends Controller
{
    public function index(Request $request): View
    {
        $q = AuditLog::query()->with('actor')->latest('created_at')->latest('id');
        if ($request->filled('action')) {
            $q->where('action', 'like', '%'.str_replace(['%', '_'], ['\%', '\_'], (string) $request->query('action')).'%');
        }
        if ($request->filled('actor')) {
            $q->where('actor_id', (int) $request->query('actor'));
        }

        return view('admin.audit', ['logs' => $q->paginate(50)->withQueryString()]);
    }
}
