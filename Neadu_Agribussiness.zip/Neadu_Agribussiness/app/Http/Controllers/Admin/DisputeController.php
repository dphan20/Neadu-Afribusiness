<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Dispute;
use App\Services\DisputeService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** S-50 / ADM-03 / BR-05: the dispute queue, with evidence, and the release / partial / refund decision. */
class DisputeController extends Controller
{
    public function index(): View
    {
        $open = Dispute::query()->with(['order.listing', 'order.buyer', 'order.seller', 'opener'])->whereNull('decision')->orderBy('decide_by')->get();
        $decided = Dispute::query()->with(['order.listing'])->whereNotNull('decision')->latest('decided_at')->limit(30)->get();

        return view('admin.disputes', compact('open', 'decided'));
    }

    public function show(Dispute $dispute, DisputeService $service): View
    {
        $dispute->load(['order.listing', 'order.buyer', 'order.seller', 'opener', 'order.delivery.points']);
        $order = $dispute->order;

        return view('admin.dispute', [
            'd' => $dispute, 'o' => $order, 'evidence' => $this->evidence($dispute),
            'splits' => ['release' => $service->split($order, 'release', null), 'refund' => $service->split($order, 'refund', null)],
            'limitTzs' => (int) config('neas.refund.two_person_above_tzs', 500_000),
        ]);
    }

    public function decide(Request $request, Dispute $dispute, DisputeService $service): RedirectResponse
    {
        $d = $request->validate([
            'decision' => ['required', 'in:release,partial,refund'], 'note' => ['required', 'string', 'min:5', 'max:1000'],
            'seller_share' => ['nullable', 'required_if:decision,partial', 'regex:/^\d{1,12}(\.\d{1,2})?$/'],
        ]);

        try {
            $result = $service->decide($dispute, $request->user(), $d['decision'], $d['decision'] === 'partial' ? Money::fromMajor($d['seller_share'])->minor : null, $d['note']);
        } catch (DomainException $e) {
            return back()->withErrors(['decision' => $e->getMessage()])->withInput();
        }

        return redirect()->route('admin.disputes')->with('status', $result === 'pending'
            ? 'This refund is above the two-person limit. A second admin must approve it under Finance before money moves.'
            : 'Decision recorded and the ledger updated.');
    }

    public function file(Dispute $dispute, int $index): StreamedResponse
    {
        $item = $this->evidence($dispute)['files'][$index] ?? null;
        abort_if($item === null || ! Storage::disk($item['disk'])->exists($item['path']), 404);

        return Storage::disk($item['disk'])->response($item['path']);
    }

    /** Evidence arrives in two shapes (buyer: details + photos on the public disk; producer: a list of private files). @return array{details: list<string>, files: list<array{path: string, name: string, disk: string}>} */
    private function evidence(Dispute $dispute): array
    {
        $raw = $dispute->evidence ?? [];
        $details = [];
        $files = [];
        if (isset($raw['details']) || isset($raw['photos'])) {
            $details[] = (string) ($raw['details'] ?? '');
            foreach ($raw['photos'] ?? [] as $p) {
                $files[] = ['path' => (string) $p, 'name' => basename((string) $p), 'disk' => Storage::disk('local')->exists((string) $p) ? 'local' : 'public']; // new photos are private; old ones may be public
            }
        } else {
            foreach ($raw as $item) {
                if (is_array($item) && isset($item['path'])) {
                    $files[] = ['path' => $item['path'], 'name' => $item['name'] ?? basename($item['path']), 'disk' => 'local'];
                }
            }
        }

        return ['details' => array_values(array_filter($details)), 'files' => $files];
    }
}
