<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Vehicle;
use App\Services\NotificationService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** LOG-01: the admin checks plate, licence and photo before a vehicle may take jobs. */
class VehicleVerificationController extends Controller
{
    public function index(): View
    {
        return view('admin.vehicles', [
            'vehicles' => Vehicle::query()->with('owner')->orderByRaw("verification_status = 'pending' desc")->latest('id')->limit(200)->get(),
        ]);
    }

    public function decide(Request $request, Vehicle $vehicle, NotificationService $notes): RedirectResponse
    {
        $data = $request->validate([
            'decision' => ['required', 'in:approve,reject'],
            'reason' => ['nullable', 'required_if:decision,reject', 'string', 'max:200'],
        ]);

        $before = ['verification_status' => $vehicle->verification_status];
        if ($data['decision'] === 'approve') {
            $vehicle->forceFill(['verification_status' => 'verified', 'verified_at' => now(), 'verified_by' => $request->user()->id, 'reject_reason' => null])->save();
            $message = 'Gari lako '.$vehicle->plate.' limethibitishwa. Unaweza kupokea kazi sasa.';
        } else {
            $vehicle->forceFill(['verification_status' => 'rejected', 'verified_at' => null, 'verified_by' => $request->user()->id, 'reject_reason' => $data['reason']])->save();
            $message = 'Gari lako '.$vehicle->plate.' halijakubaliwa: '.$data['reason'];
        }
        AuditLog::record('vehicle.'.$data['decision'], $vehicle, $before, ['verification_status' => $vehicle->verification_status]);
        $notes->notify($vehicle->owner, 'vehicle.verification', ['vehicle' => $vehicle->uuid, 'message' => $message]);

        return back()->with('status', 'Vehicle '.$vehicle->plate.' '.($data['decision'] === 'approve' ? 'verified' : 'rejected').'.');
    }
}
