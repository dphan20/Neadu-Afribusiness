<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\LedgerEntry;
use App\Models\PayoutRequest;
use App\Models\RefundApproval;
use App\Services\DisputeService;
use App\Services\ReconciliationService;
use App\Services\WalletService;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** S-50 / ADM-04: escrow balances, fees, payout requests, two-person refunds and statement reconciliation. */
class FinanceController extends Controller
{
    public function index(): View
    {
        $bal = fn (string $account): int => (int) (LedgerEntry::query()->where('account', $account)->selectRaw('COALESCE(SUM(credit_minor),0) - COALESCE(SUM(debit_minor),0) AS b')->value('b'));

        return view('admin.finance', [
            'escrow' => $bal('escrow'), 'fees' => $bal('platform_fee'), 'float' => $bal('platform:float'), 'pendingPayouts' => $bal('payout:pending'),
            'paidOut' => $bal('external:payout'),
            'payouts' => PayoutRequest::query()->with('user')->orderByRaw("status = 'requested' desc")->latest()->limit(50)->get(),
            'refunds' => RefundApproval::query()->with(['dispute.order.listing', 'requester', 'approver'])->orderByRaw("status = 'pending' desc")->latest()->limit(30)->get(),
        ]);
    }

    public function decidePayout(Request $request, PayoutRequest $payout, WalletService $wallet): RedirectResponse
    {
        $d = $request->validate(['decision' => ['required', 'in:paid,reject'], 'reason' => ['nullable', 'required_if:decision,reject', 'string', 'max:200']]);

        try {
            $wallet->decide($payout, $request->user(), $d['decision'] === 'paid', $d['reason'] ?? null);
        } catch (DomainException $e) {
            return back()->withErrors(['finance' => $e->getMessage()]);
        }

        return back()->with('status', $d['decision'] === 'paid' ? 'Payout marked as paid.' : 'Payout rejected; the money is back in the wallet.');
    }

    public function decideRefund(Request $request, RefundApproval $approval, DisputeService $service): RedirectResponse
    {
        $d = $request->validate(['decision' => ['required', 'in:approve,reject']]);

        try {
            $d['decision'] === 'approve' ? $service->approve($approval, $request->user()) : $service->reject($approval, $request->user());
        } catch (DomainException $e) {
            return back()->withErrors(['finance' => $e->getMessage()]);
        }

        return back()->with('status', $d['decision'] === 'approve' ? 'Refund approved and executed.' : 'Refund request rejected.');
    }

    public function reconcileForm(): View
    {
        return view('admin.reconcile', ['result' => null]);
    }

    public function reconcile(Request $request, ReconciliationService $service): View
    {
        $request->validate(['statement' => ['required', 'file', 'mimes:csv,txt', 'max:4096']]);

        return view('admin.reconcile', ['result' => $service->reconcile((string) file_get_contents($request->file('statement')->getRealPath()))]);
    }
}
