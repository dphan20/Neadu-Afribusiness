<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use App\Services\MessagingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

/** COM-01: the NeAS console inbox (admin guard). Staff can write to any active user and answer their support messages. */
class MessageController extends Controller
{
    public function __construct(private readonly MessagingService $messaging) {}

    public function index(Request $request): View
    {
        $admin = $request->user();
        $conversations = Conversation::query()->with(['participants.roleAssignments', 'lastMessage'])->withMax('messages', 'created_at')
            ->visibleTo($admin)->orderByDesc('messages_max_created_at')->get();

        return view('admin.messages.index', ['conversations' => $conversations, 'unread' => $this->messaging->unreadCounts($admin), 'messaging' => $this->messaging]);
    }

    public function compose(Request $request): View
    {
        $q = (string) $request->query('q', '');
        $role = (string) $request->query('role', '');

        return view('admin.messages.new', ['q' => $q, 'role' => $role, 'people' => $this->messaging->directory($request->user(), $q, $role), 'messaging' => $this->messaging]);
    }

    public function start(Request $request): RedirectResponse
    {
        $d = $request->validate(['user' => ['required', 'uuid'], 'body' => ['required', 'string', 'max:2000']]);
        $to = User::query()->where('uuid', $d['user'])->firstOrFail();
        if (! $this->messaging->canMessage($request->user(), $to)) {
            return back()->withErrors(['body' => 'You cannot message this person.'])->withInput();
        }

        $conversation = $this->messaging->direct($request->user(), $to);
        $this->messaging->send($conversation, $request->user(), $d['body']);

        return redirect()->route('admin.messages.show', $conversation);
    }

    public function show(Request $request, Conversation $conversation): View
    {
        $this->member($request, $conversation);
        $conversation->load(['participants.roleAssignments']);
        $conversation->markReadBy($request->user());

        return view('admin.messages.show', ['conversation' => $conversation, 'messaging' => $this->messaging]);
    }

    public function send(Request $request, Conversation $conversation): RedirectResponse
    {
        $this->member($request, $conversation);
        $d = $request->validate(['body' => ['required', 'string', 'max:2000']]);
        $this->messaging->send($conversation, $request->user(), $d['body']);

        return redirect()->route('admin.messages.show', $conversation);
    }

    public function file(Request $request, Message $message): StreamedResponse
    {
        $this->member($request, $message->conversation);
        abort_if($message->file_path === null, 404);
        $disk = Storage::disk('local')->exists($message->file_path) ? 'local' : 'public';
        abort_unless(Storage::disk($disk)->exists($message->file_path), 404);

        return Storage::disk($disk)->response($message->file_path);
    }

    private function member(Request $request, Conversation $conversation): void
    {
        abort_unless($conversation->hasParticipant($request->user()), 404);
    }
}
