<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Enums\ListingType;
use App\Models\AuditLog;
use App\Models\Contract;
use App\Models\FeatureFlag;
use App\Models\Listing;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

/** R3 contract offers: S-38 terms, S-39 OTP e-signature (CTR-01/02). */
class BuyerContractController extends Controller
{
    public function __construct()
    {
        // R3 feature flag (NFR-M3). Always available in local/testing so the flow can be reviewed.
        abort_unless(
            app()->environment('local', 'testing') || FeatureFlag::query()->where('key', 'contracts')->value('enabled'),
            404,
            'Contract offers are an R3 feature and are not enabled yet.'
        );
    }

    public function index(): View
    {
        $contracts = Contract::query()->with('seller')->where('buyer_id', auth()->id())->latest()->get();

        return view('buyer.contracts', compact('contracts'));
    }

    public function create(Request $request): View
    {
        $listing = $request->filled('listing')
            ? Listing::query()->with(['owner', 'produce.crop', 'produce.unit'])->where('type', ListingType::Produce->value)->where('uuid', $request->query('listing'))->firstOrFail()
            : null;

        return view('buyer.contract-create', compact('listing'));
    }

    public function store(Request $request): RedirectResponse
    {
        $d = $request->validate([
            'listing' => ['required', 'uuid'], 'quantity_kg' => ['required', 'numeric', 'gt:0'], 'deliveries' => ['required', 'integer', 'between:1,60'],
            'unit_price' => ['required', 'numeric', 'gt:0'], 'start_date' => ['required', 'date', 'after_or_equal:today'], 'end_date' => ['required', 'date', 'after:start_date'],
            'delivery_terms' => ['required', 'string', 'max:500'], 'penalty' => ['nullable', 'string', 'max:500'],
        ]);
        $listing = Listing::query()->with('produce.crop')->where('type', ListingType::Produce->value)->where('uuid', $d['listing'])->firstOrFail();
        abort_if($listing->user_id === auth()->id(), 403);

        $contract = Contract::create([
            'buyer_id' => auth()->id(), 'seller_id' => $listing->user_id, 'status' => 'offered',
            'terms' => [
                'listing_uuid' => $listing->uuid, 'listing_title' => $listing->title, 'crop' => $listing->produce?->crop?->name_en,
                'quantity_kg_per_delivery' => (float) $d['quantity_kg'], 'deliveries' => (int) $d['deliveries'],
                'unit_price_minor' => (int) round($d['unit_price'] * 100), 'start_date' => $d['start_date'], 'end_date' => $d['end_date'],
                'payment' => 'Escrow per delivery; released on buyer confirmation or 48h auto-confirm',
                'delivery_terms' => $d['delivery_terms'], 'penalty' => $d['penalty'] ?? null,
            ],
        ]);
        AuditLog::record('contract.offered', $contract, [], ['status' => 'offered']);

        return redirect()->route('buyer.contracts.show', $contract)->with('status', 'Contract offer created. Review the terms and sign with your OTP.');
    }

    public function show(string $uuid): View
    {
        $contract = $this->mine($uuid)->load('seller');

        return view('buyer.contract', ['contract' => $contract, 'signed' => isset($contract->signatures['buyer'])]);
    }

    public function sendOtp(string $uuid): RedirectResponse
    {
        $contract = $this->mine($uuid);
        abort_if(isset($contract->signatures['buyer']), 409);
        $otp = (string) random_int(100000, 999999);
        Cache::put($this->key($contract), Hash::make($otp), now()->addMinutes(10));
        Cache::forget($this->key($contract).':tries');

        // SMS delivery is wired in with the notification provider; until then the code is shown on screen in local/demo mode only.
        $back = back()->with('status', 'A 6-digit code was sent to your phone. It expires in 10 minutes.');

        return config('neas.simulate_gateways') ? $back->with('demo_otp', $otp) : $back;
    }

    public function sign(Request $request, string $uuid): RedirectResponse
    {
        $contract = $this->mine($uuid);
        abort_if(isset($contract->signatures['buyer']), 409);
        $d = $request->validate(['otp' => ['required', 'digits:6'], 'agree' => ['accepted']]);

        $tries = (int) Cache::get($this->key($contract).':tries', 0);
        if ($tries >= 5) {
            return back()->withErrors(['otp' => 'Too many attempts. Request a new code.']);
        }
        $hash = Cache::get($this->key($contract));
        if ($hash === null || ! Hash::check($d['otp'], $hash)) {
            Cache::put($this->key($contract).':tries', $tries + 1, now()->addMinutes(10));

            return back()->withErrors(['otp' => 'That code is wrong or has expired.']);
        }
        Cache::forget($this->key($contract));

        $signatures = $contract->signatures ?? [];
        $signatures['buyer'] = ['user_id' => auth()->id(), 'signed_at' => now()->toIso8601String(), 'ip' => $request->ip(), 'method' => 'otp'];
        $contract->forceFill([
            'signatures' => $signatures, 'status' => 'signed_buyer',
            'pdf_hash' => hash('sha256', json_encode($contract->terms, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)),
        ])->save();
        AuditLog::record('contract.signed_buyer', $contract, ['status' => 'offered'], ['status' => 'signed_buyer']);

        return back()->with('status', 'Signed. The producer must now counter-sign to activate the contract.');
    }

    private function mine(string $uuid): Contract
    {
        return Contract::query()->where('buyer_id', auth()->id())->where('uuid', $uuid)->firstOrFail();
    }

    private function key(Contract $c): string
    {
        return 'contract_otp:'.$c->uuid.':'.auth()->id();
    }
}
