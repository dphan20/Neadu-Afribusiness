<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use Illuminate\Http\Response;

/** robots.txt and sitemap.xml built from the real site address, so search engines index only the public pages. */
class SeoController extends Controller
{
    public function robots(): Response
    {
        $lines = [
            'User-agent: *',
            'Allow: /$',
            'Allow: /login',
            'Allow: /register',
            'Disallow: /me/',
            'Disallow: /admin',
            'Disallow: /api/',
            'Disallow: /dashboard',
            'Disallow: /workspace/',
            'Disallow: /producer',
            'Disallow: /buyer',
            'Disallow: /expert',
            'Disallow: /trainer',
            'Disallow: /transporter',
            'Disallow: /landowner',
            'Disallow: /warehouse',
            '',
            'Sitemap: '.url('/sitemap.xml'),
        ];

        return response(implode("\n", $lines)."\n", 200, ['Content-Type' => 'text/plain; charset=utf-8', 'Cache-Control' => 'public, max-age=3600']);
    }

    public function sitemap(): Response
    {
        $pages = [[route('home'), '1.0', 'weekly'], [route('register'), '0.6', 'monthly'], [route('login'), '0.4', 'monthly']];
        $xml = '<?xml version="1.0" encoding="UTF-8"?>'."\n".'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
        foreach ($pages as [$loc, $priority, $freq]) {
            $xml .= '  <url><loc>'.e($loc).'</loc><changefreq>'.$freq.'</changefreq><priority>'.$priority.'</priority></url>'."\n";
        }
        $xml .= '</urlset>'."\n";

        return response($xml, 200, ['Content-Type' => 'application/xml; charset=utf-8', 'Cache-Control' => 'public, max-age=3600']);
    }
}
