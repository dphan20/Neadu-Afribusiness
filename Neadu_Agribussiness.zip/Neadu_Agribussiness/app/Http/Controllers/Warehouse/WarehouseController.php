<?php

declare(strict_types=1);

namespace App\Http\Controllers\Warehouse;

use App\Enums\ListingType;
use App\Http\Controllers\Controller;
use App\Models\District;
use App\Models\Listing;
use App\Models\Region;
use App\Models\StorageBooking;
use App\Models\StorageFacility;
use App\Services\WarehouseService;
use App\Support\Money;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

/** Warehouse owner: S-24 manage facilities (STO-01), bookings (STO-03), receipts (STO-04), expiry (STO-05). */
class WarehouseController extends Controller
{
    public const TYPES = ['secure_warehouse' => 'Secure warehouse', 'port_storage' => 'Port storage', 'grain_storage' => 'Grain storage'];

    public const CONDITIONS = ['cold' => 'Cold storage', 'dry' => 'Dry / ventilated', 'fumigation' => 'Fumigation available'];

    public function facilities(Request $request): View
    {
        $facilities = Listing::query()->with(['storage', 'region'])->where('user_id', $request->user()->id)->where('type', 'storage')->latest()->get();
        $pending = StorageBooking::query()->whereIn('facility_listing_id', $facilities->pluck('id'))->where('status', 'requested')->selectRaw('facility_listing_id, COUNT(*) n')->groupBy('facility_listing_id')->pluck('n', 'facility_listing_id');

        return view('warehouse.facilities', compact('facilities', 'pending'));
    }

    public function form(Request $request, ?Listing $listing = null): View
    {
        if ($listing) {
            $this->own($request, $listing);
            $listing->load('storage');
        }

        return view('warehouse.form', [
            'listing' => $listing, 'facility' => $listing?->storage, 'types' => self::TYPES, 'conditions' => self::CONDITIONS,
            'regions' => Region::query()->orderBy('name')->get(), 'districts' => District::query()->orderBy('name')->get(),
        ]);
    }

    public function save(Request $request, ?Listing $listing = null): RedirectResponse
    {
        if ($listing) {
            $this->own($request, $listing);
        }
        $d = $request->validate([
            'title' => ['required', 'string', 'max:120'], 'facility_type' => ['required', 'in:'.implode(',', array_keys(self::TYPES))],
            'region_id' => ['required', 'exists:regions,id'], 'district_id' => ['required', 'exists:districts,id'],
            'lat' => ['nullable', 'numeric', 'between:-12,0'], 'lng' => ['nullable', 'numeric', 'between:29,41'],
            'capacity_kg' => ['required', 'numeric', 'gt:0', 'max:100000000'], 'rate' => ['required', 'regex:/^\d{1,9}(\.\d{1,2})?$/'],
            'conditions' => ['nullable', 'array'], 'conditions.*' => ['in:'.implode(',', array_keys(self::CONDITIONS))], 'security' => ['nullable', 'string', 'max:500'],
            'photos' => [$listing ? 'nullable' : 'required', 'array', 'max:6'], 'photos.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:5120'], 'submit' => ['nullable', 'boolean'],
        ]);
        $submit = ! empty($d['submit']);
        if ($submit && ! $request->user()->isIdentityVerified()) {
            return redirect()->route('me.identity')->with('status', 'Verify your identity (NIDA) before submitting a facility.');
        }

        $listing = DB::transaction(function () use ($request, $listing, $d, $submit): Listing {
            $base = [
                'title' => $d['title'], 'region_id' => $d['region_id'], 'district_id' => $d['district_id'], 'lat' => $d['lat'] ?? null, 'lng' => $d['lng'] ?? null,
                'price_minor' => Money::fromMajor($d['rate'])->minor, // per kg per day
            ];
            if ($listing === null) {
                $listing = Listing::query()->create($base + ['user_id' => $request->user()->id, 'type' => ListingType::Storage, 'status' => $submit ? 'pending_review' : 'draft', 'photos' => []]);
            } else {
                $listing->forceFill($base + ($submit && in_array($listing->status, ['draft', 'rejected'], true) ? ['status' => 'pending_review'] : []))->save();
            }
            $listing->forceFill(['photos' => array_merge($listing->photos ?? [], array_map(fn ($f) => $f->store("listings/{$listing->uuid}", 'public'), $request->file('photos', [])))])->save();
            StorageFacility::query()->updateOrCreate(['listing_id' => $listing->id], [
                'facility_type' => $d['facility_type'], 'capacity_kg' => $d['capacity_kg'], 'conditions' => array_values($d['conditions'] ?? []), 'security' => $d['security'] ?? null,
            ]);

            return $listing;
        });

        return redirect()->route('warehouse.facilities')->with('status', $listing->status === 'pending_review' ? 'Submitted for review.' : 'Saved.');
    }

    public function setStatus(Request $request, Listing $listing, string $to): RedirectResponse
    {
        $this->own($request, $listing);
        abort_unless(in_array($to, ['pause', 'resume', 'close'], true), 404);
        if ($to === 'pause' && $listing->status === 'active') {
            $listing->forceFill(['status' => 'paused'])->save();
        } elseif ($to === 'resume' && $listing->status === 'paused') {
            $listing->forceFill(['status' => 'active'])->save();
        } elseif ($to === 'close' && $listing->status !== 'closed') {
            if (StorageBooking::query()->where('facility_listing_id', $listing->id)->whereIn('status', ['requested', 'accepted'])->exists()) {
                return back()->withErrors(['facility' => 'Answer or finish the open bookings before closing this facility.']);
            }
            $listing->forceFill(['status' => 'closed'])->save();
        }

        return back()->with('status', 'Facility updated.');
    }

    /* ------------------------------------------------------------------ bookings */

    public function bookings(Request $request): View
    {
        $ids = Listing::query()->where('user_id', $request->user()->id)->where('type', 'storage')->pluck('id');
        $bookings = StorageBooking::query()->with(['facilityListing', 'user'])->whereIn('facility_listing_id', $ids)
            ->orderByRaw("status = 'requested' desc")->latest()->get();

        return view('warehouse.bookings', compact('bookings'));
    }

    public function accept(Request $request, StorageBooking $booking, WarehouseService $service): RedirectResponse
    {
        return $this->run(fn () => $service->accept($booking, $request->user()), 'Booking accepted.');
    }

    public function decline(Request $request, StorageBooking $booking, WarehouseService $service): RedirectResponse
    {
        $d = $request->validate(['reason' => ['required', 'string', 'max:200']]);

        return $this->run(fn () => $service->decline($booking, $request->user(), $d['reason']), 'Booking declined and the payment returned.');
    }

    public function receipt(Request $request, StorageBooking $booking, WarehouseService $service): RedirectResponse
    {
        $d = $request->validate(['produce_note' => ['required', 'string', 'max:160'], 'grade' => ['required', 'string', 'max:16']]);

        return $this->run(fn () => $service->issueReceipt($booking, $request->user(), $d['produce_note'], $d['grade']), 'Receipt issued.');
    }

    public function invoicePaid(Request $request, StorageBooking $booking, WarehouseService $service): RedirectResponse
    {
        return $this->run(fn () => $service->markInvoicePaid($booking, $request->user()), 'Invoice marked as paid.');
    }

    private function run(\Closure $action, string $ok): RedirectResponse
    {
        try {
            $action();
        } catch (DomainException $e) {
            return back()->withErrors(['booking' => $e->getMessage()]);
        }

        return back()->with('status', $ok);
    }

    private function own(Request $request, Listing $listing): void
    {
        abort_unless($listing->user_id === $request->user()->id && $listing->type->value === 'storage', 404);
    }
}
