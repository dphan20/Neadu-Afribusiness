<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;

/**
 * Shared-secret check for USSD/SMS aggregator callbacks.
 * With NEAS_USSD_SECRET unset the endpoints answer 503 everywhere except local/testing (fail closed).
 */
final class AggregatorSecret
{
    public static function check(Request $request): void
    {
        $secret = config('neas.ussd.secret');

        if ($secret === null || $secret === '') {
            abort_unless(app()->environment(['local', 'testing']), 503, 'Aggregator secret is not configured.');

            return;
        }

        abort_unless(hash_equals((string) $secret, (string) $request->header('X-NeAS-Secret')), 403);
    }
}
