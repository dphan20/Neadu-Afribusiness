<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\WebhookEvent;
use App\Services\PaymentService;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

/**
 * SRS 9.4: signed, idempotent payment callbacks.
 *
 * Body (JSON): {"event_id": "...", "reference": "<provider_ref or NeAS idempotency key>", "status": "successful|failed|cancelled", "amount_minor": 123400}
 * Header:      X-Neas-Signature = hex HMAC-SHA256 of the raw body, key NEAS_PAYMENT_WEBHOOK_SECRET.
 *
 * ADAPT THE SIGNATURE CHECK AND FIELD NAMES to the real provider's documentation before going live; the rest
 * (fail closed, constant-time compare, one-time event ids, amount check, locking) stays the same.
 */
final class PaymentWebhookController extends Controller
{
    public function __invoke(Request $request, string $provider, PaymentService $payments): JsonResponse
    {
        $secret = (string) config('neas.payments.webhook_secret');
        if ($secret === '') {
            return response()->json(['message' => 'Webhook is not configured.'], 503); // fail closed, never accept unsigned money events
        }

        $raw = $request->getContent();
        $given = strtolower(trim((string) $request->header('X-Neas-Signature', '')));
        if ($given === '' || ! hash_equals(hash_hmac('sha256', $raw, $secret), $given)) {
            Log::warning('Payment webhook with a bad signature', ['provider' => $provider, 'ip' => $request->ip()]);

            return response()->json(['message' => 'Invalid signature.'], 401);
        }

        $v = Validator::make((array) json_decode($raw, true), [
            'event_id' => ['required', 'string', 'max:120'],
            'reference' => ['required', 'string', 'max:120'],
            'status' => ['required', 'in:successful,failed,cancelled'],
            'amount_minor' => ['nullable', 'integer', 'min:0'],
        ]);
        if ($v->fails()) {
            return response()->json(['message' => 'Invalid payload.'], 422);
        }
        $data = $v->validated();

        try {
            $event = WebhookEvent::query()->firstOrCreate(['provider' => $provider, 'event_id' => $data['event_id']], ['payload' => $data]);
        } catch (UniqueConstraintViolationException) {
            return response()->json(['message' => 'Duplicate event.']); // two copies arrived at once
        }
        if ($event->processed_at !== null) {
            return response()->json(['message' => 'Duplicate event.']);
        }

        $payment = Payment::query()->where('provider_ref', $data['reference'])->orWhere('idempotency_key', $data['reference'])->first();
        if ($payment === null) {
            return response()->json(['message' => 'Unknown payment.'], 404); // not marked processed: the provider will retry
        }

        $payments->settle($payment, $data['status'], isset($data['amount_minor']) ? (int) $data['amount_minor'] : null, 'Provider reported '.$data['status']);
        $event->forceFill(['processed_at' => now()])->save();

        return response()->json(['message' => 'OK']);
    }
}
