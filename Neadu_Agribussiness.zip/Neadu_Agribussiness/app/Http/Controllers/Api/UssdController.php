<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\UssdMenu;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

/** FE-32 (R2): USSD callback (Africa's Talking format: phoneNumber, text -> "CON ..." / "END ..."). */
class UssdController extends Controller
{
    public function __invoke(Request $request, UssdMenu $menu): Response
    {
        AggregatorSecret::check($request);
        $d = $request->validate(['phoneNumber' => ['required', 'string', 'max:20'], 'text' => ['nullable', 'string', 'max:200']]);

        return response($menu->handle($d['phoneNumber'], (string) ($d['text'] ?? '')), 200, ['Content-Type' => 'text/plain; charset=utf-8']);
    }
}
