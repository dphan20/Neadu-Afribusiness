<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api;

use App\Contracts\SmsGateway;
use App\Http\Controllers\Controller;
use App\Services\SmsCommandService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/** FE-32 (R2): inbound SMS keywords. Replies in the response body and through the SMS gateway. */
class SmsController extends Controller
{
    public function __invoke(Request $request, SmsCommandService $commands, SmsGateway $gateway): JsonResponse
    {
        AggregatorSecret::check($request);
        $d = $request->validate(['from' => ['required', 'string', 'max:20'], 'text' => ['required', 'string', 'max:300']]);

        $reply = $commands->handle($d['from'], $d['text']);
        $gateway->send($d['from'], $reply);

        return response()->json(['reply' => $reply]);
    }
}
