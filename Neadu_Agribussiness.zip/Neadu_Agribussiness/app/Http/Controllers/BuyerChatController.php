<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Conversation;
use App\Models\Listing;
use App\Models\Order;
use App\Services\MessagingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** COM-01: chat attached to a listing, an order or a dispute. Only participants can read or write. */
class BuyerChatController extends Controller
{
    public function index(): View
    {
        $conversations = Conversation::query()->with(['participants', 'order.listing', 'listing', 'messages'])
            ->visibleTo(auth()->user())->latest('updated_at')->get();

        return view('buyer.chat-index', compact('conversations'));
    }

    public function show(string $uuid): View
    {
        $conversation = $this->mine($uuid)->load(['participants', 'order.listing', 'listing']);
        $conversation->markReadBy(auth()->user());

        return view('buyer.chat', compact('conversation'));
    }

    public function send(Request $request, string $uuid): RedirectResponse
    {
        $conversation = $this->mine($uuid);
        $d = $request->validate(['body' => ['required_without:photo', 'nullable', 'string', 'max:2000'], 'photo' => ['nullable', 'image', 'max:4096']]);
        app(MessagingService::class)->send($conversation, $request->user(), $d['body'] ?? null, null, $request->file('photo'));

        return redirect()->route('buyer.chat.show', $conversation)->withFragment('latest');
    }

    /** Start (or reopen) a conversation about a listing or an order. */
    public function start(Request $request): RedirectResponse
    {
        $d = $request->validate(['listing' => ['nullable', 'uuid'], 'order' => ['nullable', 'uuid']]);
        abort_if(empty($d['listing']) && empty($d['order']), 422);

        if (! empty($d['order'])) {
            $order = Order::query()->where('buyer_id', auth()->id())->where('uuid', $d['order'])->firstOrFail();
            $conversation = Conversation::query()->where('order_id', $order->id)->first()
                ?? Conversation::create(['order_id' => $order->id, 'listing_id' => $order->listing_id]);
            $sellerId = $order->seller_id;
        } else {
            $listing = Listing::query()->where('status', 'active')->where('uuid', $d['listing'])->firstOrFail();
            abort_if($listing->user_id === auth()->id(), 403);
            $conversation = Conversation::query()->whereNull('order_id')->where('listing_id', $listing->id)
                ->whereHas('participants', fn ($q) => $q->where('users.id', auth()->id()))->first()
                ?? Conversation::create(['listing_id' => $listing->id]);
            $sellerId = $listing->user_id;
        }
        $conversation->participants()->syncWithoutDetaching([auth()->id(), $sellerId]);

        return redirect()->route('buyer.chat.show', $conversation);
    }

    private function mine(string $uuid): Conversation
    {
        return Conversation::query()->where('uuid', $uuid)
            ->whereHas('participants', fn ($q) => $q->where('users.id', auth()->id()))->firstOrFail();
    }
}
