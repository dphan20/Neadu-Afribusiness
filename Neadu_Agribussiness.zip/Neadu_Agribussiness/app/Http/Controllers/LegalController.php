<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

/** Public legal pages: privacy, terms and cookies. English by default; ?lang=sw shows Kiswahili. */
class LegalController extends Controller
{
    public function show(Request $request, string $doc): View
    {
        abort_unless(in_array($doc, ['privacy', 'terms', 'cookies'], true), 404);

        $requested = $request->query('lang');
        $lang = $requested === 'sw' || ($requested === null && app()->getLocale() === 'sw') ? 'sw' : 'en';

        return view('legal.'.$doc, ['lang' => $lang]);
    }
}
