<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Enums\UserRole;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** `role:P` or `role:P,R` — the user must hold at least one of the listed roles. */
class RequireRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $codes = array_values(array_filter(array_map(fn (string $r) => UserRole::tryFrom($r)?->value, $roles)));

        abort_unless(
            $codes !== [] && $request->user()?->roleAssignments()->whereIn('role', $codes)->exists(),
            403
        );

        return $next($request);
    }
}
