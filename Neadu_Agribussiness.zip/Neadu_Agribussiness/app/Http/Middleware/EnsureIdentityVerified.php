<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Symfony\Component\HttpFoundation\Response;

/** BR-01 / ACC-03: selling, shipping and listing need a NIDA-verified identity. */
class EnsureIdentityVerified
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! $request->user()?->isIdentityVerified()) {
            $route = match (true) {
                $request->is('transporter/*') && Route::has('transporter.identity') => 'transporter.identity',
                $request->is('producer/*') && Route::has('producer.identity') => 'producer.identity',
                Route::has('me.identity') => 'me.identity',
                default => 'dashboard',
            };

            return redirect()->route($route)->with('status', 'Verify your identity (NIDA) to continue.');
        }

        return $next($request);
    }
}
