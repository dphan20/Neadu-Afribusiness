<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Enums\UserRole;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/**
 * The NeAS console is a separate sign-in: it runs on the `admin` guard, so a public-app session never opens it,
 * and an admin session never acts inside the public app. Also re-checks the account on every request and ends idle sessions.
 */
class EnsureAdminSession
{
    public function handle(Request $request, Closure $next): Response
    {
        Auth::shouldUse('admin'); // auth()->user(), $request->user() and AuditLog actor all resolve to the admin guard from here

        $guard = Auth::guard('admin');
        $user = $guard->user();
        $idle = (int) config('neas.admin.idle_minutes', 30);
        $last = (int) $request->session()->get('admin_last_seen', 0);

        $expired = $user !== null && $last > 0 && (time() - $last) > $idle * 60;
        $valid = $user !== null && $user->status === 'active' && $user->roleAssignments()->where('role', UserRole::Admin->value)->exists();

        if ($user === null || $expired || ! $valid) {
            if ($user !== null) {
                $guard->logout();
                $request->session()->forget('admin_last_seen');
            }

            return redirect()->route('admin.login')->withErrors([
                'login' => $expired ? __('Signed out after inactivity. Please sign in again.') : __('Please sign in to the NeAS console.'),
            ]);
        }

        $request->session()->put('admin_last_seen', time());

        return $next($request)->header('Cache-Control', 'no-store, private'); // never cache console pages
    }
}
