<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Browser-side defences for every response (OWASP A05). The app still uses a few inline <style>/<script> blocks,
 * so script/style keep 'unsafe-inline'; everything else is locked to this origin. Tighten with nonces once the
 * inline blocks move into Vite bundles.
 */
class SecurityHeaders
{
    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);

        // TECH-08: the live-tracking page opens a WebSocket to Reverb.
        $rt = (array) config('neas.realtime');
        $ws = ! empty($rt['enabled']) ? ' '.(($rt['scheme'] ?? 'http') === 'https' ? 'wss' : 'ws').'://'.$rt['host'].':'.$rt['port'] : '';

        $csp = implode('; ', [
            "default-src 'self'",
            "script-src 'self' 'unsafe-inline'".(app()->environment('local') ? ' http://127.0.0.1:5173 http://localhost:5173' : ''),
            "style-src 'self' 'unsafe-inline'".(app()->environment('local') ? ' http://127.0.0.1:5173 http://localhost:5173' : ''),
            "img-src 'self' data: blob: https://*.tile.openstreetmap.org",
            "font-src 'self' data:",
            "connect-src 'self'".$ws.(app()->environment('local') ? ' ws://127.0.0.1:5173 http://127.0.0.1:5173' : ''),
            "media-src 'self' blob:",
            "frame-src 'self' https://www.openstreetmap.org",
            "worker-src 'self'",
            "manifest-src 'self'",
            "object-src 'none'",
            "base-uri 'self'",
            "form-action 'self'",
            "frame-ancestors 'self'",
        ]);

        $headers = [
            'Content-Security-Policy' => $csp,
            'X-Content-Type-Options' => 'nosniff',
            'X-Frame-Options' => 'SAMEORIGIN',
            'Referrer-Policy' => 'strict-origin-when-cross-origin',
            // Camera, microphone and location are used by Ask AI, voice and tracking, but only from this origin.
            'Permissions-Policy' => 'camera=(self), microphone=(self), geolocation=(self), payment=(), usb=()',
            'Cross-Origin-Opener-Policy' => 'same-origin',
        ];
        if ($request->isSecure() && app()->isProduction()) {
            $headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
        }

        foreach ($headers as $name => $value) {
            if (! $response->headers->has($name)) {
                $response->headers->set($name, $value);
            }
        }
        $response->headers->remove('X-Powered-By');

        return $response;
    }
}
