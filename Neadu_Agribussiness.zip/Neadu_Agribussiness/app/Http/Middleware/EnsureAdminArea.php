<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Support\AdminScope;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** ADM-08: `area:finance` lets only admins whose scope covers that area through. */
class EnsureAdminArea
{
    public function handle(Request $request, Closure $next, string $area): Response
    {
        abort_unless(AdminScope::can($request->user(), $area), 403, 'Your admin scope does not include this area.');

        return $next($request);
    }
}
