<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Models\FeatureFlag;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** NFR-M3: R2/R3 features stay dark until their flag is on. Turn on with `php artisan neas:flag voice on`. */
class EnsureFeatureEnabled
{
    public function handle(Request $request, Closure $next, string $feature): Response
    {
        if (! FeatureFlag::isEnabled($feature)) {
            if ($request->expectsJson() || $request->is('api/*')) {
                abort(404);
            }

            return response()->view('producer.feature-off', ['feature' => $feature], 404);
        }

        return $next($request);
    }
}
