<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Enums\UserRole;
use App\Support\Phone;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\In;
use Illuminate\Validation\Rules\Password;

class RegisterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $email = trim((string) $this->input('email', ''));
        $phone = trim((string) $this->input('phone', ''));
        $normalized = Phone::normalize($phone);

        $this->merge([
            'email' => $email === '' ? null : mb_strtolower($email),
            // Keep the raw text when it has no digits so the format rule can report it.
            'phone' => $phone === '' ? null : ($normalized !== '' ? $normalized : $phone),
        ]);
    }

    /** @return array<string, array<int, string|In|Password>> */
    public function rules(): array
    {
        $roleValues = array_map(
            static fn (UserRole $role): string => $role->value,
            array_filter(UserRole::cases(), static fn (UserRole $role): bool => $role !== UserRole::Admin)
        );

        return [
            'name' => ['required', 'string', 'min:2', 'max:120'],
            // At least one of email / phone is required; the other is optional.
            'email' => ['nullable', 'required_without:phone', 'email:rfc', 'max:190', 'unique:users,email'],
            'phone' => ['nullable', 'required_without:email', 'regex:/^255[0-9]{9}$/', 'unique:users,phone'],
            // Any characters are allowed (letters, digits, symbols).
            'pin' => ['required', 'string', 'max:64', 'confirmed', Password::defaults()],
            'roles' => ['required', 'array', 'min:1', 'max:9'],
            'roles.*' => ['required', 'string', 'distinct', Rule::in($roleValues)],
        ];
    }

    /** @return array<string, string> */
    public function attributes(): array
    {
        return ['pin' => 'password', 'roles' => 'role', 'roles.*' => 'role'];
    }

    /** @return array<string, string> */
    public function messages(): array
    {
        return [
            'email.required_without' => 'Enter an email address or a phone number.',
            'phone.required_without' => 'Enter a phone number or an email address.',
            'phone.regex' => 'Enter a valid Tanzanian number, for example 0712 345 678 or +255 712 345 678.',
            'pin.confirmed' => 'The passwords do not match.',
            'roles.required' => 'Select at least one role.',
        ];
    }
}
