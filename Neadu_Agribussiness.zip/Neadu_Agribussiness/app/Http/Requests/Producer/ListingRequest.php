<?php

declare(strict_types=1);

namespace App\Http\Requests\Producer;

use App\Enums\ProduceCategory;
use App\Models\Crop;
use App\Models\District;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

/** MKT-01 (required) and MKT-02 (optional) listing fields. On create at least one photo is mandatory. */
class ListingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        $creating = $this->route('listing') === null;

        return [
            'crop_id' => ['required', 'integer', 'exists:crops,id'],
            'category' => ['required', Rule::in(array_map(fn (ProduceCategory $c) => $c->value, ProduceCategory::cases()))],
            'title' => ['nullable', 'string', 'max:120'],
            'region_id' => ['required', 'integer', 'exists:regions,id'],
            'district_id' => ['required', 'integer', 'exists:districts,id'],
            'quantity' => ['required', 'numeric', 'gt:0', 'max:99999999'],
            'unit_id' => ['required', 'integer', 'exists:units,id'],
            'price' => ['required', 'regex:/^\d{1,12}(\.\d{1,2})?$/'],
            'quality' => ['required', Rule::in(['premium', 'standard', 'economy'])],
            'lat' => ['nullable', 'numeric', 'between:-12,0'],
            'lng' => ['nullable', 'numeric', 'between:29,41'],
            'photos' => [$creating ? 'required' : 'nullable', 'array', 'max:6'],
            'photos.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'remove_photos' => ['nullable', 'array'],
            'remove_photos.*' => ['string'],
            'harvest_date' => ['nullable', 'date', 'before_or_equal:today'],
            'grade' => ['nullable', Rule::in(['A', 'B', 'C'])],
            'packaging' => ['nullable', 'string', 'max:120'],
            'min_order' => ['nullable', 'numeric', 'gt:0', 'lte:quantity'],
            'video' => ['nullable', 'file', 'mimetypes:video/mp4,video/webm,video/quicktime', 'max:30720'],
            'quality_notes' => ['nullable', 'string', 'max:1000'],
            'submit' => ['nullable', 'boolean'],
        ];
    }

    public function after(): array
    {
        return [function (Validator $v): void {
            $crop = Crop::query()->with('category')->find($this->input('crop_id'));
            if ($crop !== null && ProduceCategory::fromCategorySlug($crop->category->slug)->value !== $this->input('category')) {
                $v->errors()->add('category', 'The product does not belong to this category.');
            }
            if ($this->filled('district_id') && ! District::query()->whereKey($this->input('district_id'))->where('region_id', $this->input('region_id'))->exists()) {
                $v->errors()->add('district_id', 'The district is not in the selected region.');
            }
        }];
    }
}
