<?php

declare(strict_types=1);

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LoginRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        // Older clients post "phone"; the form now posts "login" (email or phone).
        if (! $this->filled('login') && $this->filled('phone')) {
            $this->merge(['login' => $this->input('phone')]);
        }
    }

    /** @return array<string, array<int, string>> */
    public function rules(): array
    {
        return [
            'login' => ['required', 'string', 'max:190'],
            'pin' => ['required', 'string', 'max:64'],
        ];
    }

    /** @return array<string, string> */
    public function attributes(): array
    {
        return ['login' => 'email or phone number', 'pin' => 'password'];
    }
}
