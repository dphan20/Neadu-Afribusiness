<?php

declare(strict_types=1);

namespace App\Enums;

/** MKT-01 produce category. Reference-data category slugs map onto these three. */
enum ProduceCategory: string
{
    case Crop = 'crop';
    case Livestock = 'livestock';
    case Fish = 'fish';

    public function label(): string
    {
        return match ($this) {
            self::Crop => 'Crop',
            self::Livestock => 'Livestock',
            self::Fish => 'Fish',
        };
    }

    public function swahiliLabel(): string
    {
        return match ($this) {
            self::Crop => 'Mazao',
            self::Livestock => 'Mifugo',
            self::Fish => 'Samaki',
        };
    }

    public static function fromCategorySlug(string $slug): self
    {
        return match ($slug) {
            'livestock' => self::Livestock,
            'fish' => self::Fish,
            default => self::Crop,
        };
    }
}
