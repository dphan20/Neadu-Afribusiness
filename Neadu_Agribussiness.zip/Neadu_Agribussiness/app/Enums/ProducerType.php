<?php

declare(strict_types=1);

namespace App\Enums;

/** Producer sub-types seeded for role P: farmer, livestock keeper, fisher. */
enum ProducerType: string
{
    case Farmer = 'farmer';
    case LivestockKeeper = 'livestock';
    case Fisher = 'fisher';

    public function label(): string
    {
        return match ($this) {
            self::Farmer => 'Farmer',
            self::LivestockKeeper => 'Livestock keeper',
            self::Fisher => 'Fisher',
        };
    }

    public function swahiliLabel(): string
    {
        return match ($this) {
            self::Farmer => 'Mkulima',
            self::LivestockKeeper => 'Mfugaji',
            self::Fisher => 'Mvuvi',
        };
    }

    public function defaultCategory(): ProduceCategory
    {
        return match ($this) {
            self::Farmer => ProduceCategory::Crop,
            self::LivestockKeeper => ProduceCategory::Livestock,
            self::Fisher => ProduceCategory::Fish,
        };
    }
}
