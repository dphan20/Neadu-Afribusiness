<?php

declare(strict_types=1);

namespace App\Enums;

/** WMO weather codes (as returned by Open-Meteo) grouped into labels the app can show in Kiswahili or English. */
enum WeatherCondition: string
{
    case Clear = 'clear';
    case MainlyClear = 'mainly_clear';
    case PartlyCloudy = 'partly_cloudy';
    case Overcast = 'overcast';
    case Fog = 'fog';
    case Drizzle = 'drizzle';
    case Rain = 'rain';
    case HeavyRain = 'heavy_rain';
    case FreezingRain = 'freezing_rain';
    case Snow = 'snow';
    case RainShowers = 'rain_showers';
    case Thunderstorm = 'thunderstorm';
    case Unknown = 'unknown';

    public static function fromCode(int $code): self
    {
        return match (true) {
            $code === 0 => self::Clear,
            $code === 1 => self::MainlyClear,
            $code === 2 => self::PartlyCloudy,
            $code === 3 => self::Overcast,
            in_array($code, [45, 48], true) => self::Fog,
            in_array($code, [51, 53, 55], true) => self::Drizzle,
            in_array($code, [61, 63], true) => self::Rain,
            $code === 65 => self::HeavyRain,
            in_array($code, [56, 57, 66, 67], true) => self::FreezingRain,
            $code >= 71 && $code <= 77, in_array($code, [85, 86], true) => self::Snow,
            in_array($code, [80, 81], true) => self::RainShowers,
            $code === 82 => self::HeavyRain,
            $code >= 95 && $code <= 99 => self::Thunderstorm,
            default => self::Unknown,
        };
    }

    /** WTH-02: heavy rain that warrants a warning on its own. */
    public function isHeavyRain(): bool
    {
        return $this === self::HeavyRain;
    }

    public function label(?string $locale = null): string
    {
        return (string) __('weather.condition.'.$this->value, [], $locale);
    }

    public function icon(): string
    {
        return match ($this) {
            self::Clear, self::MainlyClear => '☀️',
            self::PartlyCloudy => '⛅',
            self::Overcast => '☁️',
            self::Fog => '🌫️',
            self::Drizzle, self::Rain, self::RainShowers, self::FreezingRain => '🌧️',
            self::HeavyRain => '⛈️',
            self::Snow => '❄️',
            self::Thunderstorm => '⛈️',
            self::Unknown => '🌡️',
        };
    }
}
