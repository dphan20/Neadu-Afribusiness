<?php

declare(strict_types=1);

namespace App\Enums;

/** SRS 11.2 / 11.3: order and escrow state, one source of colour, icon and label. */
enum EscrowState: string
{
    case Pending = 'pending';
    case Held = 'held';
    case InTransit = 'in_transit';
    case Delivered = 'delivered';
    case Disputed = 'disputed';
    case Released = 'released';
    case Refunded = 'refunded';

    public function label(): string
    {
        return __('orders.status.'.$this->value);
    }

    /** Tailwind token name, never a hex (FE-40). */
    public function tone(): string
    {
        return match ($this) {
            self::Pending => 'warning',
            self::Held => 'primary',
            self::InTransit => 'water',
            self::Delivered, self::Released => 'success',
            self::Disputed => 'error',
            self::Refunded => 'text-muted',
        };
    }

    /** Lucide icon name, always paired with the label (FE-09). */
    public function icon(): string
    {
        return match ($this) {
            self::Pending => 'clock',
            self::Held => 'shield-check',
            self::InTransit => 'truck',
            self::Delivered, self::Released => 'circle-check',
            self::Disputed => 'triangle-alert',
            self::Refunded => 'undo-2',
        };
    }

    /** @return list<self> */
    public function allowedNext(): array
    {
        return match ($this) {
            self::Pending => [self::Held, self::Refunded],
            self::Held => [self::InTransit, self::Disputed, self::Refunded],
            self::InTransit => [self::Delivered, self::Disputed],
            self::Delivered => [self::Released, self::Disputed],
            self::Disputed => [self::Released, self::Refunded],
            self::Released, self::Refunded => [],
        };
    }

    public function canTransitionTo(self $next): bool
    {
        return in_array($next, $this->allowedNext(), true);
    }
}
