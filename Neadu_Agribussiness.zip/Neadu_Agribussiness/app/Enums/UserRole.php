<?php

declare(strict_types=1);

namespace App\Enums;

/** SRS 2.2 / 7.3 role codes. */
enum UserRole: string
{
    case Producer = 'P';
    case Buyer = 'B';
    case Expert = 'E';
    case Trainer = 'G';
    case Transporter = 'T';
    case LandOwner = 'L';
    case WarehouseOwner = 'W';
    case Trader = 'R';
    case Admin = 'A';

    public function label(): string
    {
        return match ($this) {
            self::Producer => 'Producer',
            self::Buyer => 'Buyer',
            self::Expert => 'Agricultural expert',
            self::Trainer => 'Trainer / entrepreneur',
            self::Transporter => 'Transporter',
            self::LandOwner => 'Land owner',
            self::WarehouseOwner => 'Warehouse owner',
            self::Trader => 'Trader / technology provider',
            self::Admin => 'NeAS administrator',
        };
    }

    public function swahiliLabel(): string
    {
        return match ($this) {
            self::Producer => 'Mzalishaji',
            self::Buyer => 'Mnunuzi',
            self::Expert => 'Mtaalamu wa kilimo',
            self::Trainer => 'Mkufunzi / mjasiriamali',
            self::Transporter => 'Msafirishaji',
            self::LandOwner => 'Mmiliki wa ardhi',
            self::WarehouseOwner => 'Mmiliki wa ghala',
            self::Trader => 'Mfanyabiashara / teknolojia',
            self::Admin => 'Msimamizi wa NeAS',
        };
    }

    public function dashboardPath(): string
    {
        return match ($this) {
            self::Admin => '/admin',
            self::Buyer => '/buyer',
            self::LandOwner => '/landowner',
            self::WarehouseOwner => '/warehouse',
            self::Expert => '/expert',
            self::Trainer => '/trainer',
            self::Transporter => '/transporter',
            default => '/dashboard',
        };
    }
}
