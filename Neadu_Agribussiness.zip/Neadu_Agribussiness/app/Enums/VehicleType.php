<?php

declare(strict_types=1);

namespace App\Enums;

enum VehicleType: string
{
    case Truck = 'truck';
    case Pickup = 'pickup';
    case Motorbike = 'motorbike';
    case Bicycle = 'bicycle';

    public function label(): string
    {
        return match ($this) {
            self::Truck => 'Truck',
            self::Pickup => 'Pickup',
            self::Motorbike => 'Motorbike',
            self::Bicycle => 'Bicycle',
        };
    }

    public function swahiliLabel(): string
    {
        return match ($this) {
            self::Truck => 'Lori',
            self::Pickup => 'Pick-up',
            self::Motorbike => 'Pikipiki',
            self::Bicycle => 'Baiskeli',
        };
    }

    /** Upper bound that keeps a registered capacity believable for the vehicle type. */
    public function maxCapacityKg(): int
    {
        return match ($this) {
            self::Truck => 40_000,
            self::Pickup => 2_000,
            self::Motorbike => 300,
            self::Bicycle => 100,
        };
    }

    public function needsPlate(): bool
    {
        return $this !== self::Bicycle;
    }

    public function needsLicence(): bool
    {
        return $this !== self::Bicycle;
    }
}
