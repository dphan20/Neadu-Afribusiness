<?php

declare(strict_types=1);

namespace App\Enums;

enum ListingType: string
{
    case Produce = 'produce';
    case Storage = 'storage';
    case Land = 'land';
    case Machine = 'machine';
    case Tour = 'tour';
}
