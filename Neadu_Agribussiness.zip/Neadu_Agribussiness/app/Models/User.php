<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use App\Enums\UserRole;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasPublicUuid, SoftDeletes;

    protected $attributes = [
        'language' => 'sw',
        'status' => 'active',
    ];

    protected $fillable = ['name', 'username', 'email', 'phone', 'description', 'language'];

    protected $hidden = ['pin_hash', 'nida_number', 'nida_hash', 'remember_token'];

    protected function casts(): array
    {
        return [
            'nida_number' => 'encrypted',     // DAT-01
            'pin_hash' => 'hashed',
            'phone_verified_at' => 'datetime',
            'verified_at' => 'datetime',
            'locked_until' => 'datetime',
            'credit_share_consent' => 'boolean',
        ];
    }

    /** @return HasMany<UserRoleAssignment, $this> */
    public function roleAssignments(): HasMany
    {
        return $this->hasMany(UserRoleAssignment::class);
    }

    /** @return HasOne<RoleProfile, $this> */
    public function producerProfile(): HasOne
    {
        return $this->hasOne(RoleProfile::class)->where('role', UserRole::Producer->value);
    }

    /** Seats this user booked on agri-tours. @return HasMany<TourBooking, $this> */
    public function tourBookings(): HasMany
    {
        return $this->hasMany(TourBooking::class);
    }

    /** @return HasMany<DiagnosisCase, $this> */
    public function diagnosisCasesAssigned(): HasMany
    {
        return $this->hasMany(DiagnosisCase::class, 'expert_id');
    }

    public function hasRole(UserRole $role): bool
    {
        return $this->roleAssignments->contains('role', $role->value);
    }

    /** BR-01: only identity-verified users may publish, accept orders or receive payouts. */
    public function isIdentityVerified(): bool
    {
        return in_array($this->verification_level, ['nida', 'full'], true);
    }

    public function maskedNida(): ?string
    {
        $n = $this->nida_number;

        return $n === null ? null : str_repeat('*', max(strlen($n) - 4, 0)).substr($n, -4);
    }
}
