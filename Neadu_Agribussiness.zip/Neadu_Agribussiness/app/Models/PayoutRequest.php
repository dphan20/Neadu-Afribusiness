<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PayoutRequest extends Model
{
    use HasPublicUuid;
    protected function casts(): array { return ['destination' => 'encrypted', 'decided_at' => 'datetime']; }

    protected $table = 'payout_requests';

    protected $guarded = ['id', 'uuid'];

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
