<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class Conversation extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid'];

    /** @return BelongsToMany<User, $this> */
    public function participants(): BelongsToMany { return $this->belongsToMany(User::class, 'conversation_user')->withPivot('last_read_at', 'hidden_at'); }

    /** @return HasOne<Message, $this> */
    public function lastMessage(): HasOne { return $this->hasOne(Message::class)->latestOfMany(); }

    /** @return HasMany<Message, $this> */
    public function messages(): HasMany { return $this->hasMany(Message::class)->orderBy('id'); }

    /** @return BelongsTo<Order, $this> */
    public function order(): BelongsTo { return $this->belongsTo(Order::class); }

    /** @return BelongsTo<Listing, $this> */
    public function listing(): BelongsTo { return $this->belongsTo(Listing::class); }

    public function hasParticipant(User $user): bool
    {
        return $this->participants()->whereKey($user->getKey())->exists();
    }

    /** COM-01: opening the conversation marks everything in it as read for this person. */
    public function markReadBy(User $user): void
    {
        $this->participants()->updateExistingPivot($user->getKey(), ['last_read_at' => now()]);
    }

    /**
     * Conversations this person should see in their list: they take part, and have not deleted the chat
     * (or someone has written since they did).
     *
     * @param  Builder<Conversation>  $query
     * @return Builder<Conversation>
     */
    public function scopeVisibleTo(Builder $query, User $user): Builder
    {
        return $query->whereExists(function ($s) use ($user): void {
            $s->from('conversation_user as cu')->whereColumn('cu.conversation_id', 'conversations.id')->where('cu.user_id', $user->getKey())
                ->where(function ($w): void {
                    $w->whereNull('cu.hidden_at')->orWhereExists(function ($m): void {
                        $m->from('messages as vm')->whereColumn('vm.conversation_id', 'cu.conversation_id')
                            ->whereColumn('vm.created_at', '>', 'cu.hidden_at')->whereNull('vm.deleted_at');
                    });
                });
        });
    }

    /**
     * The messages this person sees: not cleared by "delete chat", not removed with "delete for me".
     * Messages the sender deleted for everyone stay in the list as a "deleted" placeholder.
     *
     * @return Collection<int, Message>
     */
    public function messagesFor(User $user): Collection
    {
        $clearedAt = DB::table('conversation_user')->where('conversation_id', $this->id)->where('user_id', $user->getKey())->value('hidden_at');

        return $this->messages()->withTrashed()->with('sender')
            ->whereNotIn('messages.id', DB::table('message_hides')->where('user_id', $user->getKey())->select('message_id'))
            ->when($clearedAt !== null, fn ($q) => $q->where('messages.created_at', '>', $clearedAt))
            ->get();
    }
}
