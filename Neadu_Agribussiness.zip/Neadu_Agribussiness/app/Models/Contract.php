<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Contract extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid'];

    protected function casts(): array
    {
        return ['terms' => 'array', 'signatures' => 'array'];
    }

    /** @return BelongsTo<User, $this> */
    public function seller(): BelongsTo { return $this->belongsTo(User::class, 'seller_id'); }
}
