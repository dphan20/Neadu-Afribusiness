<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class DiagnosisCase extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid'];

    protected function casts(): array
    {
        return ['escalated_at' => 'datetime', 'replied_at' => 'datetime', 'claimed_at' => 'datetime', 'answered_at' => 'datetime', 'ai_correct' => 'boolean'];
    }

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    /** The producer who opened the case (alias of user()). @return BelongsTo<User, $this> */
    public function producer(): BelongsTo { return $this->belongsTo(User::class, 'user_id'); }

    /** @return HasMany<AiCorrection, $this> */
    public function corrections(): HasMany { return $this->hasMany(AiCorrection::class); }

    /** @return BelongsTo<User, $this> */
    public function expert(): BelongsTo { return $this->belongsTo(User::class, 'expert_id'); }

    /** @return BelongsTo<Conversation, $this> */
    public function conversation(): BelongsTo { return $this->belongsTo(Conversation::class); }
}
