<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use App\Enums\EscrowState;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid', 'status'];

    protected function casts(): array
    {
        return [
            'status' => EscrowState::class,
            'quantity' => 'decimal:3',
            'accept_by' => 'datetime', 'accepted_at' => 'datetime',
            'delivered_at' => 'datetime', 'auto_release_at' => 'datetime',
            'rejected_at' => 'datetime', 'released_at' => 'datetime',
        ];
    }

    /** @return BelongsTo<User, $this> */
    public function buyer(): BelongsTo { return $this->belongsTo(User::class, 'buyer_id'); }

    /** @return BelongsTo<User, $this> */
    public function seller(): BelongsTo { return $this->belongsTo(User::class, 'seller_id'); }

    /** @return BelongsTo<Listing, $this> */
    public function listing(): BelongsTo { return $this->belongsTo(Listing::class); }

    /** @return HasMany<Payment, $this> */
    public function payments(): HasMany { return $this->hasMany(Payment::class); }

    /** @return HasMany<Delivery, $this> */
    public function deliveries(): HasMany { return $this->hasMany(Delivery::class); }

    /** @return HasOne<Delivery, $this> */
    public function delivery(): HasOne { return $this->hasOne(Delivery::class)->latestOfMany(); }

    /** @return HasOne<Dispute, $this> */
    public function dispute(): HasOne { return $this->hasOne(Dispute::class)->latestOfMany(); }

    /** @return HasMany<Rating, $this> */
    public function ratings(): HasMany { return $this->hasMany(Rating::class); }

    public function total(): int { return (int) $this->subtotal_minor + (int) $this->fee_minor; }

    /** An order the producer has not yet answered (MKT-04). */
    public function awaitingAnswer(): bool
    {
        return $this->accepted_at === null && $this->rejected_at === null
            && in_array($this->status, [EscrowState::Pending, EscrowState::Held], true);
    }

    /** Server-side enforcement of the 11.2 state machine (BR-02, BR-05). */
    public function transitionTo(EscrowState $next): void
    {
        if (! $this->status->canTransitionTo($next)) {
            throw new \DomainException("Invalid order transition {$this->status->value} -> {$next->value}");
        }
        $before = $this->status->value;
        $this->forceFill(['status' => $next])->save();
        AuditLog::record('order.transition', $this, ['status' => $before], ['status' => $next->value]);
    }
}
