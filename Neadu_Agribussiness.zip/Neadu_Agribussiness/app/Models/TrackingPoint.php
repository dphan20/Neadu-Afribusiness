<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** One GPS fix from a driver's phone. Never soft-deleted: the trail is evidence in a dispute. */
class TrackingPoint extends Model
{
    public $timestamps = false;

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'lat' => 'float', 'lng' => 'float', 'accuracy_meters' => 'float', 'speed_kmh' => 'float',
            'recorded_at' => 'datetime', 'synced_at' => 'datetime',
        ];
    }

    /** @return BelongsTo<Delivery, $this> */
    public function delivery(): BelongsTo
    {
        return $this->belongsTo(Delivery::class);
    }

    /** @return BelongsTo<User, $this> */
    public function driver(): BelongsTo
    {
        return $this->belongsTo(User::class, 'driver_id');
    }
}
