<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Tour extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['itinerary' => 'array', 'learning_goals' => 'array', 'starts_at' => 'datetime', 'ends_at' => 'datetime', 'completed_at' => 'datetime'];
    }

    /** @return BelongsTo<Listing, $this> */
    public function listing(): BelongsTo { return $this->belongsTo(Listing::class); }

    /** @return HasMany<TourBooking, $this> */
    public function bookings(): HasMany { return $this->hasMany(TourBooking::class); }

    /** @return HasMany<TourReview, $this> */
    public function reviews(): HasMany { return $this->hasMany(TourReview::class); }

    /** Seats that count against capacity: paid/completed, plus reservations whose hold timer is still running (TUR-02). */
    public function seatsTaken(): int
    {
        return (int) $this->bookings()->where(fn ($q) => $q
            ->whereIn('status', ['paid', 'completed'])
            ->orWhere(fn ($h) => $h->where('status', 'reserved')->where('expires_at', '>', now())))->sum('seats');
    }

    public function seatsLeft(): int
    {
        return max(0, (int) $this->seats - $this->seatsTaken());
    }
}
