<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Consultation extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid'];

    protected function casts(): array
    {
        return ['scheduled_at' => 'datetime', 'completed_at' => 'datetime'];
    }

    /** @return BelongsTo<User, $this> */
    public function expert(): BelongsTo { return $this->belongsTo(User::class, 'expert_id'); }

    /** @return BelongsTo<User, $this> */
    public function producer(): BelongsTo { return $this->belongsTo(User::class, 'producer_id'); }

    /** @return BelongsTo<DiagnosisCase, $this> */
    public function diagnosisCase(): BelongsTo { return $this->belongsTo(DiagnosisCase::class); }
}
