<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Payment extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid'];

    protected $hidden = ['reference'];

    protected function casts(): array
    {
        return ['reference' => 'encrypted']; // DAT-01
    }
}
