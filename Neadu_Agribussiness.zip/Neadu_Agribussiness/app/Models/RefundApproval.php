<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** NFR-S4: a refund above the threshold needs a second admin before money moves. */
class RefundApproval extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['approved_at' => 'datetime', 'executed_at' => 'datetime'];
    }

    /** @return BelongsTo<Dispute, $this> */
    public function dispute(): BelongsTo { return $this->belongsTo(Dispute::class); }

    /** @return BelongsTo<User, $this> */
    public function requester(): BelongsTo { return $this->belongsTo(User::class, 'requested_by'); }

    /** @return BelongsTo<User, $this> */
    public function approver(): BelongsTo { return $this->belongsTo(User::class, 'approved_by'); }
}
