<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MachineQuote extends Model
{
    use HasPublicUuid;
    /** @return BelongsTo<Listing, $this> */
    public function listing(): BelongsTo { return $this->belongsTo(Listing::class); }

    protected $table = 'machine_quotes';

    protected $guarded = ['id', 'uuid'];

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
