<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class AdvicePost extends Model
{
    use HasPublicUuid, SoftDeletes;
    protected function casts(): array { return ['published_at' => 'datetime']; }

    /** The expert who wrote it (advice_posts.user_id). @return BelongsTo<User, $this> */
    public function expert(): BelongsTo { return $this->belongsTo(User::class, 'user_id'); }

    /** @return BelongsTo<Crop, $this> */
    public function crop(): BelongsTo { return $this->belongsTo(Crop::class); }

    /** @return BelongsTo<Region, $this> */
    public function region(): BelongsTo { return $this->belongsTo(Region::class); }

    protected $table = 'advice_posts';

    protected $guarded = ['id', 'uuid'];

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
