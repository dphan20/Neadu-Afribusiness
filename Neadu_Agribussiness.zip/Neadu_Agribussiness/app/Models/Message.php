<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Message extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid'];

    /** @return BelongsTo<User, $this> */
    public function sender(): BelongsTo { return $this->belongsTo(User::class, 'sender_id'); }

    /** @return BelongsTo<Conversation, $this> */
    public function conversation(): BelongsTo { return $this->belongsTo(Conversation::class); }
}
