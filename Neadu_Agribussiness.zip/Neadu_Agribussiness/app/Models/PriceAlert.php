<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class PriceAlert extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid'];

    protected function casts(): array
    {
        return ['channels' => 'array', 'active' => 'boolean', 'last_triggered_at' => 'datetime'];
    }

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    /** @return BelongsTo<Crop, $this> */
    public function crop(): BelongsTo { return $this->belongsTo(Crop::class); }

    /** @return BelongsTo<Market, $this> */
    public function market(): BelongsTo { return $this->belongsTo(Market::class); }
}
