<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Delivery extends Model
{
    use HasPublicUuid, SoftDeletes;

    /** LOG-04 trip flow, in order. "requested" is the open-job state before a driver accepts. */
    public const FLOW = ['assigned', 'at_pickup', 'loaded', 'in_transit', 'arrived', 'delivered'];

    /** Statuses in which a driver is actively on the job. */
    public const ACTIVE = ['assigned', 'at_pickup', 'loaded', 'in_transit', 'arrived'];

    protected $guarded = ['id', 'uuid'];

    protected function casts(): array
    {
        return [
            'timeline' => 'array', 'accepted_at' => 'datetime', 'delivered_at' => 'datetime',
            'pickup_lat' => 'float', 'pickup_lng' => 'float', 'drop_lat' => 'float', 'drop_lng' => 'float',
        ];
    }

    /** @return BelongsTo<Order, $this> */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    /** @return HasMany<TrackingPoint, $this> */
    public function points(): HasMany { return $this->hasMany(TrackingPoint::class)->orderBy('recorded_at'); }

    /** @return HasMany<TrackingPoint, $this> */
    public function trackingPoints(): HasMany { return $this->hasMany(TrackingPoint::class); }

    /** @return BelongsTo<User, $this> */
    public function transporter(): BelongsTo { return $this->belongsTo(User::class, 'transporter_id'); }

    /** @return BelongsTo<Vehicle, $this> */
    public function vehicle(): BelongsTo { return $this->belongsTo(Vehicle::class); }
}
