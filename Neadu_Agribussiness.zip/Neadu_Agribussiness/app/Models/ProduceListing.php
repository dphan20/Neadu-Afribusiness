<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\ProduceCategory;
use App\Support\Quantity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProduceListing extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'category' => ProduceCategory::class,
            'quantity' => 'decimal:3', 'quantity_sold' => 'decimal:3', 'min_order' => 'decimal:3',
            'harvest_date' => 'date',
        ];
    }

    /** @return BelongsTo<Listing, $this> */
    public function listing(): BelongsTo { return $this->belongsTo(Listing::class); }

    /** @return BelongsTo<Crop, $this> */
    public function crop(): BelongsTo { return $this->belongsTo(Crop::class); }

    /** @return BelongsTo<Unit, $this> */
    public function unit(): BelongsTo { return $this->belongsTo(Unit::class); }

    /** MKT-10: stock still available to sell, as a decimal string with 3 places. */
    public function remaining(): string
    {
        return Quantity::fromMilli(Quantity::toMilli($this->quantity) - Quantity::toMilli($this->quantity_sold));
    }

    public function isSoldOut(): bool
    {
        return Quantity::toMilli($this->remaining()) <= 0;
    }
}
