<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use App\Enums\ListingType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Listing extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid', 'verified', 'verified_at', 'verified_by']; // BR-08: set by admin only

    protected function casts(): array
    {
        return ['type' => ListingType::class, 'photos' => 'array', 'verified' => 'boolean', 'verified_at' => 'datetime'];
    }

    /** @return BelongsTo<User, $this> */
    public function owner(): BelongsTo { return $this->belongsTo(User::class, 'user_id'); }

    /** @return HasOne<ProduceListing, $this> */
    public function produce(): HasOne { return $this->hasOne(ProduceListing::class); }

    /** @return BelongsTo<Region, $this> */
    public function region(): BelongsTo { return $this->belongsTo(Region::class); }

    /** @return BelongsTo<District, $this> */
    public function district(): BelongsTo { return $this->belongsTo(District::class); }

    /** @return HasOne<LandPlot, $this> */
    public function land(): HasOne { return $this->hasOne(LandPlot::class); }

    /** @return HasOne<Machine, $this> */
    public function machine(): HasOne { return $this->hasOne(Machine::class); }

    /** @return HasOne<Tour, $this> */
    public function tour(): HasOne { return $this->hasOne(Tour::class); }

    /** @return HasOne<StorageFacility, $this> */
    public function storage(): HasOne { return $this->hasOne(StorageFacility::class); }

    /** @return HasMany<Order, $this> */
    public function orders(): HasMany { return $this->hasMany(Order::class); }

    /** MKT-10: hide a sold-out listing from the marketplace, and bring it back if stock is added. */
    public function syncAvailability(): void
    {
        $produce = $this->produce()->first();
        if ($produce === null) {
            return;
        }
        if ($produce->isSoldOut() && $this->status === 'active') {
            $this->forceFill(['status' => 'sold_out'])->save();
        } elseif (! $produce->isSoldOut() && $this->status === 'sold_out') {
            $this->forceFill(['status' => 'active'])->save();
        }
    }
}
