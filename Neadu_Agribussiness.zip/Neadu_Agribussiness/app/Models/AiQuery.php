<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/** One question (optionally with a photo) asked to the AI assistant, and its answer. */
class AiQuery extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid'];

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
