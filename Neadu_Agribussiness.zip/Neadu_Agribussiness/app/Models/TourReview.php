<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TourReview extends Model
{
    use HasPublicUuid;

    protected $guarded = ['id', 'uuid'];

    /** @return BelongsTo<User, $this> */
    public function attendee(): BelongsTo { return $this->belongsTo(User::class, 'attendee_id'); }

    /** @return BelongsTo<Tour, $this> */
    public function tour(): BelongsTo { return $this->belongsTo(Tour::class); }
}
