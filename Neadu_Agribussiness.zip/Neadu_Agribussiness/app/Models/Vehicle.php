<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use App\Enums\VehicleType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Vehicle extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid', 'verification_status', 'verified_at', 'verified_by'];

    protected function casts(): array
    {
        return ['licence_document' => 'encrypted', 'capacity_kg' => 'decimal:2', 'verified_at' => 'datetime'];
    }

    /** @return BelongsTo<User, $this> */
    public function owner(): BelongsTo { return $this->belongsTo(User::class, 'user_id'); }

    /** @return BelongsTo<User, $this> */
    public function verifier(): BelongsTo { return $this->belongsTo(User::class, 'verified_by'); }

    public function isVerified(): bool
    {
        return $this->verification_status === 'verified';
    }

    public function typeEnum(): ?VehicleType
    {
        return VehicleType::tryFrom(strtolower((string) $this->type));
    }

    public function typeLabel(): string
    {
        return $this->typeEnum()?->label() ?? ucfirst((string) $this->type);
    }
}
