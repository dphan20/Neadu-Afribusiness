<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserRoleAssignment extends Model
{
    protected $table = 'user_roles';

    protected $fillable = ['user_id', 'role'];
}
