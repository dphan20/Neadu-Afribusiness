<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

/** MKT-11 "wanted to buy" (R2). */
class WantedRequest extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid'];

    protected function casts(): array
    {
        return ['quantity' => 'decimal:3', 'needed_by' => 'date'];
    }

    /** @return BelongsTo<Crop, $this> */
    public function crop(): BelongsTo { return $this->belongsTo(Crop::class); }

    /** @return BelongsTo<Region, $this> */
    public function region(): BelongsTo { return $this->belongsTo(Region::class); }
}
