<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AiCorrection extends Model
{
    use HasPublicUuid;

    protected $guarded = ['id', 'uuid'];

    protected function casts(): array
    {
        return ['exported_at' => 'datetime'];
    }

    /** @return BelongsTo<DiagnosisCase, $this> */
    public function diagnosisCase(): BelongsTo { return $this->belongsTo(DiagnosisCase::class); }
}
