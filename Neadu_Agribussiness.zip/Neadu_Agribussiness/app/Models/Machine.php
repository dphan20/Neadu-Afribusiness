<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Machine extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['specs' => 'array', 'offers' => 'array', 'rental_rate_minor' => 'integer', 'year' => 'integer', 'stock' => 'integer'];
    }
}
