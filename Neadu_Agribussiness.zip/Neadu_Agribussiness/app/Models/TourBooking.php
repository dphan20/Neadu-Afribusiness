<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOneThrough;
use Illuminate\Database\Eloquent\SoftDeletes;

class TourBooking extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $table = 'tour_bookings';

    protected $guarded = ['id', 'uuid'];

    protected function casts(): array
    {
        return ['expires_at' => 'datetime', 'paid_at' => 'datetime', 'certificate_issued_at' => 'datetime', 'attended' => 'boolean'];
    }

    /** @return BelongsTo<Tour, $this> */
    public function tour(): BelongsTo { return $this->belongsTo(Tour::class); }

    /** The tour's listing, reached through the tour. @return HasOneThrough<Listing, Tour, $this> */
    public function listing(): HasOneThrough { return $this->hasOneThrough(Listing::class, Tour::class, 'id', 'id', 'tour_id', 'listing_id'); }

    /** @return BelongsTo<User, $this> */
    public function attendee(): BelongsTo { return $this->belongsTo(User::class, 'user_id'); }

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
