<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** ADM-07: user, time, before, after. Append-only. */
class AuditLog extends Model
{
    public const UPDATED_AT = null;

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['before' => 'array', 'after' => 'array'];
    }

    /** @return BelongsTo<User, $this> */
    public function actor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'actor_id');
    }

    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException('Audit log is append-only.'));
        static::deleting(fn () => throw new \LogicException('Audit log is append-only.'));
    }

    /** @param array<string,mixed> $before @param array<string,mixed> $after */
    public static function record(string $action, Model $target, array $before = [], array $after = []): void
    {
        self::create([
            'actor_id' => auth()->id(), 'action' => $action, 'target_type' => $target::class,
            'target_id' => $target->getKey(), 'before' => $before, 'after' => $after,
        ]);
    }
}
