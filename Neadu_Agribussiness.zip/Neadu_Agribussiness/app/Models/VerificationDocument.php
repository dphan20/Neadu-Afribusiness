<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class VerificationDocument extends Model
{
    use HasPublicUuid;
    protected function casts(): array { return ['reviewed_at' => 'datetime']; }

    protected $table = 'verification_documents';

    protected $guarded = ['id', 'uuid'];

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
