<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/** Append-only (NFR-S4). Corrections are new reversing entries, never edits. */
class LedgerEntry extends Model
{
    public const UPDATED_AT = null;

    protected $guarded = ['id'];

    protected static function booted(): void
    {
        static::updating(fn () => throw new \LogicException('Ledger entries are append-only.'));
        static::deleting(fn () => throw new \LogicException('Ledger entries are append-only.'));
    }
}
