<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class StorageBooking extends Model
{
    use HasPublicUuid, SoftDeletes;

    protected $guarded = ['id', 'uuid'];

    protected function casts(): array
    {
        return ['decided_at' => 'datetime', 'received_at' => 'datetime', 'expiry_alert_at' => 'datetime', 'settled_at' => 'datetime'];
    }

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    /** @return BelongsTo<Listing, $this> */
    public function facilityListing(): BelongsTo
    {
        return $this->belongsTo(Listing::class, 'facility_listing_id');
    }
}
