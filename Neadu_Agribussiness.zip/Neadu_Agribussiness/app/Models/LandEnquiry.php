<?php

declare(strict_types=1);

namespace App\Models;

use App\Concerns\HasPublicUuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** LND-04: a message, site-visit request or in-platform offer on a land listing. */
class LandEnquiry extends Model
{
    use HasPublicUuid;

    protected $table = 'land_enquiries';

    protected $guarded = ['id', 'uuid'];

    protected function casts(): array
    {
        return ['visit_on' => 'date', 'replied_at' => 'datetime'];
    }

    /** @return BelongsTo<Listing, $this> */
    public function listing(): BelongsTo { return $this->belongsTo(Listing::class); }

    /** @return BelongsTo<User, $this> */
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
