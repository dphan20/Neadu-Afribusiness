<?php

declare(strict_types=1);

namespace App\Contracts;

/** OPEN-Q7: AI photo diagnosis behind an interface. Output text is Kiswahili (DIA-02). */
interface DiagnosisEngine
{
    /** @return array{result: string, confidence: int, treatment: string, prevention: string} */
    public function diagnose(string $absolutePhotoPath, string $subject, string $kind): array;
}
