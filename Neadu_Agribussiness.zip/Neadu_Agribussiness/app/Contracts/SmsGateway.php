<?php

declare(strict_types=1);

namespace App\Contracts;

/** OPEN-Q3: SMS/WhatsApp provider behind an interface. */
interface SmsGateway
{
    public function send(string $phone, string $message, string $channel = 'sms'): void;
}
