<?php

declare(strict_types=1);

namespace App\Contracts;

/** OPEN-Q3 / INT-01: mobile-money and bank collection behind an interface. */
interface PaymentGateway
{
    /** @return string provider reference. Throws DomainException when the charge is refused. Must be idempotent on $idempotencyKey. */
    public function charge(string $phone, int $amountMinor, string $provider, string $idempotencyKey): string;

    /**
     * Ask the provider what happened to a charge (used when a callback never arrived).
     *
     * @return 'successful'|'pending'|'failed'|'cancelled'
     */
    public function status(string $idempotencyKey, ?string $providerRef = null): string;
}
