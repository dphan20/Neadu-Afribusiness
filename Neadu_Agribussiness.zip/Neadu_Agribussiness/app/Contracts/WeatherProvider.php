<?php

declare(strict_types=1);

namespace App\Contracts;

interface WeatherProvider
{
    /** @return list<array{date: string, tmax: float, tmin: float, rain_mm: float, wind_kmh: float}> 7 daily entries */
    public function forecast(float $lat, float $lng): array;
}
