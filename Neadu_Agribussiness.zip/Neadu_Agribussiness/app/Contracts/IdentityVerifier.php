<?php

declare(strict_types=1);

namespace App\Contracts;

/** OPEN-Q4: NIDA access path is unknown, so verification sits behind this interface. */
interface IdentityVerifier
{
    /** True when the NIDA number belongs to the person with this name. */
    public function verify(string $nidaNumber, string $fullName): bool;
}
