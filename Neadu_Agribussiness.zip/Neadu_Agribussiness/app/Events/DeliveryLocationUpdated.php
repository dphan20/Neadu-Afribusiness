<?php

declare(strict_types=1);

namespace App\Events;

use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Contracts\Events\ShouldDispatchAfterCommit;
use Illuminate\Foundation\Events\Dispatchable;

/**
 * LOG-04 / TECH-08: pushed over Laravel Reverb the moment a driver's point is stored.
 * ShouldBroadcastNow skips the queue so the buyer's marker moves within a second or two without a worker running.
 */
final class DeliveryLocationUpdated implements ShouldBroadcastNow, ShouldDispatchAfterCommit
{
    use Dispatchable, InteractsWithSockets;

    public function __construct(
        public readonly string $deliveryUuid,
        public readonly float $lat,
        public readonly float $lng,
        public readonly string $recordedAt,
        public readonly string $status,
    ) {}

    /** @return list<PrivateChannel> */
    public function broadcastOn(): array
    {
        return [new PrivateChannel('delivery.'.$this->deliveryUuid)];
    }

    public function broadcastAs(): string
    {
        return 'delivery.location.updated';
    }

    /** @return array<string, mixed> */
    public function broadcastWith(): array
    {
        return ['delivery' => $this->deliveryUuid, 'lat' => $this->lat, 'lng' => $this->lng, 'recorded_at' => $this->recordedAt, 'status' => $this->status];
    }
}
