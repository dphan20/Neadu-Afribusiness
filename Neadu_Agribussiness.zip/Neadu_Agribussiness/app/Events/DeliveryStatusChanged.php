<?php

declare(strict_types=1);

namespace App\Events;

use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Contracts\Events\ShouldDispatchAfterCommit;
use Illuminate\Foundation\Events\Dispatchable;

/** LOG-04: moves the buyer's step bar (assigned, at pickup, loaded, in transit, arrived, delivered) without a refresh. */
final class DeliveryStatusChanged implements ShouldBroadcastNow, ShouldDispatchAfterCommit
{
    use Dispatchable, InteractsWithSockets;

    public function __construct(public readonly string $deliveryUuid, public readonly string $status) {}

    /** @return list<PrivateChannel> */
    public function broadcastOn(): array
    {
        return [new PrivateChannel('delivery.'.$this->deliveryUuid)];
    }

    public function broadcastAs(): string
    {
        return 'delivery.status.changed';
    }

    /** @return array<string, string> */
    public function broadcastWith(): array
    {
        return ['delivery' => $this->deliveryUuid, 'status' => $this->status];
    }
}
