<?php

declare(strict_types=1);

namespace App\Support;

/** One storage format for Tanzanian numbers: 255XXXXXXXXX (no +, spaces or dashes). */
final class Phone
{
    public static function normalize(string $raw): string
    {
        $digits = preg_replace('/\D+/', '', $raw) ?? '';

        if (str_starts_with($digits, '0')) {
            return '255'.substr($digits, 1);   // 0712 345 678 -> 255712345678
        }

        return strlen($digits) === 9 ? '255'.$digits : $digits;   // 712345678 -> 255712345678
    }
}
