<?php

declare(strict_types=1);

namespace App\Support;

/** Money is integer minor units (TZS), never floats (SRS 8.2). */
final readonly class Money
{
    public function __construct(public int $minor, public string $currency = 'TZS') {}

    /** Parse a whole-currency amount typed by a user ("12500" or "12,500.50") into minor units without floats. */
    public static function fromMajor(string $amount, string $currency = 'TZS'): self
    {
        $clean = str_replace([',', ' '], '', trim($amount));
        if (preg_match('/^(\d+)(?:\.(\d{1,2}))?$/', $clean, $m) !== 1) {
            throw new \InvalidArgumentException('Invalid amount.');
        }

        return new self(((int) $m[1]) * 100 + (int) str_pad($m[2] ?? '0', 2, '0'), $currency);
    }

    public function plus(self $o): self { return new self($this->minor + $o->minor, $this->currency); }

    public function minus(self $o): self { return new self($this->minor - $o->minor, $this->currency); }

    /** Basis points avoid float rounding, e.g. 250 = 2.5%. */
    public function percentBps(int $bps): self { return new self(intdiv($this->minor * $bps, 10_000), $this->currency); }

    /** Display helper for views: minor units -> "12,500 TZS". */
    public static function tzs(int|string|null $minor, string $currency = 'TZS'): string
    {
        return number_format(intdiv((int) $minor, 100), 0, '.', ',').' '.$currency;
    }

    public function format(): string
    {
        return number_format(intdiv($this->minor, 100), 0, '.', ',').' '.$this->currency;
    }
}
