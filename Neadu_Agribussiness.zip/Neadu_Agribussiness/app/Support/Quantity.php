<?php

declare(strict_types=1);

namespace App\Support;

/** Quantities have 3 decimal places in the database. We compute in integer thousandths so no float or bcmath is needed. */
final class Quantity
{
    public static function toMilli(string|int|float $value): int
    {
        $s = number_format((float) $value, 3, '.', '');
        [$whole, $frac] = explode('.', ltrim($s, '+'));

        return ((int) $whole) * 1000 + (int) $frac * (str_starts_with($whole, '-') ? -1 : 1);
    }

    public static function fromMilli(int $milli): string
    {
        $sign = $milli < 0 ? '-' : '';
        $abs = abs($milli);

        return $sign.intdiv($abs, 1000).'.'.str_pad((string) ($abs % 1000), 3, '0', STR_PAD_LEFT);
    }

    /** "12.500" -> "12.5", "3.000" -> "3" for display. */
    public static function pretty(string|int|float $value): string
    {
        return rtrim(rtrim(number_format((float) $value, 3, '.', ''), '0'), '.');
    }
}
