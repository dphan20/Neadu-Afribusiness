<?php

declare(strict_types=1);

namespace App\Support;

use App\Enums\UserRole;
use App\Models\RoleProfile;
use App\Models\User;

/**
 * ADM-08 least privilege. An admin's scope lives in their admin role profile (business.scope).
 * No profile means "super", so existing admin accounts keep working until a super admin narrows them.
 */
final class AdminScope
{
    public const SCOPES = [
        'super' => 'Super admin (everything)',
        'support' => 'Support (users, disputes, listings)',
        'verification' => 'Verification (documents, vehicles, listings)',
        'finance' => 'Finance (escrow, payouts, refunds, fees)',
    ];

    /** Areas each scope may open. */
    private const AREAS = [
        'support' => ['users', 'disputes', 'listings', 'reports'],
        'verification' => ['verification', 'listings', 'reports'],
        'finance' => ['finance', 'reports'],
    ];

    public static function of(?User $user): string
    {
        if ($user === null) {
            return 'none';
        }
        $scope = RoleProfile::query()->where('user_id', $user->id)->where('role', UserRole::Admin->value)->first()?->business['scope'] ?? 'super';

        return array_key_exists($scope, self::SCOPES) ? $scope : 'super';
    }

    public static function can(?User $user, string $area): bool
    {
        $scope = self::of($user);

        return $scope === 'super' || in_array($area, self::AREAS[$scope] ?? [], true);
    }
}
