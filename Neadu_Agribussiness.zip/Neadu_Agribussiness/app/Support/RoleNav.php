<?php

declare(strict_types=1);

namespace App\Support;

use App\Enums\UserRole;
use Illuminate\Support\Facades\Route;

/**
 * Sidebar destinations per role, as [route name, label]. A destination whose route is not registered yet is left out,
 * so a role never shows a dead link while other roles are still being added.
 */
final class RoleNav
{
    /** @return list<array{string, string}> */
    public static function for(UserRole $role): array
    {
        $common = [
            ['me.notifications', 'Notifications'], ['me.chat.index', 'Messages'], ['me.ask', 'Ask AI'], ['me.wallet', 'Wallet & payouts'],
            ['me.profile', 'My profile'], ['me.settings', 'Settings'], ['me.help', 'Help'],
        ];

        $items = match ($role) {
            UserRole::Producer => [
                ['producer.home', 'Overview'], ['producer.listings.index', 'My listings'], ['producer.orders.index', 'Orders'],
                ['producer.storage.index', 'Find storage'], ['producer.storage.mine', 'Storage bookings'], ['land.index', 'Land'], ['producer.diagnosis.index', 'Diagnosis'],
                ['me.alerts.index', 'Price alerts'], ['me.weather', 'Weather'], ['tours.index', 'Agri-tours'],
                ['producer.credit', 'Credit score'], ['producer.voice', 'Voice assistant'], ['producer.profile', 'Verification'],
            ],
            UserRole::Buyer => [
                ['buyer.dashboard', 'Overview'], ['buyer.market', 'Find produce'], ['buyer.orders', 'My orders'], ['land.index', 'Land'], ['tours.index', 'Agri-tours'],
            ],
            UserRole::Expert => [
                ['expert.cases', 'Case queue'], ['expert.advice', 'My advice'], ['advice.feed', 'Advice feed'], ['me.weather', 'Weather'],
            ],
            UserRole::Trainer => [
                ['trainer.tours', 'My tours'], ['tours.index', 'All tours'], ['advice.feed', 'Advice feed'],
            ],
            UserRole::Transporter => [
                ['transporter.home', 'Overview'], ['transporter.jobs', 'Jobs'], ['transporter.trips', 'My trips'], ['transporter.vehicles', 'My vehicles'], ['transporter.earnings', 'Earnings'], ['transporter.profile', 'Transport profile'],
            ],
            UserRole::LandOwner => [['landowner.listings', 'My land'], ['landowner.enquiries', 'Enquiries'], ['land.index', 'Land market']],
            UserRole::WarehouseOwner => [['warehouse.facilities', 'My facilities'], ['warehouse.bookings', 'Bookings']],
            UserRole::Trader => [['trader.machines', 'My machinery'], ['trader.quotes', 'Quote inbox']],
            UserRole::Admin => [['admin.dashboard', 'Admin console']],
        };

        $all = array_merge($items, $role === UserRole::Admin ? [] : $common);

        return array_values(array_filter($all, static fn (array $i): bool => Route::has($i[0])));
    }

    public static function activeRole(): UserRole
    {
        $user = auth()->user();
        $active = UserRole::tryFrom((string) session('active_role', ''));
        if ($active !== null && $user?->roleAssignments->contains('role', $active->value)) {
            return $active;
        }

        return UserRole::from($user->roleAssignments->first()->role ?? 'P');
    }
}
