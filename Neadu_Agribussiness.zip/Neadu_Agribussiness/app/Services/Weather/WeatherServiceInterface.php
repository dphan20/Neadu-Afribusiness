<?php

declare(strict_types=1);

namespace App\Services\Weather;

/** SRS 9.4 provider pattern: swap the weather source without touching pages or the alert job. */
interface WeatherServiceInterface
{
    /**
     * @return array{
     *     current: ?array{temperature: float, wind_kmh: float, rain_mm: float, code: int, condition: string, time: string},
     *     daily: list<array{date: string, tmax: float, tmin: float, rain_mm: float, wind_kmh: float, code: int, condition: string}>,
     *     source: string,
     *     fetched_at: ?string,
     *     stale: bool
     * }
     */
    public function getForecast(float $lat, float $lng, string $district): array;
}
