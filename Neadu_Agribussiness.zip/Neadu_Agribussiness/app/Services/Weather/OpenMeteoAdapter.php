<?php

declare(strict_types=1);

namespace App\Services\Weather;

use App\Enums\WeatherCondition;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * WTH-01 / WTH-05 / INT-06 / NFR-A3: Open-Meteo forecast (free tier, no API key, non-commercial use).
 * Fresh data is cached 60 minutes. If the provider fails, the last good copy is returned with stale = true;
 * with nothing cached an empty state comes back. This class never throws into a page.
 */
final class OpenMeteoAdapter implements WeatherServiceInterface
{
    public const SOURCE = 'Open-Meteo';

    private const URL = 'https://api.open-meteo.com/v1/forecast';

    private const FRESH_MINUTES = 60;

    public function getForecast(float $lat, float $lng, string $district): array
    {
        $key = 'weather:'.Str::slug($district);

        $fresh = Cache::get($key);
        if (is_array($fresh)) {
            return [...$fresh, 'stale' => false];
        }

        try {
            $payload = $this->fetch($lat, $lng);
            Cache::put($key, $payload, now()->addMinutes(self::FRESH_MINUTES));
            Cache::forever($key.':last', $payload); // survives expiry so an outage still has something to show

            return [...$payload, 'stale' => false];
        } catch (Throwable $e) {
            Log::warning('Weather provider failed', ['district' => $district, 'error' => $e->getMessage()]);

            $last = Cache::get($key.':last');

            return is_array($last) ? [...$last, 'stale' => true] : $this->emptyState();
        }
    }

    /** @return array{current: array<string, mixed>, daily: list<array<string, mixed>>, source: string, fetched_at: string} */
    private function fetch(float $lat, float $lng): array
    {
        $json = Http::timeout(5)->acceptJson()->get(self::URL, [
            'latitude' => $lat,
            'longitude' => $lng,
            'timezone' => 'Africa/Dar_es_Salaam',
            'current' => 'temperature_2m,weather_code,wind_speed_10m,precipitation',
            'daily' => 'temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code,wind_speed_10m_max',
            'forecast_days' => 7,
        ])->throw()->json();

        $cur = $json['current'] ?? null;
        $daily = $json['daily'] ?? null;
        if (! is_array($cur) || ! is_array($daily) || ! isset($daily['time']) || ! is_array($daily['time']) || $daily['time'] === []) {
            throw new RuntimeException('Unexpected Open-Meteo response.');
        }

        $days = [];
        foreach ($daily['time'] as $i => $date) {
            $code = (int) ($daily['weather_code'][$i] ?? -1);
            $days[] = [
                'date' => (string) $date,
                'tmax' => (float) ($daily['temperature_2m_max'][$i] ?? 0),
                'tmin' => (float) ($daily['temperature_2m_min'][$i] ?? 0),
                'rain_mm' => (float) ($daily['precipitation_sum'][$i] ?? 0),
                'wind_kmh' => (float) ($daily['wind_speed_10m_max'][$i] ?? 0),
                'code' => $code,
                'condition' => WeatherCondition::fromCode($code)->value,
            ];
        }

        $code = (int) ($cur['weather_code'] ?? -1);

        return [
            'current' => [
                'temperature' => (float) ($cur['temperature_2m'] ?? 0),
                'wind_kmh' => (float) ($cur['wind_speed_10m'] ?? 0),
                'rain_mm' => (float) ($cur['precipitation'] ?? 0),
                'code' => $code,
                'condition' => WeatherCondition::fromCode($code)->value,
                'time' => (string) ($cur['time'] ?? ''),
            ],
            'daily' => $days,
            'source' => self::SOURCE,
            'fetched_at' => now()->toIso8601String(),
        ];
    }

    /** @return array{current: null, daily: array<never, never>, source: string, fetched_at: null, stale: bool} */
    private function emptyState(): array
    {
        return ['current' => null, 'daily' => [], 'source' => self::SOURCE, 'fetched_at' => null, 'stale' => true];
    }
}
