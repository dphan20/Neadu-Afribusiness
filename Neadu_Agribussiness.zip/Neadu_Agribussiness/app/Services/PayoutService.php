<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\EscrowState;
use App\Models\AuditLog;
use App\Models\FeeRule;
use App\Models\Order;
use App\Support\Money;
use DomainException;
use Illuminate\Support\Facades\DB;

/** MKT-05/07: release escrow to the producer minus the platform fee, and produce an itemised receipt. */
final class PayoutService
{
    public function __construct(private readonly LedgerService $ledger, private readonly NotificationService $notes) {}

    /** @return array{fee: int, bps: int, min_minor: int} OPEN-Q2: levels come from reference data */
    public function feeFor(int $subtotalMinor): array
    {
        $rule = FeeRule::query()->where('key', 'platform_fee')->where('active', true)->latest('id')->first();
        $bps = $rule?->bps ?? 0;
        $min = (int) ($rule?->min_minor ?? 0);
        $fee = min($subtotalMinor, max($min, (new Money($subtotalMinor))->percentBps($bps)->minor));

        return ['fee' => $fee, 'bps' => $bps, 'min_minor' => $min];
    }

    /** Idempotent: a released order is returned unchanged. */
    public function release(Order $order): Order
    {
        return DB::transaction(function () use ($order): Order {
            $order = Order::query()->lockForUpdate()->findOrFail($order->id);
            if ($order->status === EscrowState::Released) {
                return $order;
            }
            if (! in_array($order->status, [EscrowState::Delivered, EscrowState::Disputed], true)) {
                throw new DomainException('Only a delivered order can be paid out.');
            }

            $subtotal = (int) $order->subtotal_minor;
            ['fee' => $fee] = $this->feeFor($subtotal);
            $payout = $subtotal - $fee;

            $order->transitionTo(EscrowState::Released);
            $this->ledger->post(array_values(array_filter([
                ['account' => 'escrow', 'debit' => $subtotal],
                ['account' => 'seller:'.$order->seller_id, 'credit' => $payout],
                $fee > 0 ? ['account' => 'platform_fee', 'credit' => $fee] : null,
            ])), $order->id, null, 'Escrow release');

            $order->forceFill([
                'fee_minor' => $fee, 'payout_minor' => $payout, 'released_at' => now(),
                'receipt_no' => 'NEAS-'.now()->format('Ymd').'-'.str_pad((string) $order->id, 6, '0', STR_PAD_LEFT),
            ])->save();
            AuditLog::record('order.released', $order, [], ['payout_minor' => $payout, 'fee_minor' => $fee]);
            $this->notes->notify($order->seller, 'payout.released', [
                'order' => $order->uuid, 'message' => 'Malipo yako ya '.(new Money($payout))->format().' yametolewa.',
            ]);

            return $order;
        });
    }

    /** 11.2: delivered orders auto-release once the buyer window (default 48h) has passed. */
    public function releaseDue(): int
    {
        $count = 0;
        Order::query()->where('status', EscrowState::Delivered->value)->whereNotNull('auto_release_at')
            ->where('auto_release_at', '<=', now())->each(function (Order $order) use (&$count): void {
                $this->release($order);
                $count++;
            });

        return $count;
    }

    /** MKT-07 itemised receipt. @return array<string, mixed> */
    public function receipt(Order $order): array
    {
        $order->loadMissing(['listing.produce.unit', 'listing.produce.crop', 'buyer', 'seller', 'deliveries']);
        $fee = $order->status === EscrowState::Released ? (int) $order->fee_minor : $this->feeFor((int) $order->subtotal_minor)['fee'];
        $rule = $this->feeFor((int) $order->subtotal_minor);

        return [
            'receipt_no' => $order->receipt_no, 'released' => $order->status === EscrowState::Released,
            'order' => $order, 'item' => $order->listing?->produce?->crop?->name_en ?? $order->listing?->title,
            'unit' => $order->listing?->produce?->unit?->name_en,
            'quantity' => $order->quantity, 'unit_price' => new Money((int) $order->unit_price_minor),
            'subtotal' => new Money((int) $order->subtotal_minor), 'fee' => new Money($fee), 'fee_bps' => $rule['bps'],
            'payout' => new Money((int) $order->subtotal_minor - $fee),
        ];
    }
}
