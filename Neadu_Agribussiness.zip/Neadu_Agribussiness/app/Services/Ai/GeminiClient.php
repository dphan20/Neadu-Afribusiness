<?php

declare(strict_types=1);

namespace App\Services\Ai;

use DomainException;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\RequestException;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Thin, resilient Gemini client. Reads the key from config (.env) only; never logs prompts, answers or the key.
 *
 * Why answers used to fail:
 *  - a retired model name (404) was reported as a vague "AI had a problem";
 *  - the model's hidden "thinking" tokens shared the 2048-token output cap, so the visible answer came back empty or cut off;
 *  - safety blocks, truncation and empty replies were all reported the same way.
 * Now: a model fallback chain, a large output cap, thinking switched off where supported, and a specific message per failure.
 */
final class GeminiClient
{
    private const MAX_EDGE = 1024;      // longest side sent to the model; keeps uploads small (FE-21)
    private const MAX_RAW_BYTES = 4_000_000;
    private const SAFETY_FINISH = ['SAFETY', 'PROHIBITED_CONTENT', 'BLOCKLIST', 'SPII', 'IMAGE_SAFETY', 'RECITATION'];

    public function configured(): bool
    {
        return filled(config('services.gemini.key'));
    }

    /**
     * Default is the Gemini API (generativelanguage.googleapis.com), which accepts AI Studio keys ("AIza..." and "AQ....").
     * Set GEMINI_PROVIDER=vertex only for a Google Cloud Vertex AI key.
     */
    public function provider(): string
    {
        $forced = (string) config('services.gemini.provider', 'auto');
        if (in_array($forced, ['studio', 'vertex'], true)) {
            return $forced;
        }

        return 'studio'; // AIza... and AQ.... keys from AI Studio both use generativelanguage.googleapis.com
    }

    /** @return string full generateContent URL for a model (the key goes in the x-goog-api-key header) */
    public function url(string $model): string
    {
        if ($this->provider() === 'vertex') {
            return rtrim((string) config('services.gemini.vertex_base_url', 'https://aiplatform.googleapis.com/v1'), '/').'/publishers/google/models/'.$model.':generateContent';
        }

        return rtrim((string) config('services.gemini.base_url'), '/').'/models/'.$model.':generateContent';
    }

    /** @return list<string> primary model first, then fallbacks, no duplicates */
    public function models(): array
    {
        $fallbacks = config('services.gemini.fallback_models', []);
        $fallbacks = is_string($fallbacks) ? explode(',', $fallbacks) : (array) $fallbacks;
        $all = array_map(static fn ($m): string => trim((string) $m), [(string) config('services.gemini.model'), ...$fallbacks]);

        return array_values(array_unique(array_filter($all, static fn (string $m): bool => $m !== '')));
    }

    /**
     * @param  array<string, mixed>|null  $schema  Gemini response schema; when set the model returns JSON
     * @param  list<array{role: 'user'|'model', text: string}>  $history  earlier turns of the same conversation, oldest first
     * @return string raw text of the answer
     */
    public function generate(string $system, string $prompt, ?string $imagePath = null, ?array $schema = null, array $history = [], ?int $maxTokens = null): string
    {
        if (! $this->configured()) {
            throw new DomainException('AI is not configured. Add GEMINI_API_KEY to .env.');
        }

        $contents = $this->contents($prompt, $imagePath, $history);

        $message = null;
        foreach ($this->models() as $model) {
            [$text, $message, $stop] = $this->attempt($model, $system, $contents, $schema, $maxTokens);
            if ($text !== null) {
                return $text;
            }
            if ($stop) {
                break; // a bad key or a blocked question will not improve on another model
            }
        }

        throw new DomainException($message ?? 'The AI service had a problem. Please try again.');
    }

    /** Speech to text for the voice buttons. Returns only the words that were spoken ('' when nothing was said). */
    public function transcribe(string $path, string $mime, string $lang = 'sw-TZ'): string
    {
        if (! $this->configured()) {
            throw new DomainException('Voice needs the AI key. Add GEMINI_API_KEY to .env.');
        }
        $bytes = (string) @file_get_contents($path);
        if ($bytes === '') {
            throw new DomainException('The recording was empty. Please try again.');
        }
        $mime = strtolower(trim(explode(';', $mime)[0]));
        $mime = in_array($mime, ['audio/wav', 'audio/x-wav', 'audio/wave', 'audio/mp3', 'audio/mpeg', 'audio/ogg', 'audio/flac', 'audio/aac'], true) ? $mime : 'audio/wav';
        $language = str_starts_with($lang, 'en') ? 'English' : 'Kiswahili (Tanzania); the speaker may mix in English words';
        $contents = [['role' => 'user', 'parts' => [
            ['inline_data' => ['mime_type' => $mime, 'data' => base64_encode($bytes)]],
            ['text' => "Write down exactly what the speaker says. Language: {$language}. Return only the transcript text, nothing else."],
        ]]];

        $message = null;
        foreach ($this->models() as $model) {
            // Same settings as every other AI call (thinking tokens would otherwise use up the output and leave an empty transcript).
            $body = $this->requestBody($model, 'You are a precise speech-to-text engine for Kiswahili and English. Output only the spoken words.', $contents, null, 2048);
            try {
                $url = $this->url($model);
                $send = static fn (array $b): Response => Http::withHeaders(['x-goog-api-key' => (string) config('services.gemini.key')])
                    ->connectTimeout(8)->timeout(60)->post($url, $b);
                $response = $send($body);
                if ($response->status() === 400 && isset($body['generationConfig']['thinkingConfig'])) {
                    unset($body['generationConfig']['thinkingConfig']);
                    $response = $send($body);
                }
            } catch (Throwable $e) {
                Log::warning('gemini.transcribe_unreachable', ['model' => $model, 'error' => class_basename($e), 'detail' => mb_substr($e->getMessage(), 0, 200)]);
                $message = 'The AI service could not be reached. Check the internet connection and try again.';
                continue;
            }
            if ($response->failed()) {
                [, $message, $stop] = $this->failure($model, $response);
                if ($stop) {
                    break;
                }
                continue;
            }
            [$text, $readMessage] = $this->read($model, $response);
            if ($text === null) {
                $message = $readMessage === null || str_contains($readMessage, 'empty answer') ? 'I could not make out any words. Record again, closer to the microphone.' : $readMessage;
                continue;
            }

            return trim((string) $text, " \t\n\r\0\x0B\"'");
        }

        throw new DomainException($message ?? 'Voice could not be converted to text. Please try again.');
    }

    /**
     * Same as generate() but returns the decoded JSON object (tolerates a stray code fence); null when it is not valid JSON.
     *
     * @param  array<string, mixed>  $schema
     * @return array<string, mixed>|null
     */
    public function generateJson(string $system, string $prompt, ?string $imagePath, array $schema): ?array
    {
        $raw = trim($this->generate($system, $prompt, $imagePath, $schema));
        $raw = (string) preg_replace('/^```(?:json)?\s*|\s*```$/i', '', $raw);
        $data = json_decode($raw, true);

        return is_array($data) ? $data : null;
    }

    /** @return list<array<string, mixed>> */
    private function contents(string $prompt, ?string $imagePath, array $history): array
    {
        $contents = [];
        foreach ($history as $turn) {
            $contents[] = ['role' => $turn['role'], 'parts' => [['text' => $turn['text']]]];
        }

        $parts = [];
        if ($imagePath !== null) {
            [$mime, $bytes] = $this->prepareImage($imagePath);
            $parts[] = ['inline_data' => ['mime_type' => $mime, 'data' => base64_encode($bytes)]]; // image before text: best accuracy
        }
        $parts[] = ['text' => $prompt];
        $contents[] = ['role' => 'user', 'parts' => $parts];

        return $contents;
    }

    /**
     * Speed settings live here once: a short output cap, the least "thinking" the model allows, and BLOCK_ONLY_HIGH safety.
     *
     * @param  list<array<string, mixed>>  $contents
     * @param  array<string, mixed>|null  $schema
     * @return array<string, mixed>
     */
    private function requestBody(string $model, string $system, array $contents, ?array $schema, ?int $maxTokens): array
    {
        $cap = $maxTokens ?? (int) config('services.gemini.max_output_tokens', 8192);
        $config = ['temperature' => 0.4, 'maxOutputTokens' => max(256, $cap)];
        if (str_starts_with($model, 'gemini-2.5-flash')) {
            $config['thinkingConfig'] = ['thinkingBudget' => 0]; // thinking tokens count against the cap and add seconds
        }
        $level = (string) config('services.gemini.thinking_level', 'minimal');
        if (str_starts_with($model, 'gemini-3') && $level !== '' && $level !== 'default') {
            $config['thinkingConfig'] = ['thinkingLevel' => $level];
        }
        if ($schema !== null) {
            $config['responseMimeType'] = 'application/json';
            $config['responseSchema'] = $schema;
        }

        return [
            'systemInstruction' => ['parts' => [['text' => $system]]],
            'contents' => $contents,
            'generationConfig' => $config,
            'safetySettings' => array_map(
                static fn (string $c): array => ['category' => $c, 'threshold' => 'BLOCK_ONLY_HIGH'],
                ['HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT'],
            ),
        ];
    }

    /**
     * Streams the answer: $onText receives each piece the moment Gemini produces it (first words in about a second,
     * instead of the whole answer after 10 to 30 seconds). Return false from $onText to stop (the user pressed Stop or
     * left the page); the connection to Gemini is closed so nothing more is generated or billed.
     *
     * @param  list<array{role: 'user'|'model', text: string}>  $history
     * @param  callable(string): bool  $onText
     * @return string everything received (possibly partial when stopped)
     */
    public function stream(string $system, string $prompt, ?string $imagePath, array $history, callable $onText, ?int $maxTokens = null): string
    {
        if (! $this->configured()) {
            throw new DomainException('AI is not configured. Add GEMINI_API_KEY to .env.');
        }

        $contents = $this->contents($prompt, $imagePath, $history);
        $message = null;

        foreach ($this->models() as $model) {
            [$full, $message, $stop, $started] = $this->streamAttempt($model, $system, $contents, $maxTokens, $onText);
            if ($full !== '' || $started) {
                return $full; // some or all of the answer was already shown; never restart on another model mid-answer
            }
            if ($stop) {
                break;
            }
        }

        throw new DomainException($message ?? 'The AI service had a problem. Please try again.');
    }

    /**
     * @param  list<array<string, mixed>>  $contents
     * @param  callable(string): bool  $onText
     * @return array{0: string, 1: ?string, 2: bool, 3: bool} [text, error, stop trying other models, answer started or stopped by the user]
     */
    private function streamAttempt(string $model, string $system, array $contents, ?int $maxTokens, callable $onText): array
    {
        $body = $this->requestBody($model, $system, $contents, null, $maxTokens);
        $url = $this->url($model).'?alt=sse';

        try {
            $response = Http::withHeaders(['x-goog-api-key' => (string) config('services.gemini.key')])
                ->withOptions(['stream' => true])
                ->connectTimeout(5)->timeout((int) config('services.gemini.timeout', 30))
                ->post($url, $body);

            if ($response->status() === 400 && isset($body['generationConfig']['thinkingConfig'])) {
                unset($body['generationConfig']['thinkingConfig']); // model does not take the thinking setting: ask again without it
                $response = Http::withHeaders(['x-goog-api-key' => (string) config('services.gemini.key')])
                    ->withOptions(['stream' => true])->connectTimeout(5)->timeout((int) config('services.gemini.timeout', 30))
                    ->post($url, $body);
            }
        } catch (Throwable $e) {
            Log::warning('gemini.unreachable', ['model' => $model, 'error' => class_basename($e)]);

            return ['', 'The AI service could not be reached. Check the internet connection and try again.', false, false];
        }

        if ($response->failed()) {
            [, $message, $stop] = $this->failure($model, $response);

            return ['', $message, $stop, false];
        }

        $stream = $response->toPsrResponse()->getBody();
        $buffer = '';
        $full = '';
        $stopped = false;
        $finish = '';
        $blocked = null;

        try {
            while (! $stream->eof() && ! $stopped) {
                $chunk = $stream->read(2048);
                if ($chunk === '') {
                    continue;
                }
                $buffer .= str_replace("\r\n", "\n", $chunk);

                while (($pos = strpos($buffer, "\n\n")) !== false) {
                    $event = substr($buffer, 0, $pos);
                    $buffer = substr($buffer, $pos + 2);
                    if (! str_starts_with($event, 'data:')) {
                        continue;
                    }
                    $json = json_decode(trim(substr($event, 5)), true);
                    if (! is_array($json)) {
                        continue;
                    }
                    $blocked = $json['promptFeedback']['blockReason'] ?? $blocked;
                    $finish = (string) ($json['candidates'][0]['finishReason'] ?? $finish);
                    foreach ($json['candidates'][0]['content']['parts'] ?? [] as $part) {
                        if (($part['thought'] ?? false) === true || ! isset($part['text']) || $part['text'] === '') {
                            continue; // never show the model's reasoning
                        }
                        $full .= $part['text'];
                        if ($onText((string) $part['text']) === false) {
                            $stopped = true;
                            break 2;
                        }
                    }
                }
            }
        } catch (Throwable $e) {
            Log::warning('gemini.stream_broken', ['model' => $model, 'error' => class_basename($e)]);
        } finally {
            $stream->close(); // closing the connection tells Gemini to stop generating
        }

        if (trim($full) !== '' || $stopped) {
            return [trim($full), null, false, true];
        }

        Log::info('gemini.empty', ['model' => $model, 'finish' => $finish, 'blocked' => $blocked]);
        if ($blocked !== null || in_array($finish, self::SAFETY_FINISH, true)) {
            return ['', 'The AI could not answer this one because of its safety filter. Rephrase the question or use a clearer photo.', true, false];
        }

        return ['', 'The AI sent an empty answer. Please ask again, or add more detail.', false, false];
    }

    /**
     * @param  list<array<string, mixed>>  $contents
     * @param  array<string, mixed>|null  $schema
     * @return array{0: ?string, 1: ?string, 2: bool} [text, user-facing error, stop trying other models]
     */
    private function attempt(string $model, string $system, array $contents, ?array $schema, ?int $maxTokens = null): array
    {
        $url = $this->url($model);
        $body = $this->requestBody($model, $system, $contents, $schema, $maxTokens);

        try {
            $send = static fn (array $b): Response => Http::withHeaders(['x-goog-api-key' => (string) config('services.gemini.key')])
                ->connectTimeout(5)->timeout((int) config('services.gemini.timeout', 30))
                ->retry(
                    1,
                    (int) config('services.gemini.retry_ms', 300),
                    static fn (Throwable $e): bool => $e instanceof ConnectionException
                        || ($e instanceof RequestException && in_array($e->response->status(), [429, 500, 502, 503, 504], true)),
                    throw: false,
                )
                ->post($url, $b);
            $response = $send($body);
            if ($response->status() === 400 && isset($body['generationConfig']['thinkingConfig']) && preg_match('/think|minimal|level/i', (string) $response->json('error.message')) === 1) {
                unset($body['generationConfig']['thinkingConfig']); // this model does not accept the thinking setting: ask again without it
                $response = $send($body);
            }
        } catch (Throwable $e) {
            Log::warning('gemini.unreachable', ['model' => $model, 'error' => class_basename($e)]);

            return [null, 'The AI service could not be reached. Check the internet connection and try again.', false];
        }

        if ($response->failed()) {
            return $this->failure($model, $response);
        }

        return $this->read($model, $response);
    }

    /** @return array{0: ?string, 1: ?string, 2: bool} */
    private function failure(string $model, Response $response): array
    {
        $status = $response->status();
        $detail = (string) $response->json('error.message', '');
        Log::warning('gemini.failed', ['model' => $model, 'status' => $status, 'reason' => $response->json('error.status')]);

        if ($status === 403 && (stripos($detail, 'has not been used') !== false || stripos($detail, 'is disabled') !== false || $response->json('error.details.0.reason') === 'SERVICE_DISABLED')) {
            return [null, 'The AI is switched off in your Google Cloud project. Open the link in the error (or console.cloud.google.com/apis/library/aiplatform.googleapis.com), click Enable, wait 5 minutes, or use a free AI Studio key (aistudio.google.com/apikey) with GEMINI_PROVIDER=studio.', true];
        }

        if ($status === 401 || $status === 403 || ($status === 400 && stripos($detail, 'api key') !== false)) {
            return [null, 'The AI service rejected the API key. Create a new key and put it in GEMINI_API_KEY in .env.', true];
        }

        return [null, match (true) {
            $status === 404 => 'The AI model "'.$model.'" is no longer available. Set GEMINI_MODEL in .env to a current model.',
            $status === 429 => 'The AI service is busy or the free limit was reached. Please try again in a minute.',
            $status === 400 => 'The AI service did not accept this request. Try a shorter question or a smaller photo.',
            default => 'The AI service had a problem. Please try again.',
        }, false];
    }

    /** @return array{0: ?string, 1: ?string, 2: bool} */
    private function read(string $model, Response $response): array
    {
        $candidate = (array) $response->json('candidates.0', []);
        $finish = (string) ($candidate['finishReason'] ?? '');
        $text = trim(collect($candidate['content']['parts'] ?? [])
            ->reject(static fn ($p): bool => ($p['thought'] ?? false) === true) // never show the model's reasoning
            ->pluck('text')->filter()->implode("\n"));

        if ($text !== '') {
            return [$text, null, false]; // an answer cut off at the cap is still better than none
        }

        Log::info('gemini.empty', ['model' => $model, 'finish' => $finish, 'blocked' => $response->json('promptFeedback.blockReason')]);

        if ($response->json('promptFeedback.blockReason') !== null || in_array($finish, self::SAFETY_FINISH, true)) {
            return [null, 'The AI could not answer this one because of its safety filter. Rephrase the question or use a clearer photo.', true];
        }

        return [null, 'The AI sent an empty answer. Please ask again, or add more detail.', false];
    }

    /** @return array{string, string} [mime, bytes]; resized JPEG when GD is available */
    private function prepareImage(string $path): array
    {
        if (! is_file($path)) {
            throw new DomainException('The photo could not be read.');
        }
        $raw = (string) file_get_contents($path);

        if (function_exists('imagecreatefromstring') && ($img = @imagecreatefromstring($raw)) !== false) {
            $w = imagesx($img);
            $h = imagesy($img);
            $scale = min(1, self::MAX_EDGE / max($w, $h));
            if ($scale < 1) {
                $img = imagescale($img, (int) round($w * $scale), (int) round($h * $scale)) ?: $img;
            }
            ob_start();
            imagejpeg($img, null, 78);
            $jpeg = (string) ob_get_clean();
            if ($jpeg !== '') {
                return ['image/jpeg', $jpeg];
            }
        }

        if (strlen($raw) > self::MAX_RAW_BYTES) {
            throw new DomainException('The photo is too large. Use a smaller one.');
        }

        return [(string) (mime_content_type($path) ?: 'image/jpeg'), $raw];
    }
}
