<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\PriceAlert;
use App\Models\PriceRecord;

/** PRC-03: send an alert when the latest price crosses the producer's threshold. At most one alert per day. */
final class PriceAlertEvaluator
{
    public function __construct(private readonly NotificationService $notes) {}

    public function run(): int
    {
        $sent = 0;
        PriceAlert::query()->with(['user', 'crop', 'market'])->where('active', true)->each(function (PriceAlert $alert) use (&$sent): void {
            if ($alert->last_triggered_at !== null && $alert->last_triggered_at->gt(now()->subDay())) {
                return;
            }
            $record = PriceRecord::query()->where('crop_id', $alert->crop_id)
                ->when($alert->market_id, fn ($q) => $q->where('market_id', $alert->market_id))
                ->orderByDesc('recorded_on')->orderByDesc('id')->first();
            if ($record === null) {
                return;
            }

            $price = (int) $record->price_minor;
            $threshold = (int) $alert->threshold_minor;
            $hit = $alert->condition === 'above' ? $price >= $threshold : $price <= $threshold;
            if (! $hit) {
                return;
            }

            $message = sprintf(
                'Bei ya %s imefika %s (%s ya %s) sokoni %s.',
                $alert->crop->name_sw, ProducerQueries::tsh($price), $alert->condition === 'above' ? 'juu' : 'chini',
                ProducerQueries::tsh($threshold), $record->market?->name ?? 'soko',
            );
            foreach ($alert->channels ?? ['in_app'] as $channel) {
                $this->notes->notify($alert->user, 'price.alert', ['alert' => $alert->uuid, 'price_minor' => $price, 'message' => $message], $channel);
            }
            $alert->forceFill(['last_triggered_at' => now()])->save();
            $sent++;
        });

        return $sent;
    }
}
