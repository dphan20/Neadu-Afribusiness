<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Listing;
use App\Models\StorageBooking;
use App\Models\User;
use App\Support\Quantity;
use Carbon\CarbonImmutable;
use DomainException;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;

/** STO-02/03: find a warehouse, request space, and pay by escrow or invoice. Listing price is per kg per day. */
final class StorageBookingService
{
    public function __construct(private readonly LedgerService $ledger, private readonly NotificationService $notes) {}

    /** @param array{region_id?: int|null, district_id?: int|null, min_kg?: float|null, q?: string|null} $filters */
    public function search(array $filters): Builder
    {
        return Listing::query()->with(['storage', 'owner'])->where('type', 'storage')->where('status', 'active')
            ->when($filters['region_id'] ?? null, fn (Builder $q, $v) => $q->where('region_id', $v))
            ->when($filters['district_id'] ?? null, fn (Builder $q, $v) => $q->where('district_id', $v))
            ->when($filters['q'] ?? null, fn (Builder $q, $v) => $q->where('title', 'like', '%'.$v.'%'))
            ->when($filters['min_kg'] ?? null, fn (Builder $q, $v) => $q->whereHas('storage', fn (Builder $s) => $s->where('capacity_kg', '>=', $v)))
            ->latest();
    }

    /** Capacity left in kg over a period, counting requested and accepted bookings. */
    public function freeKg(Listing $facility, string $from, string $to): float
    {
        $capacity = (float) ($facility->storage?->capacity_kg ?? 0);
        $booked = (float) StorageBooking::query()->where('facility_listing_id', $facility->id)
            ->whereIn('status', ['requested', 'accepted'])->where('starts_on', '<=', $to)->where('ends_on', '>=', $from)->sum('quantity_kg');

        return max(0.0, $capacity - $booked);
    }

    /** Price in minor units: price per kg-day x kg x days, in integer arithmetic (grams). */
    public function price(Listing $facility, float $kg, string $from, string $to): int
    {
        $days = CarbonImmutable::parse($from)->diffInDays(CarbonImmutable::parse($to)) + 1;
        $grams = Quantity::toMilli($kg);

        return intdiv((int) $facility->price_minor * $grams * (int) $days, 1000);
    }

    public function request(User $producer, Listing $facility, float $kg, string $from, string $to, string $method): StorageBooking
    {
        if (! $producer->isIdentityVerified()) {
            throw new DomainException('Verify your identity (NIDA) before booking storage.');
        }
        if ($facility->type->value !== 'storage' || $facility->status !== 'active') {
            throw new DomainException('This facility is not available for booking.');
        }
        if (! in_array($method, ['escrow', 'invoice'], true)) {
            throw new DomainException('Choose escrow or invoice.');
        }

        return DB::transaction(function () use ($producer, $facility, $kg, $from, $to, $method): StorageBooking {
            Listing::query()->whereKey($facility->id)->lockForUpdate()->first();
            if ($kg > $this->freeKg($facility, $from, $to)) {
                throw new DomainException('Not enough free capacity for those dates.');
            }

            $price = $this->price($facility, $kg, $from, $to);
            $booking = StorageBooking::query()->create([
                'facility_listing_id' => $facility->id, 'user_id' => $producer->id, 'quantity_kg' => $kg,
                'starts_on' => $from, 'ends_on' => $to, 'price_minor' => $price, 'status' => 'requested',
                'payment_method' => $method, 'payment_state' => $method === 'escrow' ? 'held' : 'invoiced',
            ]);

            if ($method === 'escrow') {
                $this->ledger->post([
                    ['account' => 'external:payment', 'debit' => $price],
                    ['account' => 'escrow', 'credit' => $price],
                ], null, null, 'Storage booking '.$booking->uuid);
            }

            $this->notes->notify($facility->owner, 'storage.requested', ['booking' => $booking->uuid, 'message' => 'Una ombi jipya la kuhifadhi mazao.']);

            return $booking;
        });
    }

    public function cancel(StorageBooking $booking, User $producer): void
    {
        if ($booking->user_id !== $producer->id || $booking->status !== 'requested') {
            throw new DomainException('Only your own pending requests can be cancelled.');
        }

        DB::transaction(function () use ($booking): void {
            if ($booking->payment_state === 'held') {
                $this->ledger->post([
                    ['account' => 'escrow', 'debit' => (int) $booking->price_minor],
                    ['account' => 'external:payment', 'credit' => (int) $booking->price_minor],
                ], null, null, 'Refund storage booking '.$booking->uuid);
            }
            $booking->forceFill(['status' => 'cancelled', 'payment_state' => $booking->payment_state === 'held' ? 'refunded' : $booking->payment_state])->save();
        });
    }
}
