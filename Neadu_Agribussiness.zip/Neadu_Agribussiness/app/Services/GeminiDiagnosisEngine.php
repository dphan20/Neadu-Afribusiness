<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\DiagnosisEngine;
use App\Services\Ai\GeminiClient;
use DomainException;

/** DIA-01/02 on Gemini: looks at the photo and answers in Kiswahili. */
final class GeminiDiagnosisEngine implements DiagnosisEngine
{
    private const KINDS = ['crop' => 'a crop or plant', 'livestock' => 'a farm animal', 'fish' => 'fish or a fish pond'];

    public function __construct(private readonly GeminiClient $client) {}

    public function diagnose(string $absolutePhotoPath, string $subject, string $kind): array
    {
        $system = 'You are an agricultural extension assistant for smallholder farmers in Tanzania. Look at the photo and give a likely diagnosis. '
            .'Write every text field in simple Kiswahili. Be honest about uncertainty: if the photo is unclear or does not show the named subject, say so in "result" and give a low confidence. '
            .'Never invent a dosage: tell the farmer to follow the product label or ask an extension officer or vet. '
            .'confidence is an integer 0-100.';
        $prompt = 'The farmer says this is '.(self::KINDS[$kind] ?? 'a crop').': "'.$subject.'". What is wrong, how to treat it, and how to prevent it?';

        $schema = [
            'type' => 'OBJECT',
            'properties' => [
                'result' => ['type' => 'STRING'], 'confidence' => ['type' => 'INTEGER'],
                'treatment' => ['type' => 'STRING'], 'prevention' => ['type' => 'STRING'],
            ],
            'required' => ['result', 'confidence', 'treatment', 'prevention'],
        ];

        $data = $this->client->generateJson($system, $prompt, $absolutePhotoPath, $schema);
        if ($data === null || ! isset($data['result'], $data['treatment'], $data['prevention'])) {
            throw new DomainException('The AI answer could not be understood. Please try again.');
        }

        return [
            'result' => mb_substr((string) $data['result'], 0, 250),
            'confidence' => max(0, min(100, (int) ($data['confidence'] ?? 50))),
            'treatment' => (string) $data['treatment'],
            'prevention' => (string) $data['prevention'],
        ];
    }
}
