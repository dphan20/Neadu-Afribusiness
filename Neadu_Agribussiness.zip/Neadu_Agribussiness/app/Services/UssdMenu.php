<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Crop;
use App\Models\PriceAlert;
use App\Models\User;
use DomainException;

/**
 * FE-32 (R2): USSD for feature phones, Africa's Talking style. `$text` is every answer so far joined by "*".
 * Replies start with CON (menu continues) or END (session over). Accepting an order needs the PIN.
 */
final class UssdMenu
{
    public function __construct(
        private readonly ProducerQueries $queries,
        private readonly WeatherService $weather,
        private readonly OrderWorkflow $orders,
        private readonly PinGuard $pins,
    ) {}

    public function handle(string $phone, string $text): string
    {
        $user = $this->queries->userByPhone($phone);
        if ($user === null || ! $user->roleAssignments()->where('role', 'P')->exists()) {
            return 'END Namba hii haijasajiliwa kama mzalishaji wa NeAS. Jisajili kwenye programu au tovuti.';
        }

        $steps = $text === '' ? [] : explode('*', $text);

        return match ($steps[0] ?? null) {
            null => "CON NeAS - Karibu {$this->first($user)}\n1. Bei za soko\n2. Oda zangu\n3. Hali ya hewa\n4. Tahadhari za bei",
            '1' => $this->prices($steps),
            '2' => $this->orderFlow($user, $steps),
            '3' => 'END '.$this->weatherText($user),
            '4' => $this->alerts($user),
            default => 'END Chaguo si sahihi.',
        };
    }

    /** @param list<string> $s */
    private function prices(array $s): string
    {
        $crops = Crop::query()->orderBy('name_sw')->limit(9)->get();
        if (count($s) === 1) {
            return "CON Chagua zao:\n".$crops->values()->map(fn (Crop $c, int $i) => ($i + 1).'. '.$c->name_sw)->implode("\n");
        }
        $crop = $crops->values()->get(((int) $s[1]) - 1);
        if ($crop === null) {
            return 'END Chaguo si sahihi.';
        }
        $rows = $this->queries->latestPrices($crop, null, 3);

        return $rows->isEmpty() ? "END Hakuna bei za {$crop->name_sw} kwa sasa."
            : "END Bei za {$crop->name_sw}:\n".$rows->map(fn ($r) => $r->market->name.': '.ProducerQueries::tsh((int) $r->price_minor))->implode("\n");
    }

    /** @param list<string> $s */
    private function orderFlow(User $user, array $s): string
    {
        $orders = $this->queries->awaitingOrders($user)->take(5)->values();
        if ($orders->isEmpty()) {
            return 'END Huna oda zinazosubiri jibu.';
        }
        if (count($s) === 1) {
            return "CON Oda zinazosubiri:\n".$orders->map(fn ($o, int $i) => ($i + 1).'. '.($o->listing?->title ?? 'Oda').' '.ProducerQueries::tsh((int) $o->subtotal_minor))->implode("\n");
        }
        $order = $orders->get(((int) $s[1]) - 1);
        if ($order === null) {
            return 'END Chaguo si sahihi.';
        }
        if (count($s) === 2) {
            return "CON {$order->listing?->title}\n1. Kubali\n2. Kataa";
        }
        if (! in_array($s[2], ['1', '2'], true)) {
            return 'END Chaguo si sahihi.';
        }
        if (count($s) === 3) {
            return 'CON Weka PIN yako kuthibitisha:';
        }
        if (! $this->pins->check($user, $s[3])) {
            return 'END PIN si sahihi.';
        }
        try {
            $s[2] === '1' ? $this->orders->accept($order, $user) : $this->orders->reject($order, $user, 'Rejected via USSD');
        } catch (DomainException $e) {
            return 'END Haikuwezekana: '.$e->getMessage();
        }

        return 'END Imekamilika. Mnunuzi amearifiwa.';
    }

    private function weatherText(User $user): string
    {
        $region = $this->queries->producerRegion($user);

        return $this->weather->summarySw($this->weather->forecast($region), $region?->name);
    }

    private function alerts(User $user): string
    {
        $alerts = PriceAlert::query()->with('crop')->where('user_id', $user->id)->where('active', true)->limit(5)->get();

        return $alerts->isEmpty() ? 'END Huna tahadhari za bei. Ziweke kwenye programu.'
            : "END Tahadhari zako:\n".$alerts->map(fn ($a) => $a->crop->name_sw.' '.($a->condition === 'above' ? '>=' : '<=').' '.ProducerQueries::tsh((int) $a->threshold_minor))->implode("\n");
    }

    private function first(User $user): string
    {
        return explode(' ', $user->name)[0];
    }
}
