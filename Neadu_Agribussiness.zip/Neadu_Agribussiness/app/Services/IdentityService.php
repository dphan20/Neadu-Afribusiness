<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\IdentityVerifier;
use App\Models\AuditLog;
use App\Models\User;
use DomainException;

/** ACC-03: NIDA verification. BR-01 makes this a gate for selling, shipping and listing. */
final class IdentityService
{
    public function __construct(private readonly IdentityVerifier $verifier) {}

    public function verifyNida(User $user, string $nidaNumber): void
    {
        if ($user->phone !== null && $user->phone_verified_at === null && ! config('neas.simulate_gateways')) {
            throw new DomainException('Verify your phone number first.');
        }

        // HMAC lets us enforce "one NIDA, one account" without decrypting stored numbers.
        $hash = hash_hmac('sha256', $nidaNumber, (string) config('app.key'));
        if (User::query()->where('nida_hash', $hash)->whereKeyNot($user->id)->exists()) {
            throw new DomainException('This NIDA number is already linked to another account.');
        }

        if (! $this->verifier->verify($nidaNumber, $user->name)) {
            throw new DomainException('We could not verify this NIDA number. Check it and try again.');
        }

        $before = ['verification_level' => $user->verification_level];
        $user->forceFill([
            'nida_number' => $nidaNumber, 'nida_hash' => $hash, 'verification_level' => 'nida', 'verified_at' => now(),
        ])->save();
        AuditLog::record('identity.verified', $user, $before, ['verification_level' => 'nida']);
    }
}
