<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\EscrowState;
use App\Models\AuditLog;
use App\Models\Dispute;
use App\Models\Order;
use App\Models\Payment;
use App\Models\RefundApproval;
use App\Models\User;
use DomainException;
use Illuminate\Support\Facades\DB;

/**
 * ADM-03 / BR-05 / NFR-S4: an admin decides a dispute as release, partial or refund.
 * The buyer paid goods + escrow fee into escrow. Refunds go back to the payer; refunds above the
 * configured threshold wait for a second admin before any money moves.
 */
final class DisputeService
{
    public function __construct(private readonly LedgerService $ledger, private readonly NotificationService $notes) {}

    /** @return array{fee: int, seller: int, refund: int} what each side receives for a decision */
    public function split(Order $order, string $decision, ?int $partialMinor): array
    {
        $total = $order->total();
        $subtotal = (int) $order->subtotal_minor;
        $fee = (int) $order->fee_minor;

        return match ($decision) {
            'release' => ['fee' => $fee, 'seller' => $subtotal, 'refund' => 0],
            'refund' => ['fee' => 0, 'seller' => 0, 'refund' => $total],
            'partial' => $this->partial($total, $subtotal, $fee, $partialMinor),
            default => throw new DomainException('Unknown decision.'),
        };
    }

    /** @return 'executed'|'pending' */
    public function decide(Dispute $dispute, User $admin, string $decision, ?int $partialMinor, string $note): string
    {
        return DB::transaction(function () use ($dispute, $admin, $decision, $partialMinor, $note): string {
            $dispute = Dispute::query()->lockForUpdate()->findOrFail($dispute->id);
            $order = Order::query()->lockForUpdate()->findOrFail($dispute->order_id);
            $this->assertOpen($dispute, $order);
            $split = $this->split($order, $decision, $partialMinor);

            $limit = (int) config('neas.refund.two_person_above_tzs', 500_000) * 100;
            if ($split['refund'] > $limit) {
                if (RefundApproval::query()->where('dispute_id', $dispute->id)->where('status', 'pending')->exists()) {
                    throw new DomainException('A refund for this dispute is already waiting for a second admin.');
                }
                $approval = RefundApproval::query()->create([
                    'dispute_id' => $dispute->id, 'payment_id' => Payment::query()->where('order_id', $order->id)->value('id'), 'amount_minor' => $split['refund'],
                    'requested_by' => $admin->id, 'decision' => $decision, 'partial_minor' => $decision === 'partial' ? $partialMinor : null, 'note' => $note, 'status' => 'pending',
                ]);
                AuditLog::record('refund.requested', $approval, [], ['dispute' => $dispute->uuid, 'amount_minor' => $split['refund'], 'decision' => $decision]);

                return 'pending';
            }

            $this->execute($dispute, $order, $admin, $decision, $partialMinor, $note, $split);

            return 'executed';
        });
    }

    /** The second admin confirms a pending refund (must be a different person). */
    public function approve(RefundApproval $approval, User $second): void
    {
        DB::transaction(function () use ($approval, $second): void {
            $a = RefundApproval::query()->lockForUpdate()->findOrFail($approval->id);
            if ($a->status !== 'pending') {
                throw new DomainException('This request was already handled.');
            }
            if ($a->requested_by === $second->id) {
                throw new DomainException('A different admin must approve this refund (two-person rule).');
            }
            $dispute = Dispute::query()->lockForUpdate()->findOrFail($a->dispute_id);
            $order = Order::query()->lockForUpdate()->findOrFail($dispute->order_id);
            $this->assertOpen($dispute, $order);
            $split = $this->split($order, $a->decision, $a->partial_minor);
            $this->execute($dispute, $order, $second, $a->decision, $a->partial_minor, (string) $a->note, $split);
            $a->forceFill(['approved_by' => $second->id, 'approved_at' => now(), 'executed_at' => now(), 'status' => 'executed'])->save();
            AuditLog::record('refund.approved', $a, ['status' => 'pending'], ['status' => 'executed']);
        });
    }

    public function reject(RefundApproval $approval, User $admin): void
    {
        if ($approval->status !== 'pending') {
            throw new DomainException('This request was already handled.');
        }
        $approval->forceFill(['status' => 'rejected', 'approved_by' => $admin->id, 'approved_at' => now()])->save();
        AuditLog::record('refund.rejected', $approval, ['status' => 'pending'], ['status' => 'rejected']);
    }

    /** @param array{fee: int, seller: int, refund: int} $split */
    private function execute(Dispute $dispute, Order $order, User $admin, string $decision, ?int $partialMinor, string $note, array $split): void
    {
        $lines = [['account' => 'escrow', 'debit' => $order->total()]];
        if ($split['seller'] > 0) {
            $lines[] = ['account' => 'seller:'.$order->seller_id, 'credit' => $split['seller']];
        }
        if ($split['fee'] > 0) {
            $lines[] = ['account' => 'platform_fee', 'credit' => $split['fee']];
        }
        if ($split['refund'] > 0) {
            $lines[] = ['account' => 'external:payment', 'credit' => $split['refund']];
        }
        $this->ledger->post($lines, $order->id, null, 'Dispute '.$decision.' '.$dispute->uuid);

        $order->transitionTo($decision === 'refund' ? EscrowState::Refunded : EscrowState::Released);
        if ($decision !== 'refund') {
            $order->forceFill(['released_at' => now(), 'payout_minor' => $split['seller'], 'fee_minor' => $split['fee']])->save();
        }
        Payment::query()->where('order_id', $order->id)->where('state', 'held')->update(['state' => $decision === 'refund' ? 'refunded' : 'released']);

        $dispute->forceFill([
            'decision' => $decision, 'partial_minor' => $decision === 'partial' ? $partialMinor : null,
            'decided_by' => $admin->id, 'decided_at' => now(), 'admin_note' => $note,
        ])->save();
        AuditLog::record('dispute.decided', $dispute, [], ['decision' => $decision, 'split' => $split]);
        foreach ([$order->buyer, $order->seller] as $u) {
            $this->notes->notify($u, 'dispute.decided', ['dispute' => $dispute->uuid, 'message' => 'Uamuzi wa mgogoro: '.['release' => 'malipo yametolewa kwa muuzaji', 'partial' => 'malipo yamegawanywa', 'refund' => 'pesa zimerudishwa kwa mnunuzi'][$decision].'.']);
        }
    }

    /** @return array{fee: int, seller: int, refund: int} */
    private function partial(int $total, int $subtotal, int $fee, ?int $partialMinor): array
    {
        if ($partialMinor === null || $partialMinor <= 0 || $partialMinor >= $subtotal) {
            throw new DomainException('The seller share must be more than zero and less than the goods value.');
        }
        $feeShare = intdiv($fee * $partialMinor, max(1, $subtotal));

        return ['fee' => $feeShare, 'seller' => $partialMinor, 'refund' => $total - $partialMinor - $feeShare];
    }

    private function assertOpen(Dispute $dispute, Order $order): void
    {
        if ($dispute->decision !== null || $order->status !== EscrowState::Disputed) {
            throw new DomainException('This dispute has already been decided.');
        }
    }
}
