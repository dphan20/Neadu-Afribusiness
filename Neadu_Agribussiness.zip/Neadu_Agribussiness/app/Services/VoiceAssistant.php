<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Order;
use App\Models\User;
use DomainException;
use Illuminate\Support\Facades\Cache;

/**
 * VOI-01..04 (R2): Kiswahili voice commands. The browser turns speech into text (Web Speech API, sw-TZ);
 * this class understands the text. Anything that moves money needs a spoken "ndiyo" first (VOI-04).
 */
final class VoiceAssistant
{
    private const CONFIRM_TTL_SECONDS = 120;

    public function __construct(
        private readonly ProducerQueries $queries,
        private readonly WeatherService $weather,
        private readonly OrderWorkflow $orders,
    ) {}

    /** @return array{reply: string, needs_confirmation: bool} */
    public function handle(User $user, string $utterance): array
    {
        $t = mb_strtolower(trim($utterance));
        $key = 'voice:pending:'.$user->id;

        if ($pending = Cache::get($key)) {
            if (preg_match('/\b(ndiyo|ndio|sawa|thibitisha)\b/u', $t)) {
                Cache::forget($key);

                return $this->say($this->execute($user, $pending));
            }
            if (preg_match('/\b(hapana|ghairi|acha|siyo)\b/u', $t)) {
                Cache::forget($key);

                return $this->say('Sawa, nimeghairi.');
            }
        }

        // Money actions: accept / reject an order by its number in the spoken list.
        if (preg_match('/\b(kubali|kataa)\b.*?\b(\d+|moja|mbili|tatu|nne|tano)\b/u', $t, $m)) {
            $n = $this->number($m[2]);
            $order = $this->queries->awaitingOrders($user)->values()->get($n - 1);
            if ($order === null) {
                return $this->say("Sina oda namba {$n} inayosubiri jibu lako.");
            }
            $action = $m[1] === 'kubali' ? 'accept' : 'reject';
            Cache::put($key, ['action' => $action, 'order' => $order->uuid], self::CONFIRM_TTL_SECONDS);
            $verb = $action === 'accept' ? 'kukubali' : 'kukataa';

            return ['reply' => "Unataka {$verb} oda namba {$n}: {$this->describe($order)}. Sema ndiyo kuthibitisha au hapana kughairi.", 'needs_confirmation' => true];
        }

        if (str_contains($t, 'bei')) {
            return $this->say($this->prices($t));
        }
        if (preg_match('/ghala|hifadh/u', $t)) {
            return $this->say($this->warehouses($user, $t));
        }
        if (preg_match('/hali ya hewa|mvua|hewa|joto/u', $t)) {
            $region = $this->queries->findRegion($t) ?? $this->queries->producerRegion($user);

            return $this->say($this->weather->summarySw($this->weather->forecast($region), $region?->name));
        }
        if (preg_match('/fuatilia|usafirishaji|mzigo|mizigo|gari/u', $t)) {
            return $this->say($this->tracking($user));
        }
        if (preg_match('/oda|maagizo/u', $t)) {
            return $this->say($this->orderList($user));
        }

        return $this->say('Samahani, sijaelewa. Unaweza kuuliza: bei ya mahindi, ghala, hali ya hewa, oda zangu, au mzigo wangu uko wapi.');
    }

    /** @param array{action: string, order: string} $pending */
    private function execute(User $user, array $pending): string
    {
        $order = Order::query()->where('uuid', $pending['order'])->first();
        if ($order === null) {
            return 'Oda haipatikani tena.';
        }
        try {
            if ($pending['action'] === 'accept') {
                $this->orders->accept($order, $user);

                return 'Nimekubali oda. Mnunuzi amearifiwa.';
            }
            $this->orders->reject($order, $user, 'Rejected by voice command');

            return 'Nimekataa oda. Mnunuzi amearifiwa.';
        } catch (DomainException $e) {
            return 'Haikuwezekana: '.$e->getMessage();
        }
    }

    private function prices(string $t): string
    {
        $crop = $this->queries->findCrop($t);
        $rows = $this->queries->latestPrices($crop, $this->queries->findRegion($t), 3);
        if ($rows->isEmpty()) {
            return 'Sina bei za hivi karibuni za mazao hayo.';
        }

        return $rows->map(fn ($r) => sprintf('%s: %s sokoni %s', $r->crop->name_sw, ProducerQueries::tsh((int) $r->price_minor), $r->market->name))->implode('. ').'.';
    }

    private function warehouses(User $user, string $t): string
    {
        $region = $this->queries->findRegion($t) ?? $this->queries->producerRegion($user);
        $rows = $this->queries->storageNear($region, 3);
        if ($rows->isEmpty()) {
            return 'Sijapata ghala kwa sasa.';
        }

        return 'Maghala: '.$rows->map(fn ($l) => sprintf('%s, uwezo kilo %s', $l->title, number_format((float) ($l->storage?->capacity_kg ?? 0))))->implode('; ').'.';
    }

    private function orderList(User $user): string
    {
        $rows = $this->queries->awaitingOrders($user);
        if ($rows->isEmpty()) {
            return 'Huna oda zinazosubiri jibu lako.';
        }

        return "Una oda {$rows->count()} zinazosubiri jibu. ".$rows->values()->map(fn (Order $o, int $i) => 'Namba '.($i + 1).': '.$this->describe($o))->implode('. ').'. Sema kubali oda namba, au kataa oda namba.';
    }

    private function tracking(User $user): string
    {
        $rows = $this->queries->deliveries($user, 3);
        if ($rows->isEmpty()) {
            return 'Huna mizigo inayosafirishwa.';
        }

        return $rows->map(fn ($d) => sprintf('Mzigo wa %s: %s', $d->order->listing?->title ?? 'oda', str_replace('_', ' ', $d->status)))->implode('. ').'.';
    }

    private function describe(Order $o): string
    {
        return sprintf('%s, kiasi %s, jumla %s', $o->listing?->title ?? 'bidhaa', rtrim(rtrim((string) $o->quantity, '0'), '.'), ProducerQueries::tsh((int) $o->subtotal_minor));
    }

    private function number(string $w): int
    {
        return ['moja' => 1, 'mbili' => 2, 'tatu' => 3, 'nne' => 4, 'tano' => 5][$w] ?? (int) $w;
    }

    /** @return array{reply: string, needs_confirmation: bool} */
    private function say(string $reply): array
    {
        return ['reply' => $reply, 'needs_confirmation' => false];
    }
}
