<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Payment;

/**
 * ADM-04: compare a mobile-money / bank statement (CSV: reference, amount in TSh, optional date) with NeAS payments.
 * A row matches a payment when the reference (phone or account, digits only) and the amount are the same.
 */
final class ReconciliationService
{
    /** @return array{matched: list<array<string,mixed>>, statement_only: list<array<string,mixed>>, neas_only: list<array<string,mixed>>, rows: int} */
    public function reconcile(string $csv, int $days = 90): array
    {
        $payments = Payment::query()->with('order')->whereIn('state', ['held', 'released', 'refunded'])->where('created_at', '>=', now()->subDays($days))->get()
            ->map(fn (Payment $p): array => ['p' => $p, 'ref' => $this->digits((string) $p->reference), 'amount' => (int) $p->amount_minor])->all();

        $matched = $statementOnly = [];
        $rows = 0;
        foreach (preg_split('/\R/', trim($csv)) ?: [] as $line) {
            $cells = str_getcsv($line);
            if (count($cells) < 2 || ! is_numeric(str_replace(',', '', (string) $cells[1]))) {
                continue; // header or blank
            }
            $rows++;
            $ref = $this->digits((string) $cells[0]);
            $amount = (int) round(((float) str_replace(',', '', (string) $cells[1])) * 100);
            $hit = null;
            foreach ($payments as $i => $row) {
                if ($row['ref'] === $ref && $row['amount'] === $amount) {
                    $hit = $i;
                    break;
                }
            }
            if ($hit === null) {
                $statementOnly[] = ['reference' => $cells[0], 'amount_minor' => $amount, 'date' => $cells[2] ?? ''];
            } else {
                $p = $payments[$hit]['p'];
                $matched[] = ['reference' => $cells[0], 'amount_minor' => $amount, 'payment' => $p->uuid, 'state' => $p->state, 'order' => $p->order?->uuid];
                unset($payments[$hit]);
            }
        }
        $neasOnly = array_values(array_map(fn (array $r): array => ['payment' => $r['p']->uuid, 'reference' => $r['p']->reference, 'amount_minor' => $r['amount'], 'state' => $r['p']->state, 'date' => $r['p']->created_at?->format('d-m-Y')], $payments));

        return ['matched' => $matched, 'statement_only' => $statementOnly, 'neas_only' => $neasOnly, 'rows' => $rows];
    }

    private function digits(string $s): string
    {
        return preg_replace('/\D+/', '', $s) ?? '';
    }
}
