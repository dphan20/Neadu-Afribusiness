<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\DiagnosisEngine;
use App\Enums\UserRole;
use App\Models\Conversation;
use App\Models\DiagnosisCase;
use App\Models\Message;
use App\Models\User;
use DomainException;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/** DIA-01..04: photo diagnosis in Kiswahili, expert chat and escalation. */
final class DiagnosisService
{
    public function __construct(private readonly DiagnosisEngine $engine, private readonly NotificationService $notes) {}

    public function diagnose(User $producer, UploadedFile $photo, string $subject, string $kind): DiagnosisCase
    {
        $path = $photo->store('diagnosis/'.$producer->uuid, 'local'); // private disk
        $out = $this->engine->diagnose(Storage::disk('local')->path($path), $subject, $kind);

        return DiagnosisCase::query()->create([
            'user_id' => $producer->id, 'photo_path' => $path, 'subject' => $subject, 'subject_kind' => $kind,
            'result' => $out['result'], 'confidence' => $out['confidence'],
            'treatment' => $out['treatment'], 'prevention' => $out['prevention'],
            'status' => 'open', 'ai_result' => $out['result'],
        ]);
    }

    /** DIA-03: one tap from a diagnosis into a chat with an expert (reuses the case's chat if it exists). */
    public function openExpertChat(DiagnosisCase $case): Conversation
    {
        if ($case->conversation_id !== null) {
            return $case->conversation;
        }

        return DB::transaction(function () use ($case): Conversation {
            $expert = $this->pickExpert();
            $conversation = Conversation::query()->create([]);
            $conversation->participants()->attach([$case->user_id, $expert->id]);
            Message::query()->create([
                'conversation_id' => $conversation->id, 'sender_id' => $case->user_id, 'kind' => 'text',
                'body' => "Habari mtaalamu. Naomba msaada kuhusu {$case->subject}. Utambuzi wa awali: {$case->result} ({$case->confidence}%).",
            ]);
            $case->forceFill(['expert_id' => $expert->id, 'conversation_id' => $conversation->id, 'status' => 'in_review', 'claimed_at' => now()])->save();
            $this->notes->notify($expert, 'diagnosis.chat', ['case' => $case->uuid, 'message' => 'Mzalishaji anahitaji ushauri wako.']);

            return $conversation;
        });
    }

    /** DIA-04: formally escalate so the expert sees it in "Expert cases". */
    public function escalate(DiagnosisCase $case): DiagnosisCase
    {
        if ($case->escalated_at !== null) {
            return $case;
        }
        // Goes to the expert queue (S-37); the first expert to claim it owns it. A case already in a chat stays with that expert.
        $case->forceFill(['escalated_at' => now(), 'status' => $case->expert_id === null ? 'escalated' : $case->status])->save();

        return $case->refresh();
    }

    /** Active expert with the fewest unanswered cases; verified experts first. */
    private function pickExpert(): User
    {
        $expert = User::query()->where('status', 'active')
            ->whereIn('id', DB::table('user_roles')->where('role', UserRole::Expert->value)->select('user_id'))
            ->withCount(['diagnosisCasesAssigned as open_cases' => fn ($q) => $q->whereNull('expert_reply')])
            ->orderByRaw("CASE WHEN verification_level IN ('nida','full') THEN 0 ELSE 1 END")
            ->orderBy('open_cases')->first();

        return $expert ?? throw new DomainException('No expert is available right now. Please try again later.');
    }
}
