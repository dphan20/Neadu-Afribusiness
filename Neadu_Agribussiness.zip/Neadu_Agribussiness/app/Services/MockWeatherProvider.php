<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\WeatherProvider;

/** Deterministic offline forecast, used when the live provider is unreachable or WEATHER provider = mock. */
final class MockWeatherProvider implements WeatherProvider
{
    public function forecast(float $lat, float $lng): array
    {
        $days = [];
        for ($i = 0; $i < 7; $i++) {
            $seed = abs((int) (($lat * 1000 + $lng * 100) + $i * 7)) % 100;
            $days[] = [
                'date' => now()->addDays($i)->toDateString(),
                'tmax' => 27 + ($seed % 8),
                'tmin' => 16 + ($seed % 5),
                'rain_mm' => (float) (($seed % 4 === 0) ? 10 + $seed % 30 : 0),
                'wind_kmh' => (float) (10 + $seed % 25),
            ];
        }

        return $days;
    }
}
