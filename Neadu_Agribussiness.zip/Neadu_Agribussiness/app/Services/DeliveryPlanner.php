<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\EscrowState;
use App\Enums\UserRole;
use App\Models\Order;
use App\Models\Rating;
use App\Models\User;
use App\Models\Delivery;
use App\Models\Vehicle;
use DomainException;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/** LOG-02/04: price suggestion, transporter suggestions and delivery booking. */
final class DeliveryPlanner
{
    public function __construct(private readonly NotificationService $notes) {}

    /** Road distance estimate: great-circle distance times a road factor. */
    public function distanceKm(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $r = 6371.0;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;

        return round($r * 2 * atan2(sqrt($a), sqrt(1 - $a)) * (float) config('neas.transport.road_factor'), 2);
    }

    /** Suggested price in minor units: base + per km + per tonne-km. */
    public function suggestPrice(float $km, ?int $kg): int
    {
        $c = config('neas.transport');
        $tzs = $c['base_tzs'] + $km * $c['per_km_tzs'] + $km * (($kg ?? 0) / 1000) * $c['per_tonne_km_tzs'];

        return (int) (round($tzs / 100) * 100) * 100; // round to nearest 100 TZS, then to minor units
    }

    /** Order weight in whole kg, or null when the unit has no kg equivalent (head, litre). */
    public function orderWeightKg(Order $order): ?int
    {
        $factor = $order->listing?->produce?->unit?->kg_factor_milli;
        if ($factor === null) {
            return null;
        }
        $qtyMilli = (int) round(((float) $order->quantity) * 1000);

        return intdiv($qtyMilli * (int) $factor + 999_999, 1_000_000);
    }

    /** @return Collection<int, array{user: User, vehicle: Vehicle, rating: ?float}> smallest sufficient vehicle first */
    public function suggestTransporters(?int $kg, int $limit = 5): Collection
    {
        return Vehicle::query()->with('owner')
            ->when($kg !== null, fn ($q) => $q->where('capacity_kg', '>=', $kg))
            ->whereHas('owner', fn ($q) => $q->where('status', 'active')
                ->whereIn('id', DB::table('user_roles')->where('role', UserRole::Transporter->value)->select('user_id')))
            ->orderBy('capacity_kg')->limit($limit * 3)->get()
            ->unique('user_id')->take($limit)
            ->map(fn (Vehicle $v): array => [
                'user' => $v->owner, 'vehicle' => $v,
                'rating' => ($avg = Rating::query()->where('ratee_id', $v->user_id)->avg('stars')) === null ? null : round((float) $avg, 1),
            ])->values();
    }

    /**
     * @param array{pickup_lat?: float|null, pickup_lng?: float|null, drop_lat: float, drop_lng: float, transporter_id?: int|null, price_minor?: int|null} $data
     */
    public function book(Order $order, User $producer, array $data): Delivery
    {
        if ($order->seller_id !== $producer->id) {
            throw new DomainException('This order does not belong to you.');
        }
        if (! $producer->isIdentityVerified()) {
            throw new DomainException('Verify your identity (NIDA) before booking delivery.');
        }
        if ($order->accepted_at === null || $order->status !== EscrowState::Held) {
            throw new DomainException('Delivery can be booked once the order is accepted and paid into escrow.');
        }
        if ($order->deliveries()->whereNotIn('status', ['cancelled'])->exists()) {
            throw new DomainException('A delivery is already booked for this order.');
        }

        $order->loadMissing('listing.produce.unit');
        $pickupLat = $data['pickup_lat'] ?? $order->listing?->lat;
        $pickupLng = $data['pickup_lng'] ?? $order->listing?->lng;
        if ($pickupLat === null || $pickupLng === null) {
            throw new DomainException('Add a pickup location to book delivery.');
        }

        $transporterId = $data['transporter_id'] ?? null;
        if ($transporterId !== null) {
            $isTransporter = DB::table('user_roles')->where('user_id', $transporterId)->where('role', UserRole::Transporter->value)->exists();
            if (! $isTransporter) {
                throw new DomainException('The selected transporter is not available.');
            }
        }

        $km = $this->distanceKm((float) $pickupLat, (float) $pickupLng, (float) $data['drop_lat'], (float) $data['drop_lng']);
        $suggested = $this->suggestPrice($km, $this->orderWeightKg($order));
        $code = str_pad((string) random_int(0, 999_999), 6, '0', STR_PAD_LEFT);

        $delivery = Delivery::query()->create([
            'order_id' => $order->id, 'transporter_id' => $transporterId, 'booked_by' => $producer->id,
            'pickup_lat' => $pickupLat, 'pickup_lng' => $pickupLng, 'drop_lat' => $data['drop_lat'], 'drop_lng' => $data['drop_lng'],
            'distance_km' => $km, 'suggested_price_minor' => $suggested, 'price_minor' => $data['price_minor'] ?? $suggested,
            'status' => 'requested', 'delivery_code_hash' => Hash::make($code),   // BR-09
        ]);
        $order->forceFill(['delivery_option' => 'transporter'])->save();

        // BR-09: the handover code goes to the buyer, never to the seller or transporter.
        $this->notes->notify($order->buyer, 'delivery.code', [
            'order' => $order->uuid, 'delivery_code' => $code, 'message' => "Nambari ya kupokea mzigo: {$code}. Mpe msafirishaji tu unapopokea mzigo.",
        ]);
        if ($transporterId !== null) {
            $this->notes->notify(User::query()->findOrFail($transporterId), 'delivery.requested', ['delivery' => $delivery->uuid, 'message' => 'Una kazi mpya ya usafirishaji.']);
        }

        return $delivery;
    }
}
