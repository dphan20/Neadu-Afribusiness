<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\WeatherProvider;
use App\Models\Region;
use Carbon\CarbonInterface;

/** WTH-01..03: forecast, severe-weather alerts and planting / harvest windows, all in Kiswahili. */
final class WeatherService
{
    private const MONTHS_SW = [1 => 'Januari', 'Februari', 'Machi', 'Aprili', 'Mei', 'Juni', 'Julai', 'Agosti', 'Septemba', 'Oktoba', 'Novemba', 'Desemba'];

    public function __construct(private readonly WeatherProvider $provider) {}

    /** @return list<array{date: string, tmax: float, tmin: float, rain_mm: float, wind_kmh: float}> */
    public function forecast(?Region $region): array
    {
        [$lat, $lng] = $this->coordinates($region);

        return $this->provider->forecast($lat, $lng);
    }

    /** Region centre used for every forecast (regions have no lat/lng column). @return array{0: float, 1: float} */
    public function coordinates(?Region $region): array
    {
        [$lat, $lng] = config('neas.region_coordinates')[$region?->name ?? 'Dodoma'] ?? config('neas.region_coordinates')['Dodoma'];

        return [(float) $lat, (float) $lng];
    }

    /**
     * WTH-03: a simple, indicative rule on the 7-day rain total. Not agronomic advice.
     *
     * @param  list<array{rain_mm: float}>  $days
     * @return array{level: string, mm: int}|null null when there is no forecast
     */
    public function rainHint(array $days): ?array
    {
        if ($days === []) {
            return null;
        }
        $total = array_sum(array_map(static fn (array $d): float => (float) $d['rain_mm'], $days));

        return ['level' => $total < 10 ? 'dry' : ($total < 40 ? 'moderate' : 'wet'), 'mm' => (int) round($total)];
    }

    /** WTH-02. @return list<array{date: string, kind: string, message: string}> */
    public function alerts(array $days): array
    {
        $limit = config('neas.weather.severe');
        $out = [];
        foreach ($days as $d) {
            if ($d['rain_mm'] >= $limit['rain_mm']) {
                $out[] = ['date' => $d['date'], 'kind' => 'rain', 'message' => "Mvua kubwa inatarajiwa ({$d['rain_mm']} mm). Linda mazao na vuna mapema ikiwezekana."];
            }
            if ($d['wind_kmh'] >= $limit['wind_kmh']) {
                $out[] = ['date' => $d['date'], 'kind' => 'wind', 'message' => "Upepo mkali unatarajiwa ({$d['wind_kmh']} km/h). Funga na linda mabanda na mazao."];
            }
            if ($d['tmax'] >= $limit['heat_c']) {
                $out[] = ['date' => $d['date'], 'kind' => 'heat', 'message' => "Joto kali linatarajiwa ({$d['tmax']}°C). Hakikisha mifugo na mimea inapata maji ya kutosha."];
            }
        }

        return $out;
    }

    /** WTH-03. @return array{status: string, label: string, next: ?string}|null null when the crop has no calendar */
    public function window(string $cropSlug, CarbonInterface $now): ?array
    {
        $cal = config('neas.crop_calendar')[$cropSlug] ?? null;
        if ($cal === null) {
            return null;
        }
        $m = (int) $now->month;
        $status = in_array($m, $cal['planting'], true) ? 'planting' : (in_array($m, $cal['harvest'], true) ? 'harvest' : 'off');
        $label = match ($status) {
            'planting' => 'Sasa ni wakati wa kupanda',
            'harvest' => 'Sasa ni wakati wa kuvuna',
            default => 'Si wakati wa kupanda wala kuvuna',
        };

        $next = null;
        for ($i = 1; $i <= 12; $i++) {
            $month = (($m - 1 + $i) % 12) + 1;
            if ($status !== 'planting' && in_array($month, $cal['planting'], true)) {
                $next = 'Kupanda kunaanza '.self::MONTHS_SW[$month];
                break;
            }
            if ($status === 'planting' && in_array($month, $cal['harvest'], true)) {
                $next = 'Kuvuna kunaanza '.self::MONTHS_SW[$month];
                break;
            }
        }

        return ['status' => $status, 'label' => $label, 'next' => $next];
    }

    public function summarySw(array $days, ?string $regionName): string
    {
        $today = $days[0] ?? null;
        if ($today === null) {
            return 'Hakuna utabiri wa hali ya hewa kwa sasa.';
        }
        $text = sprintf('Hali ya hewa %s leo: joto kati ya %d na %d nyuzi, mvua %s.',
            $regionName ?? 'kwako', round($today['tmin']), round($today['tmax']),
            $today['rain_mm'] > 0 ? round($today['rain_mm']).' mm' : 'hakuna');
        $alerts = $this->alerts($days);
        if ($alerts !== []) {
            $text .= ' Tahadhari: '.$alerts[0]['message'];
        }

        return $text;
    }
}
