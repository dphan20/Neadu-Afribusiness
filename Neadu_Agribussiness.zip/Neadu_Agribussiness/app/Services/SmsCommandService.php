<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\User;
use DomainException;

/**
 * FE-32 (R2): SMS keywords for feature phones.
 *   BEI mahindi [mkoa]   HALI [mkoa]   ODA   KUBALI <namba> <PIN>   KATAA <namba> <PIN>
 */
final class SmsCommandService
{
    public function __construct(
        private readonly ProducerQueries $queries,
        private readonly WeatherService $weather,
        private readonly OrderWorkflow $orders,
        private readonly PinGuard $pins,
    ) {}

    public function handle(string $phone, string $body): string
    {
        $user = $this->queries->userByPhone($phone);
        if ($user === null || ! $user->roleAssignments()->where('role', 'P')->exists()) {
            return 'Namba hii haijasajiliwa NeAS kama mzalishaji.';
        }

        $parts = preg_split('/\s+/', trim($body)) ?: [];
        $keyword = mb_strtoupper($parts[0] ?? '');
        $rest = implode(' ', array_slice($parts, 1));

        return match ($keyword) {
            'BEI' => $this->prices($rest),
            'HALI' => $this->weatherText($user, $rest),
            'ODA' => $this->orderList($user),
            'KUBALI', 'KATAA' => $this->answer($user, $keyword, $parts),
            default => 'Tuma: BEI mahindi | HALI | ODA | KUBALI 1 PIN | KATAA 1 PIN',
        };
    }

    private function prices(string $text): string
    {
        $rows = $this->queries->latestPrices($this->queries->findCrop($text), $this->queries->findRegion($text), 3);

        return $rows->isEmpty() ? 'Hakuna bei zilizopatikana.'
            : $rows->map(fn ($r) => "{$r->crop->name_sw} {$r->market->name}: ".ProducerQueries::tsh((int) $r->price_minor))->implode('; ');
    }

    private function weatherText(User $user, string $text): string
    {
        $region = $this->queries->findRegion($text) ?? $this->queries->producerRegion($user);

        return $this->weather->summarySw($this->weather->forecast($region), $region?->name);
    }

    private function orderList(User $user): string
    {
        $rows = $this->queries->awaitingOrders($user)->take(5)->values();

        return $rows->isEmpty() ? 'Huna oda zinazosubiri jibu.'
            : $rows->map(fn ($o, int $i) => ($i + 1).'. '.($o->listing?->title ?? 'Oda').' '.ProducerQueries::tsh((int) $o->subtotal_minor))->implode('; ').'. Jibu: KUBALI namba PIN';
    }

    /** @param list<string> $parts */
    private function answer(User $user, string $keyword, array $parts): string
    {
        $n = (int) ($parts[1] ?? 0);
        $pin = $parts[2] ?? '';
        $order = $this->queries->awaitingOrders($user)->values()->get($n - 1);
        if ($order === null) {
            return "Sina oda namba {$n}. Tuma ODA kuona orodha.";
        }
        if (! $this->pins->check($user, $pin)) {
            return 'PIN si sahihi.';
        }
        try {
            $keyword === 'KUBALI' ? $this->orders->accept($order, $user) : $this->orders->reject($order, $user, 'Rejected via SMS');
        } catch (DomainException $e) {
            return 'Haikuwezekana: '.$e->getMessage();
        }

        return $keyword === 'KUBALI' ? 'Oda imekubaliwa.' : 'Oda imekataliwa.';
    }
}
