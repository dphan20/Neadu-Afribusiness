<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\PaymentGateway;
use App\Enums\EscrowState;
use App\Models\AuditLog;
use App\Models\Order;
use App\Models\Payment;
use DomainException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Phase 4: one place that moves a buyer payment through
 *   initiated -> held | failed | cancelled | review   (later: released | refunded, by the escrow code).
 *
 * Every transition happens under a row lock, so a callback, a poll and a double-click can never fund an order twice.
 * `review` means money arrived that NeAS cannot safely put into escrow (wrong amount, or the order was already closed):
 * it is shown to finance and never silently kept.
 */
final class PaymentService
{
    public function __construct(
        private readonly PaymentGateway $gateway,
        private readonly LedgerService $ledger,
        private readonly NotificationService $notes,
    ) {}

    /** Begin paying an accepted order. Returns the payment; in simulation mode it is already `held`. */
    public function start(Order $order, string $provider, string $reference): Payment
    {
        // A callback may have been missed for an earlier attempt: ask the provider before allowing a second charge.
        foreach (Payment::query()->where('order_id', $order->id)->where('state', 'initiated')->get() as $earlier) {
            $this->refresh($earlier);
        }

        $payment = DB::transaction(function () use ($order, $provider, $reference): Payment {
            $order = Order::query()->lockForUpdate()->findOrFail($order->id);
            if ($order->status !== EscrowState::Pending || $order->accepted_at === null || $order->counter_unit_price_minor !== null) {
                throw new DomainException('This order is not ready for payment.');
            }
            if (Payment::query()->where('order_id', $order->id)->whereIn('state', ['held', 'review'])->exists()) {
                throw new DomainException('This order already has a payment.');
            }
            if (Payment::query()->where('order_id', $order->id)->where('state', 'initiated')->exists()) {
                throw new DomainException('A payment for this order is still waiting for approval on your phone.');
            }

            $attempt = Payment::withTrashed()->where('order_id', $order->id)->count() + 1;

            return Payment::query()->create([
                'order_id' => $order->id, 'amount_minor' => $order->total(), 'fee_minor' => $order->fee_minor, 'currency' => $order->currency,
                'provider' => $provider, 'reference' => $reference, 'state' => 'initiated',
                'idempotency_key' => 'order-'.$order->uuid.'-pay-'.$attempt,
            ]);
        });

        if (config('neas.simulate_gateways')) {
            return $this->settle($payment, 'successful', (int) $payment->amount_minor);
        }

        try {
            $ref = $this->gateway->charge((string) $payment->reference, (int) $payment->amount_minor, $payment->provider, $payment->idempotency_key);
            $payment->forceFill(['provider_ref' => mb_substr($ref, 0, 80)])->save();
        } catch (DomainException $e) {
            $this->settle($payment, 'failed', null, $e->getMessage()); // refused by the provider: nothing was charged

            throw $e;
        } catch (Throwable $e) {
            // Network error or timeout: the charge may or may not exist. Leave it `initiated`; the callback or
            // `neas:reconcile-payments` will decide, and the idempotency key makes a repeat harmless.
            Log::warning('Payment charge outcome unknown', ['payment' => $payment->uuid, 'error' => $e->getMessage()]);
        }

        return $payment->refresh();
    }

    /**
     * Apply a provider outcome. Safe to call any number of times, from a callback, a poll or a person.
     *
     * @param  'successful'|'failed'|'cancelled'  $outcome
     * @param  int|null  $paidMinor  amount the provider says it collected (callbacks must send it)
     */
    public function settle(Payment $payment, string $outcome, ?int $paidMinor = null, ?string $reason = null): Payment
    {
        return DB::transaction(function () use ($payment, $outcome, $paidMinor, $reason): Payment {
            $p = Payment::query()->lockForUpdate()->findOrFail($payment->id);
            $order = Order::query()->lockForUpdate()->findOrFail($p->order_id);

            if ($outcome === 'successful') {
                // A late success may still arrive for a payment we already gave up on; only these states can still be funded.
                if (! in_array($p->state, ['initiated', 'failed', 'cancelled'], true)) {
                    return $p; // held, released, refunded or in review already: duplicate delivery
                }
                if ($paidMinor === null || $paidMinor !== (int) $p->amount_minor) {
                    return $this->flag($p, 'Amount mismatch: expected '.$p->amount_minor.', provider reported '.($paidMinor ?? 'none'));
                }
                if ($order->status !== EscrowState::Pending) {
                    return $this->flag($p, 'Paid after the order was closed ('.$order->status->value.'). Refund the buyer.');
                }

                $p->forceFill(['state' => 'held', 'settled_at' => now(), 'failure_reason' => null])->save();
                $this->ledger->post([
                    ['account' => 'buyer:'.$order->buyer_id, 'debit' => (int) $p->amount_minor],
                    ['account' => 'escrow', 'credit' => (int) $p->amount_minor],
                ], $order->id, $p->id, 'Escrow funded');
                $order->transitionTo(EscrowState::Held);
                AuditLog::record('payment.held', $p, ['state' => 'initiated'], ['state' => 'held']);
                $this->notes->notify($order->seller, 'order.paid', ['order' => $order->uuid, 'message' => 'Mnunuzi amelipa. Pesa ziko salama kwenye escrow.']);

                return $p;
            }

            if ($p->state !== 'initiated') {
                return $p; // a failure report must never undo a payment that is already held or closed
            }
            $p->forceFill(['state' => $outcome === 'cancelled' ? 'cancelled' : 'failed', 'failure_reason' => mb_substr((string) $reason, 0, 200), 'settled_at' => now()])->save();
            AuditLog::record('payment.'.$p->state, $p, ['state' => 'initiated'], ['reason' => $reason]);
            $this->notes->notify($order->buyer, 'payment.'.$p->state, [
                'order' => $order->uuid, 'message' => $outcome === 'cancelled' ? 'Malipo yalighairiwa. Unaweza kujaribu tena.' : 'Malipo hayakufanikiwa. Hakuna pesa iliyokatwa; jaribu tena.',
            ]);

            return $p;
        });
    }

    /** Ask the provider about one waiting payment and apply the answer. Returns the final state. */
    public function refresh(Payment $payment): string
    {
        $status = $this->gateway->status($payment->idempotency_key, $payment->provider_ref);

        return match ($status) {
            'successful' => $this->settle($payment, 'successful', (int) $payment->amount_minor)->state, // a poll has no separate amount; the provider says it is paid in full
            'failed', 'cancelled' => $this->settle($payment, $status, null, 'Provider reported '.$status)->state,
            default => $payment->refresh()->state,
        };
    }

    /**
     * Callbacks that never came: poll payments waiting longer than `pending_minutes`, and give up after `expire_minutes`.
     *
     * @return array{checked: int, held: int, closed: int, still_waiting: int}
     */
    public function reconcilePending(): array
    {
        $out = ['checked' => 0, 'held' => 0, 'closed' => 0, 'still_waiting' => 0];
        $after = now()->subMinutes((int) config('neas.payments.pending_minutes', 10));
        $giveUp = now()->subMinutes((int) config('neas.payments.expire_minutes', 30));

        Payment::query()->where('state', 'initiated')->where('created_at', '<=', $after)->orderBy('id')->each(function (Payment $p) use (&$out, $giveUp): void {
            $out['checked']++;

            try {
                $state = $this->refresh($p);
            } catch (Throwable $e) {
                Log::warning('Payment status check failed', ['payment' => $p->uuid, 'error' => $e->getMessage()]);
                $out['still_waiting']++;

                return;
            }
            if ($state === 'held') {
                $out['held']++;
            } elseif ($state === 'initiated' && $p->created_at <= $giveUp) {
                $this->settle($p, 'cancelled', null, 'No confirmation from the provider in time.'); // a late success can still revive it
                $out['closed']++;
            } elseif ($state === 'initiated') {
                $out['still_waiting']++;
            } else {
                $out['closed']++;
            }
        });

        return $out;
    }

    private function flag(Payment $p, string $why): Payment
    {
        $p->forceFill(['state' => 'review', 'failure_reason' => mb_substr($why, 0, 200)])->save();
        Log::critical('Payment needs manual review', ['payment' => $p->uuid, 'why' => $why]);
        AuditLog::record('payment.review', $p, [], ['why' => $why]);

        return $p;
    }
}
