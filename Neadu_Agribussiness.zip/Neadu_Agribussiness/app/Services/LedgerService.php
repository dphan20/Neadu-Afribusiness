<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\LedgerEntry;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/** Double-entry posting: every transaction must balance to zero (SRS 12.1 reconciliation). */
final class LedgerService
{
    /**
     * @param  list<array{account: string, debit?: int, credit?: int}>  $lines
     * @return string transaction uuid
     */
    public function post(array $lines, ?int $orderId = null, ?int $paymentId = null, ?string $memo = null): string
    {
        $debit = array_sum(array_map(fn (array $l): int => $l['debit'] ?? 0, $lines));
        $credit = array_sum(array_map(fn (array $l): int => $l['credit'] ?? 0, $lines));
        if ($lines === [] || $debit !== $credit) {
            throw new \DomainException("Unbalanced ledger transaction: debit {$debit} != credit {$credit}");
        }

        $tx = (string) Str::uuid7();
        DB::transaction(function () use ($lines, $tx, $orderId, $paymentId, $memo): void {
            foreach ($lines as $l) {
                LedgerEntry::create([
                    'transaction_uuid' => $tx, 'order_id' => $orderId, 'payment_id' => $paymentId, 'memo' => $memo,
                    'account' => $l['account'], 'debit_minor' => $l['debit'] ?? 0, 'credit_minor' => $l['credit'] ?? 0,
                ]);
            }
        });

        return $tx;
    }
}
