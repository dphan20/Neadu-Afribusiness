<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\UserRole;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\NotificationLog;
use App\Models\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/** COM-01: one place for finding people, starting direct conversations, sending, unread counts and notifying. */
final class MessagingService
{
    public function __construct(private readonly NotificationService $notes) {}

    /**
     * People this user may write to: active accounts only, never themselves. Needs a name / username / full phone search
     * (2+ characters) or a role filter, so the directory cannot be dumped. Phone numbers are matched but never shown.
     *
     * @return Collection<int, User>
     */
    public function directory(User $me, string $q = '', string $role = ''): Collection
    {
        $q = trim(str_replace(['%', '_', '\\'], '', $q));
        $roleValue = UserRole::tryFrom($role)?->value;
        $searching = mb_strlen($q) >= 2;
        if (! $searching && $roleValue === null) {
            return new Collection();
        }

        $query = User::query()->with('roleAssignments')->where('status', 'active')->whereKeyNot($me->getKey());
        if ($roleValue !== null) {
            $query->whereHas('roleAssignments', fn ($r) => $r->where('role', $roleValue));
        }
        if ($searching) {
            $digits = preg_replace('/\D+/', '', $q) ?? '';
            $query->where(function ($w) use ($q, $digits): void {
                $w->where('name', 'like', '%'.$q.'%')->orWhere('username', 'like', '%'.$q.'%');
                if (strlen($digits) >= 9) {
                    $w->orWhere('phone', $digits);
                }
            });
        }

        return $query->orderBy('name')->limit(30)->get();
    }

    public function canMessage(User $from, User $to): bool
    {
        return $from->isNot($to) && $to->status === 'active';
    }

    /** One private 1:1 thread per pair of people (listing, order, case and tour chats are separate). */
    public function direct(User $a, User $b): Conversation
    {
        $existing = Conversation::query()
            ->whereNull('order_id')->whereNull('listing_id')->whereNull('diagnosis_case_id')->whereNull('consultation_id')->whereNull('tour_id')
            ->whereHas('participants', fn ($q) => $q->whereKey($a->getKey()))
            ->whereHas('participants', fn ($q) => $q->whereKey($b->getKey()))
            ->has('participants', '=', 2)
            ->first();
        if ($existing !== null) {
            return $existing;
        }

        $conversation = Conversation::query()->create([]);
        $conversation->participants()->attach([$a->getKey(), $b->getKey()]);

        return $conversation;
    }

    public function send(Conversation $conversation, User $sender, ?string $body, ?UploadedFile $voice = null, ?UploadedFile $photo = null): Message
    {
        $file = $voice ?? $photo;
        $body = $body !== null && trim($body) !== '' ? trim($body) : null;

        $message = Message::query()->create([
            'conversation_id' => $conversation->id, 'sender_id' => $sender->id,
            'kind' => $voice !== null ? 'voice' : ($photo !== null ? 'photo' : 'text'),
            'body' => $body, 'file_path' => $file?->store('chat/'.$conversation->uuid, 'local'),
        ]);
        $conversation->touch();
        $conversation->markReadBy($sender);
        $this->notifyOthers($conversation, $sender, $message);

        return $message;
    }

    /** In-app notification for each other participant, but only one unread notice per conversation (no spam). */
    private function notifyOthers(Conversation $conversation, User $sender, Message $message): void
    {
        $preview = $message->body !== null ? Str::limit($message->body, 80) : match ($message->kind) {
            'voice' => '🎤 Voice note', 'photo' => '📷 Photo', default => 'New message',
        };

        foreach ($conversation->participants()->whereKeyNot($sender->id)->where('status', 'active')->get() as $to) {
            $pending = NotificationLog::query()->where('user_id', $to->id)->where('type', 'chat.message')->whereNull('read_at')
                ->where('content->conversation', $conversation->uuid)->exists();
            if (! $pending) {
                $this->notes->notify($to, 'chat.message', ['message' => $sender->name.': '.$preview, 'conversation' => $conversation->uuid, 'from' => $sender->name]);
            }
        }
    }

    /** @return array<int, int> conversation id => unread messages for this user */
    public function unreadCounts(User $user): array
    {
        return DB::table('messages')
            ->join('conversation_user as cu', fn ($j) => $j->on('cu.conversation_id', '=', 'messages.conversation_id')->where('cu.user_id', '=', $user->id))
            ->where('messages.sender_id', '!=', $user->id)->whereNull('messages.deleted_at')
            ->where(fn ($q) => $q->whereNull('cu.last_read_at')->orWhereColumn('messages.created_at', '>', 'cu.last_read_at'))
            ->groupBy('messages.conversation_id')
            ->selectRaw('messages.conversation_id as cid, count(*) as n')
            ->pluck('n', 'cid')->map(fn ($n): int => (int) $n)->all();
    }

    public function totalUnread(User $user): int
    {
        return array_sum($this->unreadCounts($user));
    }

    /** "Farm producer, Buyer" style labels for a person; staff show as NeAS support. */
    public function roleLabels(User $user): string
    {
        return $user->roleAssignments->map(function ($a): ?string {
            $role = UserRole::tryFrom((string) $a->role);

            return $role === null ? null : ($role === UserRole::Admin ? 'NeAS support' : $role->label());
        })->filter()->unique()->implode(', ');
    }

    /** May this person act on this message? They must be in the conversation and not have removed it for themselves. */
    public function canSee(User $user, Message $message): bool
    {
        return $message->conversation?->hasParticipant($user) === true
            && ! DB::table('message_hides')->where('message_id', $message->id)->where('user_id', $user->id)->exists();
    }

    /**
     * Forwards one message into each given conversation. Text, photos and voice notes can be forwarded; the file is copied so
     * deleting the original later does not break the copy. The new message is from the forwarder and is marked as forwarded.
     *
     * @param  iterable<Conversation>  $targets conversations the forwarder takes part in
     * @return int how many copies were sent
     */
    public function forward(Message $source, User $by, iterable $targets): int
    {
        $sent = 0;
        foreach ($targets as $conversation) {
            if (! $conversation->hasParticipant($by)) {
                continue;
            }

            $path = null;
            if ($source->file_path !== null) {
                $path = $this->copyAttachment($source->file_path, $conversation);
                if ($path === null) {
                    continue; // the original file is gone: do not send an empty bubble
                }
            }

            $copy = Message::query()->create([
                'conversation_id' => $conversation->id, 'sender_id' => $by->id,
                'kind' => $source->kind === 'call' ? 'text' : $source->kind, 'body' => $source->body, 'file_path' => $path,
                'forwarded_from_id' => $source->id,
            ]);
            $conversation->touch();
            $conversation->markReadBy($by);
            $this->notifyOthers($conversation, $by, $copy);
            $sent++;
        }

        return $sent;
    }

    /** "Delete for everyone": only the sender. The row is soft-deleted (kept for dispute evidence) and shows as "deleted". */
    public function deleteForEveryone(Message $message, User $by): bool
    {
        if ($message->sender_id !== $by->id) {
            return false;
        }

        return (bool) $message->delete();
    }

    /** "Delete for me": works on any message in a chat the person takes part in; the other people still see it. */
    public function deleteForMe(Message $message, User $user): void
    {
        DB::table('message_hides')->insertOrIgnore(['message_id' => $message->id, 'user_id' => $user->id, 'created_at' => now()]);
    }

    /** "Delete chat": clears the history for this person only. It comes back (empty) when someone writes again. */
    public function hideConversation(Conversation $conversation, User $user): void
    {
        $conversation->participants()->updateExistingPivot($user->getKey(), ['hidden_at' => now(), 'last_read_at' => now()]);
    }

    private function copyAttachment(string $path, Conversation $to): ?string
    {
        foreach (['local', 'public'] as $disk) { // older buyer / expert photos live on the public disk
            if (Storage::disk($disk)->exists($path)) {
                $new = 'chat/'.$to->uuid.'/'.Str::uuid()->toString().'.'.(pathinfo($path, PATHINFO_EXTENSION) ?: 'bin');
                Storage::disk('local')->put($new, Storage::disk($disk)->get($path));

                return $new;
            }
        }

        return null;
    }
}
