<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\AuditLog;
use App\Models\Listing;
use App\Models\User;
use App\Models\VerificationDocument;
use App\Models\Vehicle;
use DomainException;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;

/** ADM-01 / LOG-01 / LND-03 / BR-08: documents are uploaded privately and approved or rejected (with a reason) by an admin. */
final class VerificationService
{
    public function __construct(private readonly NotificationService $notes) {}

    public function submit(User $user, string $subjectType, ?int $subjectId, string $kind, UploadedFile $file): VerificationDocument
    {
        $owned = match ($subjectType) {
            'vehicle' => Vehicle::query()->whereKey($subjectId)->where('user_id', $user->id)->exists(),
            'land' => Listing::query()->whereKey($subjectId)->where('user_id', $user->id)->where('type', 'land')->exists(),
            'user' => true,
            default => false,
        };
        if (! $owned) {
            throw new DomainException('You cannot attach a document to that record.');
        }

        return VerificationDocument::query()->create([
            'user_id' => $user->id, 'subject_type' => $subjectType, 'subject_id' => $subjectId, 'kind' => $kind,
            'path' => $file->store('verification/'.$user->uuid, 'local'),
        ]);
    }

    public function decide(VerificationDocument $doc, User $admin, bool $approve, ?string $reason): void
    {
        if (! $approve && ($reason === null || trim($reason) === '')) {
            throw new DomainException('Give a reason when rejecting.');
        }

        DB::transaction(function () use ($doc, $admin, $approve, $reason): void {
            $doc = VerificationDocument::query()->lockForUpdate()->findOrFail($doc->id);
            if ($doc->status !== 'pending') {
                throw new DomainException('This document was already reviewed.');
            }
            $doc->forceFill(['status' => $approve ? 'approved' : 'rejected', 'reason' => $reason, 'reviewed_by' => $admin->id, 'reviewed_at' => now()])->save();

            if ($doc->subject_type === 'vehicle' && ($v = Vehicle::query()->find($doc->subject_id))) {
                $v->forceFill(['verification_status' => $approve ? 'verified' : 'rejected', 'reject_reason' => $approve ? null : $reason])->save();
            }
            if ($doc->subject_type === 'land' && ($l = Listing::query()->find($doc->subject_id))) {
                $l->forceFill($approve
                    ? ['verified' => true, 'verified_at' => now(), 'verified_by' => $admin->id, 'status' => $l->status === 'pending_review' ? 'active' : $l->status]
                    : ['verified' => false, 'status' => 'rejected', 'moderation_note' => $reason])->save();
            }
            if ($doc->subject_type === 'user' && $approve) {
                $doc->user->forceFill(['verification_level' => 'full', 'verified_at' => now()])->save();
            }

            AuditLog::record('verification.'.($approve ? 'approved' : 'rejected'), $doc, [], ['reason' => $reason]);
            $this->notes->notify($doc->user, 'verification.decided', ['message' => $approve ? 'Nyaraka zako zimekubaliwa.' : 'Nyaraka zako zimekataliwa: '.$reason]);
        });
    }
}
