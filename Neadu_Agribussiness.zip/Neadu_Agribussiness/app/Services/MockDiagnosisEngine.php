<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\DiagnosisEngine;

/** OPEN-Q7: deterministic stand-in for the real model. The same photo always gives the same answer. */
final class MockDiagnosisEngine implements DiagnosisEngine
{
    /** @var array<string, list<array{string, string, string}>> kind => [[result, treatment, prevention]] */
    private const CATALOGUE = [
        'crop' => [
            ['Ugonjwa wa kutu ya majani (leaf rust)', 'Nyunyizia dawa ya ukungu (fungicide) iliyopendekezwa na afisa ugani. Ondoa majani yaliyoathirika na yachome.', 'Panda mbegu zinazostahimili ugonjwa, zungusha mazao, na epuka kujaa kwa mimea shambani.'],
            ['Ugonjwa wa baka jani (blight)', 'Ondoa mimea iliyoathirika na nyunyizia dawa ya shaba (copper) kwa maelekezo ya lebo.', 'Epuka kumwagilia majani jioni, acha nafasi kati ya mimea, tumia mbegu safi.'],
            ['Upungufu wa naitrojeni', 'Weka mbolea ya naitrojeni (UREA/CAN) kwa kiasi kilichopendekezwa kulingana na ukubwa wa shamba.', 'Tumia mboji au samadi kila msimu na pima udongo mara kwa mara.'],
            ['Shambulio la viwavi jeshi (fall armyworm)', 'Kagua shamba asubuhi, nyunyizia dawa ya wadudu iliyoidhinishwa, na dawa ya kibaiolojia kama inapatikana.', 'Panda mapema kwa pamoja na wakulima wenzako na kagua shamba kila wiki.'],
        ],
        'livestock' => [
            ['Ugonjwa wa kuhara kwa kuku (coccidiosis)', 'Wape kuku dawa ya coccidiostat kwa maji ya kunywa kama ilivyoelekezwa na daktari wa mifugo.', 'Weka banda kavu na safi, badilisha matandiko, na epuka msongamano.'],
            ['Ugonjwa wa kupe (tick-borne disease)', 'Oga mifugo kwa dawa ya kupe (acaricide) na mwone daktari wa mifugo kwa matibabu ya ugonjwa.', 'Oga mifugo kila wiki kwa ratiba na weka malisho safi.'],
            ['Ugonjwa wa miguu na midomo (foot and mouth)', 'Tenga mnyama mgonjwa na toa taarifa kwa afisa mifugo mara moja.', 'Chanja mifugo kwa ratiba na zuia mifugo wapya wasichanganyike bila karantini.'],
        ],
        'fish' => [
            ['Ugonjwa wa mapezi kuoza (fin rot)', 'Boresha ubora wa maji, toa samaki walioathirika, na tumia chumvi ya bwawa kwa kipimo sahihi.', 'Punguza msongamano wa samaki, badilisha maji mara kwa mara, na lisha kwa kiasi.'],
            ['Upungufu wa oksijeni majini', 'Ongeza mzunguko wa maji au hewa na punguza ulishaji kwa siku chache.', 'Epuka kulisha kupita kiasi na weka bwawa lenye kina na mzunguko mzuri.'],
            ['Vimelea vya ngozi (skin parasites)', 'Tumia matibabu ya chumvi na wasiliana na mtaalamu wa uvuvi kwa dawa sahihi.', 'Kagua samaki wapya kabla ya kuwaingiza bwawani na weka bwawa safi.'],
        ],
    ];

    public function diagnose(string $absolutePhotoPath, string $subject, string $kind): array
    {
        $options = self::CATALOGUE[$kind] ?? self::CATALOGUE['crop'];
        $seed = is_file($absolutePhotoPath) ? (int) crc32((string) md5_file($absolutePhotoPath)) : (int) crc32($subject);
        [$result, $treatment, $prevention] = $options[$seed % count($options)];

        return ['result' => $result, 'confidence' => 45 + ($seed % 50), 'treatment' => $treatment, 'prevention' => $prevention];
    }
}
