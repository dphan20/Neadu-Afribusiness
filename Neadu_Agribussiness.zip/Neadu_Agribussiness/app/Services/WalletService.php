<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\LedgerEntry;
use App\Models\PayoutRequest;
use App\Models\User;
use DomainException;
use Illuminate\Support\Facades\DB;

/** S-45: earnings, balance and payout requests, for every role that gets paid. Payouts need a verified identity (BR-01). */
final class WalletService
{
    /** Ledger accounts that belong to a user. */
    public const PREFIXES = ['seller', 'transporter', 'expert', 'organiser', 'owner', 'trader'];

    public function __construct(private readonly LedgerService $ledger) {}

    /** @return list<string> */
    public function accounts(User $user): array
    {
        return array_map(fn (string $p) => $p.':'.$user->id, self::PREFIXES);
    }

    /** Available money in minor units: credits minus debits on the user's accounts (payout requests are debits). */
    public function balance(User $user): int
    {
        $row = LedgerEntry::query()->whereIn('account', $this->accounts($user))
            ->selectRaw('COALESCE(SUM(credit_minor),0) c, COALESCE(SUM(debit_minor),0) d')->first();

        return (int) $row->c - (int) $row->d;
    }

    public function requestPayout(User $user, int $amountMinor, string $method, string $destination): PayoutRequest
    {
        if (! $user->isIdentityVerified()) {
            throw new DomainException('Verify your identity (NIDA) before requesting a payout.');
        }
        if ($amountMinor < 1_000_00) {
            throw new DomainException('The minimum payout is TSh 1,000.');
        }

        return DB::transaction(function () use ($user, $amountMinor, $method, $destination): PayoutRequest {
            if ($amountMinor > $this->balance($user)) {
                throw new DomainException('You do not have that much available.');
            }
            $req = PayoutRequest::query()->create(['user_id' => $user->id, 'amount_minor' => $amountMinor, 'method' => $method, 'destination' => $destination]);
            $this->ledger->post([
                ['account' => 'seller:'.$user->id, 'debit' => $amountMinor], ['account' => 'payout:pending', 'credit' => $amountMinor],
            ], null, null, 'Payout request '.$req->uuid);

            return $req;
        });
    }

    /** Admin: mark paid (money left the platform) or reject (money returns to the wallet). */
    public function decide(PayoutRequest $req, User $admin, bool $paid, ?string $reason): void
    {
        DB::transaction(function () use ($req, $admin, $paid, $reason): void {
            $req = PayoutRequest::query()->lockForUpdate()->findOrFail($req->id);
            if ($req->status !== 'requested') {
                throw new DomainException('This payout was already decided.');
            }
            $a = (int) $req->amount_minor;
            $this->ledger->post($paid
                ? [['account' => 'payout:pending', 'debit' => $a], ['account' => 'external:payout', 'credit' => $a]]
                : [['account' => 'payout:pending', 'debit' => $a], ['account' => 'seller:'.$req->user_id, 'credit' => $a]], null, null, ($paid ? 'Payout paid ' : 'Payout rejected ').$req->uuid);
            $req->forceFill(['status' => $paid ? 'paid' : 'rejected', 'reason' => $reason, 'decided_by' => $admin->id, 'decided_at' => now()])->save();
        });
    }
}
