<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\EscrowState;
use App\Events\DeliveryLocationUpdated;
use App\Models\AuditLog;
use App\Models\Delivery;
use App\Models\FeatureFlag;
use App\Models\LedgerEntry;
use App\Models\Order;
use App\Models\TrackingPoint;
use App\Models\User;
use App\Models\Vehicle;
use App\Support\Quantity;
use Carbon\Carbon;
use DomainException;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Transporter workflow, LOG-01 .. LOG-09: open jobs, acceptance, the six-step trip, GPS points,
 * proof of delivery and the transport payment held in escrow until the goods are delivered.
 */
final class TransportService
{
    public const MAX_CODE_ATTEMPTS = 5;

    /** LOG-04: assigned -> at pickup -> loaded -> in transit -> arrived -> delivered. */
    public const STEPS = [
        'assigned' => ['label' => 'Assigned', 'next' => 'at_pickup', 'action' => "I've arrived at pickup"],
        'at_pickup' => ['label' => 'At pickup', 'next' => 'loaded', 'action' => 'Goods loaded'],
        'loaded' => ['label' => 'Loaded', 'next' => 'in_transit', 'action' => 'Start trip'],
        'in_transit' => ['label' => 'In transit', 'next' => 'arrived', 'action' => "I've arrived at drop-off"],
        'arrived' => ['label' => 'Arrived', 'next' => 'delivered', 'action' => 'Confirm delivery'],
        'delivered' => ['label' => 'Delivered', 'next' => null, 'action' => null],
    ];

    public function __construct(private readonly LedgerService $ledger, private readonly NotificationService $notes) {}

    /* ---------------------------------------------------------------- reading helpers */

    public function haversine(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;

        return 6371.0 * 2 * atan2(sqrt($a), sqrt(1 - $a));
    }

    /** Road distance in km: the booked figure when there is one, otherwise straight line x road factor. */
    public function distanceKm(Delivery $d): float
    {
        if ($d->distance_km !== null && (float) $d->distance_km > 0) {
            return round((float) $d->distance_km, 1);
        }

        return round($this->haversine((float) $d->pickup_lat, (float) $d->pickup_lng, (float) $d->drop_lat, (float) $d->drop_lng)
            * (float) config('neas.transporter.road_factor', 1.3), 1);
    }

    /** Load weight in whole kg, or null when the unit has no kg equivalent (head, litre). */
    public function weightKg(Delivery $d): ?int
    {
        $order = $d->order;
        $factor = $order?->listing?->produce?->unit?->kg_factor_milli;
        if ($order === null || $factor === null) {
            return null;
        }

        return intdiv(Quantity::toMilli($order->quantity) * (int) $factor + 999_999, 1_000_000);
    }

    /** @return array{label: string, next: ?string, action: ?string} */
    public function step(Delivery $d): array
    {
        return self::STEPS[$d->status] ?? ['label' => ucfirst((string) $d->status), 'next' => null, 'action' => null];
    }

    /** Navigate to the pickup until the goods are loaded, then to the drop-off. */
    public function navUrl(Delivery $d): string
    {
        $toPickup = in_array($d->status, ['requested', 'assigned', 'at_pickup'], true);
        $lat = $toPickup ? $d->pickup_lat : $d->drop_lat;
        $lng = $toPickup ? $d->pickup_lng : $d->drop_lng;

        return 'https://www.google.com/maps/dir/?api=1&travelmode=driving&destination='.$lat.','.$lng;
    }

    /** LOG-03: open jobs plus requests addressed to this driver. @return Collection<int, Delivery> */
    public function jobsFor(User $driver): Collection
    {
        return Delivery::query()->with(['order.listing.produce.unit', 'order.listing.region'])
            ->where('status', 'requested')
            ->where(fn ($q) => $q->whereNull('transporter_id')->orWhere('transporter_id', $driver->id))
            ->whereHas('order', fn ($q) => $q->whereNotIn('status', [EscrowState::Refunded->value, EscrowState::Released->value]))
            ->latest()->get();
    }

    /** @return Collection<int, Delivery> */
    public function activeTrips(User $driver): Collection
    {
        return Delivery::query()->with(['order.listing', 'vehicle'])->where('transporter_id', $driver->id)
            ->whereIn('status', Delivery::ACTIVE)->latest()->get();
    }

    public function backhaulEnabled(): bool
    {
        return app()->environment('local', 'testing') || FeatureFlag::isEnabled('backhaul');
    }

    /**
     * LOG-09: open jobs that start close to where the last trip ended, so the return leg is not empty.
     *
     * @return Collection<int, array{delivery: Delivery, empty_km: float}>
     */
    public function backhaul(Delivery $last, int $radiusKm = 60, int $limit = 5): Collection
    {
        $factor = (float) config('neas.transporter.road_factor', 1.3);

        return Delivery::query()->with(['order.listing.region'])->where('status', 'requested')->whereNull('transporter_id')
            ->whereHas('order', fn ($q) => $q->whereNotIn('status', [EscrowState::Refunded->value, EscrowState::Released->value]))
            ->latest()->limit(100)->get()
            ->map(fn (Delivery $j): array => [
                'delivery' => $j,
                'empty_km' => round($this->haversine((float) $last->drop_lat, (float) $last->drop_lng, (float) $j->pickup_lat, (float) $j->pickup_lng) * $factor, 1),
            ])
            ->filter(fn (array $r): bool => $r['empty_km'] <= $radiusKm)->sortBy('empty_km')->take($limit)->values();
    }

    /** @return array{balance: int, entries: Collection<int, LedgerEntry>} LOG-08 earnings on the transporter ledger account */
    public function earnings(User $driver): array
    {
        $q = fn () => LedgerEntry::query()->where('account', 'transporter:'.$driver->id);

        return [
            'balance' => (int) $q()->sum('credit_minor') - (int) $q()->sum('debit_minor'),
            'entries' => $q()->latest('id')->limit(100)->get(),
        ];
    }

    /* ---------------------------------------------------------------- job acceptance (LOG-03) */

    public function accept(Delivery $delivery, User $driver, Vehicle $vehicle): Delivery
    {
        if (! $driver->isIdentityVerified()) {
            throw new DomainException('Verify your identity (NIDA) before accepting jobs.');
        }
        if ((int) $vehicle->user_id !== (int) $driver->id || ! $vehicle->isVerified()) {
            throw new DomainException('Choose one of your vehicles that the NeAS team has verified.');
        }

        return DB::transaction(function () use ($delivery, $driver, $vehicle): Delivery {
            $d = Delivery::query()->lockForUpdate()->findOrFail($delivery->id);
            if ($d->status !== 'requested' || ($d->transporter_id !== null && (int) $d->transporter_id !== (int) $driver->id)) {
                throw new DomainException('This job is no longer available.');
            }

            $d->loadMissing('order.listing.produce.unit');
            if (in_array($d->order->status, [EscrowState::Refunded, EscrowState::Released], true)) {
                throw new DomainException('The order for this job was cancelled.');
            }
            $weight = $this->weightKg($d);
            if ($weight !== null && $weight > (float) $vehicle->capacity_kg) {
                throw new DomainException("This load is about {$weight} kg, which is more than this vehicle can carry.");
            }

            $d->forceFill(['transporter_id' => $driver->id, 'vehicle_id' => $vehicle->id, 'status' => 'assigned', 'accepted_at' => now()]);
            $this->log($d, 'assigned');
            $d->save();
            $this->fundEscrow($d);
            AuditLog::record('delivery.accepted', $d, [], ['transporter_id' => $driver->id, 'vehicle_id' => $vehicle->id]);
            $this->notes->notify($d->order->buyer, 'delivery.accepted', [
                'order' => $d->order->uuid, 'message' => 'Msafirishaji amekubali kazi ya kusafirisha oda yako.',
            ]);

            return $d;
        });
    }

    /** Decline a request addressed to you, or drop an accepted job before pickup. The job returns to the open board. */
    public function release(Delivery $delivery, User $driver): Delivery
    {
        return DB::transaction(function () use ($delivery, $driver): Delivery {
            $d = Delivery::query()->lockForUpdate()->findOrFail($delivery->id);
            $this->guardDriver($d, $driver);

            if ($d->status === 'requested') {
                $d->forceFill(['transporter_id' => null])->save();
            } elseif ($d->status === 'assigned') {
                $this->refundEscrow($d);
                $d->forceFill(['transporter_id' => null, 'vehicle_id' => null, 'status' => 'requested', 'accepted_at' => null]);
                $this->log($d, 'released');
                $d->save();
            } else {
                throw new DomainException('A trip that has started cannot be dropped. Contact support if there is a problem.');
            }
            AuditLog::record('delivery.released', $d, [], ['by' => $driver->id]);

            return $d;
        });
    }

    /* ---------------------------------------------------------------- trip status (LOG-04) */

    public function advance(Delivery $delivery, User $driver, string $to, ?float $lat = null, ?float $lng = null): Delivery
    {
        return DB::transaction(function () use ($delivery, $driver, $to, $lat, $lng): Delivery {
            $d = Delivery::query()->lockForUpdate()->findOrFail($delivery->id);
            $this->guardDriver($d, $driver);

            $fromIdx = array_search($d->status, Delivery::FLOW, true);
            $toIdx = array_search($to, Delivery::FLOW, true);
            if ($toIdx === false || $to === 'delivered') {
                throw new DomainException('Delivery is confirmed with the recipient code or a proof of delivery.');
            }
            if ($fromIdx === false) {
                throw new DomainException('Accept the job first.');
            }
            if ($toIdx <= $fromIdx) {
                return $d;   // an offline-queued step that was already applied
            }
            if (self::STEPS[$d->status]['next'] !== $to) {
                throw new DomainException('Follow the trip steps in order.');
            }

            $order = Order::query()->lockForUpdate()->findOrFail($d->order_id);
            if ($to === 'loaded' && ! in_array($order->status, [EscrowState::Held, EscrowState::InTransit], true)) {
                throw new DomainException('Wait until the buyer has paid and the producer has accepted the order before loading.');
            }
            if ($to === 'in_transit' && $order->status === EscrowState::Held) {
                $order->transitionTo(EscrowState::InTransit);
            }

            $before = $d->status;
            $d->status = $to;
            $this->log($d, $to, $lat, $lng);
            $d->save();
            AuditLog::record('delivery.status', $d, ['status' => $before], ['status' => $to]);

            if ($to === 'in_transit') {
                $this->notes->notify($order->buyer, 'delivery.status', ['order' => $order->uuid, 'status' => $to, 'message' => 'Mzigo wako uko njiani.']);
            } elseif ($to === 'arrived') {
                $this->notes->notify($order->buyer, 'delivery.status', ['order' => $order->uuid, 'status' => $to, 'message' => 'Msafirishaji amefika. Mpe nambari ya kupokea mzigo.']);
            }

            return $d;
        });
    }

    /** LOG-05: store GPS points, also replayed from the phone's offline buffer. @param list<array<string, mixed>> $points */
    public function recordPoints(Delivery $delivery, User $driver, array $points): int
    {
        $d = Delivery::query()->findOrFail($delivery->id);
        $this->guardDriver($d, $driver);
        if (! in_array($d->status, Delivery::ACTIVE, true)) {
            return 0;
        }

        $saved = 0;
        $latest = null;
        foreach (array_slice($points, 0, 200) as $p) {
            $lat = $p['lat'] ?? null;
            $lng = $p['lng'] ?? null;
            if (! is_numeric($lat) || ! is_numeric($lng) || abs((float) $lat) > 90 || abs((float) $lng) > 180) {
                continue;
            }
            $at = isset($p['t']) && is_numeric($p['t']) ? Carbon::createFromTimestampMs((int) $p['t']) : now();
            if ($at->gt(now()->addMinutes(5)) || $at->lt(now()->subDays(3))) {
                $at = now();
            }
            if (TrackingPoint::query()->where('delivery_id', $d->id)->where('recorded_at', $at->format('Y-m-d H:i:s'))->exists()) {
                continue;
            }
            $accuracy = isset($p['accuracy']) && is_numeric($p['accuracy']) && (float) $p['accuracy'] >= 0 ? min((float) $p['accuracy'], 999999.0) : null;
            $speed = isset($p['speed']) && is_numeric($p['speed']) && (float) $p['speed'] >= 0 ? min((float) $p['speed'], 9999.0) : null;
            $point = TrackingPoint::query()->create([
                'delivery_id' => $d->id, 'driver_id' => $driver->id, 'lat' => (float) $lat, 'lng' => (float) $lng, 'recorded_at' => $at,
                'accuracy_meters' => $accuracy, 'speed_kmh' => $speed, 'synced_at' => now(),
            ]);
            if ($latest === null || $point->recorded_at->gt($latest->recorded_at)) {
                $latest = $point;
            }
            $saved++;
        }

        // LOG-04 / TECH-08: one push per batch, for the newest point only (a replayed offline buffer must not flood the buyer's map).
        if ($latest !== null) {
            DeliveryLocationUpdated::dispatch($d->uuid, (float) $latest->lat, (float) $latest->lng, $latest->recorded_at->toIso8601String(), (string) $d->status);
        }

        return $saved;
    }

    /* ---------------------------------------------------------------- proof of delivery (LOG-06) */

    public function confirmWithCode(Delivery $delivery, User $driver, string $code): Delivery
    {
        $d = Delivery::query()->findOrFail($delivery->id);
        $this->guardDriver($d, $driver);
        $this->guardDeliverable($d);
        if ((int) $d->code_attempts >= self::MAX_CODE_ATTEMPTS) {
            throw new DomainException('Too many wrong codes. Use a photo or signature as proof, or contact support.');
        }

        $code = preg_replace('/\D+/', '', $code) ?? '';
        if ($code === '' || $d->delivery_code_hash === null || ! Hash::check($code, $d->delivery_code_hash)) {
            $d->increment('code_attempts');
            $left = max(0, self::MAX_CODE_ATTEMPTS - (int) $d->code_attempts);

            throw new DomainException($left > 0
                ? "That code is not correct. {$left} tries left."
                : 'Too many wrong codes. Use a photo or signature as proof, or contact support.');
        }

        return $this->complete($d, $driver, 'code', null, null);
    }

    public function confirmWithProof(Delivery $delivery, User $driver, string $recipient, ?UploadedFile $photo, ?string $signature): Delivery
    {
        $d = Delivery::query()->findOrFail($delivery->id);
        $this->guardDriver($d, $driver);
        $this->guardDeliverable($d);

        $recipient = trim($recipient);
        if ($recipient === '') {
            throw new DomainException('Enter the name of the person who received the goods.');
        }
        if ($photo === null && ($signature === null || trim($signature) === '')) {
            throw new DomainException('Take a photo or capture a signature as proof of delivery.');
        }

        if ($photo !== null) {
            $type = 'photo';
            $path = $photo->store('delivery-proofs', 'local');
        } else {
            if (! preg_match('#^data:image/png;base64,([A-Za-z0-9+/=]+)$#', (string) $signature, $m)) {
                throw new DomainException('The signature could not be read. Please sign again.');
            }
            $bin = base64_decode($m[1], true);
            if ($bin === false || strlen($bin) < 100 || strlen($bin) > 400_000) {
                throw new DomainException('The signature could not be read. Please sign again.');
            }
            $type = 'signature';
            $path = 'delivery-proofs/'.Str::uuid().'.png';
            Storage::disk('local')->put($path, $bin);
        }

        return $this->complete($d, $driver, $type, $path, $recipient);
    }

    private function complete(Delivery $delivery, User $driver, string $proofType, ?string $path, ?string $recipient): Delivery
    {
        return DB::transaction(function () use ($delivery, $driver, $proofType, $path, $recipient): Delivery {
            $d = Delivery::query()->lockForUpdate()->findOrFail($delivery->id);
            if ($d->status === 'delivered') {
                return $d;
            }

            $order = Order::query()->lockForUpdate()->findOrFail($d->order_id);
            if ($order->status === EscrowState::Held) {
                $order->transitionTo(EscrowState::InTransit);
            }
            if ($order->status !== EscrowState::InTransit) {
                throw new DomainException('This order is not in transit (it may be disputed or closed).');
            }

            // LOG-06: the buyer's confirm/dispute window (escrow release) starts now.
            $order->transitionTo(EscrowState::Delivered);
            $order->forceFill(['delivered_at' => now(), 'auto_release_at' => now()->addHours((int) config('neas.auto_confirm_hours', 48))])->save();

            $d->forceFill(['status' => 'delivered', 'delivered_at' => now(), 'proof_type' => $proofType, 'proof_path' => $path, 'recipient_name' => $recipient]);
            $this->log($d, 'delivered');
            $d->save();

            $this->releaseTransport($d);   // LOG-08
            AuditLog::record('delivery.delivered', $d, [], ['proof' => $proofType]);
            $this->notes->notify($order->buyer, 'delivery.delivered', [
                'order' => $order->uuid, 'message' => 'Mzigo umewasilishwa. Thibitisha upokeaji au fungua mgogoro ndani ya muda uliowekwa.',
            ]);
            $this->notes->notify($order->seller, 'delivery.delivered', ['order' => $order->uuid, 'message' => 'Mzigo wa oda yako umewasilishwa kwa mnunuzi.']);

            return $d;
        });
    }

    /* ---------------------------------------------------------------- transport payment (LOG-08) */

    /** The transport fee is paid into escrow when a driver accepts, and stays there until delivery. */
    private function fundEscrow(Delivery $d): void
    {
        $price = (int) $d->price_minor;
        if ($d->escrow_state !== 'none' || $price <= 0) {
            return;
        }
        $this->ledger->post([
            ['account' => 'external:payment', 'debit' => $price],
            ['account' => 'escrow', 'credit' => $price],
        ], null, null, 'Transport escrow '.$d->uuid);
        $d->forceFill(['escrow_state' => 'held'])->save();
    }

    private function refundEscrow(Delivery $d): void
    {
        $price = (int) $d->price_minor;
        if ($d->escrow_state !== 'held' || $price <= 0) {
            return;
        }
        $this->ledger->post([
            ['account' => 'escrow', 'debit' => $price],
            ['account' => 'external:payment', 'credit' => $price],
        ], null, null, 'Transport escrow refund '.$d->uuid);
        $d->forceFill(['escrow_state' => 'none'])->save();
    }

    private function releaseTransport(Delivery $d): void
    {
        $price = (int) $d->price_minor;
        if ($d->escrow_state !== 'held' || $price <= 0 || $d->transporter_id === null) {
            return;
        }
        $this->ledger->post([
            ['account' => 'escrow', 'debit' => $price],
            ['account' => 'transporter:'.$d->transporter_id, 'credit' => $price],
        ], null, null, 'Transport payout '.$d->uuid);
        $d->forceFill(['escrow_state' => 'released'])->save();

        $driver = User::query()->find($d->transporter_id);
        if ($driver !== null) {
            $this->notes->notify($driver, 'transport.paid', [
                'delivery' => $d->uuid, 'message' => 'Malipo ya usafirishaji TSh '.number_format(intdiv($price, 100)).' yameingizwa kwenye akaunti yako.',
            ]);
        }
    }

    /* ---------------------------------------------------------------- guards */

    private function guardDriver(Delivery $d, User $driver): void
    {
        if ((int) $d->transporter_id !== (int) $driver->id) {
            throw new DomainException('This trip is not assigned to you.');
        }
    }

    private function guardDeliverable(Delivery $d): void
    {
        if (! in_array($d->status, ['in_transit', 'arrived'], true)) {
            throw new DomainException('Start the trip before confirming delivery.');
        }
    }

    private function log(Delivery $d, string $status, ?float $lat = null, ?float $lng = null): void
    {
        $timeline = $d->timeline ?? [];
        $timeline[] = ['status' => $status, 'at' => now()->toIso8601String(), 'lat' => $lat, 'lng' => $lng];
        $d->timeline = $timeline;
    }
}
