<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\AiQuery;
use App\Models\User;
use App\Services\Ai\GeminiClient;
use App\Support\RoleNav;
use DomainException;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Throwable;

/** "Ask AI": a question about a photo (a plant, animal, machine, produce, land, a document) or plain text. */
final class AssistantService
{
    private const HISTORY_TURNS = 4;      // earlier questions sent back so follow-ups ("and how much of it?") make sense
    private const HISTORY_HOURS = 12;
    private const HISTORY_CHARS = 600; 

    public function __construct(private readonly GeminiClient $client) {}

    public function ask(User $user, string $question, ?UploadedFile $photo, ?string $page = null): AiQuery
    {
        $path = $photo?->store('assistant/'.$user->uuid, 'local'); // private disk

        try {
            $answer = $this->client->generate(
                $this->system($user, $page, $question),
                $question,
                $path ? Storage::disk('local')->path($path) : null,
                null,
                $this->history($user),
                (int) config('services.gemini.ask_max_tokens', 700),
            );
        } catch (Throwable $e) {
            if ($path) {
                Storage::disk('local')->delete($path); // do not keep photos of questions that were never answered
            }
            throw $e instanceof DomainException ? $e : new DomainException('The AI service had a problem. Please try again.', 0, $e);
        }

        return AiQuery::query()->create([
            'user_id' => $user->id, 'question' => $question, 'photo_path' => $path,
            'answer' => $answer, 'model' => (string) config('services.gemini.model'),
        ]);
    }

    /**
     * Streaming version of ask(): the row is created first (so Stop and Delete work at once), the answer is written as it
     * arrives, and a Stop keeps whatever was already said. $emit(string) must return false when the browser has gone.
     *
     * @param  callable(AiQuery): void  $started  called as soon as the row exists
     * @param  callable(string): bool  $emit
     */
    public function stream(User $user, string $question, ?UploadedFile $photo, ?string $page, callable $started, callable $emit): AiQuery
    {
        $path = $photo?->store('assistant/'.$user->uuid, 'local');
        $history = $this->history($user);

        $query = AiQuery::query()->create([
            'user_id' => $user->id, 'question' => $question, 'photo_path' => $path,
            'answer' => '', 'model' => (string) config('services.gemini.model'),
        ]);
        $started($query);

        try {
            $answer = $this->client->stream(
                $this->system($user, $page, $question),
                $question,
                $path ? Storage::disk('local')->path($path) : null,
                $history,
                $emit,
                (int) config('services.gemini.ask_max_tokens', 700),
            );
        } catch (Throwable $e) {
            $this->forget($query); // nothing worth keeping: no answer, no orphan photo
            throw $e instanceof DomainException ? $e : new DomainException('The AI service had a problem. Please try again.', 0, $e);
        }

        if (trim($answer) === '') {
            $this->forget($query); // stopped before the first word
            return $query;
        }

        $query->forceFill(['answer' => $answer])->save();

        return $query;
    }

    /** Delete one question and answer for good, with its photo. It also stops being sent to the AI as context. */
    public function forget(AiQuery $query): void
    {
        if ($query->photo_path) {
            Storage::disk('local')->delete($query->photo_path);
        }
        $query->forceDelete();
    }

    /** Delete the user's whole Ask AI history. */
    public function forgetAll(User $user): int
    {
        $count = 0;
        AiQuery::query()->withTrashed()->where('user_id', $user->id)->each(function (AiQuery $q) use (&$count): void {
            $this->forget($q);
            $count++;
        });

        return $count;
    }

    /** @return list<array{role: 'user'|'model', text: string}> */
    private function history(User $user): array
    {
        $turns = [];
        $recent = AiQuery::query()->where('user_id', $user->id)->where('answer', '!=', '')->where('created_at', '>=', now()->subHours(self::HISTORY_HOURS))
            ->latest('id')->limit(self::HISTORY_TURNS)->get(['question', 'answer', 'photo_path'])->reverse();

        foreach ($recent as $q) {
            $turns[] = ['role' => 'user', 'text' => mb_substr((string) $q->question, 0, self::HISTORY_CHARS).($q->photo_path ? ' [the user attached a photo]' : '')];
            $turns[] = ['role' => 'model', 'text' => mb_substr((string) $q->answer, 0, self::HISTORY_CHARS)];
        }

        return $turns;
    }

    /** 'English', 'Kiswahili' or null when the question does not make the language clear (short or mixed). */
    public static function detectLanguage(string $text): ?string
    {
        $sw = ['na', 'ya', 'wa', 'kwa', 'ni', 'la', 'za', 'katika', 'hii', 'huu', 'hiki', 'nini', 'gani', 'jinsi', 'vipi', 'naomba', 'habari', 'mimi', 'wewe', 'kuhusu', 'lini', 'wapi', 'sana', 'pia', 'siyo', 'sio', 'kuna', 'nataka', 'tafadhali', 'ninaweza', 'unaweza', 'ninawezaje', 'nifanye', 'nina', 'yangu', 'wangu', 'langu', 'zangu', 'gani', 'mbolea', 'mahindi', 'shamba', 'bei', 'kuuza', 'kununua', 'msaada', 'ndiyo', 'hapana', 'je', 'au', 'lakini', 'kama', 'ili', 'baada', 'kabla', 'mkulima', 'mazao', 'ng\'ombe', 'kuku', 'samaki', 'ugonjwa', 'dawa', 'mimea', 'majani', 'ninataka', 'inaweza', 'ina', 'zina', 'una', 'ana', 'tunaweza', 'asante'];
        $en = ['the', 'is', 'are', 'what', 'how', 'my', 'can', 'i', 'you', 'to', 'of', 'and', 'in', 'for', 'with', 'this', 'that', 'do', 'does', 'why', 'when', 'where', 'which', 'please', 'should', 'have', 'it', 'on', 'be', 'a', 'an', 'will', 'would', 'could', 'me', 'wrong', 'tell', 'about', 'need', 'want', 'much', 'many', 'best', 'there', 'from', 'your', 'if', 'or', 'not', 'at', 'was', 'its', 'help', 'price', 'sell', 'buy', 'plant', 'disease'];
        preg_match_all("/[\p{L}']+/u", mb_strtolower($text), $m);
        $words = $m[0];
        $swScore = count(array_intersect($words, $sw));
        $enScore = count(array_intersect($words, $en));
        // Swahili is agglutinative: count common verb prefixes too (ninataka, tunaweza, wanakula ...)
        foreach ($words as $w) {
            if (preg_match('/^(ni|u|a|tu|m|wa)(na|me|ta|li)[a-z]{2,}$/u', $w) === 1 && ! in_array($w, $en, true)) {
                $swScore++;
            }
        }
        if ($swScore === $enScore) {
            return null;
        }

        return $enScore > $swScore ? 'English' : 'Kiswahili';
    }

    private function system(User $user, ?string $page, string $question = ''): string
    {
        $preferred = $user->language === 'en' ? 'English' : 'Kiswahili';
        $detected = self::detectLanguage($question);
        $lang = $detected !== null
            ? "The user's latest message is written in {$detected}. Write your WHOLE answer in {$detected}, even if earlier answers in this chat were in another language and even if the app language is different."
            : "If you cannot tell the language, use {$preferred}.";
        $role = RoleNav::activeRole();
        $menu = implode(', ', array_map(static fn (array $i): string => $i[1], RoleNav::for($role)));
        $order = (array) config('neas.order');
        $dispute = (array) config('neas.dispute');
        $where = $page ? "\nThe user is on the page \"".preg_replace('/[^\w\/\-]/', '', $page).'" of the app. Use it only as a hint about what they are doing.' : '';

        return <<<PROMPT
You are NeAS Assistant, the helper inside the Neadu Agribusiness System (NeAS), an agribusiness marketplace in Tanzania used by farmers, livestock keepers, fishers, buyers, experts, trainers, transporters, land owners, warehouse owners and machinery traders.

HOW TO ANSWER
1. Answer the exact question that was asked, in the first sentence. Then add only the steps or facts that help. Do not repeat the question and do not give a lecture.
2. Be practical for a smallholder: simple words, short steps, local crops, local units (kg, acre, TZS), things that can be bought or done in Tanzania.
3. Language: ALWAYS reply in the language of the user's latest message. English question = English answer. Kiswahili question = Kiswahili answer. Never switch language on your own. {$lang}
4. Keep it short: normally under 120 words, at most 6 short steps. No long introductions, no summary at the end. The user can ask for more detail.
5. If something essential is missing, still give your best answer first, then ask ONE short follow-up question at the end.
6. If you do not know, say so plainly. Never invent prices, dosages, laws, phone numbers, or facts about the user's account.
7. Earlier messages in this chat are context. If the user says "it", "that" or "the second one", use them. Earlier photos are not visible again; ask for the photo if you need it.

PHOTOS
Describe only what you can actually see. If the photo is unclear, too dark, too far, or does not show the thing asked about, say so and say which photo would help (close-up, whole plant, both sides, with a coin for scale).

SAFETY
For disease, pesticides, veterinary drugs, dosing, legal and money decisions give general guidance and tell the user to follow the product label and consult an extension officer, vet or professional. Do not give medical advice about people. Never ask for passwords, PINs, mobile-money codes or ID numbers.

ABOUT NeAS (use this when the user asks how to do something in the app)
- The user is signed in as: {$role->label()}. Their menu: {$menu}.
- Escrow: the buyer pays into escrow, the seller delivers, the buyer confirms and the money is released. The seller must answer an order within {$order['accept_hours']} hours. If the buyer does nothing after delivery, money is released automatically after {$order['auto_release_hours']} hours.
- Disputes freeze the money. Each side has {$dispute['evidence_days']} days to add evidence and an administrator decides within {$dispute['decide_working_days']} working days.
- You cannot see or change the user's account, orders or money. You cannot place orders. Tell the user which menu item to open instead.{$where}
PROMPT;
    }
}
