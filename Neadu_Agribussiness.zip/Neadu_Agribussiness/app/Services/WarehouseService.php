<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\AuditLog;
use App\Models\FeatureFlag;
use App\Models\StorageBooking;
use App\Models\User;
use DomainException;
use Illuminate\Support\Facades\DB;

/** STO-03..05: the warehouse owner's side of a booking: accept or decline, receipt, settlement and expiry alerts. */
final class WarehouseService
{
    public function __construct(
        private readonly LedgerService $ledger, private readonly NotificationService $notes,
        private readonly PayoutService $payouts, private readonly StorageBookingService $bookings,
    ) {}

    public function accept(StorageBooking $booking, User $owner): StorageBooking
    {
        return DB::transaction(function () use ($booking, $owner): StorageBooking {
            $b = $this->lock($booking, $owner);
            $facility = $b->facilityListing;
            $capacity = (float) ($facility->storage?->capacity_kg ?? 0);
            $others = (float) StorageBooking::query()->where('facility_listing_id', $facility->id)->whereKeyNot($b->id)
                ->whereIn('status', ['requested', 'accepted'])->where('starts_on', '<=', $b->ends_on)->where('ends_on', '>=', $b->starts_on)->sum('quantity_kg');
            if ((float) $b->quantity_kg > $capacity - $others) {
                throw new DomainException('You do not have enough free capacity for these dates.');
            }
            $b->forceFill(['status' => 'accepted', 'decided_at' => now()])->save();
            AuditLog::record('storage.accepted', $b, ['status' => 'requested'], ['status' => 'accepted']);
            $this->notes->notify($b->user, 'storage.accepted', ['booking' => $b->uuid, 'message' => "Ombi lako la kuhifadhi katika {$facility->title} limekubaliwa."]);

            return $b;
        });
    }

    public function decline(StorageBooking $booking, User $owner, string $reason): StorageBooking
    {
        return DB::transaction(function () use ($booking, $owner, $reason): StorageBooking {
            $b = $this->lock($booking, $owner);
            if ($b->payment_state === 'held') {
                $this->ledger->post([
                    ['account' => 'escrow', 'debit' => (int) $b->price_minor], ['account' => 'external:payment', 'credit' => (int) $b->price_minor],
                ], null, null, 'Refund declined storage booking '.$b->uuid);
            }
            $b->forceFill([
                'status' => 'declined', 'decided_at' => now(), 'decline_reason' => $reason,
                'payment_state' => $b->payment_state === 'held' ? 'refunded' : $b->payment_state,
            ])->save();
            AuditLog::record('storage.declined', $b, ['status' => 'requested'], ['status' => 'declined']);
            $this->notes->notify($b->user, 'storage.declined', ['booking' => $b->uuid, 'message' => "Ombi lako limekataliwa: {$reason}. Pesa zako zimerudishwa."]);

            return $b;
        });
    }

    /** STO-04 (R2): record what actually arrived and give the producer a digital receipt. */
    public function issueReceipt(StorageBooking $booking, User $owner, string $produce, string $grade): StorageBooking
    {
        $b = StorageBooking::query()->with(['facilityListing', 'user'])->findOrFail($booking->id);
        $this->assertOwner($b, $owner);
        if ($b->status !== 'accepted') {
            throw new DomainException('Only accepted bookings can get a receipt.');
        }
        $b->forceFill([
            'produce_note' => $produce, 'grade' => $grade, 'received_at' => $b->received_at ?? now(),
            'receipt_no' => $b->receipt_no ?? 'SR-'.now()->format('Ymd').'-'.str_pad((string) $b->id, 5, '0', STR_PAD_LEFT),
        ])->save();
        $this->notes->notify($b->user, 'storage.receipt', ['booking' => $b->uuid, 'message' => "Risiti ya ghala {$b->receipt_no} iko tayari."]);

        return $b;
    }

    /** Monthly-invoice bookings are paid outside NeAS; the owner confirms when the money arrived. */
    public function markInvoicePaid(StorageBooking $booking, User $owner): StorageBooking
    {
        $b = StorageBooking::query()->with('facilityListing')->findOrFail($booking->id);
        $this->assertOwner($b, $owner);
        if ($b->payment_method !== 'invoice' || $b->status !== 'accepted' || $b->payment_state !== 'invoiced') {
            throw new DomainException('This booking has no open invoice.');
        }
        $b->forceFill(['payment_state' => 'paid'])->save();

        return $b;
    }

    /** Escrow bookings pay the owner (minus the platform fee) once the storage period has ended. @return int bookings settled */
    public function settleDue(): int
    {
        $n = 0;
        StorageBooking::query()->with(['facilityListing.owner', 'user'])->where('status', 'accepted')->whereNull('settled_at')
            ->where('ends_on', '<', now()->toDateString())->each(function (StorageBooking $b) use (&$n): void {
                DB::transaction(function () use ($b): void {
                    $b = StorageBooking::query()->lockForUpdate()->findOrFail($b->id);
                    if ($b->settled_at !== null) {
                        return;
                    }
                    $owner = $b->facilityListing->user_id;
                    if ($b->payment_state === 'held') {
                        $fee = $this->payouts->feeFor((int) $b->price_minor)['fee'];
                        $this->ledger->post(array_values(array_filter([
                            ['account' => 'escrow', 'debit' => (int) $b->price_minor],
                            ['account' => 'owner:'.$owner, 'credit' => (int) $b->price_minor - $fee],
                            $fee > 0 ? ['account' => 'platform_fee', 'credit' => $fee] : null,
                        ])), null, null, 'Storage payout '.$b->uuid);
                        $b->payment_state = 'released';
                    }
                    $b->forceFill(['status' => 'completed', 'settled_at' => now()])->save();
                    $this->notes->notify($b->facilityListing->owner, 'storage.settled', ['booking' => $b->uuid, 'message' => 'Muda wa kuhifadhi umeisha. Malipo yako yako kwenye pochi.']);
                });
                $n++;
            });

        return $n;
    }

    /** STO-05 (R2): warn producer and owner a few days before storage ends. @return int bookings alerted */
    public function sendExpiryAlerts(): int
    {
        if (! FeatureFlag::isEnabled('storage_alerts')) {
            return 0;
        }
        $days = (int) config('neas.storage.expiry_alert_days', 3);
        $n = 0;
        StorageBooking::query()->with(['facilityListing.owner', 'user'])->where('status', 'accepted')->whereNull('expiry_alert_at')
            ->whereBetween('ends_on', [now()->toDateString(), now()->addDays($days)->toDateString()])->each(function (StorageBooking $b) use (&$n): void {
                $msg = "Hifadhi ya mazao katika {$b->facilityListing->title} inaisha {$b->ends_on}.";
                $this->notes->notify($b->user, 'storage.expiring', ['booking' => $b->uuid, 'message' => $msg]);
                $this->notes->notify($b->facilityListing->owner, 'storage.expiring', ['booking' => $b->uuid, 'message' => $msg]);
                $b->forceFill(['expiry_alert_at' => now()])->save();
                $n++;
            });

        return $n;
    }

    private function lock(StorageBooking $booking, User $owner): StorageBooking
    {
        $b = StorageBooking::query()->with(['facilityListing.storage', 'user'])->lockForUpdate()->findOrFail($booking->id);
        $this->assertOwner($b, $owner);
        if ($b->status !== 'requested') {
            throw new DomainException('This request was already answered.');
        }
        if (! $owner->isIdentityVerified()) {
            throw new DomainException('Verify your identity (NIDA) before answering bookings.');
        }

        return $b;
    }

    private function assertOwner(StorageBooking $b, User $owner): void
    {
        if ($b->facilityListing->user_id !== $owner->id) {
            throw new DomainException('This booking is not for your facility.');
        }
    }
}
