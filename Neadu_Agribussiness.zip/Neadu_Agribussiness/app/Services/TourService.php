<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\PaymentGateway;
use App\Models\Listing;
use App\Models\Tour;
use App\Models\TourBooking;
use App\Models\User;
use DomainException;
use Illuminate\Support\Facades\DB;

/**
 * TUR-01..02 (R2), attendee side: reserve seats (hold timer), pay into escrow, release unpaid seats.
 * The organiser side (complete, certificates, payout, cancel) lives in TrainerController.
 */
final class TourService
{
    /** Default hold; each tour can set its own `hold_minutes`. */
    public const HOLD_MINUTES = 30;

    public function __construct(
        private readonly LedgerService $ledger, private readonly PaymentGateway $gateway, private readonly NotificationService $notes,
    ) {}

    public function freeSeats(Listing $listing): int
    {
        return $listing->tour?->seatsLeft() ?? 0;
    }

    public function book(User $user, Listing $listing, int $seats): TourBooking
    {
        $listing->loadMissing('tour');
        $tour = $listing->tour ?? throw new DomainException('This tour is not open for booking.');

        return DB::transaction(function () use ($user, $listing, $tour, $seats): TourBooking {
            Tour::query()->whereKey($tour->id)->lockForUpdate()->first(); // no overselling
            if ($listing->type->value !== 'tour' || $listing->status !== 'active' || $tour->state !== 'scheduled' || $tour->starts_at->isPast()) {
                throw new DomainException('This tour is not open for booking.');
            }
            if ($listing->user_id === $user->id) {
                throw new DomainException('You cannot book your own tour.');
            }
            if ($seats < 1 || $seats > $tour->seatsLeft()) {
                throw new DomainException('Not enough seats left.');
            }

            return TourBooking::query()->create([
                'tour_id' => $tour->id, 'user_id' => $user->id, 'seats' => $seats, 'total_minor' => (int) $listing->price_minor * $seats,
                'status' => 'reserved', 'expires_at' => now()->addMinutes((int) ($tour->hold_minutes ?: self::HOLD_MINUTES)),
            ]);
        });
    }

    public function pay(TourBooking $b, User $user, string $provider, string $phone): TourBooking
    {
        return DB::transaction(function () use ($b, $user, $provider, $phone): TourBooking {
            $b = TourBooking::query()->lockForUpdate()->findOrFail($b->id);
            if ($b->user_id !== $user->id || $b->status !== 'reserved' || $b->expires_at === null || $b->expires_at->isPast()) {
                throw new DomainException('This booking can no longer be paid. Please book again.');
            }
            $this->gateway->charge($phone, (int) $b->total_minor, $provider, 'tour-'.$b->id);
            $this->ledger->post([['account' => 'external:payment', 'debit' => (int) $b->total_minor], ['account' => 'escrow', 'credit' => (int) $b->total_minor]], null, null, 'Tour seat '.$b->uuid.' paid');
            $b->forceFill(['status' => 'paid', 'paid_at' => now(), 'expires_at' => null])->save();
            $owner = $b->tour->listing->owner;
            if ($owner) {
                $this->notes->notify($owner, 'tour.booked', ['message' => "Mshiriki mpya ({$b->seats} viti) kwenye {$b->tour->listing->title}."]);
            }

            return $b;
        });
    }

    /** TUR-02: seats whose payment timer ran out go back on sale. */
    public function releaseExpired(): int
    {
        return TourBooking::query()->where('status', 'reserved')->where('expires_at', '<=', now())->update(['status' => 'expired']);
    }
}
