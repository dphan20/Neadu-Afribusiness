<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\EscrowState;
use App\Enums\ListingType;
use App\Models\AuditLog;
use App\Models\Crop;
use App\Models\Listing;
use App\Models\ProduceListing;
use App\Models\Region;
use App\Models\User;
use App\Support\Money;
use App\Support\Quantity;
use DomainException;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/** MKT-01/02/10: create, edit, pause, resume and close produce listings. Listings are reviewed before going live (BR-07). */
final class ListingService
{
    /** @param array<string, mixed> $d validated ListingRequest data @param list<UploadedFile> $photos */
    public function create(User $owner, array $d, array $photos, ?UploadedFile $video): Listing
    {
        return DB::transaction(function () use ($owner, $d, $photos, $video): Listing {
            $listing = Listing::query()->create([
                'user_id' => $owner->id, 'type' => ListingType::Produce, 'title' => $this->title($d),
                'region_id' => $d['region_id'], 'district_id' => $d['district_id'], 'lat' => $d['lat'] ?? null, 'lng' => $d['lng'] ?? null,
                'price_minor' => Money::fromMajor((string) $d['price'])->minor, 'currency' => 'TZS',
                'status' => ! empty($d['submit']) ? 'pending_review' : 'draft', 'photos' => [],
            ]);

            $listing->forceFill(['photos' => $this->storePhotos($listing, $photos)])->save();
            ProduceListing::query()->create($this->produceFields($d) + [
                'listing_id' => $listing->id, 'video_path' => $video?->store("listings/{$listing->uuid}", 'public'),
            ]);
            AuditLog::record('listing.created', $listing, [], ['status' => $listing->status]);

            return $listing;
        });
    }

    /** @param array<string, mixed> $d @param list<UploadedFile> $photos */
    public function update(Listing $listing, array $d, array $photos, ?UploadedFile $video): Listing
    {
        if (in_array($listing->status, ['closed'], true)) {
            throw new DomainException('A closed listing cannot be edited.');
        }

        return DB::transaction(function () use ($listing, $d, $photos, $video): Listing {
            $listing->loadMissing('produce');
            $produce = $listing->produce;
            $sold = Quantity::toMilli($produce->quantity_sold);
            if (Quantity::toMilli($d['quantity']) < $sold) {
                throw new DomainException('Quantity cannot be lower than what is already sold ('.Quantity::pretty($produce->quantity_sold).').');
            }

            $remove = array_values(array_intersect($d['remove_photos'] ?? [], $listing->photos ?? []));
            $kept = array_values(array_diff($listing->photos ?? [], $remove));
            $photoPaths = array_merge($kept, $this->storePhotos($listing, $photos));
            if ($photoPaths === []) {
                throw new DomainException('A listing needs at least one photo.');
            }
            Storage::disk('public')->delete($remove);

            // Changing what is being sold, or its pictures, needs a fresh review.
            $material = $produce->crop_id !== (int) $d['crop_id'] || $produce->category->value !== $d['category']
                || $remove !== [] || $photos !== [] || $video !== null;
            $status = $listing->status;
            if ($material && in_array($status, ['active', 'paused', 'sold_out'], true)) {
                $status = 'pending_review';
            }
            if ($status === 'rejected' || $status === 'draft') {
                $status = ! empty($d['submit']) ? 'pending_review' : $status;
            }

            $before = ['price_minor' => $listing->price_minor, 'status' => $listing->status];
            $listing->forceFill([
                'title' => $this->title($d), 'region_id' => $d['region_id'], 'district_id' => $d['district_id'],
                'lat' => $d['lat'] ?? null, 'lng' => $d['lng'] ?? null,
                'price_minor' => Money::fromMajor((string) $d['price'])->minor, 'photos' => $photoPaths, 'status' => $status,
            ])->save();

            $fields = $this->produceFields($d);
            if ($video !== null) {
                if ($produce->video_path) {
                    Storage::disk('public')->delete($produce->video_path);
                }
                $fields['video_path'] = $video->store("listings/{$listing->uuid}", 'public');
            }
            $produce->forceFill($fields)->save();
            $listing->syncAvailability(); // more stock can bring a sold-out listing back
            AuditLog::record('listing.updated', $listing, $before, ['price_minor' => $listing->price_minor, 'status' => $listing->status]);

            return $listing->refresh();
        });
    }

    public function submit(Listing $listing): void
    {
        $this->move($listing, ['draft', 'rejected'], 'pending_review', 'Only drafts or rejected listings can be submitted for review.');
    }

    public function pause(Listing $listing): void
    {
        $this->move($listing, ['active'], 'paused', 'Only an active listing can be paused.');
    }

    public function resume(Listing $listing): void
    {
        $this->move($listing, ['paused'], 'active', 'Only a paused listing can be resumed.');
        $listing->syncAvailability();
    }

    public function close(Listing $listing): void
    {
        $open = $listing->orders()->whereIn('status', array_map(fn (EscrowState $s) => $s->value, [
            EscrowState::Pending, EscrowState::Held, EscrowState::InTransit, EscrowState::Delivered, EscrowState::Disputed,
        ]))->exists();
        if ($open) {
            throw new DomainException('Finish or cancel the open orders on this listing before closing it.');
        }
        $this->move($listing, ['draft', 'pending_review', 'active', 'paused', 'sold_out', 'rejected'], 'closed', 'This listing is already closed.');
    }

    /** @param list<string> $from */
    private function move(Listing $listing, array $from, string $to, string $error): void
    {
        if (! in_array($listing->status, $from, true)) {
            throw new DomainException($error);
        }
        $before = $listing->status;
        $listing->forceFill(['status' => $to])->save();
        AuditLog::record('listing.'.$to, $listing, ['status' => $before], ['status' => $to]);
    }

    /** @param array<string, mixed> $d */
    private function title(array $d): string
    {
        if (! empty($d['title'])) {
            return $d['title'];
        }

        return Crop::query()->findOrFail($d['crop_id'])->name_en.' - '.Region::query()->findOrFail($d['region_id'])->name;
    }

    /** @param array<string, mixed> $d @return array<string, mixed> */
    private function produceFields(array $d): array
    {
        return [
            'category' => $d['category'], 'crop_id' => $d['crop_id'], 'unit_id' => $d['unit_id'], 'quantity' => $d['quantity'],
            'quality' => $d['quality'], 'grade' => $d['grade'] ?? null, 'harvest_date' => $d['harvest_date'] ?? null,
            'quality_notes' => $d['quality_notes'] ?? null, 'packaging' => $d['packaging'] ?? null, 'min_order' => $d['min_order'] ?? null,
        ];
    }

    /** @param list<UploadedFile> $photos @return list<string> */
    private function storePhotos(Listing $listing, array $photos): array
    {
        return array_map(fn (UploadedFile $f): string => $f->store("listings/{$listing->uuid}", 'public'), $photos);
    }
}
