<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\SmsGateway;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * OPEN-Q3: live SMS through Africa's Talking (covers Vodacom, Airtel, Tigo/Yas, Halotel in Tanzania).
 * Select with SMS_DRIVER=africastalking and set AT_USERNAME, AT_API_KEY (and optionally AT_SENDER_ID). WhatsApp is not sent from here.
 * Failures are logged, never thrown: a provider outage must not turn an order or sign-in page into a 500.
 */
final class AfricasTalkingSmsGateway implements SmsGateway
{
    public function send(string $phone, string $message, string $channel = 'sms'): void
    {
        if ($channel !== 'sms') {
            Log::info("[{$channel}] not sent (no provider for this channel) to {$phone}");

            return;
        }
        $cfg = (array) config('services.sms.africastalking');
        if (blank($cfg['username'] ?? null) || blank($cfg['api_key'] ?? null)) {
            Log::error('SMS not sent: AT_USERNAME / AT_API_KEY are not set.');

            return;
        }
        $payload = ['username' => $cfg['username'], 'to' => '+'.ltrim($phone, '+'), 'message' => $message];
        if (filled($cfg['sender_id'] ?? null)) {
            $payload['from'] = $cfg['sender_id'];
        }

        try {
            $response = Http::asForm()->timeout((int) ($cfg['timeout'] ?? 10))->retry(2, 300, throw: false)
                ->withHeaders(['apiKey' => $cfg['api_key'], 'Accept' => 'application/json'])->post($cfg['url'], $payload);
            $status = $response->json('SMSMessageData.Recipients.0.status');
            if (! $response->successful() || ($status !== null && $status !== 'Success')) {
                Log::error('SMS provider rejected the message', ['http' => $response->status(), 'status' => $status, 'phone_tail' => substr($phone, -4)]);
            }
        } catch (Throwable $e) {
            Log::error('SMS provider unreachable: '.$e->getMessage(), ['phone_tail' => substr($phone, -4)]);
        }
    }
}
