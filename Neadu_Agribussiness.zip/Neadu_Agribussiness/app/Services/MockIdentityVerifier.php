<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\IdentityVerifier;

/** OPEN-Q4: local adapter. Accepts any well-formed 20-digit NIDA number; replace with the real NIDA client. */
final class MockIdentityVerifier implements IdentityVerifier
{
    public function verify(string $nidaNumber, string $fullName): bool
    {
        return preg_match('/^\d{20}$/', $nidaNumber) === 1 && trim($fullName) !== '';
    }
}
