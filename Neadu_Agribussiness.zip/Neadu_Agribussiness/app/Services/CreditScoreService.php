<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\EscrowState;
use App\Models\AuditLog;
use App\Models\CreditScoreSnapshot;
use App\Models\Dispute;
use App\Models\Order;
use App\Models\Rating;
use App\Models\User;

/** CRS-01..03 (R3): transparent score from platform behaviour. 300 base, 850 cap. Lenders see it only with consent (BR-10). */
final class CreditScoreService
{
    public const BASE = 300;
    public const MAX = 850;

    /** @return array{score: int, factors: list<array{key: string, label: string, points: int, max: int, detail: string, tip: ?string}>} */
    public function compute(User $user): array
    {
        $released = Order::query()->where('seller_id', $user->id)->where('status', EscrowState::Released->value);
        $completed = (clone $released)->count();
        $volumeTzs = intdiv((int) (clone $released)->sum('subtotal_minor'), 100);
        $ratings = Rating::query()->where('ratee_id', $user->id);
        $ratingCount = (clone $ratings)->count();
        $avg = $ratingCount > 0 ? (float) (clone $ratings)->avg('stars') : null;
        $expired = Order::query()->where('seller_id', $user->id)->where('reject_reason', 'No response within the allowed time.')->count();
        $lost = Dispute::query()->where('decision', 'refund')->whereHas('order', fn ($q) => $q->where('seller_id', $user->id))->count();
        $months = (int) $user->created_at?->diffInMonths(now());

        $factors = [
            $this->factor('identity', 'Identity verified', $user->isIdentityVerified() ? 50 : 0, 50, $user->isIdentityVerified() ? 'NIDA verified' : 'Not verified',
                $user->isIdentityVerified() ? null : 'Verify your NIDA number to add 50 points.'),
            $this->factor('tenure', 'Time on NeAS', min(50, $months * 2), 50, "{$months} months", $months < 25 ? 'Keep your account active; this grows every month.' : null),
            $this->factor('sales', 'Completed sales', min(160, $completed * 8), 160, "{$completed} completed orders", $completed < 20 ? 'Complete more orders to the end; each one adds 8 points.' : null),
            $this->factor('volume', 'Sales volume', min(80, intdiv($volumeTzs, 250_000)), 80, 'TSh '.number_format($volumeTzs).' paid out', $volumeTzs < 20_000_000 ? 'Sell larger volumes through escrow to raise this.' : null),
            $this->factor('ratings', 'Buyer ratings', $avg === null ? 0 : (int) round($avg / 5 * 100), 100, $avg === null ? 'No ratings yet' : round($avg, 1).' / 5 from '.$ratingCount, ($avg ?? 0) < 4.5 ? 'Deliver on time and as described to earn better ratings.' : null),
            $this->factor('reliability', 'Answering orders on time', max(-100, $expired * -20), 0, "{$expired} orders expired", $expired > 0 ? 'Answer every order within 24 hours.' : null),
            $this->factor('disputes', 'Disputes lost', max(-120, $lost * -40), 0, "{$lost} refunded disputes", $lost > 0 ? 'Describe produce honestly and upload clear photos to avoid disputes.' : null),
        ];

        $score = self::BASE + array_sum(array_column($factors, 'points'));

        return ['score' => max(self::BASE, min(self::MAX, $score)), 'factors' => $factors];
    }

    /** Stores one snapshot per user per day (the last computation of the day wins). */
    public function snapshot(User $user): CreditScoreSnapshot
    {
        $r = $this->compute($user);

        return CreditScoreSnapshot::query()->updateOrCreate(
            ['user_id' => $user->id, 'snapshot_on' => now()->toDateString()],
            ['score' => $r['score'], 'factors' => $r['factors'], 'lender_consent' => $user->credit_share_consent],
        );
    }

    /** CRS-03: consent is explicit, revocable and audited. */
    public function setConsent(User $user, bool $consent): void
    {
        $before = ['credit_share_consent' => $user->credit_share_consent];
        $user->forceFill(['credit_share_consent' => $consent])->save();
        CreditScoreSnapshot::query()->where('user_id', $user->id)->update(['lender_consent' => $consent]);
        AuditLog::record($consent ? 'credit.consent_granted' : 'credit.consent_revoked', $user, $before, ['credit_share_consent' => $consent]);
    }

    /** The only door for lenders: null unless the producer has consented. */
    public function forLender(User $user): ?array
    {
        return $user->credit_share_consent ? $this->compute($user) : null;
    }

    /** @return array{key: string, label: string, points: int, max: int, detail: string, tip: ?string} */
    private function factor(string $key, string $label, int $points, int $max, string $detail, ?string $tip): array
    {
        return compact('key', 'label', 'points', 'max', 'detail', 'tip');
    }
}
