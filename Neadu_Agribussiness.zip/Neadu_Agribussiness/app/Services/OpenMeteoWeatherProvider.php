<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\WeatherProvider;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Throwable;

/** Live 7-day forecast from Open-Meteo (no API key). Cached 30 min; falls back to the mock forecast on any failure. */
final class OpenMeteoWeatherProvider implements WeatherProvider
{
    public function __construct(private readonly MockWeatherProvider $fallback) {}

    public function forecast(float $lat, float $lng): array
    {
        return Cache::remember("weather:{$lat}:{$lng}", now()->addMinutes(30), function () use ($lat, $lng): array {
            try {
                $res = Http::timeout(5)->get('https://api.open-meteo.com/v1/forecast', [
                    'latitude' => $lat, 'longitude' => $lng, 'timezone' => 'Africa/Dar_es_Salaam', 'forecast_days' => 7,
                    'daily' => 'temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max',
                ])->throw()->json('daily');

                $days = [];
                foreach ($res['time'] as $i => $date) {
                    $days[] = [
                        'date' => $date, 'tmax' => (float) $res['temperature_2m_max'][$i], 'tmin' => (float) $res['temperature_2m_min'][$i],
                        'rain_mm' => (float) ($res['precipitation_sum'][$i] ?? 0), 'wind_kmh' => (float) ($res['wind_speed_10m_max'][$i] ?? 0),
                    ];
                }

                return $days !== [] ? $days : $this->fallback->forecast($lat, $lng);
            } catch (Throwable) {
                return $this->fallback->forecast($lat, $lng);
            }
        });
    }
}
