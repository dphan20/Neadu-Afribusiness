<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Crop;
use App\Models\Delivery;
use App\Models\Listing;
use App\Models\Order;
use App\Models\PriceRecord;
use App\Models\Region;
use App\Models\User;
use Illuminate\Support\Collection;

/** Read-side lookups shared by the web UI, the Swahili voice assistant, USSD and SMS. */
final class ProducerQueries
{
    /** Phones are stored as typed at registration, so match with and without the leading "+". */
    public function userByPhone(string $phone): ?User
    {
        $digits = ltrim(trim($phone), '+');

        return User::query()->whereIn('phone', [$digits, '+'.$digits])->first();
    }

    public function findCrop(string $text): ?Crop
    {
        $t = mb_strtolower($text);

        return Crop::query()->get()->first(fn (Crop $c): bool => str_contains($t, mb_strtolower($c->name_sw))
            || str_contains($t, mb_strtolower($c->name_en)) || str_contains($t, $c->slug));
    }

    public function findRegion(string $text): ?Region
    {
        $t = mb_strtolower($text);

        return Region::query()->get()->first(fn (Region $r): bool => str_contains($t, mb_strtolower($r->name)));
    }

    public function producerRegion(User $user): ?Region
    {
        $id = $user->producerProfile?->region_id;

        return $id === null ? null : Region::query()->find($id);
    }

    /** @return Collection<int, PriceRecord> */
    public function latestPrices(?Crop $crop, ?Region $region, int $limit = 3): Collection
    {
        return PriceRecord::query()->with(['crop', 'market', 'region', 'unit'])
            ->when($crop, fn ($q) => $q->where('crop_id', $crop->id))
            ->when($region, fn ($q) => $q->where('region_id', $region->id))
            ->orderByDesc('recorded_on')->orderByDesc('id')->limit($limit)->get();
    }

    /** @return Collection<int, Order> oldest first, so "order 1" is the one closest to its deadline */
    public function awaitingOrders(User $user): Collection
    {
        return Order::query()->with(['listing', 'buyer'])->where('seller_id', $user->id)
            ->whereIn('status', ['pending', 'held'])->whereNull('accepted_at')->whereNull('rejected_at')
            ->oldest()->get();
    }

    /** @return Collection<int, Delivery> */
    public function deliveries(User $user, int $limit = 5): Collection
    {
        return Delivery::query()->with('order.listing')->whereHas('order', fn ($q) => $q->where('seller_id', $user->id))
            ->whereNotIn('status', ['cancelled'])->latest()->limit($limit)->get();
    }

    /** @return Collection<int, Listing> */
    public function storageNear(?Region $region, int $limit = 3): Collection
    {
        return Listing::query()->with(['storage', 'owner'])->where('type', 'storage')->where('status', 'active')
            ->when($region, fn ($q) => $q->where('region_id', $region->id))->latest()->limit($limit)->get();
    }

    public static function tsh(int $minor): string
    {
        return 'TSh '.number_format(intdiv($minor, 100));
    }
}
