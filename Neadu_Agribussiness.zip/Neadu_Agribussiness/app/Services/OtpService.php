<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\SmsGateway;
use App\Models\OtpCode;
use App\Models\User;
use DomainException;
use Illuminate\Support\Facades\Hash;

/** ACC-01/02: phone OTP. Codes are hashed, expire in 5 minutes, allow 5 wrong tries and 3 sends per 10 minutes. */
final class OtpService
{
    public function __construct(private readonly SmsGateway $sms) {}

    public function issue(string $phone): void
    {
        $recent = OtpCode::query()->where('phone', $phone)->where('created_at', '>=', now()->subMinutes(10))->count();
        if ($recent >= 3) {
            throw new DomainException('Too many codes requested. Please wait a few minutes.');
        }

        OtpCode::query()->where('phone', $phone)->whereNull('consumed_at')->update(['consumed_at' => now()]);

        $code = str_pad((string) random_int(0, 999_999), 6, '0', STR_PAD_LEFT);
        OtpCode::query()->create(['phone' => $phone, 'code_hash' => Hash::make($code), 'expires_at' => now()->addMinutes(5)]);

        $this->sms->send($phone, "Nambari yako ya uthibitisho ya NeAS ni {$code}. Inaisha baada ya dakika 5.");
    }

    public function verify(User $user, string $code): bool
    {
        $otp = OtpCode::query()->where('phone', $user->phone)->whereNull('consumed_at')
            ->where('expires_at', '>', now())->latest('id')->first();

        if ($otp === null || $otp->attempts >= 5) {
            return false;
        }

        if (! Hash::check($code, $otp->code_hash)) {
            $otp->increment('attempts');

            return false;
        }

        $otp->forceFill(['consumed_at' => now()])->save();
        $user->forceFill(['phone_verified_at' => now()])->save();

        return true;
    }
}
