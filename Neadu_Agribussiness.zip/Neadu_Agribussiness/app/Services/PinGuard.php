<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Hash;

/** PIN check with the same lockout rule as web login (5 wrong tries = 15 minutes). Used where money moves over USSD/SMS. */
final class PinGuard
{
    public function check(User $user, string $pin): bool
    {
        if ($user->status !== 'active' || $user->pin_hash === null || ($user->locked_until !== null && $user->locked_until->isFuture())) {
            return false;
        }

        if (Hash::check($pin, $user->pin_hash)) {
            if ($user->failed_pin_attempts > 0) {
                $user->forceFill(['failed_pin_attempts' => 0, 'locked_until' => null])->save();
            }

            return true;
        }

        $attempts = $user->failed_pin_attempts + 1;
        $lock = $attempts >= 5;
        $user->forceFill(['failed_pin_attempts' => $lock ? 0 : $attempts, 'locked_until' => $lock ? now()->addMinutes(15) : null])->save();

        return false;
    }
}
