<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\EscrowState;
use App\Models\AuditLog;
use App\Models\LedgerEntry;
use App\Models\Order;
use App\Models\ProduceListing;
use App\Models\User;
use App\Support\Quantity;
use DomainException;
use Illuminate\Support\Facades\DB;

/** MKT-04: the producer accepts, rejects or counters an order within 24 hours. */
final class OrderWorkflow
{
    public function __construct(private readonly LedgerService $ledger, private readonly NotificationService $notes) {}

    public function accept(Order $order, User $seller): Order
    {
        $this->guardSeller($order, $seller);
        $this->guardAnswerable($order);

        DB::transaction(function () use ($order): void {
            $order = Order::query()->lockForUpdate()->findOrFail($order->id);
            if (! $order->awaitingAnswer()) {
                throw new DomainException('This order has already been answered.');
            }

            $produce = ProduceListing::query()->where('listing_id', $order->listing_id)->lockForUpdate()->firstOrFail();
            $wanted = Quantity::toMilli($order->quantity);
            $remaining = Quantity::toMilli($produce->remaining());
            if ($wanted > $remaining) {
                throw new DomainException('Not enough stock left on this listing to accept the order.');
            }

            $produce->forceFill(['quantity_sold' => Quantity::fromMilli(Quantity::toMilli($produce->quantity_sold) + $wanted)])->save();
            $produce->listing->syncAvailability();   // MKT-10

            $order->forceFill([
                'accepted_at' => now(),
                'counter_status' => $order->counter_status === 'offered' ? 'declined' : $order->counter_status,
            ])->save();
            AuditLog::record('order.accepted', $order, [], ['accepted_at' => now()->toIso8601String()]);
            $this->notes->notify($order->buyer, 'order.accepted', ['order' => $order->uuid, 'message' => 'Muuzaji amekubali oda yako.']);
        });

        return $order->refresh();
    }

    public function reject(Order $order, User $seller, string $reason): Order
    {
        $this->guardSeller($order, $seller);
        $this->guardAnswerable($order);

        $this->cancel($order, $reason, 'order.rejected', 'Muuzaji amekataa oda yako. Pesa zako zitarudishwa.');

        return $order->refresh();
    }

    /** Counter-offer: only while nothing is paid, so the escrowed amount never changes under the buyer. */
    public function counter(Order $order, User $seller, int $unitPriceMinor): Order
    {
        $this->guardSeller($order, $seller);
        $this->guardAnswerable($order);
        if ($order->status !== EscrowState::Pending) {
            throw new DomainException('A counter-offer is only possible before the buyer has paid.');
        }
        if ($unitPriceMinor <= 0 || $unitPriceMinor === (int) $order->unit_price_minor) {
            throw new DomainException('Enter a price different from the current one.');
        }

        $order->forceFill(['counter_unit_price_minor' => $unitPriceMinor, 'counter_status' => 'offered'])->save();
        AuditLog::record('order.countered', $order, ['unit_price_minor' => $order->unit_price_minor], ['counter_unit_price_minor' => $unitPriceMinor]);
        $this->notes->notify($order->buyer, 'order.countered', [
            'order' => $order->uuid, 'counter_unit_price_minor' => $unitPriceMinor, 'message' => 'Muuzaji amependekeza bei mpya kwa oda yako.',
        ]);

        return $order->refresh();
    }

    /** BR-01: shipping needs a verified identity; the order must be accepted and paid into escrow. */
    public function ship(Order $order, User $seller): Order
    {
        $this->guardSeller($order, $seller);
        if ($order->accepted_at === null || $order->status !== EscrowState::Held) {
            throw new DomainException('Only an accepted, escrow-funded order can be shipped.');
        }
        $order->transitionTo(EscrowState::InTransit);

        return $order->refresh();
    }

    /** 24h window elapsed with no answer: cancel and refund (BR-04). Returns how many orders were cancelled. */
    public function expireUnanswered(): int
    {
        $count = 0;
        Order::query()->whereIn('status', [EscrowState::Pending->value, EscrowState::Held->value])
            ->whereNull('accepted_at')->whereNull('rejected_at')->where('accept_by', '<', now())
            ->each(function (Order $order) use (&$count): void {
                $this->expire($order);
                $count++;
            });

        return $count;
    }

    public function expire(Order $order): void
    {
        $this->cancel($order, 'No response within the allowed time.', 'order.expired', 'Oda yako ilifutwa kwa sababu muuzaji hakujibu kwa wakati.');
    }

    private function cancel(Order $order, string $reason, string $audit, string $message): void
    {
        DB::transaction(function () use ($order, $reason, $audit, $message): void {
            $order = Order::query()->lockForUpdate()->findOrFail($order->id);
            if (! $order->awaitingAnswer()) {
                throw new DomainException('This order has already been answered.');
            }

            $held = $this->escrowBalance($order);
            if ($held > 0) {
                $this->ledger->post([
                    ['account' => 'escrow', 'debit' => $held],
                    ['account' => 'buyer:'.$order->buyer_id, 'credit' => $held],
                ], $order->id, null, 'Refund: '.$audit);
            }

            $order->forceFill(['rejected_at' => now(), 'reject_reason' => mb_substr($reason, 0, 250)])->save();
            $order->transitionTo(EscrowState::Refunded);
            AuditLog::record($audit, $order, [], ['reason' => $reason]);
            $this->notes->notify($order->buyer, $audit, ['order' => $order->uuid, 'message' => $message]);
        });
    }

    private function escrowBalance(Order $order): int
    {
        $row = LedgerEntry::query()->where('order_id', $order->id)->where('account', 'escrow')
            ->selectRaw('COALESCE(SUM(credit_minor),0) as c, COALESCE(SUM(debit_minor),0) as d')->first();

        return (int) $row->c - (int) $row->d;
    }

    private function guardSeller(Order $order, User $seller): void
    {
        if ($order->seller_id !== $seller->id) {
            throw new DomainException('This order does not belong to you.');
        }
        if (! $seller->isIdentityVerified()) {
            throw new DomainException('Verify your identity (NIDA) before accepting or shipping orders.');
        }
    }

    private function guardAnswerable(Order $order): void
    {
        if (! $order->awaitingAnswer()) {
            throw new DomainException('This order has already been answered or is closed.');
        }
        if ($order->accept_by !== null && $order->accept_by->isPast()) {
            $this->expire($order);
            throw new DomainException('The response window has passed. The order was cancelled.');
        }
    }
}
