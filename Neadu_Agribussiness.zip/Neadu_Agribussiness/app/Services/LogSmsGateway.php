<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\SmsGateway;
use Illuminate\Support\Facades\Log;

/** OPEN-Q3: local adapter that writes messages to the log instead of sending them. */
final class LogSmsGateway implements SmsGateway
{
    public function send(string $phone, string $message, string $channel = 'sms'): void
    {
        Log::info("[{$channel}] to {$phone}: {$message}");
    }
}
