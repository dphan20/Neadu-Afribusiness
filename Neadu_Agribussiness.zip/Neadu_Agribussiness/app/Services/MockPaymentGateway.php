<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\PaymentGateway;
use DomainException;

/** OPEN-Q3: local adapter. Succeeds for every amount except phone numbers ending in 0000 (to exercise failure paths). */
final class MockPaymentGateway implements PaymentGateway
{
    public function charge(string $phone, int $amountMinor, string $provider, string $idempotencyKey): string
    {
        if (str_ends_with($phone, '0000') && $phone !== '255700000000') {
            throw new DomainException('The payment was declined by the provider.');
        }

        return 'MOCK-'.strtoupper(substr(hash('sha256', $idempotencyKey), 0, 12));
    }

    public function status(string $idempotencyKey, ?string $providerRef = null): string
    {
        // A mock charge that returned a reference succeeded; one without a reference never reached the provider.
        return $providerRef !== null && str_starts_with($providerRef, 'MOCK-') ? 'successful' : 'failed';
    }
}
