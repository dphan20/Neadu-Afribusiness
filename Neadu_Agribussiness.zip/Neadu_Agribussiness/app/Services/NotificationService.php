<?php

declare(strict_types=1);

namespace App\Services;

use App\Contracts\SmsGateway;
use App\Models\NotificationLog;
use App\Models\User;

/** One place that writes the in-app notification log and, for sms/whatsapp, hands the text to the gateway. */
final class NotificationService
{
    public function __construct(private readonly SmsGateway $sms) {}

    /** @param array<string, mixed> $content must hold a human-readable 'message' */
    public function notify(User $user, string $type, array $content, string $channel = 'in_app'): NotificationLog
    {
        $log = NotificationLog::query()->create([
            'user_id' => $user->id, 'type' => $type, 'channel' => $channel, 'content' => $content, 'sent_at' => now(),
        ]);

        if (in_array($channel, ['sms', 'whatsapp'], true)) {
            $this->sms->send($user->phone, (string) ($content['message'] ?? $type), $channel);
        }

        return $log;
    }
}
