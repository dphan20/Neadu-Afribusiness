<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\Ai\GeminiClient;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;

/** php artisan ai:test  - shows exactly why Ask AI fails (never prints the key). */
class TestAi extends Command
{
    protected $signature = 'ai:test {question?}';

    protected $description = 'Call Gemini with the configured key and print the real status of every model';

    public function handle(GeminiClient $client): int
    {
        $question = (string) ($this->argument('question') ?: 'Why are my maize leaves too dark green?');
        if (! $client->configured()) {
            $this->error('GEMINI_API_KEY is empty in .env (then run: php artisan config:clear).');

            return self::FAILURE;
        }
        $key = (string) config('services.gemini.key');
        $this->line('Key: '.substr($key, 0, 4).'... ('.strlen($key).' chars)   Provider: '.$client->provider());

        foreach ($client->models() as $model) {
            $url = $client->url($model);
            $this->line("\n[{$model}] POST ".$url);
            try {
                $r = Http::withHeaders(['x-goog-api-key' => $key])->timeout(40)->post($url, [
                    'contents' => [['role' => 'user', 'parts' => [['text' => $question]]]],
                    'generationConfig' => ['maxOutputTokens' => 512],
                ]);
            } catch (\Throwable $e) {
                $this->error('  No connection: '.$e->getMessage());
                $this->line('  Check internet, firewall/antivirus, and that PHP can reach Google (curl.cainfo in php.ini).');

                return self::FAILURE;
            }
            if ($r->successful()) {
                $text = collect($r->json('candidates.0.content.parts', []))->pluck('text')->filter()->implode(' ');
                $this->info('  HTTP '.$r->status().' OK. Answer: '.mb_substr($text, 0, 300));

                return self::SUCCESS;
            }
            $this->error('  HTTP '.$r->status().' '.$r->json('error.status').': '.mb_substr((string) $r->json('error.message', $r->body()), 0, 300));
        }
        $this->warn("\nNo model answered. Fix the first error above (key type, model name or network).");

        return self::FAILURE;
    }
}
