<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Enums\EscrowState;
use App\Http\Controllers\BuyerController;
use App\Models\Order;
use App\Services\LedgerService;
use Illuminate\Console\Command;

/** MKT-06: release escrow automatically when the buyer has not confirmed or disputed within the window (default 48h). */
class AutoReleaseOrders extends Command
{
    protected $signature = 'neas:auto-release';

    protected $description = 'Auto-confirm delivered orders whose confirmation window has passed';

    public function handle(LedgerService $ledger): int
    {
        $count = 0;
        Order::query()->where('status', EscrowState::Delivered->value)->whereNotNull('auto_release_at')->where('auto_release_at', '<=', now())
            ->each(function (Order $order) use ($ledger, &$count): void {
                try {
                    app(BuyerController::class)->release($order, $ledger);
                    $count++;
                } catch (\DomainException $e) {
                    $this->warn("Order {$order->uuid} not released: {$e->getMessage()}");
                }
            });
        $this->info("Auto-released {$count} order(s).");

        return self::SUCCESS;
    }
}
