<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\OrderWorkflow;
use Illuminate\Console\Command;

class ExpireUnansweredOrders extends Command
{
    protected $signature = 'orders:expire-unanswered';
    protected $description = 'Cancel and refund orders the producer did not answer within 24 hours';

    public function handle(OrderWorkflow $workflow): int
    {
        $this->info('Expired orders: '.$workflow->expireUnanswered());

        return self::SUCCESS;
    }
}
