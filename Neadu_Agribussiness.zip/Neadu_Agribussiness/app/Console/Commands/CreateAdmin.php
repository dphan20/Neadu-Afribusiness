<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Enums\UserRole;
use App\Models\RoleProfile;
use App\Models\User;
use App\Models\UserRoleAssignment;
use App\Support\AdminScope;
use App\Support\Phone;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

/** Admins are never self-registered: php artisan admin:create "Name" email@x.com --scope=finance */
class CreateAdmin extends Command
{
    protected $signature = 'admin:create {name} {email} {--phone=} {--scope=super : super|support|verification|finance} {--password= : Leave empty to be asked}';

    protected $description = 'Create (or promote) a NeAS console administrator with a scope';

    public function handle(): int
    {
        $scope = (string) $this->option('scope');
        if (! array_key_exists($scope, AdminScope::SCOPES)) {
            $this->error('Scope must be one of: '.implode(', ', array_keys(AdminScope::SCOPES)));

            return self::FAILURE;
        }
        $email = mb_strtolower((string) $this->argument('email'));
        $password = (string) ($this->option('password') ?: $this->secret('Password (min 12 characters)'));
        if (mb_strlen($password) < 12) {
            $this->error('Use at least 12 characters for an admin password.');

            return self::FAILURE;
        }

        $user = DB::transaction(function () use ($email, $password, $scope): User {
            $phone = $this->option('phone') ? Phone::normalize((string) $this->option('phone')) : null;
            $user = User::query()->where('email', $email)->when($phone, fn ($q) => $q->orWhere('phone', $phone))->first()
                ?? User::query()->create(['name' => (string) $this->argument('name'), 'email' => $email, 'phone' => $phone]);
            if ($user->email === null) {
                $user->forceFill(['email' => $email])->save();
            }
            $user->forceFill(['pin_hash' => $password, 'status' => 'active', 'failed_pin_attempts' => 0, 'locked_until' => null])->save();
            UserRoleAssignment::query()->firstOrCreate(['user_id' => $user->id, 'role' => UserRole::Admin->value]);
            $profile = RoleProfile::query()->firstOrNew(['user_id' => $user->id, 'role' => UserRole::Admin->value]);
            $profile->forceFill(['business' => array_merge($profile->business ?? [], ['scope' => $scope])])->save();

            return $user;
        });

        $this->info("Admin {$user->email} ready ({$scope}). Sign in at ".url('/admin/login'));

        return self::SUCCESS;
    }
}
