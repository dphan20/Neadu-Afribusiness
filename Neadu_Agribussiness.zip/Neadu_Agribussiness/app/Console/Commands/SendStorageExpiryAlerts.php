<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\WarehouseService;
use Illuminate\Console\Command;

class SendStorageExpiryAlerts extends Command
{
    protected $signature = 'storage:expiry-alerts';

    protected $description = 'STO-05: warn producers and warehouse owners before a storage booking ends';

    public function handle(WarehouseService $service): int
    {
        $this->info('Alerts sent: '.$service->sendExpiryAlerts());

        return self::SUCCESS;
    }
}
