<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\WarehouseService;
use Illuminate\Console\Command;

class SettleStorageBookings extends Command
{
    protected $signature = 'storage:settle';

    protected $description = 'Pay warehouse owners for storage periods that have ended';

    public function handle(WarehouseService $service): int
    {
        $this->info('Settled bookings: '.$service->settleDue());

        return self::SUCCESS;
    }
}
