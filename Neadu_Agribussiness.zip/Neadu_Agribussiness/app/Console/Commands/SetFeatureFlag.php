<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\FeatureFlag;
use Illuminate\Console\Command;

class SetFeatureFlag extends Command
{
    protected $signature = 'neas:flag {key : e.g. voice, diagnosis, credit_score, ussd} {state : on|off}';
    protected $description = 'Switch an R2/R3 feature flag on or off';

    public function handle(): int
    {
        $flag = FeatureFlag::query()->where('key', $this->argument('key'))->first();
        if ($flag === null) {
            $this->error('Unknown flag.');

            return self::FAILURE;
        }
        $flag->forceFill(['enabled' => $this->argument('state') === 'on'])->save();
        $this->info("{$flag->key}: ".($flag->enabled ? 'on' : 'off'));

        return self::SUCCESS;
    }
}
