<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\PriceAlertEvaluator;
use Illuminate\Console\Command;

class EvaluatePriceAlerts extends Command
{
    protected $signature = 'alerts:evaluate';
    protected $description = 'Send price alerts whose threshold has been crossed';

    public function handle(PriceAlertEvaluator $evaluator): int
    {
        $this->info('Alerts sent: '.$evaluator->run());

        return self::SUCCESS;
    }
}
