<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\LedgerEntry;
use App\Models\Listing;
use App\Models\MachineQuote;
use App\Models\Order;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

/**
 * Removes what the local demo seeders created, so a database can go to production clean.
 * Shows what it would remove unless --force is given. Real accounts and real money records are never touched.
 */
class PurgeDemoData extends Command
{
    protected $signature = 'neas:purge-demo {--force : really delete (otherwise only counts)} {--users : also remove the demo accounts that have no orders, deliveries or ledger entries}';

    protected $description = 'Remove demo machinery, quotes and demo price records created by the demo seeders';

    public function handle(): int
    {
        $demoUsers = User::query()->where('phone', 'like', '25570000000_')->get();
        $demoIds = $demoUsers->pluck('id');
        $listings = Listing::withTrashed()->whereIn('user_id', $demoIds)->where('type', 'machine');
        $quotes = MachineQuote::query()->whereIn('listing_id', (clone $listings)->pluck('id'))->orWhereIn('user_id', $demoIds);
        $prices = DB::table('price_records')->where('source', 'like', 'Demo%');

        $this->line('Demo machine listings : '.(clone $listings)->count());
        $this->line('Demo quote requests   : '.(clone $quotes)->count());
        $this->line('Demo price records    : '.(clone $prices)->count());

        $removable = $demoUsers->filter(fn (User $u): bool => ! Order::query()->where(fn ($q) => $q->where('buyer_id', $u->id)->orWhere('seller_id', $u->id))->exists()
            && ! LedgerEntry::query()->where('account', 'like', '%:'.$u->id)->exists());
        if ($this->option('users')) {
            $this->line('Demo accounts removable: '.$removable->count().' of '.$demoUsers->count());
        }

        if (! $this->option('force')) {
            $this->warn('Nothing deleted. Run again with --force to delete.');

            return self::SUCCESS;
        }

        DB::transaction(function () use ($quotes, $listings, $prices, $removable): void {
            $quotes->delete();
            (clone $listings)->get()->each(fn (Listing $l) => $l->forceDelete());
            $prices->delete();
            if ($this->option('users')) {
                $removable->each(function (User $u): void {
                    $u->tokens()->delete();
                    $u->roleAssignments()->delete();
                    $u->delete();
                });
            }
        });
        $this->info('Demo data removed.');

        return self::SUCCESS;
    }
}
