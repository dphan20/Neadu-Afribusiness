<?php

declare(strict_types=1);

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Throwable;

/** Run on the server before go-live and after every deploy: `php artisan neas:preflight`. Exit code 1 when a blocker is found. */
class Preflight extends Command
{
    protected $signature = 'neas:preflight {--local : Treat warnings for a non-production machine as OK}';

    protected $description = 'Check that the environment is safe to run in production';

    public function handle(): int
    {
        $blockers = 0;
        $rows = [];
        $add = function (string $name, bool $pass, string $detail, bool $blocker = true) use (&$rows, &$blockers): void {
            $rows[] = [$pass ? 'OK' : ($blocker ? 'BLOCKER' : 'warn'), $name, $detail];
            if (! $pass && $blocker) {
                $blockers++;
            }
        };

        $add('APP_ENV=production', app()->environment('production'), (string) config('app.env'));
        $add('APP_DEBUG=false', config('app.debug') === false, config('app.debug') ? 'debug is ON: stack traces leak secrets' : 'off');
        $add('APP_KEY set', filled(config('app.key')), filled(config('app.key')) ? 'set' : 'run php artisan key:generate');
        $add('APP_URL uses https', str_starts_with((string) config('app.url'), 'https://'), (string) config('app.url'));
        $add('Production database', ! in_array(config('database.default'), ['sqlite'], true), (string) config('database.default'));
        $add('Database reachable', $this->try(fn () => DB::select('select 1') !== []), 'connection test');
        $add('Cache store is shared (redis)', in_array(config('cache.default'), ['redis', 'memcached'], true), (string) config('cache.default'), false);
        $add('Cache works', $this->try(function (): bool { Cache::put('neas:preflight', '1', 10); return Cache::get('neas:preflight') === '1'; }), 'write + read');
        $add('Queue is asynchronous', ! in_array(config('queue.default'), ['sync', 'null'], true), (string) config('queue.default'));
        $add('Sessions are not file-based', config('session.driver') !== 'file', (string) config('session.driver'), false);
        $add('Secure session cookie', (bool) config('session.secure') || str_starts_with((string) config('app.url'), 'https://'), 'SESSION_SECURE_COOKIE=true', false);
        $add('Mail is not the log driver', ! in_array(config('mail.default'), ['log', 'array'], true), (string) config('mail.default'));
        $add('SMS provider is live', config('services.sms.driver') !== 'log', (string) config('services.sms.driver'));
        $add('SMS credentials set', config('services.sms.driver') === 'log' || (filled(config('services.sms.africastalking.username')) && filled(config('services.sms.africastalking.api_key'))), 'AT_USERNAME / AT_API_KEY');
        $add('Payment simulation off', config('neas.simulate_gateways') === false, config('neas.simulate_gateways') ? 'NEAS_SIMULATE_GATEWAYS must be false' : 'off');
        $add('Payment gateway is live (not Mock)', ! (app(\App\Contracts\PaymentGateway::class) instanceof \App\Services\MockPaymentGateway), get_class(app(\App\Contracts\PaymentGateway::class)));
        $add('USSD/SMS secret set', filled(config('neas.ussd.secret')), 'NEAS_USSD_SECRET');
        $add('Public storage link', is_link(public_path('storage')) || is_dir(public_path('storage')), 'php artisan storage:link');
        $add('Storage writable', $this->try(function (): bool { Storage::disk('local')->put('.preflight', '1'); Storage::disk('local')->delete('.preflight'); return true; }), 'private disk');
        $add('Frontend build present', is_file(public_path('build/manifest.json')), 'pnpm run build');
        $add('Config cached', app()->configurationIsCached(), 'php artisan config:cache', false);
        $add('No demo accounts', ! \App\Models\User::query()->where('phone', 'like', '2557000000%')->exists(), 'seeded demo users (DemoUsersSeeder) must not exist in production');

        $this->table(['', 'Check', 'Detail'], $rows);
        if ($blockers > 0 && ! $this->option('local')) {
            $this->error("{$blockers} blocker(s). Fix them before going live.");

            return self::FAILURE;
        }
        $this->info($blockers > 0 ? "{$blockers} blocker(s) ignored (--local)." : 'Ready.');

        return self::SUCCESS;
    }

    private function try(callable $fn): bool
    {
        try {
            return (bool) $fn();
        } catch (Throwable) {
            return false;
        }
    }
}
