<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Services\PaymentService;
use Illuminate\Console\Command;

/** Phase 4: payments whose callback never arrived are checked with the provider, then funded or closed. */
class ReconcilePayments extends Command
{
    protected $signature = 'neas:reconcile-payments';

    protected $description = 'Ask the provider about payments still waiting after the callback window';

    public function handle(PaymentService $payments): int
    {
        $r = $payments->reconcilePending();
        $this->info("Checked {$r['checked']}: {$r['held']} funded, {$r['closed']} closed, {$r['still_waiting']} still waiting.");

        return self::SUCCESS;
    }
}
