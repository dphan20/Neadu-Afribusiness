<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\NotificationLog;
use App\Models\PriceAlert;
use App\Models\PriceRecord;
use App\Support\Money;
use Illuminate\Console\Command;

/** PRC-03: notify buyers when the latest market price crosses their threshold (once per price record). */
class CheckPriceAlerts extends Command
{
    protected $signature = 'neas:check-price-alerts';

    protected $description = 'Send price-alert notifications for matching price records';

    public function handle(): int
    {
        $sent = 0;
        PriceAlert::query()->with('crop')->each(function (PriceAlert $alert) use (&$sent): void {
            $record = PriceRecord::query()->where('crop_id', $alert->crop_id)
                ->when($alert->market_id, fn ($q) => $q->where('market_id', $alert->market_id))->latest('recorded_on')->latest('id')->first();
            if ($record === null) {
                return;
            }
            $hit = $alert->condition === 'above' ? $record->price_minor >= $alert->threshold_minor : $record->price_minor <= $alert->threshold_minor;
            if (! $hit) {
                return;
            }
            $already = NotificationLog::query()->where('user_id', $alert->user_id)->where('type', 'price_alert')
                ->where('content->alert', $alert->uuid)->where('content->record', $record->id)->exists();
            if ($already) {
                return;
            }
            foreach ($alert->channels ?? ['in_app'] as $channel) {
                NotificationLog::create([
                    'user_id' => $alert->user_id, 'type' => 'price_alert', 'channel' => $channel, 'sent_at' => now(),
                    'content' => [
                        'alert' => $alert->uuid, 'record' => $record->id,
                        'message' => ($alert->crop?->name_en ?? 'Produce').' is now '.Money::tzs($record->price_minor).' ('.$alert->condition.' your '.Money::tzs($alert->threshold_minor).' target)',
                    ],
                ]);
                $sent++;
            }
        });
        $this->info("Sent {$sent} price alert notification(s).");

        return self::SUCCESS;
    }
}
