<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\TourBooking;
use Illuminate\Console\Command;

/** TUR-02: free the seats of reservations that were not paid before their hold timer ran out. */
class ReleaseUnpaidSeats extends Command
{
    protected $signature = 'neas:release-unpaid-seats';

    protected $description = 'Expire unpaid tour reservations past their hold time';

    public function handle(): int
    {
        $n = TourBooking::query()->where('status', 'reserved')->where('expires_at', '<=', now())->update(['status' => 'expired']);
        $this->info("Released {$n} unpaid reservation(s).");

        return self::SUCCESS;
    }
}
