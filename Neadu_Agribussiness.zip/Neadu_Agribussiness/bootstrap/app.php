<?php

use App\Http\Middleware\EnsureAccountIsActive;
use App\Http\Middleware\EnsureAdminArea;
use App\Http\Middleware\EnsureAdminSession;
use App\Http\Middleware\EnsureFeatureEnabled;
use App\Http\Middleware\EnsureIdentityVerified;
use App\Http\Middleware\RequireRole;
use App\Http\Middleware\SecurityHeaders;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    // TECH-08: private channel auth (/broadcasting/auth) uses the normal signed-in session.
    ->withBroadcasting(__DIR__.'/../routes/channels.php', ['middleware' => ['web', 'auth', 'active']])
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->append(SecurityHeaders::class);
        $middleware->trustProxies(at: env('TRUSTED_PROXIES') ? explode(',', (string) env('TRUSTED_PROXIES')) : null);
        $middleware->alias([
            'active' => EnsureAccountIsActive::class,
            'identity' => EnsureIdentityVerified::class,
            'feature' => EnsureFeatureEnabled::class,
            'role' => RequireRole::class,
            'area' => EnsureAdminArea::class,
            'admin' => EnsureAdminSession::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
